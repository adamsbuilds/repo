import os
import json
from datetime import datetime
import sqlite3
from zipfile import ZipFile
from pathlib import Path
import shutil
import xbmc
import xbmcvfs
import xbmcaddon
from .downloader import Downloader
from .save_data import save_backup_restore
from .maintenance import fresh_start, clean_backups
from .addonvar import dp, dialog, zippath, addon_name, addon_id, home, setting, setting_set, local_string, addons_db
from .colors import colors

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2

addons_path = Path(xbmcvfs.translatePath('special://home/addons'))
user_data = Path(xbmcvfs.translatePath('special://userdata'))

def build_install(name, name2, version, url):
    # Ready to install, Cancel, Continue
    if not dialog.yesno(
        COLOR2(name),
        COLOR2(local_string(30028)),
        nolabel=local_string(30029),
        yeslabel=local_string(30030)
    ):
        return
    
    # Save addon settings before wiping the database
    addon_settings = preserve_addon_settings()
    
    download_build(name, url)
    save_backup_restore('backup')
    fresh_start()
    extract_build()
    if name2 == setting('buildname'):
        save_backup_restore('restore_gui')
    else:
        save_backup_restore('restore')
    clean_backups()
    setting_set('buildname', name2)
    setting_set('buildversion', version)
    setting_set('update_passed', 'false')
    setting_set('firstrun', 'true')
    
    # Restore addon settings
    restore_addon_settings(addon_settings)
    
    enable_wizard()
    
    dialog.ok(addon_name, local_string(30036))  # Install Complete
    os._exit(1)

def download_build(name, url):
    if os.path.exists(zippath):
        os.unlink(zippath)
    d = Downloader(url)
    d.download_build(name, zippath)

def extract_build():
    if os.path.exists(zippath):
        dp.create(addon_name, local_string(30034))  # Extracting files
        counter = 1
        with ZipFile(zippath, 'r') as z:
            files = z.infolist()
            for file in files:
                filename = file.filename
                filename_path = os.path.join(home, filename)
                progress_percentage = int(counter/len(files)*100)
                try:
                    if not os.path.exists(filename_path) or 'Addons33.db' in filename:
                        z.extract(file, home)
                except Exception as e:
                    xbmc.log(f'Error extracting {filename} - {e}', xbmc.LOGINFO)
                dp.update(progress_percentage, f'{local_string(30034)}...\n{progress_percentage}%\n{filename}')
                counter += 1
        dp.update(100, local_string(30035))  # Done Extracting
        xbmc.sleep(500)
        dp.close()
        os.unlink(zippath)

def enable_wizard():
    try:
        timestamp = str(datetime.now())[:-7]

        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('INSERT or IGNORE into installed (addonID , enabled, installDate) VALUES (?,?,?)', (addon_id, 1, timestamp,))

        cursor.execute('UPDATE installed SET enabled = ? WHERE addonID = ? ', (1, addon_id,))
        con.commit()
    except sqlite3.Error as e:
        xbmc.log('There was an error writing to the database - %s' %e, xbmc.LOGINFO)
        return
    finally:
        try:
            if con:
                con.close()
        except UnboundLocalError as e:
            xbmc.log('%s: There was an error connecting to the database - %s' % (xbmcaddon.Addon().getAddonInfo('name'), e), xbmc.LOGINFO)

def preserve_addon_settings():
    """
    Extract addon enabled/disabled state and auto-update settings from current database
    Returns a dictionary with addon settings to be restored after build install
    """
    addon_settings = {}
    try:
        if not os.path.exists(addons_db):
            return addon_settings
            
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        
        # Get addon enabled/disabled states
        cursor.execute('SELECT addonID, enabled FROM installed')
        for row in cursor.fetchall():
            addon_id_val, enabled = row
            addon_settings[addon_id_val] = {'enabled': enabled}
        
        # Get auto-update settings (if available)
        try:
            cursor.execute('SELECT addonID, updateMode FROM update_rules')
            for row in cursor.fetchall():
                addon_id_val, update_mode = row
                if addon_id_val in addon_settings:
                    addon_settings[addon_id_val]['updateMode'] = update_mode
                else:
                    addon_settings[addon_id_val] = {'updateMode': update_mode}
        except sqlite3.OperationalError:
            # update_rules table might not exist, continue without it
            pass
        
        con.close()
        xbmc.log(f'Preserved settings for {len(addon_settings)} addons', xbmc.LOGINFO)
        
    except sqlite3.Error as e:
        xbmc.log(f'Error preserving addon settings: {e}', xbmc.LOGINFO)
    
    return addon_settings

def restore_addon_settings(addon_settings):
    """
    Restore addon enabled/disabled state and auto-update settings to the database
    """
    if not addon_settings:
        return
    
    try:
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        
        for addon_id_val, settings in addon_settings.items():
            if 'enabled' in settings:
                try:
                    cursor.execute(
                        'UPDATE installed SET enabled = ? WHERE addonID = ?',
                        (settings['enabled'], addon_id_val)
                    )
                except sqlite3.OperationalError:
                    # Addon might not exist in new build, skip
                    pass
            
            if 'updateMode' in settings:
                try:
                    cursor.execute(
                        'INSERT OR REPLACE INTO update_rules (addonID, updateMode) VALUES (?, ?)',
                        (addon_id_val, settings['updateMode'])
                    )
                except sqlite3.OperationalError:
                    # update_rules table might not exist, continue
                    pass
        
        con.commit()
        con.close()
        xbmc.log(f'Restored settings for {len(addon_settings)} addons', xbmc.LOGINFO)
        
    except sqlite3.Error as e:
        xbmc.log(f'Error restoring addon settings: {e}', xbmc.LOGINFO)