import sqlite3
import xbmc
from xbmc import log
from .addonvar import addons_db, addon_id

def enable_wizard_addon():
    """
    Enable only the wizard addon on first boot, preserving other addon states
    """
    try:
        timestamp = str(__import__('datetime').datetime.now())[:-7]
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        
        # Only ensure the wizard addon is enabled
        cursor.execute(
            'INSERT OR IGNORE INTO installed (addonID, enabled, installDate) VALUES (?,?,?)',
            (addon_id, 1, timestamp)
        )
        cursor.execute(
            'UPDATE installed SET enabled = ? WHERE addonID = ?',
            (1, addon_id)
        )
        con.commit()
        con.close()
        
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin('UpdateAddonRepos')
        
    except Exception as e:
        log(f'Error enabling wizard addon: {e}', xbmc.LOGERROR)