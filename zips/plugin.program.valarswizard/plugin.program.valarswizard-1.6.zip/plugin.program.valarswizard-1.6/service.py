import xbmc
from resources.lib.modules._service import Startup

if __name__ == '__main__':
    # Initialize Kodi's system monitor
    monitor = xbmc.Monitor()
    
    # Wait until the Kodi Home Window (Window ID 10000) is fully active and loaded
    while not xbmc.getCondVisibility("Window.isVisible(10000)"):
        # Check if Kodi is shutting down; if so, break out immediately to avoid hangs
        if monitor.waitForAbort(1):
            break
            
    # Once the home screen is active, safely launch your wizard startup routines
    if not monitor.abortRequested():
        s = Startup()
        s.run_startup()
