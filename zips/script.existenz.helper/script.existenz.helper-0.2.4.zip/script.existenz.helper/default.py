# -*- coding: utf-8 -*-
"""Pickers for skin.existenz: home rows, sidebar entries. A destination can be a Kodi library list, a folder inside a video add-on, a source or playlist, a Kodi screen,
an add-on to launch, or a path typed in by hand.

Run as:
  RunScript(script.existenz.helper,action=pick_rows)   -> dialog to choose a page, then what each of its home rows shows
  RunScript(script.existenz.helper,action=reset_rows)  -> put the rows of a page back to their default (Skin Settings)
  RunScript(script.existenz.helper,action=addons_page) -> fill a page with the Add-ons rows (Skin Settings)
  RunScript(script.existenz.helper,action=init_defaults) -> first run on a new install (Home.xml): starting sidebar, empty pages, OSD defaults
  RunScript(script.existenz.helper,action=migrate_bridge) -> one-time (Home.xml, until the skin bool BridgeMigrated is set): rows saved through the separate Widget Bridge
                                                           add-on get the add-on's own address back (see Widget Bridge below)
  RunScript(script.existenz.helper,action=pick_sidebar,slot=N) -> choose what entry N (1-8) of the Home sidebar opens (Skin Settings > Sidebar)
  RunScript(script.existenz.helper,action=reset_sidebar)       -> put the sidebar back to its default entries
  RunScript(script.existenz.helper,action=pick_topbar,slot=N)  -> choose what entry N (1-8) of the top bar opens (Skin Settings > Top Bar)
  RunScript(script.existenz.helper,action=reset_topbar)        -> put the top bar back to its default entries
  RunScript(script.existenz.helper,action=seeksteps)   -> for the player OSD skip buttons (run when the OSD opens): read Kodi's skip steps (Settings > Player >
                                                           Videos) and store the first forward / back step in the skin strings SeekFwdIdle / SeekBackIdle, and set the
                                                           window properties sp10, sp30 ... (+10, +30 ...) on the Home window that the skin compares pending
                                                           skips with. Run by the OSD once per Kodi session and again after Kodi's settings are closed
  RunScript(script.existenz.helper,action=search)       -> the Search entry of the sidebar / top bar and the New search button of the results page: asks for the text with Kodi's
                                                           keyboard and shows the results as a transient page of Home (see Search page below)
  RunScript(script.existenz.helper,action=pick_search,slot=N) -> choose what search row N (1-6) searches (Skin Settings > Search): the Kodi library, an installed add-on's
                                                           search or an address with {query} where the text goes
  RunScript(script.existenz.helper,action=reset_search)        -> put the search rows back to their default (library movies and TV shows)
  RunScript(script.existenz.helper,action=toggle_parent) -> flip Kodi's own "Show parent folder items" setting, so the .. item goes from (or comes back to) every list
                                                           (Skin Settings > General)
  RunScript(script.existenz.helper,action=power_items)   -> choose which items the power menu shows (Skin Settings > General): a tick list; the skin bools PowerMenu.Hide.<key> are
                                                           set for the unticked items (Exit Kodi is not in the list: it always shows)

  RunScript(script.existenz.helper,action=pick_accent)   -> choose the skin's accent color (Skin Settings > Artwork): a list of color chips (the skin's DialogSelect draws the ListItem
                                                           property swatch as a chip) or a hex code; stored in the skin strings AccentColor (AARRGGBB) and AccentColorName, which
                                                           $VAR[ColorAccent] / $VAR[AccentColorLabel] in Includes_Colors.xml read. Picking the default red clears both. The "Reset accent
                                                           color" button in Skin Settings clears them without this script

Pages: the Home screen can have up to 8 pages, one per sidebar entry whose type is "Page" (sidebar entry N shows page N; the "Home" entry always shows page 1). Each page has
its own 8 rows. Every page is stored in skin strings P<page>Row<slot>.Path / .Label / .Style (empty path = no row; "none" = hidden).
The skin only ever reads the "live" rows HomeRow<slot>.Path / .Label / .Style, which are Home window properties (memory only; see $VAR[HomeRow<N>Path] in
Includes.xml); the sidebar's page switch (PageSwitch in Includes.xml) copies the chosen page into them and loads the rows, Home.xml does the same for the start page
when Kodi starts, and the pickers keep the live rows in step when you edit the page that is showing. The page on screen is the Home window property rl.page (empty = 1);
the skin string CurrentPage only remembers it for the next Kodi start when "Remember last sidebar selection" is on. They are not skin strings because every
Skin.SetString / Skin.Reset makes Kodi save its whole settings file to disk at once. The first time anything here runs, the rows you had before pages existed (the old
HomeRow<slot>.* skin strings) are copied into page 1 (skin setting PagesInit).
Search rows are stored in skin strings Search<N>.Label / .Path / .Style, the path being a template with {query} where the typed text goes ("none" = an emptied row).
Search page: a search shows its results as a transient page of Home, not a window of its own. The search action puts the (up to six) rows, with the typed text filled in, into the live
rows HomeRow1-6 (rows 7-8 empty) - Home's own rows, hero, focus handling, bridge wrapping and sidebar are used as they are - without writing them to any stored page or touching the
skin string CurrentPage. The Home window properties rl.search / rl.search.term (the text) make Home.xml show the "Results for" header with the New search button in place of the top
bar, and rl.page is set to 0 so that no sidebar entry is marked as the page on screen; a click on any sidebar page (PageSwitch in Includes.xml) is then an ordinary page switch, which also
clears the search properties. Nothing is stored: after a Kodi restart or Reload Skin Home shows its normal start page.
Every picker ends with a Name step (rows, sidebar entries, top bar entries); a row or entry can also be renamed on its own.

Widget Bridge: the helper has its own (bridge.py, the plugin entry point plugin://script.existenz.helper/?bridge=1&&<add-on address>), which runs the add-on's code in a
fresh Python instance (no reuselanguageinvoker) while the items in the row still open and play through the add-on itself. The skin puts its address in front of
every add-on row on Home at render time (Skin Settings > Advanced > Widget Behavior = Safe, the default; $VAR[BridgePrefix] in Includes.xml), so rows are saved with
the add-on's own address. The separate Widget Bridge add-on (plugin.video.widgetbridge) is no longer needed, but the pickers still understand it: browsing an add-on
through it (Video add-ons > Widget Bridge > the add-on > its folders) gives addresses plugin://plugin.video.widgetbridge/?_b=1&_w=<the add-on's address>. A home
row saved from there drops the _b=1 and keeps running through that add-on (_for_row). A sidebar or top bar entry opens a folder rather than loading a row, so it
gets the add-on's own address back and keeps the add-on's reuse (_for_entry). Rows that were saved that way before are put back to the add-on's own address once
(migrate_bridge), after which the separate add-on can be uninstalled.
"""
import json
import re
import sys
from urllib.parse import parse_qsl, quote
import xbmc
import xbmcgui

SLOTS = 8
PAGES = 8
HOME_WINDOW = 10000
# built-in default rows (slot -> label): none - every page, the first included, starts empty and is filled with the picker
DEFAULT_ROWS = {}
PARTS = ('Path', 'Label', 'Style')



def _get(name):
    return xbmc.getInfoLabel('Skin.String(%s)' % name)


def _sk(builtin):
    """Run a skin builtin and wait for it, so a value read straight afterwards is the new one."""
    xbmc.executebuiltin(builtin, True)


_FORMAT_TAGS = re.compile(r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)(?:\s[^\]]*)?\]', re.I)
_LINE_BREAK = re.compile(r'\[CR\]', re.I)


def _plain(text):
    """Text of a label without Kodi's formatting codes ([COLOR red], [B], [I], [UPPERCASE], [LOWERCASE], [CAPITALIZE], [LIGHT], [CR]). Add-ons colour and embolden
    the names in their lists; in the pickers every entry should look the same, and a name saved from one must not carry the codes into the rows and sidebar."""
    text = _LINE_BREAK.sub(' ', text or '')
    return ' '.join(_FORMAT_TAGS.sub('', text).split())


def _ask_name(heading, default):
    """The Name step that ends every picker. Cancelling or clearing the box keeps the suggested name; a comma cannot be used (it would split the skin builtin)."""
    dialog = xbmcgui.Dialog()
    default = _plain(default)
    while True:
        name = dialog.input(heading, defaultt=default)
        if not name:
            return default
        if ',' in name:
            dialog.notification(heading, 'A comma cannot be used in a name', xbmcgui.NOTIFICATION_WARNING, 3500)
            continue
        return name.strip() or default


BRIDGE_URL = 'plugin://plugin.video.widgetbridge/'
BRIDGE_BROWSE = BRIDGE_URL + '?_b=1&'


def _for_row(path):
    """A folder browsed through Widget Bridge, made into a row: the bridge's widget address (its browse flag dropped, so the row's items point at the add-on
    itself and not back through the bridge)."""
    if path.startswith(BRIDGE_BROWSE):
        return BRIDGE_URL + '?' + path[len(BRIDGE_BROWSE):]
    return path


def _for_entry(path):
    """A folder browsed through Widget Bridge, made into a sidebar / top bar entry: the add-on's own address, so opening it browses the add-on directly."""
    if path.startswith(BRIDGE_URL + '?'):
        return dict(parse_qsl(path.split('?', 1)[1])).get('_w') or path
    return path


def migrate_bridge():
    """One time (Home.xml runs this while the skin bool BridgeMigrated is not set): home rows saved through the separate Widget Bridge add-on (stored path
    plugin://plugin.video.widgetbridge/?_w=<encoded address>) get the add-on's own address back, on every page, since the skin now routes add-on rows through
    the helper's own bridge (bridge.py). The rows on screen are updated too. A row whose address holds a comma is left as it is (a skin string cannot carry one
    through a builtin) and keeps working through the old add-on."""
    if xbmc.getCondVisibility('Skin.HasSetting(BridgeMigrated)'):
        return
    for page in range(1, PAGES + 1):
        for slot in range(1, SLOTS + 1):
            name = '%s.Path' % _store_name(page, slot)
            target = _bridge_target(_get(name))
            if target and ',' not in target:
                _sk('Skin.SetString(%s,%s)' % (name, target))
    win = xbmcgui.Window(HOME_WINDOW)
    for slot in range(1, SLOTS + 1):
        target = _bridge_target(win.getProperty('HomeRow%d.Path' % slot))
        if target and ',' not in target:
            _live(_current_page(), slot, target, win.getProperty('HomeRow%d.Label' % slot), win.getProperty('HomeRow%d.Style' % slot))
    _sk('Skin.SetBool(BridgeMigrated)')


def _bridge_target(path):
    """The add-on's own address inside an address of the separate Widget Bridge add-on (browse or widget form); '' for anything else."""
    if not path.startswith(BRIDGE_URL + '?'):
        return ''
    target = dict(parse_qsl(path.split('?', 1)[1])).get('_w') or ''
    return target if target.startswith('plugin://') else ''


def _current_page():
    """The page on screen: Window(Home).Property(rl.page), set by Home.xml at Kodi start and by the sidebar's page switch. 0 while the search page shows (search), which no
    stored page matches, so editing page 1 from Skin Settings does not replace the results."""
    if xbmcgui.Window(HOME_WINDOW).getProperty('rl.search'):
        return 0
    try:
        page = int(xbmcgui.Window(HOME_WINDOW).getProperty('rl.page') or 1)
    except ValueError:
        page = 1
    return page if 1 <= page <= PAGES else 1


def _store_name(page, slot):
    return 'P%dRow%d' % (page, slot)


def _ensure_init():
    """First run after pages were added: the rows chosen before (the old live skin strings HomeRow<slot>.*) become page 1."""
    if xbmc.getCondVisibility('Skin.HasSetting(PagesInit)'):
        return
    for slot in range(1, SLOTS + 1):
        for part in PARTS:
            value = _get('HomeRow%d.%s' % (slot, part))
            if value:
                _sk('Skin.SetString(%s.%s,%s)' % (_store_name(1, slot), part, value))
    if not _get('CurrentPage'):
        _sk('Skin.SetString(CurrentPage,1)')
    _sk('Skin.SetBool(PagesInit)')


def init_defaults():
    """First run on a new install (Home.xml runs this while the skin string RLDefaultsApplied is not set): the starting sidebar, an empty Home page, no top bar and
    the OSD defaults. Nothing is overwritten if the sidebar, rows or top bar were already set up (an install that already has its own choices only gets the flag).
    Sidebar: 1 Home (a page, left empty so the page shows its Choose rows button), 6 Favorites, 7 Add-Ons (a page filled with the Add-ons rows), 8 Settings."""
    if xbmc.getCondVisibility('Skin.HasSetting(RLDefaultsApplied)'):
        return
    configured = any(_get('Sidebar%d.Key' % i) or _get('TopBar%d.Key' % i) or _get('HomeRow%d.Path' % i) or _get('P1Row%d.Path' % i)
                     for i in range(1, SLOTS + 1))
    if not configured:
        entries = {1: ('page', 'Home'), 2: ('none', ''), 3: ('none', ''), 4: ('none', ''), 5: ('none', ''),
                   6: ('favourites', 'Favorites'), 7: ('page', 'Add-Ons'), 8: ('settings', 'Settings')}
        for slot, (key, label) in entries.items():
            _sk('Skin.SetString(Sidebar%d.Key,%s)' % (slot, key))
            _set_string('Sidebar%d.Label' % slot, label)
            _sk('Skin.Reset(Sidebar%d.Path)' % slot)
        for slot in range(1, SLOTS + 1):
            _sk('Skin.SetString(TopBar%d.Key,none)' % slot)
            _sk('Skin.Reset(TopBar%d.Label)' % slot)
            _sk('Skin.Reset(TopBar%d.Path)' % slot)
        _sk('Skin.Reset(TopBarText)')
        _sk('Skin.SetString(CurrentPage,1)')
        _sk('Skin.SetBool(PagesInit)')
        win = xbmcgui.Window(HOME_WINDOW)
        win.setProperty('rl.page', '1')
        for slot in range(1, SLOTS + 1):
            for page in range(1, 9):
                _sk('Skin.Reset(%s.Path)' % _store_name(page, slot))
            win.setProperty('HomeRow%d.Path' % slot, 'none')
            win.clearProperty('HomeRow%d.Label' % slot)
            win.clearProperty('HomeRow%d.Style' % slot)
        _fill_addons_rows(7, [i for i, row in enumerate(ADDON_PAGE_ROWS) if _addon_type_installed(row)])
        _sk('Skin.SetBool(OSDAudioOpensMenu)')
        _sk('Skin.SetBool(OSDSubtitlesOpensMenu)')
        _sk('Skin.SetString(OSDAutoCloseSeconds,3)')
        _sk('Skin.Reset(BackgroundPlayback)')
    _sk('Skin.SetBool(RLDefaultsApplied)')


def _set_string(name, value):
    if value:
        _sk('Skin.SetString(%s,%s)' % (name, value))
    else:
        _sk('Skin.Reset(%s)' % name)


def _live(page, slot, path, label, style):
    """Copy one row of a page into the live rows the skin reads (Home window properties, so nothing is written to disk). An empty slot means no row. Sets Window(Home).Property(rl.switching) for a second (the same as
    the sidebar's page switch, PageSwitch in Includes.xml) so the changed row is not taken for an empty one before Kodi has started loading it (rlidle<N> in Timers.xml)."""
    win = xbmcgui.Window(HOME_WINDOW)
    win.setProperty('rl.switching', '1')
    xbmc.executebuiltin('AlarmClock(rlswitch,"ClearProperty(rl.switching,home)",00:00:01,silent)')
    win.setProperty('HomeRow%d.Path' % slot, path or 'none')
    win.setProperty('HomeRow%d.Label' % slot, label or '')
    win.setProperty('HomeRow%d.Style' % slot, style or '')


def _store(page, slot, path, label, style):
    """Save one row of a page ('' = default / empty, 'none' = hidden); if that page is the one showing, the live rows follow."""
    _set_string('%s.Path' % _store_name(page, slot), path)
    _set_string('%s.Label' % _store_name(page, slot), label)
    _set_string('%s.Style' % _store_name(page, slot), style)
    if page == _current_page():
        _live(page, slot, path, label, style)


def _read_store(page, slot):
    return [_get('%s.%s' % (_store_name(page, slot), part)) for part in PARTS]


def _slot_label(page, slot):
    path, label, _style = _read_store(page, slot)
    if path == 'none':
        return '(Empty)'
    if path:
        return label or path
    default = DEFAULT_ROWS.get(slot) if page == 1 else None
    return '%s (default)' % default if default else '(Empty)'


def _page_label(page):
    """The page's name is the name of its sidebar entry; page 1 is called Home until an entry says otherwise."""
    label = _get('Sidebar%d.Label' % page)
    if label and _get('Sidebar%d.Key' % page) in ('page', 'home', ''):
        return label
    return 'Home' if page == 1 else 'Page %d' % page


def _pages():
    """Pages that exist: page 1 always, then every sidebar entry set to type Page."""
    return [p for p in range(1, PAGES + 1) if p == 1 or _get('Sidebar%d.Key' % p) == 'page']


def _choose_page(heading):
    pages = _pages()
    if len(pages) == 1:
        return pages[0]
    current = _current_page()
    names = ['%s%s' % (_page_label(p), '   (showing now)' if p == current else '') for p in pages]
    pick = xbmcgui.Dialog().select(heading, names, preselect=pages.index(current) if current in pages else 0)
    return pages[pick] if pick >= 0 else None


def pick_rows():
    _ensure_init()
    dialog = xbmcgui.Dialog()
    page = _choose_page('Which page do you want to edit?')
    if page is None:
        return
    title = 'Home screen rows - %s' % _page_label(page)
    while True:
        slots = ['Row %d:  %s' % (i, _slot_label(page, i)) for i in range(1, SLOTS + 1)]
        slots.append('Clear all rows on this page')
        slot_idx = dialog.select(title, slots)
        if slot_idx < 0:
            return
        if slot_idx == SLOTS:
            for i in range(1, SLOTS + 1):
                _store(page, i, '', '', '')
            continue
        slot = slot_idx + 1
        path, label, style = _read_store(page, slot)
        shown = bool(path and path != 'none') or (page == 1 and path != 'none' and slot in DEFAULT_ROWS)
        choices = ['Choose what this row shows...', '(Empty - hide this row)', 'Clear this row']
        if shown:
            choices.append('Rename this row...')
        what = dialog.select('Row %d' % slot, choices)
        if what < 0:
            continue
        if what == 1:
            _store(page, slot, 'none', '', '')
        elif what == 2:
            _store(page, slot, '', '', '')
        elif what == 3:
            current_name = label or DEFAULT_ROWS.get(slot, '')
            _store(page, slot, path, _ask_name('Row name', current_name), style)
        else:
            picked = pick_destination(rows_only=True)
            if picked:
                picked['path'] = _for_row(picked['path'])
                if ',' in picked['path']:
                    dialog.notification('Home rows', 'A comma in the address cannot be used', xbmcgui.NOTIFICATION_WARNING, 4000)
                    continue
                # a row of episodes is drawn as landscape cards (the episode's own picture), genres as square cards, everything else as posters (square also suits
                # add-ons, channels, people ...); guess from the address, let the user decide
                where = (picked['path'] + ' ' + picked['label']).lower()
                if 'episode' in where:
                    guess = 1
                elif 'genre' in where:
                    guess = 2
                else:
                    guess = 0
                styles = [('poster', 'Posters (movies, TV shows)'), ('landscape', 'Episode cards (landscape pictures)'), ('square', 'Square pictures (add-ons, genres, channels...)')]
                style_pick = dialog.select('Show this row as', [label for _, label in styles], preselect=guess)
                if style_pick < 0:
                    continue
                # the Name step comes last
                name = _ask_name('Row name', picked['label'])
                _store(page, slot, picked['path'], name, styles[style_pick][0])


def reset_rows():
    _ensure_init()
    page = _choose_page('Which page do you want to reset?')
    if page is None:
        return
    for i in range(1, SLOTS + 1):
        _store(page, i, '', '', '')
    xbmcgui.Dialog().notification('Skin', '%s: rows %s' % (_page_label(page), 'cleared'), time=2500)


def _skip_label(seconds):
    """Short unsigned label that fits in the OSD skip arrow: 10, 30, 1m, 10m, 30m, 1h."""
    n = abs(int(seconds))
    if n < 60:
        return str(n)
    if n % 3600 == 0:
        return '%dh' % (n // 3600)
    if n % 60 == 0:
        return '%dm' % (n // 60)
    return str(n)


# The pending-skip sizes the skin compares Player.SeekStepSize with (see the SkipFwdLabel variable in Includes.xml). A skin condition cannot contain a + (it is the AND
# operator), so the forward sizes (+10, +30 ...) are handed to the skin as window properties sp10, sp30 ... on the Home window, where they stay for the whole session.
SKIP_SIZES = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 150, 180, 210, 240, 270, 300, 360, 420, 480, 540, 600, 720, 900, 1080, 1200, 1260, 1440, 1500, 1620, 1800, 2100, 2400, 2700, 3000, 3600, 4200, 4800, 5400, 6000, 7200, 9000, 10800, 12600, 14400, 16200, 18000]


def _set_skip_size_properties():
    home = xbmcgui.Window(HOME_WINDOW)
    for n in SKIP_SIZES:
        home.setProperty('sp%d' % n, '+%d' % n)


SIDEBAR_SLOTS = 8
# what a sidebar entry can open besides a eXistenZ list: key -> label (the skin turns the key into the action, see Home.xml control 9500)
SIDEBAR_BUILTINS = [
    ('home', 'Home (page 1)'),
    ('page', 'Page - its own set of home rows (page number = entry number)'),
    ('addons', 'Add-ons'),
    ('favourites', 'Favourites'),
    ('search', 'Search'),
    ('files', 'File manager'),
    ('settings', 'Kodi settings'),
    ('skinsettings', 'Skin settings'),
    ('power', 'Power menu'),
]


def _rpc(method, params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    return reply.get('result') or {}


# fixed starting points: (label, path)
VIDEO_LIBRARY = [
    ('Movies', 'videodb://movies/titles/'),
    ('Movie genres', 'videodb://movies/genres/'),
    ('Movie sets', 'videodb://movies/sets/'),
    ('Recently added movies', 'videodb://recentlyaddedmovies/'),
    ('TV shows', 'videodb://tvshows/titles/'),
    ('TV show genres', 'videodb://tvshows/genres/'),
    ('Recently added episodes', 'videodb://recentlyaddedepisodes/'),
    ('Music videos', 'videodb://musicvideos/titles/'),
]
EXTRAS = [
    ('Video playlists', 'special://videoplaylists/'),
    ('Favourites', 'favourites://'),
]


def _browse_directory(label, path, kind='row'):
    """Walk into folders (add-on menus, library nodes, sources, playlists) one level at a time.
    Returns {'kind', 'label', 'path'} for the folder the user chose, or None."""
    trail = []
    while True:
        result = _rpc('Files.GetDirectory', {'directory': path, 'media': 'files', 'properties': ['title']})
        folders = [f for f in result.get('files', []) if f.get('filetype') == 'directory' and f.get('file')]
        names = ['[Use this folder: %s]' % label] + (['[Back]'] if trail else []) + [_plain(f.get('label') or f.get('title') or f['file']) for f in folders]
        first = 2 if trail else 1
        choice = xbmcgui.Dialog().select(label, names)
        if choice < 0:
            return None
        if choice == 0:
            return {'kind': kind, 'label': label, 'path': path}
        if trail and choice == 1:
            label, path = trail.pop()
            continue
        folder = folders[choice - first]
        trail.append((label, path))
        label, path = _plain(folder.get('label') or folder.get('title') or label), folder['file']


def _pick_addon(addon_type, title, kind):
    addons = _rpc('Addons.GetAddons', {'type': addon_type, 'enabled': True, 'properties': ['name']}).get('addons', [])
    addons.sort(key=lambda a: a.get('name', '').lower())
    pick = xbmcgui.Dialog().select(title, [_plain(a.get('name')) or a['addonid'] for a in addons])
    if pick < 0:
        return None
    name = _plain(addons[pick].get('name')) or addons[pick]['addonid']
    path = 'plugin://%s/' % addons[pick]['addonid']
    if kind == 'programs':
        # a program add-on is launched, not browsed
        return {'kind': 'programs', 'label': name, 'path': path}
    return _browse_directory(name, path, kind)


def _manual_entry():
    dialog = xbmcgui.Dialog()
    path = dialog.input('Path or address (for example plugin://plugin.video.example/?mode=list or videodb://movies/titles/)')
    if not path:
        return None
    kind = 'music' if path.startswith(('musicdb://', 'special://musicplaylists')) else 'pictures' if path.startswith('special://pictures') else 'row'
    default = path.rstrip('/').split('/')[-1].split('?')[0] or path
    return {'kind': kind, 'label': default, 'path': path}


def pick_destination(rows_only=False):
    """The picker used for home rows and sidebar entries: browse like a file browser, or type a path.
    A row can only show video lists, so rows_only leaves out what is launched or opens music / pictures."""
    # add-ons first, the library and the rest below them
    entries = [('Video add-ons', lambda: _pick_addon('xbmc.addon.video', 'Video add-ons', 'row'))]
    if not rows_only:
        entries += [
            ('Program add-ons (launch)', lambda: _pick_addon('xbmc.addon.executable', 'Program add-ons', 'programs')),
            ('Music add-ons', lambda: _pick_addon('xbmc.addon.audio', 'Music add-ons', 'music')),
        ]
    entries += [
        ('Video sources (folders you added)', _pick_video_source),
        ('Playlists and favourites', lambda: _pick_from('Playlists and favourites', EXTRAS)),
        ('Video library', lambda: _pick_from('Video library', VIDEO_LIBRARY)),
        ('Type a path or address...', _manual_entry),
    ]
    pick = xbmcgui.Dialog().select('Choose', [name for name, _ in entries])
    if pick < 0:
        return None
    return entries[pick][1]()


def _pick_from(title, places):
    pick = xbmcgui.Dialog().select(title, [lab for lab, _ in places])
    if pick < 0:
        return None
    return _browse_directory(places[pick][0], places[pick][1])


def _pick_video_source():
    sources = _rpc('Files.GetSources', {'media': 'video'}).get('sources', [])
    pick = xbmcgui.Dialog().select('Video sources', [_plain(s.get('label')) or s['file'] for s in sources])
    if pick < 0:
        return None
    return _browse_directory(_plain(sources[pick].get('label')) or sources[pick]['file'], sources[pick]['file'])


TOPBAR_BUILTINS = [
    ('addons', 'Add-ons'),
    ('favourites', 'Favourites'),
    ('search', 'Search'),
    ('files', 'File manager'),
    ('settings', 'Kodi settings'),
    ('skinsettings', 'Skin settings'),
    ('power', 'Power menu'),
]


def pick_entry(prefix, slot, builtins, title):
    """Choose what an entry of the sidebar (prefix 'Sidebar') or the top bar (prefix 'TopBar') opens: empty, a Kodi screen, a page (sidebar only) or any destination.
    The Name step comes last, and the entry can also just be renamed."""
    dialog = xbmcgui.Dialog()
    key_now = _get('%s%d.Key' % (prefix, slot))
    label_now = _get('%s%d.Label' % (prefix, slot))
    # the browser comes first (add-ons, library, folders, a typed path), then Empty and the fixed Kodi screens
    names = ['Browse add-ons, library and folders, or type a path...', '(Empty - hide this entry)'] + [lab for _, lab in builtins]
    can_rename = bool(label_now) or key_now not in ('', 'none')
    if can_rename:
        names.append('Rename this entry...')
    choice = dialog.select('%s entry %d' % (title, slot), names)
    if choice < 0:
        return
    if choice == 1:
        xbmc.executebuiltin('Skin.SetString(%s%d.Key,none)' % (prefix, slot))
        xbmc.executebuiltin('Skin.Reset(%s%d.Label)' % (prefix, slot))
        xbmc.executebuiltin('Skin.Reset(%s%d.Path)' % (prefix, slot))
        return
    if can_rename and choice == len(names) - 1:
        xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, _ask_name('Name', label_now or key_now)))
        return
    if choice >= 2:
        key, label = builtins[choice - 2]
        default = label.split(' (')[0].split(' - ')[0]
        if key == 'page':
            default = label_now if key_now == 'page' and label_now else 'Page %d' % slot
        name = _ask_name('Name', default)
        xbmc.executebuiltin('Skin.SetString(%s%d.Key,%s)' % (prefix, slot, key))
        xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, name))
        xbmc.executebuiltin('Skin.Reset(%s%d.Path)' % (prefix, slot))
        if key == 'page':
            _ensure_init()
            dialog.notification(title, '%s is page %d. Fill it with Skin Settings > General > Choose home screen rows' % (name, slot), time=5000)
        return
    picked = pick_destination()
    if not picked:
        return
    picked['path'] = _for_entry(picked['path'])
    if ',' in picked['path']:
        dialog.notification(title, 'A comma in the address cannot be used', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    name = _ask_name('Name', picked['label'])
    xbmc.executebuiltin('Skin.SetString(%s%d.Key,%s)' % (prefix, slot, picked['kind']))
    xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, name))
    xbmc.executebuiltin('Skin.SetString(%s%d.Path,%s)' % (prefix, slot, picked['path']))


def pick_sidebar(slot):
    pick_entry('Sidebar', slot, SIDEBAR_BUILTINS, 'Sidebar')


def pick_topbar(slot):
    pick_entry('TopBar', slot, TOPBAR_BUILTINS, 'Top bar')


def reset_topbar():
    for slot in range(1, SIDEBAR_SLOTS + 1):
        for part in ('Key', 'Label', 'Path'):
            xbmc.executebuiltin('Skin.Reset(TopBar%d.%s)' % (slot, part))


def reset_sidebar():
    for slot in range(1, SIDEBAR_SLOTS + 1):
        for part in ('Key', 'Label', 'Path'):
            xbmc.executebuiltin('Skin.Reset(Sidebar%d.%s)' % (slot, part))


def sync_seek_steps():
    """Store the first forward / back skip step of Kodi's own list (videoplayer.seeksteps) for the OSD skip buttons.

    Kodi builds its forward steps in list order and its backward steps in reverse list order (see CSeekHandler::Configure), so the first forward step is the
    first positive value in the setting and the first backward step is the last negative one. Nothing is stored if the setting cannot be read, and the
    skin then shows 10.
    """
    _set_skip_size_properties()
    # read for this session: VideoOSD.xml only runs this while Window(Home).Property(rl.seekread) is empty (SettingsCategory.xml clears it when settings close)
    xbmcgui.Window(HOME_WINDOW).setProperty('rl.seekread', '1')
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
        'params': {'setting': 'videoplayer.seeksteps'}})))
    steps = (reply.get('result') or {}).get('value') or []
    forward = [s for s in steps if s > 0]
    backward = [s for s in steps if s < 0]
    # Written only when the value changed: every Skin.SetString makes Kodi save its whole settings file to disk there and then, and this runs as the OSD opens
    # (once per Kodi session), right next to the video. The skin strings keep the labels between sessions, so the OSD has them before this has run.
    if forward:
        label = _skip_label(forward[0])
        if _get('SeekFwdIdle') != label:
            xbmc.executebuiltin('Skin.SetString(SeekFwdIdle,%s)' % label)
    if backward:
        label = _skip_label(backward[-1])
        if _get('SeekBackIdle') != label:
            xbmc.executebuiltin('Skin.SetString(SeekBackIdle,%s)' % label)


def toggle_parent():
    """Flip Kodi's own setting filelists.showparentdiritems (Settings > Media > General > Show parent folder items), which decides whether lists have a ".." item.
    The skin has no builtin for Kodi settings, so this reads it over JSON-RPC and writes the opposite. Run once per click in Skin Settings; nothing stays running.
    """
    current = _rpc('Settings.GetSettingValue', {'setting': 'filelists.showparentdiritems'}).get('value')
    if current is None:
        return
    _rpc('Settings.SetSettingValue', {'setting': 'filelists.showparentdiritems', 'value': not current})


# Power menu items (Custom1110_PowerMenu.xml and DialogButtonMenu.xml): key = the skin bool PowerMenu.Hide.<key> that hides the item. Exit Kodi is not here on purpose.
POWER_ITEMS = (
    ('reload', 'Reload Skin'),
    ('rows', 'Choose Home Rows'),
    ('addons', 'Add-ons'),
    ('files', 'File Manager'),
    ('skinsettings', 'Skin Settings'),
    ('settings', 'Kodi Settings'),
    ('debug', 'Debug logging'),
)


def power_items():
    """Tick the power menu items to show. Only items whose state changed are written (every skin bool write makes Kodi save its settings file); Cancel changes nothing."""
    shown = [i for i, (key, _) in enumerate(POWER_ITEMS)
             if not xbmc.getCondVisibility('Skin.HasSetting(PowerMenu.Hide.%s)' % key)]
    chosen = xbmcgui.Dialog().multiselect('Power menu items', [name for _, name in POWER_ITEMS], preselect=shown)
    if chosen is None:
        return
    for i, (key, _) in enumerate(POWER_ITEMS):
        if (i in chosen) == (i in shown):
            continue
        _sk('Skin.Reset(PowerMenu.Hide.%s)' % key if i in chosen else 'Skin.SetBool(PowerMenu.Hide.%s)' % key)


# Accent color (Skin Settings > Artwork). The default is the skin's red (FFE50914, the fallback of $VAR[ColorAccent] in Includes_Colors.xml).
ACCENT_DEFAULT = 'FFE50914'
ACCENT_PALETTE = (
    # blues
    ('Blue', 'FF66A7D7'), ('Ice blue', 'FFA8D8F0'), ('Sky blue', 'FF4FC3F7'), ('Azure', 'FF2196F3'), ('Royal blue', 'FF448AFF'), ('Midnight', 'FF2866A4'), ('Indigo', 'FF7986CB'),
    # cyans and teals
    ('Cyan', 'FF26C6DA'), ('Aqua', 'FF00E5FF'), ('Teal', 'FF009688'), ('Turquoise', 'FF1DE9B6'),
    # greens
    ('Mint', 'FF80E0B0'), ('Emerald', 'FF2ECC71'), ('Green', 'FF66BB6A'), ('Jade', 'FF00C853'), ('Chartreuse', 'FF4FAF00'), ('Lime', 'FFC0CA33'), ('Olive', 'FFB5B84A'),
    # yellows and oranges
    ('Yellow', 'FFFFEB3B'), ('Gold', 'FFFFCA28'), ('Amber', 'FFE99931'), ('Orange', 'FFFF9800'), ('Tangerine', 'FFFF6D00'), ('Coral', 'FFFF7043'), ('Salmon', 'FFFF8A80'),
    # reds and pinks
    ('Scarlet', 'FFFF5252'), ('Crimson', 'FFE5395A'), ('Rose', 'FFF06292'), ('Pink', 'FFEC407A'), ('Hot pink', 'FFFF4081'),
    # purples
    ('Magenta', 'FFE040FB'), ('Violet', 'FFC050FF'), ('Grape', 'FFAB47BC'), ('Orchid', 'FFDA70D6'), ('Lavender', 'FFB39DDB'),
    # deeper tones
    ('Dark red', 'FFB71C1C'), ('Burgundy', 'FF9B1B30'), ('Brick', 'FFC0392B'), ('Burnt orange', 'FFCC5500'), ('Rust', 'FFB7410E'), ('Dark gold', 'FFB8860B'),
    ('Forest', 'FF2E7D32'), ('Dark teal', 'FF00796B'), ('Dark blue', 'FF1976D2'), ('Navy', 'FF3949AB'), ('Deep purple', 'FF7E57C2'), ('Plum', 'FF8E4585'), ('Slate', 'FF607D8B'),
    # neutrals
    ('Sand', 'FFD7B98E'), ('Silver', 'FFBDBDBD'), ('White', 'FFFFFFFF'),
)


def _swatch_item(name, hexcolor):
    """One row of the color list: the name, and the property swatch that DialogSelect.xml draws as a color chip (the name is plain text, so it stays readable on the focus fill)."""
    item = xbmcgui.ListItem(name)
    item.setProperty('swatch', hexcolor)
    return item


def pick_accent():
    """Choose the accent color: a list of color chips, or "Custom hex color..." (six digits). Stored only as the skin strings AccentColor (AARRGGBB) and AccentColorName,
    which the skin reads live ($VAR[ColorAccent]), so nothing is written to the skin folder, a skin update cannot reset it and no skin reload is needed. Picking the default
    red clears both strings. Cancelling changes nothing."""
    dialog = xbmcgui.Dialog()
    colors = [('Red (default)', ACCENT_DEFAULT)] + list(ACCENT_PALETTE)
    current = _get('AccentColor').upper() or ACCENT_DEFAULT
    preselect = next((i for i, (_, hexcolor) in enumerate(colors) if hexcolor == current), -1)
    items = [_swatch_item(name, hexcolor) for name, hexcolor in colors] + [xbmcgui.ListItem('Custom hex color...')]
    choice = dialog.select('Accent color', items, preselect=preselect)
    if choice < 0:
        return
    if choice < len(colors):
        name, hexcolor = colors[choice]
    else:
        raw = dialog.input('Hex color, e.g. FF8800', defaultt='').strip().lstrip('#')
        if not re.match(r'^[0-9A-Fa-f]{6}$', raw):
            if raw:
                dialog.notification('Accent color', 'Enter 6 hex digits, e.g. FF8800', xbmcgui.NOTIFICATION_WARNING, 3500)
            return
        hexcolor = 'FF' + raw.upper()
        name = '#' + raw.upper()
    if hexcolor == ACCENT_DEFAULT:
        _sk('Skin.Reset(AccentColor)')
        _sk('Skin.Reset(AccentColorName)')
        return
    _sk('Skin.SetString(AccentColor,%s)' % hexcolor)
    _sk('Skin.SetString(AccentColorName,"%s")' % name)


# Add-ons page: a page of home rows (see pick_rows) whose rows are lists of add-ons. A row's style says how it is drawn and which window opens what is
# in it (Includes.xml: the "addon" layouts and the HomeRow<N>Target variables). "addon-cat" is the Categories row (addons:// is Kodi's own list of My add-ons,
# Recently updated, Install from repository, Install from zip file, Search ...; pressing OK on one opens it in the add-on browser).
ADDON_PAGE_ROWS = (
    ('Categories', 'addons://', 'addon-cat', None),
    ('Video add-ons', 'addons://user/xbmc.addon.video', 'addon-video', 'xbmc.addon.video'),
    ('Music add-ons', 'addons://user/xbmc.addon.audio', 'addon-music', 'xbmc.addon.audio'),
    ('Program add-ons', 'addons://user/xbmc.addon.executable', 'addon-program', 'xbmc.addon.executable'),
    ('Picture add-ons', 'addons://user/xbmc.addon.image', 'addon-picture', 'xbmc.addon.image'),
    ('Game add-ons', 'addons://user/xbmc.addon.game', 'addon-game', 'xbmc.addon.game'),
)


def addons_page():
    """Fill a page with the Add-ons rows. Pick the page, then which rows it should have (types you have no add-ons of are left unticked at first); the rest
    of the page is emptied. Rows can be renamed, moved or removed afterwards with the normal row picker."""
    _ensure_init()
    dialog = xbmcgui.Dialog()
    page = _choose_page('Which page should show your add-ons?')
    if page is None:
        return
    names = [row[0] for row in ADDON_PAGE_ROWS]
    installed = [i for i, row in enumerate(ADDON_PAGE_ROWS) if _addon_type_installed(row)]
    chosen = dialog.multiselect('Add-ons rows - %s' % _page_label(page), names, preselect=installed)
    if chosen is None:
        return
    _fill_addons_rows(page, chosen)
    dialog.notification('Add-ons page', '%s now shows %d row(s)' % (_page_label(page), min(len(chosen), SLOTS)), time=3500)


def _addon_type_installed(row):
    return row[3] is None or bool(_rpc('Addons.GetAddons', {'type': row[3], 'enabled': True}).get('addons'))


def _fill_addons_rows(page, chosen):
    """Put the chosen Add-ons rows (indexes into ADDON_PAGE_ROWS) on a page, in order, and empty the rest of it."""
    slot = 1
    for i in chosen[:SLOTS]:
        name, path, style, _t = ADDON_PAGE_ROWS[i]
        _store(page, slot, path, name, style)
        slot += 1
    while slot <= SLOTS:
        _store(page, slot, 'none', '', '')
        slot += 1


SEARCH_SLOTS = 6
# the Kodi library searches: videodb title-contains filter. The text sits inside JSON that is itself inside the address, so _fill_query escapes it for JSON first and
# then percent-encodes it
LIBRARY_MOVIES = ('videodb://movies/titles/?xsp=%7B%22order%22%3A%7B%22direction%22%3A%22ascending%22%2C%22ignorefolders%22%3A0%2C%22method%22%3A%22sorttitle%22%7D%2C'
                  '%22rules%22%3A%7B%22and%22%3A%5B%7B%22field%22%3A%22title%22%2C%22operator%22%3A%22contains%22%2C%22value%22%3A%5B%22{query}%22%5D%7D%5D%7D%2C%22type%22%3A%22movies%22%7D')
LIBRARY_TVSHOWS = LIBRARY_MOVIES.replace('videodb://movies/titles/', 'videodb://tvshows/titles/').replace('%22movies%22%7D', '%22tvshows%22%7D')
SEARCH_DEFAULTS = {1: ('Movies', LIBRARY_MOVIES, 'poster'), 2: ('TV shows', LIBRARY_TVSHOWS, 'poster')}
# search addresses of the video add-ons (add-on id, add-on name, [(what it searches, address, style)]); {query} is where the text goes
SEARCH_PRESETS = [
    ('plugin.video.fen', 'Fen', [
        ('Movies', 'plugin://plugin.video.fen/?mode=build_movie_list&action=tmdb_movies_search&query={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.fen/?mode=build_tvshow_list&action=tmdb_tv_search&query={query}', 'poster'),
        ('Collections', 'plugin://plugin.video.fen/?mode=build_movie_list&action=tmdb_movies_search_sets&query={query}', 'poster'),
        ('People', 'plugin://plugin.video.fen/?mode=person_direct.search&query={query}', 'square'),
        ('Trakt lists', 'plugin://plugin.video.fen/?mode=trakt.list.search_trakt_lists&query={query}', 'square'),
    ]),
    ('plugin.video.redlight', 'Red Light', [
        ('Movies', 'plugin://plugin.video.redlight/?mode=build_movie_list&action=tmdb_movies_search&query={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.redlight/?mode=build_tvshow_list&action=tmdb_tv_search&is_anime_list=false&query={query}', 'poster'),
        ('Anime', 'plugin://plugin.video.redlight/?mode=build_tvshow_list&action=tmdb_anime_search&is_anime_list=true&query={query}', 'poster'),
        ('Collections', 'plugin://plugin.video.redlight/?mode=navigator.collection_results&query={query}', 'poster'),
        ('People', 'plugin://plugin.video.redlight/?mode=person_direct.search&key_id={query}', 'square'),
        ('Trakt lists', 'plugin://plugin.video.redlight/?mode=trakt.list.search_trakt_lists&query={query}', 'square'),
    ]),
    ('plugin.video.gears', 'Gears', [
        ('Movies', 'plugin://plugin.video.gears/?mode=build_movie_list&action=tmdb_movies_search&query={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.gears/?mode=build_tvshow_list&action=tmdb_tv_search&query={query}', 'poster'),
        ('Anime', 'plugin://plugin.video.gears/?mode=build_tvshow_list&action=tmdb_tv_search&is_anime_list=true&query={query}', 'poster'),
        ('People', 'plugin://plugin.video.gears/?mode=person_direct.search&key_id={query}', 'square'),
        ('Trakt lists', 'plugin://plugin.video.gears/?mode=trakt.list.search_trakt_lists&query={query}', 'square'),
    ]),
    ('plugin.video.umbrella', 'Umbrella', [
        ('Movies', 'plugin://plugin.video.umbrella/?action=movieSearchterm&name={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.umbrella/?action=tvSearchterm&name={query}', 'poster'),
        ('Movies with this actor', 'plugin://plugin.video.umbrella/?action=actorSearchMovies&name={query}', 'poster'),
        ('TV shows with this actor', 'plugin://plugin.video.umbrella/?action=actorSearchTV&name={query}', 'poster'),
        ('Trakt lists (movies)', 'plugin://plugin.video.umbrella/?action=trakt_search_lists&media_type=movies&name={query}', 'square'),
        ('Trakt lists (TV shows)', 'plugin://plugin.video.umbrella/?action=trakt_search_lists&media_type=tvshows&name={query}', 'square'),
    ]),
    ('plugin.video.pov', 'POV', [
        ('Movies', 'plugin://plugin.video.pov/?mode=build_movie_list&action=tmdb_movies_search&query={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.pov/?mode=build_tvshow_list&action=tmdb_tv_search&query={query}', 'poster'),
        ('Collections', 'plugin://plugin.video.pov/?mode=build_movie_list&action=tmdb_movies_search_collections&query={query}', 'poster'),
        ('People', 'plugin://plugin.video.pov/?mode=get_search_term&search_type=people&query={query}', 'square'),
        ('Trakt lists', 'plugin://plugin.video.pov/?mode=build_trakt_list.search_trakt_lists&search_title={query}', 'square'),
    ]),
    ('plugin.video.seren', 'Seren', [
        ('Movies', 'plugin://plugin.video.seren/?action=moviesSearchResults&actionArgs={query}', 'poster'),
        ('TV shows', 'plugin://plugin.video.seren/?action=showsSearchResults&actionArgs={query}', 'poster'),
    ]),
]


def _fill_query(template, text):
    """The final address of a search row: the typed text, encoded, in place of {query}. A library (videodb) address carries the text inside JSON, so quotes and
    backslashes are escaped for JSON before the percent-encoding."""
    if template.startswith('videodb://'):
        text = json.dumps(text, ensure_ascii=False)[1:-1]
    return template.replace('{query}', quote(text, safe=''))


def _store_search(slot, path, label, style):
    """Save one search row ('none' = emptied); the skin only reads these when a search runs."""
    _set_string('Search%d.Path' % slot, path)
    _set_string('Search%d.Label' % slot, label)
    _set_string('Search%d.Style' % slot, style)


def _read_search(slot):
    return [_get('Search%d.%s' % (slot, part)) for part in PARTS]


def _ensure_search_defaults():
    """While no search row has ever been set, write the default rows (library movies and TV shows) so the pickers and the settings list show what a search uses."""
    if any(_get('Search%d.Path' % slot) for slot in range(1, SEARCH_SLOTS + 1)):
        return
    for slot in range(1, SEARCH_SLOTS + 1):
        label, path, style = SEARCH_DEFAULTS.get(slot, ('', '', ''))
        _store_search(slot, path, label, style)


def reset_search():
    for slot in range(1, SEARCH_SLOTS + 1):
        label, path, style = SEARCH_DEFAULTS.get(slot, ('', '', ''))
        _store_search(slot, path, label, style)
    xbmcgui.Dialog().notification('Search', 'Search rows put back to default', time=2500)


def search():
    """Ask for the text and show the results as a transient page of Home. The up-to-six search rows, with the text filled in, become the live rows 1-6 (7 and 8 empty), exactly as
    a sidebar page switch would put a page's rows there (PageSwitch in Includes.xml: focused-row memory cleared, rows marked stale until their new items are in), but nothing is
    stored: not in a page's skin strings, not in CurrentPage. rl.search / rl.search.term (Home window properties) switch on the "Results for" header of Home.xml, rl.page is
    set to 0 so that no sidebar entry counts as the current page, and rl.searchfocus asks the skin timer rlrescue (Timers.xml) to move focus to the first row that has items,
    also when focus is on the New search button. Run again from the results page it simply replaces the rows."""
    _ensure_search_defaults()
    rows = [_read_search(slot) for slot in range(1, SEARCH_SLOTS + 1)]
    if not any(path and path != 'none' for path, _label, _style in rows):
        xbmcgui.Dialog().notification('Search', 'No search rows are set. Choose them in Skin Settings > Search', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    text = xbmcgui.Dialog().input('Search').strip()
    if not text:
        return
    win = xbmcgui.Window(HOME_WINDOW)
    on_home = xbmcgui.getCurrentWindowId() == HOME_WINDOW
    win.setProperty('rl.switching', '1')
    xbmc.executebuiltin('AlarmClock(rlswitch,"ClearProperty(rl.switching,home)",00:00:01,silent)')
    for name in ('rl.lastrow', 'rl.herorow', 'rl.heroitem'):
        win.clearProperty(name)
    # like a page switch: a row keeps its old items until the new ones arrive, so mark it stale (noting its first item) and it stays hidden until its content is new
    for slot in range(1, SLOTS + 1):
        if on_home:
            win.setProperty('rl.staleid%d' % slot, xbmc.getInfoLabel('Container(%d).ListItemAbsolute(0).FileNameAndPath' % (5000 + slot)))
        win.setProperty('rl.stale%d' % slot, '1')
    win.setProperty('rl.page', '0')
    win.setProperty('rl.search', text)
    win.setProperty('rl.search.term', text)
    win.setProperty('rl.searchfocus', '1')
    for slot in range(1, SLOTS + 1):
        path, label, style = rows[slot - 1] if slot <= SEARCH_SLOTS else ('', '', '')
        if path and path != 'none':
            win.setProperty('HomeRow%d.Path' % slot, _fill_query(path, text))
            win.setProperty('HomeRow%d.Label' % slot, label)
            win.setProperty('HomeRow%d.Style' % slot, style or 'poster')
        else:
            win.setProperty('HomeRow%d.Path' % slot, 'none')
            win.clearProperty('HomeRow%d.Label' % slot)
            win.clearProperty('HomeRow%d.Style' % slot)
    if not on_home:
        xbmc.executebuiltin('ActivateWindow(home)')
    xbmc.executebuiltin('SetFocus(5001)')


def pick_search(slot):
    """Choose what search row `slot` searches: nothing, the Kodi library, an installed add-on's search, or an address typed in. Name (and look) come last, like the row picker."""
    _ensure_search_defaults()
    dialog = xbmcgui.Dialog()
    options = [('(Empty - remove this row)', None), ('Kodi library: Movies', ('Movies', LIBRARY_MOVIES, 'poster')), ('Kodi library: TV shows', ('TV shows', LIBRARY_TVSHOWS, 'poster'))]
    for addon_id, addon_name, searches in SEARCH_PRESETS:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
            options += [('%s: %s' % (addon_name, what), ('%s: %s' % (addon_name, what), path, style)) for what, path, style in searches]
    options.append(('Type an address...', 'manual'))
    pick = dialog.select('Search row %d' % slot, [name for name, _ in options])
    if pick < 0:
        return
    picked = options[pick][1]
    if picked is None:
        _store_search(slot, 'none', '', '')
        return
    if picked == 'manual':
        path = dialog.input('Address to search, with {query} where the text goes (for example plugin://plugin.video.example/?mode=search&query={query})').strip()
        if not path:
            return
        if '{query}' not in path:
            path += '{query}'
        picked = ('Search', path, 'poster')
    label, path, style = picked
    if ',' in path:
        dialog.notification('Search', 'A comma in the address cannot be used', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    styles = [('poster', 'Posters (movies, TV shows)'), ('landscape', 'Episode cards (landscape pictures)'), ('square', 'Square pictures (add-ons, genres, channels...)')]
    style_pick = dialog.select('Show this row as', [name for _, name in styles], preselect=[key for key, _ in styles].index(style))
    if style_pick < 0:
        return
    # the Name step comes last
    _store_search(slot, path, _ask_name('Row name', label), styles[style_pick][0])


if __name__ == '__main__':
    args = dict(a.split('=', 1) for a in sys.argv[1:] if '=' in a)
    action = args.get('action', 'pick_rows')
    if action == 'reset_rows':
        reset_rows()
    elif action == 'init_defaults':
        init_defaults()
    elif action == 'migrate_bridge':
        migrate_bridge()
    elif action == 'addons_page':
        addons_page()
    elif action == 'seeksteps':
        sync_seek_steps()
    elif action == 'pick_sidebar':
        pick_sidebar(int(args.get('slot', '1')))
    elif action == 'reset_sidebar':
        reset_sidebar()
    elif action == 'pick_topbar':
        pick_topbar(int(args.get('slot', '1')))
    elif action == 'reset_topbar':
        reset_topbar()
    elif action == 'search':
        search()
    elif action == 'pick_search':
        pick_search(int(args.get('slot', '1')))
    elif action == 'reset_search':
        reset_search()
    elif action == 'toggle_parent':
        toggle_parent()
    elif action == 'power_items':
        power_items()
    elif action == 'pick_accent':
        pick_accent()
    elif action == 'pick_rows':
        pick_rows()
    else:
        # set_page / settle / focus_row were removed (Home does this in the skin now: PageSwitch in Includes.xml, Timers.xml); an older skin build that still
        # calls them must not open the row picker by surprise
        xbmc.log('[existenz] unknown helper action: %s' % action, xbmc.LOGINFO)