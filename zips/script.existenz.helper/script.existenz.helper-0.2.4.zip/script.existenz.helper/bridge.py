# -*- coding: utf-8 -*-
"""Widget Bridge for the eXistenZ skin: runs an add-on's plugin code in a fresh Python instance, for the rows on Home.

Why. Kodi keeps ONE reusable Python instance for the whole system (CScriptInvocationManager::GetLanguageInvoker, Kodi 21). An add-on with
<reuselanguageinvoker>true</reuselanguageinvoker> has every call either grab that instance and reset it, or throw it away and start a new one. When Home loads
several rows of that add-on at once, those grabs and resets land in the same instant, and Kodi can crash. Whether to reuse is decided per add-on from its
addon.xml only (CScriptRunner::ExecuteScript), never per call, so Kodi cannot leave rows out by itself. This plugin entry point of the skin helper has reuse off
(addon.xml): each row loaded through it starts a fresh instance of the helper, which then runs the target add-on's own code inside it. The target keeps its reuse
for browsing it directly; its rows never touch the reused instance.

The skin does this itself (Skin Settings > Advanced > Widget Behavior = Safe, the default): $VAR[BridgePrefix] (Includes.xml) is put in front of the path of every
add-on row on Home. Nothing here needs to be set up by hand.

Address (WIDGET mode, the only one): the fixed prefix, then the target add-on's address raw, not percent-encoded:
  plugin://script.existenz.helper/?bridge=1&&<target url>   e.g.  plugin://script.existenz.helper/?bridge=1&&plugin://plugin.video.example/?mode=list&page=1
The target is everything after the first "&&" of sys.argv[2], so it needs no encoding and may carry any "&" or "=" of its own. The percent-encoded form of the
standalone Widget Bridge add-on, ?_w=<encoded target url>, is accepted too.
The target url is run and its items are left alone, so opening a folder or playing an item from the row goes to the add-on itself (with its reuse).

Optional pages=K (1 to 6, default 1) among the bridge's own parameters, before the "&&":
  plugin://script.existenz.helper/?bridge=1&pages=3&&<target url>
A title that a later page repeats from an earlier one is left out of the row (see run_target).
Only used while the skin bool RowAutoPage is on (read at the start of every call); with it off pages is ignored, nothing is held back or tagged, items go to Kodi as the target adds them and its own endOfDirectory goes straight through, as before. The skin asks for it when Skin Settings > "Load the next page into rows" is on (RowAutoPage; HomeRow<N>Path in Includes.xml, rlmore in Timers.xml). With K > 1 the
target runs for its page, the page's "next page" item is taken out and remembered, and the target runs again for that item's address - in this same Python
instance, so only its entry script runs again - until K pages are collected or a page has no next-page item. Kodi then gets all the items in order, followed by
the last page's next-page item (so the card is still at the very end and works as before), and the directory is ended once; the target's own endOfDirectory
calls are swallowed. A page that fails or comes back empty (page 2 on) ends the collecting with what there is. The next-page item is the last item a page added,
if it is a folder with a plugin:// address of the same add-on and its label matches next / more / page <number> (any case) or it has the property
SpecialSort = bottom; otherwise the list has no next page. Whenever the list ends with a next-page item (K < 6), the last five items and the next-page item
get the ListItem property rl.more = K+1: the skin reads it as "focus is near the end, ask for this many pages". With RowAutoPage on, all items are held until the target has
finished, then handed to Kodi in one call (also with K = 1).

Running the target as Kodi would:
  - sys.argv = [plugin://<id>/<path>, handle, ?<query>, resume:false] (CScriptRunner::ExecuteScript)
  - sys.path gets the folder of the target's entry script and the lib folders of the modules it imports (addon.xml <requires>, followed down), as Kodi
    sets them for an add-on; the helper's own folder comes off so nothing in it can shadow a module of the target
  - xbmcaddon.Addon() with no id answers for the target, not for the helper (settings, profile folder, path, strings); xbmcplugin.getSetting / setSetting too
  - its entry script (addon.xml pluginsource library) runs as __main__ (_run_as_main)
The target cannot open Kodi's busy spinner (ActivateWindow(busydialog / busydialognocancel)): a row loads in the background, and a modal spinner over Home
takes every key press until the target closes it again - forever, if the target hangs or forgets.
Limits: an add-on that subclasses xbmcaddon.Addon gets a function there instead of the class.
"""
import os
import sys
import traceback
import types
import xml.etree.ElementTree as ET
import re
from urllib.parse import parse_qsl, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

SELF_ID = 'script.existenz.helper'
OLD_BRIDGE_ID = 'plugin.video.widgetbridge'
HANDLE = int(sys.argv[1])
ADDON_ROOTS = ('special://home/addons/', 'special://xbmc/addons/')
MAX_PAGES = 6
TAIL_ITEMS = 5  # how many items before the next-page item get rl.more
NEXT_LABEL = re.compile(r'next|more|page\s*\d+', re.IGNORECASE)
BUSY_WINDOWS = ('busydialog', 'busydialognocancel', '10138', '10160')  # Kodi's two busy spinners, by name and by window id


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[eXistenZ Widget Bridge] %s' % message, level)


def get_target(paramstring):
    """'?bridge=1&&plugin://x/?a=1&b=2' -> 'plugin://x/?a=1&b=2'; '?_w=<encoded url>' -> the decoded url. An address of the standalone Widget Bridge add-on
    (a row that was saved through it) is unwrapped to the add-on it points at."""
    if '&&' in paramstring:
        target = paramstring.partition('&&')[2]
    else:
        target = dict(parse_qsl(paramstring.lstrip('?'))).get('_w', '')
    parts = urlsplit(target)
    if parts.scheme == 'plugin' and parts.netloc.lower() == OLD_BRIDGE_ID:
        target = dict(parse_qsl(parts.query)).get('_w', '')
    return target


def pages_enabled():
    """Skin Settings > "Load the next page into rows" (skin bool RowAutoPage). Off: the bridge works as it always did."""
    return xbmc.getCondVisibility('Skin.HasSetting(RowAutoPage)')


def get_pages(paramstring):
    """pages=K among the bridge's own parameters (before the first "&&"): 1 to 6, default 1."""
    if '&&' not in paramstring:
        return 1
    try:
        pages = int(dict(parse_qsl(paramstring.partition('&&')[0].lstrip('?'))).get('pages', 1))
    except ValueError:
        return 1
    return max(1, min(MAX_PAGES, pages))


def _addon_dir(addon_id):
    """Folder of an installed add-on: from Kodi first (it knows where every enabled add-on is), else the two add-on folders on disk (a module that is
    installed but not enabled on its own, for example)."""
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        if path:
            return xbmcvfs.translatePath(path)
    except RuntimeError:
        pass
    for root in ADDON_ROOTS:
        folder = xbmcvfs.translatePath(root + addon_id)
        if os.path.isfile(os.path.join(folder, 'addon.xml')):
            return folder
    return None


def _manifest(folder):
    try:
        return ET.parse(os.path.join(folder, 'addon.xml')).getroot()
    except (ET.ParseError, OSError, TypeError) as error:
        log('cannot read addon.xml in %s: %s' % (folder, error), xbmc.LOGWARNING)
        return None


def _module_paths(manifest, seen):
    """Lib folders of the Python modules an add-on imports, followed down through their own imports (Kodi puts these on sys.path for the add-on).
    Kodi's own pseudo add-ons (xbmc.python, xbmc.gui ...) have no files and are skipped."""
    paths = []
    for dep in manifest.findall('./requires/import'):
        dep_id = dep.get('addon') or ''
        if not dep_id or dep_id.startswith('xbmc.') or dep_id in seen:
            continue
        seen.add(dep_id)
        folder = _addon_dir(dep_id)
        dep_manifest = _manifest(folder) if folder else None
        if dep_manifest is None:
            if dep.get('optional') != 'true':
                log('module %s not found' % dep_id, xbmc.LOGWARNING)
            continue
        for ext in dep_manifest.findall('extension'):
            if ext.get('point') == 'xbmc.python.module':
                paths.append(os.path.join(folder, ext.get('library') or 'lib'))
        paths += _module_paths(dep_manifest, seen)
    return paths


def _patch_kodi_modules(target_id, state):
    """Make the Kodi modules answer for the target add-on, and keep it from opening Kodi's busy spinner."""
    original_addon = xbmcaddon.Addon

    def addon(id=None, *args, **kwargs):  # same keyword as Kodi's: xbmcaddon.Addon(id='...')
        return original_addon(id or target_id)

    xbmcaddon.Addon = addon
    # these two look the add-on up from the plugin handle, which belongs to the helper
    xbmcplugin.getSetting = lambda handle, id: original_addon(target_id).getSetting(id)
    xbmcplugin.setSetting = lambda handle, id, value: original_addon(target_id).setSetting(id, value)

    original_end = xbmcplugin.endOfDirectory
    original_resolved = xbmcplugin.setResolvedUrl

    if not state.get('collect'):
        # RowAutoPage off: items go to Kodi as the target adds them and its own end of directory goes straight through
        def end_of_directory_off(*args, **kwargs):
            state['answered'] = True
            return original_end(*args, **kwargs)

        def set_resolved_url_off(*args, **kwargs):
            state['answered'] = True
            return original_resolved(*args, **kwargs)

        xbmcplugin.endOfDirectory = end_of_directory_off
        xbmcplugin.setResolvedUrl = set_resolved_url_off
        _patch_builtin(target_id)
        return

    original_add_items = xbmcplugin.addDirectoryItems
    original_sort = xbmcplugin.addSortMethod
    state['real_end'] = original_end
    state['real_add_items'] = original_add_items

    # the items of the page being run are held (state['items']) and handed to Kodi at the end, so the last ones can be tagged and several pages can be one list
    def add_directory_item(handle, url, listitem, isFolder=False, totalItems=0):
        state['items'].append((url, listitem, bool(isFolder)))
        return True

    def add_directory_items(handle, items, totalItems=0):
        for item in items:
            state['items'].append((item[0], item[1], bool(item[2]) if len(item) > 2 else False))
        return True

    # the target's own end of directory is only noted: the bridge ends the directory once, after the last page
    def end_of_directory(handle=None, succeeded=True, updateListing=False, cacheToDisc=True):
        state['answered'] = True
        state['end'] = {'succeeded': succeeded, 'updateListing': updateListing, 'cacheToDisc': cacheToDisc}

    def set_resolved_url(*args, **kwargs):
        state['answered'] = True
        return original_resolved(*args, **kwargs)

    # every page of one list asks for the same sort methods: pass each one on once
    def add_sort_method(handle, sortMethod, *args, **kwargs):
        key = (sortMethod, args, tuple(sorted(kwargs.items())))
        if key in state['sorts']:
            return None
        state['sorts'].add(key)
        return original_sort(handle, sortMethod, *args, **kwargs)

    xbmcplugin.addDirectoryItem = add_directory_item
    xbmcplugin.addDirectoryItems = add_directory_items
    xbmcplugin.endOfDirectory = end_of_directory
    xbmcplugin.setResolvedUrl = set_resolved_url
    xbmcplugin.addSortMethod = add_sort_method

    _patch_builtin(target_id)


def _patch_builtin(target_id):
    original_builtin = xbmc.executebuiltin

    def execute_builtin(function, wait=False):
        command = (function or '').replace(' ', '').lower()
        if command.startswith('activatewindow(') and command[15:].rstrip(')').split(',')[0] in BUSY_WINDOWS:
            log('%s: left out %s (rows load in the background)' % (target_id, function), xbmc.LOGDEBUG)
            return None
        return original_builtin(function, wait)

    xbmc.executebuiltin = execute_builtin


def _run_as_main(script):
    """Run the target's entry script as __main__, the way Kodi runs a plugin. Not runpy.run_path: that swaps sys.argv[0] for the script's file path while the
    script runs, and add-ons build their own links from sys.argv[0]."""
    with open(script, 'rb') as source:
        code = compile(source.read(), script, 'exec')
    main = types.ModuleType('__main__')
    main.__file__ = script
    main.__builtins__ = __builtins__
    sys.modules['__main__'] = main
    exec(code, main.__dict__)


def _is_next_page(item, target_id):
    """The last item of a page is its "next page" item: a folder of the same add-on whose label looks like paging (next / more / page <n>) or that asks to be sorted
    to the bottom."""
    url, listitem, is_folder = item
    own = 'plugin://%s' % target_id.lower()
    if not is_folder or not (url.lower() == own or url.lower().startswith(own + '/')):
        return False
    try:
        if NEXT_LABEL.search(listitem.getLabel() or ''):
            return True
        return (listitem.getProperty('SpecialSort') or '').lower() == 'bottom'
    except Exception:
        return False


def _item_keys(item):
    """What identifies an item when pages are joined: its address and, for a video with ids, its media type with its TMDb / IMDb id (the same title can come back
    under a slightly different address)."""
    url, listitem, _ = item
    keys = {('url', url)}
    try:
        tag = listitem.getVideoInfoTag()
        kind = tag.getMediaType() or ''
        for source in ('tmdb', 'imdb'):
            value = tag.getUniqueID(source)
            if value:
                keys.add((kind, source, str(value)))
    except Exception:
        pass
    return keys


def _run_page(url, script, target_id, state, notify):
    """Run the target's entry script once for url (sys.argv as Kodi sets it for a plugin call). True when it ran without an error."""
    base, _, query = url.partition('?')
    sys.argv = [base, str(HANDLE), ('?' + query) if query else '', 'resume:false']
    try:
        _run_as_main(script)
    except SystemExit:
        pass
    except Exception as error:
        log('%s failed:\n%s' % (url, traceback.format_exc()), xbmc.LOGERROR)
        if notify:
            xbmcgui.Dialog().notification('eXistenZ Widget Bridge', '%s: %s' % (target_id, error), xbmcgui.NOTIFICATION_ERROR, 6000)
        return False
    return True


def run_target(target_url, pages=1):
    target_id = urlsplit(target_url).netloc
    if not target_url.lower().startswith('plugin://') or not target_id or target_id.lower() == SELF_ID:
        log('not a plugin address this can run: %s' % target_url, xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    folder = _addon_dir(target_id)
    manifest = _manifest(folder) if folder else None
    entry = None
    if manifest is not None:
        for ext in manifest.findall('extension'):
            if ext.get('point') == 'xbmc.python.pluginsource':
                entry = ext.get('library')
                break
    if not entry:
        log('%s is not installed, or is not a Python plugin' % target_id, xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # the folder of the target's entry script first, then its modules - exactly what Kodi puts on sys.path for a plugin (CPythonInvoker: scriptDir, then
    # getAddonModuleDeps). Not the add-on's top folder: an add-on whose entry script sits in resources/lib imports its code from there. The helper's own
    # folder comes off so nothing in it (its resources folder, for one) can shadow a module of the target. No os.chdir() into the target's folder: the working
    # directory belongs to the whole Kodi process, and one left inside an add-on folder stops Windows from moving that folder when the add-on updates.
    script = os.path.join(folder, entry)
    own = os.path.normcase(os.path.dirname(os.path.abspath(__file__))).rstrip(os.sep)
    sys.path = [p for p in sys.path if os.path.normcase(os.path.abspath(p or '.')).rstrip(os.sep) != own]
    extra = [os.path.dirname(script)] + _module_paths(manifest, {target_id})
    sys.path[0:0] = [p for p in extra if p not in sys.path]

    collect = pages_enabled()
    if not collect:
        # RowAutoPage off: exactly the single-page run (pages is ignored, nothing is held back or tagged)
        base, _, query = target_url.partition('?')
        sys.argv = [base, str(HANDLE), ('?' + query) if query else '', 'resume:false']
        state = {'answered': False}
        _patch_kodi_modules(target_id, state)
        try:
            _run_as_main(script)
        except SystemExit:
            pass
        except Exception as error:
            log('%s failed:\n%s' % (target_url, traceback.format_exc()), xbmc.LOGERROR)
            if not state['answered']:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            xbmcgui.Dialog().notification('eXistenZ Widget Bridge', '%s: %s' % (target_id, error), xbmcgui.NOTIFICATION_ERROR, 6000)
        return

    state = {'items': [], 'answered': False, 'end': None, 'sorts': set(), 'collect': True}
    _patch_kodi_modules(target_id, state)

    collected = []  # items of the pages done, each page's next-page item taken out
    next_item = None  # the next-page item of the last page done
    seen = set()  # _item_keys of everything collected so far
    first_end = None
    first_ok = True
    failed = False
    for page in range(1, pages + 1):
        state['items'] = []
        state['answered'] = False
        state['end'] = None
        ok = _run_page(next_item[0] if next_item else target_url, script, target_id, state, notify=(page == 1))
        if page == 1:
            first_end, first_ok = state['end'], ok
        elif not ok or not state['items']:
            # page 2 on: keep what there is, with the next-page item that led here put back at the end (nothing of this page is used)
            failed = True
            break
        page_items = state['items']
        next_item = None
        if page_items and _is_next_page(page_items[-1], target_id):
            next_item = page_items.pop()
        # An add-on fetches (and caches) each page of a list at a different moment, and a list such as Trending moves in between, so a title at the end of one
        # page often comes back at the start of the next. In the add-on nobody sees it, the pages being on different screens; in one row it shows as the same card
        # twice. From page 2 on, a title already in the row is left out.
        repeats = 0
        for item in page_items:
            keys = _item_keys(item)
            if page > 1 and keys & seen:
                repeats += 1
                continue
            seen |= keys
            collected.append(item)
        if repeats:
            log('%s: page %d repeated %d of the earlier titles in the row, left out' % (target_id, page, repeats))
        if next_item is None or page == pages or not ok:
            break

    if next_item is not None and pages < MAX_PAGES and not failed and first_ok:
        for url, listitem, is_folder in collected[-TAIL_ITEMS:] + [next_item]:
            try:
                listitem.setProperty('rl.more', str(pages + 1))
            except Exception:
                pass
    if next_item is not None:
        collected.append(next_item)
    if collected:
        state['real_add_items'](HANDLE, collected, len(collected))

    if pages > 1:
        state['real_end'](HANDLE, succeeded=bool(collected))
    elif first_end is not None:
        state['real_end'](HANDLE, **first_end)
    elif not first_ok:
        state['real_end'](HANDLE, succeeded=False)


target = get_target(sys.argv[2] if len(sys.argv) > 2 else '')
run_target(target, get_pages(sys.argv[2] if len(sys.argv) > 2 else ''))
