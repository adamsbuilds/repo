# -*- coding: utf-8 -*-
"""Pickers for skin.existenz: home rows, sidebar entries. A destination can be a Kodi library list, a folder inside a video add-on, a source or playlist, a Kodi screen,
an add-on to launch, or a path typed in by hand.

Run as:
  RunScript(script.existenz.helper,action=pick_rows)   -> dialog to choose a page, then what each of its home rows shows
  RunScript(script.existenz.helper,action=reset_rows)  -> put the rows of a page back to their default (Skin Settings)
  RunScript(script.existenz.helper,action=set_page,page=N) -> show Home page N (1-8): sidebar entries of type Page / Home run this
  RunScript(script.existenz.helper,action=switch_skin) -> switch back to Estuary (escape hatch from the power menu)
  RunScript(script.existenz.helper,action=pick_sidebar,slot=N) -> choose what entry N (1-8) of the Home sidebar opens (Skin Settings > Sidebar)
  RunScript(script.existenz.helper,action=reset_sidebar)       -> put the sidebar back to its default entries
  RunScript(script.existenz.helper,action=pick_topbar,slot=N)  -> choose what entry N (1-8) of the top bar opens (Skin Settings > Top Bar)
  RunScript(script.existenz.helper,action=reset_topbar)        -> put the top bar back to its default entries
  RunScript(script.existenz.helper,action=seeksteps)   -> for the player OSD skip buttons (run when the OSD opens): read Kodi's skip steps (Settings > Player >
                                                           Videos) and store the first forward / back step in the skin strings SeekFwdIdle / SeekBackIdle, and set the
                                                           window properties sp10, sp30 ... (+10, +30 ...) on the OSD window that the skin compares pending skips with

Pages: the Home screen can have up to 8 pages, one per sidebar entry whose type is "Page" (sidebar entry N shows page N; the "Home" entry always shows page 1). Each page has
its own 8 rows. Every page is stored in skin strings P<page>Row<slot>.Path / .Label / .Style (empty path = built-in default row on page 1, no row on the other pages; "none" = hidden).
The skin only ever reads the "live" strings HomeRow<slot>.Path / .Label / .Style (see $VAR[HomeRow<N>Path] in Includes.xml); action=set_page copies the chosen page into them
and loads the rows one at a time, and the pickers keep the live strings in step when you edit the page that is showing. The page on screen is the skin string CurrentPage
(empty = 1). The first time anything here runs, the rows you had before pages existed are copied into page 1 (skin setting PagesInit).
Every picker ends with a Name step (rows, sidebar entries, top bar entries); a row or entry can also be renamed on its own.
"""
import json
import re
import sys
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

SLOTS = 8
PAGES = 8
HOME_WINDOW = 10000
# the built-in default rows (slot -> label); keep in sync with the default values of the HomeRow<N> variables in Includes.xml. Slots 5-8 are hidden by default. Page 1 only.
# no built-in rows: every page, the first included, starts empty and is filled with the picker
DEFAULT_ROWS = {}
PARTS = ('Path', 'Label', 'Style')

ADDON = xbmcaddon.Addon()


def _get(name):
    return xbmc.getInfoLabel('Skin.String(%s)' % name)


def _sk(builtin):
    """Run a skin builtin and wait for it, so a value read straight afterwards is the new one."""
    xbmc.executebuiltin(builtin, True)


_FORMAT_TAGS = re.compile(r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)(?:\s[^\]]*)?\]', re.I)
_LINE_BREAK = re.compile(r'\[CR\]', re.I)


def _plain(text):
    """Text of a label without Kodi's formatting codes ([COLOR red], [B], [I], [UPPERCASE], [LOWERCASE], [CAPITALIZE], [LIGHT], [CR]). Add-ons colour and embolden
    the names in their lists; in the pickers every entry should look the same, and a name saved from one must not carry the codes into the rows and sidebar."""
    text = _LINE_BREAK.sub(' ', text or '')
    return ' '.join(_FORMAT_TAGS.sub('', text).split())


def _ask_name(heading, default):
    """The Name step that ends every picker. Cancelling or clearing the box keeps the suggested name; a comma cannot be used (it would split the skin builtin)."""
    dialog = xbmcgui.Dialog()
    default = _plain(default)
    while True:
        name = dialog.input(heading, defaultt=default)
        if not name:
            return default
        if ',' in name:
            dialog.notification(heading, 'A comma cannot be used in a name', xbmcgui.NOTIFICATION_WARNING, 3500)
            continue
        return name.strip() or default


def _current_page():
    try:
        page = int(_get('CurrentPage') or 1)
    except ValueError:
        page = 1
    return page if 1 <= page <= PAGES else 1


def _store_name(page, slot):
    return 'P%dRow%d' % (page, slot)


def _ensure_init():
    """First run after pages were added: the rows chosen before become page 1."""
    if xbmc.getCondVisibility('Skin.HasSetting(PagesInit)'):
        return
    for slot in range(1, SLOTS + 1):
        for part in PARTS:
            value = _get('HomeRow%d.%s' % (slot, part))
            if value:
                _sk('Skin.SetString(%s.%s,%s)' % (_store_name(1, slot), part, value))
    if not _get('CurrentPage'):
        _sk('Skin.SetString(CurrentPage,1)')
    _sk('Skin.SetBool(PagesInit)')


def init_defaults():
    """First run on a new install (Home.xml runs this while the skin string RLDefaultsApplied is not set): the starting sidebar, an empty Home page, no top bar and
    the OSD defaults. Nothing is overwritten if the sidebar, rows or top bar were already set up (an install that already has its own choices only gets the flag).
    Sidebar: 1 Home (a page, left empty so the page shows its Choose rows button), 6 Favorites, 7 Add-Ons (a page filled with the Add-ons rows), 8 Settings."""
    if xbmc.getCondVisibility('Skin.HasSetting(RLDefaultsApplied)'):
        return
    configured = any(_get('Sidebar%d.Key' % i) or _get('TopBar%d.Key' % i) or _get('HomeRow%d.Path' % i) or _get('P1Row%d.Path' % i)
                     for i in range(1, SLOTS + 1))
    if not configured:
        entries = {1: ('page', 'Home'), 2: ('none', ''), 3: ('none', ''), 4: ('none', ''), 5: ('none', ''),
                   6: ('favourites', 'Favorites'), 7: ('page', 'Add-Ons'), 8: ('settings', 'Settings')}
        for slot, (key, label) in entries.items():
            _sk('Skin.SetString(Sidebar%d.Key,%s)' % (slot, key))
            _set_string('Sidebar%d.Label' % slot, label)
            _sk('Skin.Reset(Sidebar%d.Path)' % slot)
        for slot in range(1, SLOTS + 1):
            _sk('Skin.SetString(TopBar%d.Key,none)' % slot)
            _sk('Skin.Reset(TopBar%d.Label)' % slot)
            _sk('Skin.Reset(TopBar%d.Path)' % slot)
        _sk('Skin.Reset(TopBarText)')
        _sk('Skin.SetString(CurrentPage,1)')
        _sk('Skin.SetBool(PagesInit)')
        for slot in range(1, SLOTS + 1):
            for page in range(1, 9):
                _sk('Skin.Reset(%s.Path)' % _store_name(page, slot))
            _set_string('HomeRow%d.Path' % slot, 'none')
            _sk('Skin.Reset(HomeRow%d.Label)' % slot)
            _sk('Skin.Reset(HomeRow%d.Style)' % slot)
        _fill_addons_rows(7, [i for i, row in enumerate(ADDON_PAGE_ROWS) if _addon_type_installed(row)])
        _sk('Skin.SetBool(OSDAudioOpensMenu)')
        _sk('Skin.SetBool(OSDSubtitlesOpensMenu)')
        _sk('Skin.SetString(OSDAutoCloseSeconds,3)')
        _sk('Skin.Reset(BackgroundPlayback)')
    _sk('Skin.SetBool(RLDefaultsApplied)')


def _set_string(name, value):
    if value:
        _sk('Skin.SetString(%s,%s)' % (name, value))
    else:
        _sk('Skin.Reset(%s)' % name)


def _live(page, slot, path, label, style):
    """Copy one row of a page into the strings the skin reads. An empty slot means no row."""
    _set_string('HomeRow%d.Path' % slot, path or 'none')
    _set_string('HomeRow%d.Label' % slot, label)
    _set_string('HomeRow%d.Style' % slot, style)


def _store(page, slot, path, label, style):
    """Save one row of a page ('' = default / empty, 'none' = hidden); if that page is the one showing, the live strings follow."""
    _set_string('%s.Path' % _store_name(page, slot), path)
    _set_string('%s.Label' % _store_name(page, slot), label)
    _set_string('%s.Style' % _store_name(page, slot), style)
    if page == _current_page():
        _live(page, slot, path, label, style)


def _read_store(page, slot):
    return [_get('%s.%s' % (_store_name(page, slot), part)) for part in PARTS]


def _slot_label(page, slot):
    path, label, _style = _read_store(page, slot)
    if path == 'none':
        return '(Empty)'
    if path:
        return label or path
    default = DEFAULT_ROWS.get(slot) if page == 1 else None
    return '%s (default)' % default if default else '(Empty)'


def _page_label(page):
    """The page's name is the name of its sidebar entry; page 1 is called Home until an entry says otherwise."""
    label = _get('Sidebar%d.Label' % page)
    if label and _get('Sidebar%d.Key' % page) in ('page', 'home', ''):
        return label
    return 'Home' if page == 1 else 'Page %d' % page


def _pages():
    """Pages that exist: page 1 always, then every sidebar entry set to type Page."""
    return [p for p in range(1, PAGES + 1) if p == 1 or _get('Sidebar%d.Key' % p) == 'page']


def _choose_page(heading):
    pages = _pages()
    if len(pages) == 1:
        return pages[0]
    current = _current_page()
    names = ['%s%s' % (_page_label(p), '   (showing now)' if p == current else '') for p in pages]
    pick = xbmcgui.Dialog().select(heading, names, preselect=pages.index(current) if current in pages else 0)
    return pages[pick] if pick >= 0 else None


def pick_rows():
    _ensure_init()
    dialog = xbmcgui.Dialog()
    page = _choose_page('Which page do you want to edit?')
    if page is None:
        return
    title = 'Home screen rows - %s' % _page_label(page)
    while True:
        slots = ['Row %d:  %s' % (i, _slot_label(page, i)) for i in range(1, SLOTS + 1)]
        slots.append('Clear all rows on this page')
        slot_idx = dialog.select(title, slots)
        if slot_idx < 0:
            return
        if slot_idx == SLOTS:
            for i in range(1, SLOTS + 1):
                _store(page, i, '', '', '')
            continue
        slot = slot_idx + 1
        path, label, style = _read_store(page, slot)
        shown = bool(path and path != 'none') or (page == 1 and path != 'none' and slot in DEFAULT_ROWS)
        choices = ['Choose what this row shows...', '(Empty - hide this row)', 'Clear this row']
        if shown:
            choices.append('Rename this row...')
        what = dialog.select('Row %d' % slot, choices)
        if what < 0:
            continue
        if what == 1:
            _store(page, slot, 'none', '', '')
        elif what == 2:
            _store(page, slot, '', '', '')
        elif what == 3:
            current_name = label or DEFAULT_ROWS.get(slot, '')
            _store(page, slot, path, _ask_name('Row name', current_name), style)
        else:
            picked = pick_destination(rows_only=True)
            if picked:
                if ',' in picked['path']:
                    dialog.notification('Home rows', 'A comma in the address cannot be used', xbmcgui.NOTIFICATION_WARNING, 4000)
                    continue
                # a row of episodes is drawn as landscape cards (the episode's own picture), everything else as posters; guess from the address, let the user decide
                guess = 1 if 'episode' in picked['path'].lower() or 'episode' in picked['label'].lower() else 0
                style_pick = dialog.select('Show this row as', ['Posters (movies, TV shows)', 'Episode cards (landscape pictures)'], preselect=guess)
                if style_pick < 0:
                    continue
                # the Name step comes last
                name = _ask_name('Row name', picked['label'])
                _store(page, slot, picked['path'], name, 'landscape' if style_pick == 1 else 'poster')


def reset_rows():
    _ensure_init()
    page = _choose_page('Which page do you want to reset?')
    if page is None:
        return
    for i in range(1, SLOTS + 1):
        _store(page, i, '', '', '')
    xbmcgui.Dialog().notification('Skin', '%s: rows %s' % (_page_label(page), 'cleared'), time=2500)


def _rows_focused():
    return xbmc.getCondVisibility(' | '.join('Control.HasFocus(%d)' % (5000 + i) for i in range(1, SLOTS + 1)))


def _focus_lowest_populated(upto):
    """Give focus to the first row (up to row 'upto') that has items, unless a row already has it or the sidebar is open (focus must stay where the user put it)."""
    if xbmcgui.Window(HOME_WINDOW).getProperty('rl.sidebar') == '1' or _rows_focused():
        return True
    for i in range(1, upto + 1):
        if _row_populated(i):
            xbmc.executebuiltin('SetFocus(%d)' % (5000 + i))
            return True
    return False


def _row_populated(slot):
    """A row counts only if it is switched on for this page and has items. A row that was switched off keeps the items it had on the previous page (Kodi does not
    empty a list whose address becomes blank), so NumItems alone cannot be trusted."""
    return (xbmc.getCondVisibility('Integer.IsGreater(Container(%d).NumItems,0)' % (5000 + slot))
            and _get('HomeRow%d.Path' % slot) not in ('none', ''))


def set_page(page):
    """Show a page on Home: blank the rows, copy the page into the live strings, then load the rows one per second (the same stagger Home.xml uses after the
    player, so Kodi is never asked for every row at once) and focus the first row that has something in it."""
    _ensure_init()
    win = xbmcgui.Window(HOME_WINDOW)
    if page == _current_page() and win.getProperty('rl.fromplayer') != '1':
        # already showing: just go back to the row you were on
        xbmc.executebuiltin('SetFocus(%s)' % (win.getProperty('rl.lastrow') or '5001'))
        return
    token = '%.3f-%d' % (time.time(), page)
    win.setProperty('rl.pagejob', token)
    for name in ['rlgo%d' % i for i in range(0, SLOTS + 1)] + ['rlfocus', 'rlgoend']:
        xbmc.executebuiltin('CancelAlarm(%s,silent)' % name)
    win.setProperty('rl.fromplayer', '1')
    for i in range(1, SLOTS + 1):
        win.clearProperty('rl.go%d' % i)
    win.clearProperty('rl.lastrow')
    _sk('Skin.SetString(CurrentPage,%d)' % page)
    for slot in range(1, SLOTS + 1):
        path, label, style = _read_store(page, slot)
        _live(page, slot, path, label, style)
    # a page with no rows shows a button instead (Home.xml, PageEmpty); if focus was left on a row that just went away, put it in the sidebar
    if xbmc.getCondVisibility('$EXP[PageEmpty]') and _rows_focused():
        win.setProperty('rl.sidebar', '1')
        xbmc.executebuiltin('SetFocus(9500)')
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(0.5):
        return
    for i in range(1, SLOTS + 1):
        if win.getProperty('rl.pagejob') != token:
            return  # another page was chosen meanwhile; that run takes over
        win.setProperty('rl.go%d' % i, '1')
        if monitor.waitForAbort(1.0):
            return
        _focus_lowest_populated(i)
    if win.getProperty('rl.pagejob') == token:
        _focus_lowest_populated(SLOTS)
        win.clearProperty('rl.fromplayer')


def switch_skin(skin_id='skin.estuary'):
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
        'params': {'setting': 'lookandfeel.skin', 'value': skin_id}}))


def _skip_label(seconds):
    """Short unsigned label that fits in the OSD skip arrow: 10, 30, 1m, 10m, 30m, 1h."""
    n = abs(int(seconds))
    if n < 60:
        return str(n)
    if n % 3600 == 0:
        return '%dh' % (n // 3600)
    if n % 60 == 0:
        return '%dm' % (n // 60)
    return str(n)


# Window id of the player OSD (videoosd) and the pending-skip sizes the skin compares Player.SeekStepSize with (see the SkipFwdLabel variable in Includes.xml).
# A skin condition cannot contain a + (it is the AND operator), so the forward sizes (+10, +30 ...) are handed to the skin as window properties sp10, sp30 ...
VIDEO_OSD_WINDOW = 12901
SKIP_SIZES = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 150, 180, 210, 240, 270, 300, 360, 420, 480, 540, 600, 720, 900, 1080, 1200, 1260, 1440, 1500, 1620, 1800, 2100, 2400, 2700, 3000, 3600, 4200, 4800, 5400, 6000, 7200, 9000, 10800, 12600, 14400, 16200, 18000]


def _set_skip_size_properties():
    osd = xbmcgui.Window(VIDEO_OSD_WINDOW)
    for n in SKIP_SIZES:
        osd.setProperty('sp%d' % n, '+%d' % n)


SIDEBAR_SLOTS = 8
# what a sidebar entry can open besides a eXistenZ list: key -> label (the skin turns the key into the action, see Home.xml control 9500)
SIDEBAR_BUILTINS = [
    ('home', 'Home (page 1)'),
    ('page', 'Page - its own set of home rows (page number = entry number)'),
    ('addons', 'Add-ons'),
    ('favourites', 'Favourites'),
    ('files', 'File manager'),
    ('settings', 'Kodi settings'),
    ('skinsettings', 'Skin settings'),
    ('power', 'Power menu'),
]


def _rpc(method, params):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    return reply.get('result') or {}


# fixed starting points: (label, path)
VIDEO_LIBRARY = [
    ('Movies', 'videodb://movies/titles/'),
    ('Movie genres', 'videodb://movies/genres/'),
    ('Movie sets', 'videodb://movies/sets/'),
    ('Recently added movies', 'videodb://recentlyaddedmovies/'),
    ('TV shows', 'videodb://tvshows/titles/'),
    ('TV show genres', 'videodb://tvshows/genres/'),
    ('Recently added episodes', 'videodb://recentlyaddedepisodes/'),
    ('Music videos', 'videodb://musicvideos/titles/'),
]
EXTRAS = [
    ('Video playlists', 'special://videoplaylists/'),
    ('Favourites', 'favourites://'),
]
# kinds that open in a window of their own: kind -> Kodi window
KIND_WINDOW = {'row': 'videos', 'music': 'music', 'programs': 'programs', 'pictures': 'pictures'}


def _browse_directory(label, path, kind='row'):
    """Walk into folders (add-on menus, library nodes, sources, playlists) one level at a time.
    Returns {'kind', 'label', 'path'} for the folder the user chose, or None."""
    trail = []
    while True:
        result = _rpc('Files.GetDirectory', {'directory': path, 'media': 'files', 'properties': ['title']})
        folders = [f for f in result.get('files', []) if f.get('filetype') == 'directory' and f.get('file')]
        names = ['[Use this folder: %s]' % label] + (['[Back]'] if trail else []) + [_plain(f.get('label') or f.get('title') or f['file']) for f in folders]
        first = 2 if trail else 1
        choice = xbmcgui.Dialog().select(label, names)
        if choice < 0:
            return None
        if choice == 0:
            return {'kind': kind, 'label': label, 'path': path}
        if trail and choice == 1:
            label, path = trail.pop()
            continue
        folder = folders[choice - first]
        trail.append((label, path))
        label, path = _plain(folder.get('label') or folder.get('title') or label), folder['file']


def _pick_addon(addon_type, title, kind):
    addons = _rpc('Addons.GetAddons', {'type': addon_type, 'enabled': True, 'properties': ['name']}).get('addons', [])
    addons.sort(key=lambda a: a.get('name', '').lower())
    pick = xbmcgui.Dialog().select(title, [_plain(a.get('name')) or a['addonid'] for a in addons])
    if pick < 0:
        return None
    name = _plain(addons[pick].get('name')) or addons[pick]['addonid']
    path = 'plugin://%s/' % addons[pick]['addonid']
    if kind == 'programs':
        # a program add-on is launched, not browsed
        return {'kind': 'programs', 'label': name, 'path': path}
    return _browse_directory(name, path, kind)


def _manual_entry():
    dialog = xbmcgui.Dialog()
    path = dialog.input('Path or address (for example plugin://plugin.video.example/?mode=list or videodb://movies/titles/)')
    if not path:
        return None
    kind = 'music' if path.startswith(('musicdb://', 'special://musicplaylists')) else 'pictures' if path.startswith('special://pictures') else 'row'
    default = path.rstrip('/').split('/')[-1].split('?')[0] or path
    return {'kind': kind, 'label': default, 'path': path}


def pick_destination(rows_only=False):
    """The picker used for home rows and sidebar entries: browse like a file browser, or type a path.
    A row can only show video lists, so rows_only leaves out what is launched or opens music / pictures."""
    # add-ons first, the library and the rest below them
    entries = [('Video add-ons', lambda: _pick_addon('xbmc.addon.video', 'Video add-ons', 'row'))]
    if not rows_only:
        entries += [
            ('Program add-ons (launch)', lambda: _pick_addon('xbmc.addon.executable', 'Program add-ons', 'programs')),
            ('Music add-ons', lambda: _pick_addon('xbmc.addon.audio', 'Music add-ons', 'music')),
        ]
    entries += [
        ('Video sources (folders you added)', _pick_video_source),
        ('Playlists and favourites', lambda: _pick_from('Playlists and favourites', EXTRAS)),
        ('Video library', lambda: _pick_from('Video library', VIDEO_LIBRARY)),
        ('Type a path or address...', _manual_entry),
    ]
    pick = xbmcgui.Dialog().select('Choose', [name for name, _ in entries])
    if pick < 0:
        return None
    return entries[pick][1]()


def _pick_from(title, places):
    pick = xbmcgui.Dialog().select(title, [lab for lab, _ in places])
    if pick < 0:
        return None
    return _browse_directory(places[pick][0], places[pick][1])


def _pick_video_source():
    sources = _rpc('Files.GetSources', {'media': 'video'}).get('sources', [])
    pick = xbmcgui.Dialog().select('Video sources', [_plain(s.get('label')) or s['file'] for s in sources])
    if pick < 0:
        return None
    return _browse_directory(_plain(sources[pick].get('label')) or sources[pick]['file'], sources[pick]['file'])


TOPBAR_BUILTINS = [
    ('addons', 'Add-ons'),
    ('favourites', 'Favourites'),
    ('files', 'File manager'),
    ('settings', 'Kodi settings'),
    ('skinsettings', 'Skin settings'),
    ('power', 'Power menu'),
]


def pick_entry(prefix, slot, builtins, title):
    """Choose what an entry of the sidebar (prefix 'Sidebar') or the top bar (prefix 'TopBar') opens: empty, a Kodi screen, a page (sidebar only) or any destination.
    The Name step comes last, and the entry can also just be renamed."""
    dialog = xbmcgui.Dialog()
    key_now = _get('%s%d.Key' % (prefix, slot))
    label_now = _get('%s%d.Label' % (prefix, slot))
    # the browser comes first (add-ons, library, folders, a typed path), then Empty and the fixed Kodi screens
    names = ['Browse add-ons, library and folders, or type a path...', '(Empty - hide this entry)'] + [lab for _, lab in builtins]
    can_rename = bool(label_now) or key_now not in ('', 'none')
    if can_rename:
        names.append('Rename this entry...')
    choice = dialog.select('%s entry %d' % (title, slot), names)
    if choice < 0:
        return
    if choice == 1:
        xbmc.executebuiltin('Skin.SetString(%s%d.Key,none)' % (prefix, slot))
        xbmc.executebuiltin('Skin.Reset(%s%d.Label)' % (prefix, slot))
        xbmc.executebuiltin('Skin.Reset(%s%d.Path)' % (prefix, slot))
        return
    if can_rename and choice == len(names) - 1:
        xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, _ask_name('Name', label_now or key_now)))
        return
    if choice >= 2:
        key, label = builtins[choice - 2]
        default = label.split(' (')[0].split(' - ')[0]
        if key == 'page':
            default = label_now if key_now == 'page' and label_now else 'Page %d' % slot
        name = _ask_name('Name', default)
        xbmc.executebuiltin('Skin.SetString(%s%d.Key,%s)' % (prefix, slot, key))
        xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, name))
        xbmc.executebuiltin('Skin.Reset(%s%d.Path)' % (prefix, slot))
        if key == 'page':
            _ensure_init()
            dialog.notification(title, '%s is page %d. Fill it with Skin Settings > General > Choose home screen rows' % (name, slot), time=5000)
        return
    picked = pick_destination()
    if not picked:
        return
    if ',' in picked['path']:
        dialog.notification(title, 'A comma in the address cannot be used', xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    name = _ask_name('Name', picked['label'])
    xbmc.executebuiltin('Skin.SetString(%s%d.Key,%s)' % (prefix, slot, picked['kind']))
    xbmc.executebuiltin('Skin.SetString(%s%d.Label,%s)' % (prefix, slot, name))
    xbmc.executebuiltin('Skin.SetString(%s%d.Path,%s)' % (prefix, slot, picked['path']))


def pick_sidebar(slot):
    pick_entry('Sidebar', slot, SIDEBAR_BUILTINS, 'Sidebar')


def pick_topbar(slot):
    pick_entry('TopBar', slot, TOPBAR_BUILTINS, 'Top bar')


def reset_topbar():
    for slot in range(1, SIDEBAR_SLOTS + 1):
        for part in ('Key', 'Label', 'Path'):
            xbmc.executebuiltin('Skin.Reset(TopBar%d.%s)' % (slot, part))


def reset_sidebar():
    for slot in range(1, SIDEBAR_SLOTS + 1):
        for part in ('Key', 'Label', 'Path'):
            xbmc.executebuiltin('Skin.Reset(Sidebar%d.%s)' % (slot, part))


def sync_seek_steps():
    """Store the first forward / back skip step of Kodi's own list (videoplayer.seeksteps) for the OSD skip buttons.

    Kodi builds its forward steps in list order and its backward steps in reverse list order (see CSeekHandler::Configure), so the first forward step is the
    first positive value in the setting and the first backward step is the last negative one. Nothing is stored if the setting cannot be read, and the
    skin then shows 10.
    """
    _set_skip_size_properties()
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
        'params': {'setting': 'videoplayer.seeksteps'}})))
    steps = (reply.get('result') or {}).get('value') or []
    forward = [s for s in steps if s > 0]
    backward = [s for s in steps if s < 0]
    if forward:
        xbmc.executebuiltin('Skin.SetString(SeekFwdIdle,%s)' % _skip_label(forward[0]))
    if backward:
        xbmc.executebuiltin('Skin.SetString(SeekBackIdle,%s)' % _skip_label(backward[-1]))


# Add-ons page: a page of home rows (see pick_rows) whose rows are lists of add-ons. A row's style says how it is drawn and which window opens what is
# in it (Includes.xml: the "addon" layouts and the HomeRow<N>Target variables). "addon-cat" is the Categories row (addons:// is Kodi's own list of My add-ons,
# Recently updated, Install from repository, Install from zip file, Search ...; pressing OK on one opens it in the add-on browser).
ADDON_PAGE_ROWS = (
    ('Categories', 'addons://', 'addon-cat', None),
    ('Video add-ons', 'addons://user/xbmc.addon.video', 'addon-video', 'xbmc.addon.video'),
    ('Music add-ons', 'addons://user/xbmc.addon.audio', 'addon-music', 'xbmc.addon.audio'),
    ('Program add-ons', 'addons://user/xbmc.addon.executable', 'addon-program', 'xbmc.addon.executable'),
    ('Picture add-ons', 'addons://user/xbmc.addon.image', 'addon-picture', 'xbmc.addon.image'),
    ('Game add-ons', 'addons://user/xbmc.addon.game', 'addon-game', 'xbmc.addon.game'),
)


def addons_page():
    """Fill a page with the Add-ons rows. Pick the page, then which rows it should have (types you have no add-ons of are left unticked at first); the rest
    of the page is emptied. Rows can be renamed, moved or removed afterwards with the normal row picker."""
    _ensure_init()
    dialog = xbmcgui.Dialog()
    page = _choose_page('Which page should show your add-ons?')
    if page is None:
        return
    names = [row[0] for row in ADDON_PAGE_ROWS]
    installed = [i for i, row in enumerate(ADDON_PAGE_ROWS) if _addon_type_installed(row)]
    chosen = dialog.multiselect('Add-ons rows - %s' % _page_label(page), names, preselect=installed)
    if chosen is None:
        return
    _fill_addons_rows(page, chosen)
    dialog.notification('Add-ons page', '%s now shows %d row(s)' % (_page_label(page), min(len(chosen), SLOTS)), time=3500)


def _addon_type_installed(row):
    return row[3] is None or bool(_rpc('Addons.GetAddons', {'type': row[3], 'enabled': True}).get('addons'))


def _fill_addons_rows(page, chosen):
    """Put the chosen Add-ons rows (indexes into ADDON_PAGE_ROWS) on a page, in order, and empty the rest of it."""
    slot = 1
    for i in chosen[:SLOTS]:
        name, path, style, _t = ADDON_PAGE_ROWS[i]
        _store(page, slot, path, name, style)
        slot += 1
    while slot <= SLOTS:
        _store(page, slot, 'none', '', '')
        slot += 1


if __name__ == '__main__':
    args = dict(a.split('=', 1) for a in sys.argv[1:] if '=' in a)
    action = args.get('action', 'pick_rows')
    if action == 'switch_skin':
        switch_skin()
    elif action == 'reset_rows':
        reset_rows()
    elif action == 'set_page':
        set_page(int(args.get('page', '1')))
    elif action == 'init_defaults':
        init_defaults()
    elif action == 'addons_page':
        addons_page()
    elif action == 'seeksteps':
        sync_seek_steps()
    elif action == 'pick_sidebar':
        pick_sidebar(int(args.get('slot', '1')))
    elif action == 'reset_sidebar':
        reset_sidebar()
    elif action == 'pick_topbar':
        pick_topbar(int(args.get('slot', '1')))
    elif action == 'reset_topbar':
        reset_topbar()
    else:
        pick_rows()
