# Widget Bridge (`plugin.video.widgetbridge`) — developer notes

Widget Bridge lets any skin load an add-on's lists as widgets / home rows **without** that add-on's `reuselanguageinvoker`, while the add-on keeps
using it everywhere else. It runs the add-on's own code, unchanged, inside a fresh Python instance of its own for every widget.

It was written for eXistenZ and Red Light, but nothing in it is specific to either: it works with any Python plugin add-on and any skin whose
widget picker can browse video add-ons.

---

## The problem it solves

### What `reuselanguageinvoker` does

An add-on that sets `<reuselanguageinvoker>true</reuselanguageinvoker>` in its `addon.xml` asks Kodi to keep its Python instance alive after a call
and reuse it for the next one, instead of starting a new interpreter and re-importing all of its code every time. Browsing such an add-on is
noticeably faster, which is why add-ons like Fen Light and its forks (Red Light) turn it on.

### Why it breaks when a skin loads several rows at once

Two details of how Kodi 21 implements it (read from the Kodi source):

- **The decision is per add-on, never per call.** `CScriptRunner::ExecuteScript` (`xbmc/interfaces/generic/ScriptRunner.cpp`) reads the flag from the
  add-on's `addon.xml` and nothing else. Kodi does not know, or care, whether the call came from a widget on Home or from the user browsing the
  add-on, so there is no way to say "reuse for browsing, not for widgets".
- **There is only one reusable instance for the whole system.** `CScriptInvocationManager` keeps a single `m_lastInvokerThread`
  (`xbmc/interfaces/generic/ScriptInvocationManager.cpp`). Each new call either takes that instance and `Reset()`s it to run again, or releases it
  and starts a new one.

Kodi loads widget rows as background jobs, up to **three at the same time** (`CDirectoryProvider` jobs run at `PRIORITY_LOW`, and
`CJobManager::GetMaxWorkers` allows `5 - (HIGH - LOW) = 3` of those at once — `xbmc/utils/JobManager.cpp`). When several rows of a reuse add-on
start in the same instant, they all race for that one instance: one is being reset while others are starting. With Red Light on eXistenZ this
crashed Kodi inside its Python engine — on Kodi start, on a page switch with several Red Light rows, and when a video started while rows were
refreshing.

### Fixes that were possible, and why this one

| Option | Result |
| --- | --- |
| Turn `reuselanguageinvoker` off in the add-on | No crash, but browsing loses the speed-up the add-on turned it on for. |
| Stagger the rows in the skin (eXistenZ "Safe") | No crash, but rows start half a second apart, with an extra wait after playback and Reload Skin. A page of 8 rows takes several seconds. |
| Patch Kodi to skip reuse for widget calls | Only helps people running that patched Kodi build. |
| **Widget Bridge** | Widgets never touch the reused instance; browsing keeps it. Rows load all at once, like any skin. Works on stock Kodi. |

---

## How it works

Widget Bridge is itself an ordinary video plugin with `reuselanguageinvoker` **off**. Every call to it therefore starts a fresh Python instance.
Inside that instance it loads the target add-on's code and runs it as if Kodi had called the add-on directly.

```
Skin row  ──►  plugin://plugin.video.widgetbridge/?_w=<plugin://plugin.video.redlight/?mode=...>
                     │  (fresh Python instance, reuse off)
                     ▼
               Widget Bridge sets up the environment Kodi would give Red Light
                     │
                     ▼
               Red Light's own entry script runs, lists its items into the bridge's handle
                     │
                     ▼
Row shows Red Light's items; their links still point at plugin://plugin.video.redlight/...
(so opening a folder or playing an item goes to Red Light itself, with its reuse)
```

### Addresses

| Address | What it does |
| --- | --- |
| `plugin://plugin.video.widgetbridge/` | Lists every enabled plugin add-on (video, music, program) — the starting point in a widget picker. |
| `…/?_b=1&_w=<target url>` | **Browse mode.** Runs the target and rewrites its *folder* links to bridge addresses, so a picker can keep walking down inside the bridge. |
| `…/?_w=<target url>` | **Widget mode.** Runs the target and leaves every link alone. This is what a row should be saved as. |

`<target url>` is the full `plugin://` address, percent-encoded with `quote(url, safe='')`. That also guarantees no comma ends up in the address,
which matters because skin builtins split their parameters on commas.

### Running the target exactly as Kodi would

`run_target()` in `default.py` reproduces what Kodi does when it starts a plugin:

1. **Find the add-on and its entry script.** The target's folder comes from `xbmcaddon.Addon(id).getAddonInfo('path')`, falling back to
   `special://home/addons` and `special://xbmc/addons`. The entry script is the `library` of its `xbmc.python.pluginsource` extension.
2. **`sys.argv`** is rebuilt the way `CScriptRunner::ExecuteScript` builds it:
   `[plugin://<id>/<path>, <handle>, ?<query>, resume:false]`. The handle is the bridge's own, so the target's `addDirectoryItem` /
   `endOfDirectory` calls land in the bridge's listing.
3. **`sys.path`** gets the folder of the target's **entry script** first, then the `lib` folders of every module it imports (its `<requires>`,
   followed down recursively; Kodi's own `xbmc.*` pseudo add-ons are skipped). This mirrors `CPythonInvoker` (`scriptDir`, then
   `getAddonModuleDeps`). The bridge's own folder is removed so nothing in it can shadow a module of the target.
4. **Kodi's modules answer for the target, not the bridge:**
   - `xbmcaddon.Addon()` with no id returns the target's add-on, so settings, profile folder (databases, tokens), path and strings are the target's.
   - `xbmcplugin.getSetting` / `setSetting` read and write the target's settings (Kodi would otherwise look them up from the handle, which belongs
     to the bridge).
   - `endOfDirectory` / `setResolvedUrl` are wrapped only to note that the target answered, so a failed target can still be closed cleanly.
5. **The entry script runs as `__main__`** (`_run_as_main`): compiled and executed in a fresh `__main__` module, as Kodi does.
6. **Widget mode only:** `xbmc.executebuiltin` is wrapped so the target cannot open Kodi's busy spinner (`ActivateWindow(busydialog)` /
   `busydialognocancel`, or window id 10138 / 10160); the call is skipped and noted in a debug log. A widget loads in the background, and a modal
   spinner over the skin's home takes every key press until the target closes it — never, if the target hangs or returns without closing it.
   Every other builtin goes through untouched. While you browse, the spinner is left alone.
7. **Browse mode only:** `addDirectoryItem` / `addDirectoryItems` are wrapped so that items marked as folders *of the target add-on* get a bridge
   browse address. Playable items, other add-ons' links and context-menu actions are never touched.
8. **Errors** are logged with a full traceback (`[Widget Bridge]` in `kodi.log`) and shown as a Kodi notification naming the add-on, instead of
   leaving the picker on a silently empty folder.

### Two bugs found while building it (worth knowing if this code is touched)

- **`runpy.run_path` must not be used.** It swaps `sys.argv[0]` for the script's file path while the script runs. Add-ons build their own links
  from `sys.argv[0]`, so every link came out as a file path. `_run_as_main` compiles and `exec`s the script instead.
- **The import path must start at the entry script's folder, not the add-on's top folder.** Fen Light–style add-ons keep their entry script and
  code in `resources/lib/`; with only the top folder on the path they failed to import their own modules, and the bridge showed an empty folder.

---

## Using it from a skin

**Any skin:** in its widget picker, go to Video add-ons › Widget Bridge › the add-on › its folders, and choose the folder you want. The saved
address is a browse address (`_b=1`), so a folder opened *from that widget* keeps going through the bridge (it works the same, just without the
add-on's reuse while browsing from that row). Playing an item always goes straight to the add-on.

**eXistenZ:** the row picker (`script.existenz.helper`, `_for_row`) drops `_b=1` when it saves a row, so the row is a widget address and opening a
folder from it goes straight to the real add-on, with its reuse. Sidebar and top-bar entries picked through the bridge are saved as the add-on's own
address (`_for_entry`), since those open a folder rather than load a row.

With the add-on's rows loaded through the bridge, eXistenZ's Skin Settings › Advanced › Widget Behavior can stay on **Normal** (all rows at once,
standard Kodi behaviour); **Safe** is only needed for reuse add-ons loaded directly.

---

## Performance

Measured on a Windows PC (Kodi 21.3) with eXistenZ, two pages of Red Light rows all loaded through the bridge:

- **36 bridge calls, no errors, and Kodi never reused an instance for any of them** — no "Reusing LanguageInvokerThread" in the log. Red Light
  playback started twice directly while bridge rows refreshed, without a crash.
- **A page switch went out immediately:** the first row request left about 2 ms after Select, and a 4-row page was loaded in about **1 second**.
- **One call on its own: about 0.21 s** in total (starting Python, the bridge, Red Light doing its work). **Several at once: 0.6–0.8 s each**,
  because the instances share the CPU — but the page as a whole finishes far sooner than with rows staggered half a second apart.

Where the cost goes:

- **The bridge itself** reads a few small `addon.xml` files and sets up the import path before handing over — a few milliseconds on a PC, more on
  a Chromecast-class box, and a small part of each call.
- **The real cost is not reusing an instance:** each widget call pays the Python start-up and the add-on's imports, exactly like any add-on that
  does not use `reuselanguageinvoker` (most add-ons). That is the price of rows not fighting over the one shared instance.
- **The first browse after Home loads starts cold:** Kodi's single reusable slot is released whenever a non-reuse call comes in, so widget calls
  push the add-on's warm instance out. From the second browse call on it is warm again.

A possible later optimisation: remember each add-on's module paths (for example in a Home window property) instead of reading the `addon.xml`
files on every call. Not worth it so far.

---

## Known limits

- An add-on that reads `Container.PluginName` to decide where it was opened from sees `plugin.video.widgetbridge` while you **browse** through the
  bridge (in a picker). On a widget it sees what any widget sees.
- An add-on that **subclasses** `xbmcaddon.Addon` gets a function in its place (the bridge replaces `Addon` with a function so that `Addon()`
  without an id answers for the target) and would fail.
- Anything an add-on keeps in module-level state *between* calls only survives with reuse. Through the bridge every call starts clean — the same as
  that add-on with reuse turned off.

---

## Files

| File | Purpose |
| --- | --- |
| `addon.xml` | Video plugin (`<provides>video</provides>`), `reuselanguageinvoker` explicitly **false**. |
| `default.py` | Everything: add-on list, browse / widget modes, running the target (`run_target`, `_patch_kodi_modules`, `_module_paths`, `_run_as_main`). |
| `resources/icon.png` | Icon. |
| `LICENSE.txt` | GPL-3.0. |

## Testing checklist

1. Install, then in a skin's widget picker browse Widget Bridge › an add-on with `reuselanguageinvoker` › several folders deep. Every level should
   list; a failure shows a notification naming the add-on.
2. Put several of its rows on one Home page and switch pages / start Kodi repeatedly. Look for `[Widget Bridge]` errors and confirm there is no
   "Reusing LanguageInvokerThread" for `plugin.video.widgetbridge` in a debug log.
3. Play items from a bridge row, and play while rows refresh — no crash.
4. Check the add-on's own settings, Trakt / debrid tokens and watched / progress marks show up in bridge rows (they come from the add-on's own
   profile folder).
