# -*- coding: utf-8 -*-
"""Widget Bridge: runs any add-on's plugin code in a fresh Python instance, for widgets / home rows.

Why. Kodi keeps ONE reusable Python instance for the whole system (CScriptInvocationManager::GetLanguageInvoker, Kodi 21). An add-on with
<reuselanguageinvoker>true</reuselanguageinvoker> has every call either grab that instance and reset it, or throw it away and start a new one. When a
skin loads several rows of that add-on at once, those grabs and resets land in the same instant - the crash eXistenZ's staggered row loading works around.
Whether to reuse is decided per add-on from its addon.xml only (CScriptRunner::ExecuteScript), never per call, so Kodi cannot leave widgets out by itself.
This add-on has reuse off: each widget call starts a fresh instance of Widget Bridge, which then runs the target add-on's own code inside it. The target
keeps reuse for browsing it directly; its widgets never touch the reused instance.

Addresses:
  plugin://plugin.video.widgetbridge/                       -> list of every enabled plugin add-on (video, music, program)
  plugin://plugin.video.widgetbridge/?_b=1&_w=<target url>  -> BROWSE: run the target url; its sub-folders are rewritten to bridge addresses, so you can
                                                               keep walking down inside the bridge (in a skin's widget picker)
  plugin://plugin.video.widgetbridge/?_w=<target url>       -> WIDGET: run the target url and leave its items alone, so opening a folder or playing an item
                                                               from the widget goes to the add-on itself (with its reuse). Pickers that know the bridge
                                                               (script.existenz.helper) drop the _b=1 when they save a row; any other skin's picker keeps it,
                                                               and folders opened from that widget simply keep going through the bridge.
<target url> is the full plugin:// address, percent-encoded (so it never carries a comma, which skin builtins would split on).

Running the target as Kodi would:
  - sys.argv = [plugin://<id>/<path>, handle, ?<query>, resume:false] (CScriptRunner::ExecuteScript)
  - sys.path gets the folder of the target's entry script and the lib folders of the modules it imports (addon.xml <requires>, followed down), as Kodi
    sets them for an add-on
  - xbmcaddon.Addon() with no id answers for the target, not for the bridge (settings, profile folder, path, strings); xbmcplugin.getSetting / setSetting too
  - its entry script (addon.xml pluginsource library) runs as __main__ (_run_as_main)
On a WIDGET call the target cannot open Kodi's busy spinner (ActivateWindow(busydialog / busydialognocancel)): a widget loads in the background, and
a modal spinner over the skin's home takes every key press until the target closes it again - forever, if the target hangs or forgets. While you browse
(_b=1) the spinner is left alone, since you are waiting on that folder anyway.
Limits: an add-on that reads Container.PluginName to know where it was opened from sees the bridge while you browse through it (on a widget it sees what any
widget sees); an add-on that subclasses xbmcaddon.Addon gets a function there instead of the class.
"""
import json
import os
import sys
import traceback
import types
import xml.etree.ElementTree as ET
from urllib.parse import parse_qsl, quote, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

SELF_ID = 'plugin.video.widgetbridge'
SELF_URL = 'plugin://%s/' % SELF_ID
HANDLE = int(sys.argv[1])
PARAMS = dict(parse_qsl(sys.argv[2].lstrip('?')))
ADDON_ROOTS = ('special://home/addons/', 'special://xbmc/addons/')
BUSY_WINDOWS = ('busydialog', 'busydialognocancel', '10138', '10160')  # Kodi's two busy spinners, by name and by window id


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[Widget Bridge] %s' % message, level)


def bridge_url(target_url, browse=True):
    """The bridge address for a target url; browse=True keeps rewriting sub-folders (see Addresses above)."""
    return '%s?%s_w=%s' % (SELF_URL, '_b=1&' if browse else '', quote(target_url, safe=''))


def _addon_dir(addon_id):
    """Folder of an installed add-on: from Kodi first (it knows where every enabled add-on is), else the two add-on folders on disk (a module that is
    installed but not enabled on its own, for example)."""
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        if path:
            return xbmcvfs.translatePath(path)
    except RuntimeError:
        pass
    for root in ADDON_ROOTS:
        folder = xbmcvfs.translatePath(root + addon_id)
        if os.path.isfile(os.path.join(folder, 'addon.xml')):
            return folder
    return None


def _manifest(folder):
    try:
        return ET.parse(os.path.join(folder, 'addon.xml')).getroot()
    except (ET.ParseError, OSError, TypeError) as error:
        log('cannot read addon.xml in %s: %s' % (folder, error), xbmc.LOGWARNING)
        return None


def _module_paths(manifest, seen):
    """Lib folders of the Python modules an add-on imports, followed down through their own imports (Kodi puts these on sys.path for the add-on).
    Kodi's own pseudo add-ons (xbmc.python, xbmc.gui ...) have no files and are skipped."""
    paths = []
    for dep in manifest.findall('./requires/import'):
        dep_id = dep.get('addon') or ''
        if not dep_id or dep_id.startswith('xbmc.') or dep_id in seen:
            continue
        seen.add(dep_id)
        folder = _addon_dir(dep_id)
        dep_manifest = _manifest(folder) if folder else None
        if dep_manifest is None:
            if dep.get('optional') != 'true':
                log('module %s not found' % dep_id, xbmc.LOGWARNING)
            continue
        for ext in dep_manifest.findall('extension'):
            if ext.get('point') == 'xbmc.python.module':
                paths.append(os.path.join(folder, ext.get('library') or 'lib'))
        paths += _module_paths(dep_manifest, seen)
    return paths


def _patch_kodi_modules(target_id, browse, state):
    """Make the Kodi modules answer for the target add-on; on a widget, keep it from opening Kodi's busy spinner; and (browse) send its sub-folders
    back through the bridge."""
    original_addon = xbmcaddon.Addon

    def addon(id=None, *args, **kwargs):  # same keyword as Kodi's: xbmcaddon.Addon(id='...')
        return original_addon(id or target_id)

    xbmcaddon.Addon = addon
    # these two look the add-on up from the plugin handle, which belongs to the bridge
    xbmcplugin.getSetting = lambda handle, id: original_addon(target_id).getSetting(id)
    xbmcplugin.setSetting = lambda handle, id, value: original_addon(target_id).setSetting(id, value)

    original_end = xbmcplugin.endOfDirectory
    original_resolved = xbmcplugin.setResolvedUrl

    def end_of_directory(*args, **kwargs):
        state['answered'] = True
        return original_end(*args, **kwargs)

    def set_resolved_url(*args, **kwargs):
        state['answered'] = True
        return original_resolved(*args, **kwargs)

    xbmcplugin.endOfDirectory = end_of_directory
    xbmcplugin.setResolvedUrl = set_resolved_url

    if not browse:
        original_builtin = xbmc.executebuiltin

        def execute_builtin(function, wait=False):
            command = (function or '').replace(' ', '').lower()
            if command.startswith('activatewindow(') and command[15:].rstrip(')').split(',')[0] in BUSY_WINDOWS:
                log('%s: left out %s (widgets load in the background)' % (target_id, function), xbmc.LOGDEBUG)
                return None
            return original_builtin(function, wait)

        xbmc.executebuiltin = execute_builtin
        return

    def wrap(url, is_folder):
        if is_folder and url and url.lower().startswith('plugin://') and urlsplit(url).netloc.lower() == target_id.lower():
            return bridge_url(url, browse=True)
        return url

    original_add = xbmcplugin.addDirectoryItem
    original_add_many = xbmcplugin.addDirectoryItems

    def add_directory_item(handle, url, listitem, isFolder=False, totalItems=0):
        return original_add(handle, wrap(url, isFolder), listitem, isFolder, totalItems)

    def add_directory_items(handle, items, totalItems=0):
        fixed = []
        for item in items:
            item = list(item)
            item[0] = wrap(item[0], len(item) > 2 and bool(item[2]))
            fixed.append(tuple(item))
        return original_add_many(handle, fixed, totalItems)

    xbmcplugin.addDirectoryItem = add_directory_item
    xbmcplugin.addDirectoryItems = add_directory_items


def _run_as_main(script):
    """Run the target's entry script as __main__, the way Kodi runs a plugin. Not runpy.run_path: that swaps sys.argv[0] for the script's file path while the
    script runs, and add-ons build their own links from sys.argv[0]."""
    with open(script, 'rb') as source:
        code = compile(source.read(), script, 'exec')
    main = types.ModuleType('__main__')
    main.__file__ = script
    main.__builtins__ = __builtins__
    sys.modules['__main__'] = main
    exec(code, main.__dict__)


def run_target(target_url, browse):
    target_id = urlsplit(target_url).netloc
    if not target_url.lower().startswith('plugin://') or not target_id or target_id.lower() == SELF_ID:
        log('not a plugin address this can run: %s' % target_url, xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    folder = _addon_dir(target_id)
    manifest = _manifest(folder) if folder else None
    entry = None
    if manifest is not None:
        for ext in manifest.findall('extension'):
            if ext.get('point') == 'xbmc.python.pluginsource':
                entry = ext.get('library')
                break
    if not entry:
        log('%s is not installed, or is not a Python plugin' % target_id, xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    base, _, query = target_url.partition('?')
    sys.argv = [base, str(HANDLE), ('?' + query) if query else '', 'resume:false']

    # the folder of the target's entry script first, then its modules - exactly what Kodi puts on sys.path for a plugin (CPythonInvoker: scriptDir, then
    # getAddonModuleDeps). Not the add-on's top folder: an add-on whose entry script sits in resources/lib imports its code from there. The bridge's own
    # folder comes off so nothing in it can shadow a module of the target.
    script = os.path.join(folder, entry)
    own = os.path.normcase(os.path.abspath(xbmcvfs.translatePath(xbmcaddon.Addon(SELF_ID).getAddonInfo('path'))))
    sys.path = [p for p in sys.path if os.path.normcase(os.path.abspath(p or '.')).rstrip(os.sep) != own.rstrip(os.sep)]
    extra = [os.path.dirname(script)] + _module_paths(manifest, {target_id})
    sys.path[0:0] = [p for p in extra if p not in sys.path]

    state = {'answered': False}
    _patch_kodi_modules(target_id, browse, state)
    try:
        _run_as_main(script)
    except SystemExit:
        pass
    except Exception as error:
        log('%s failed:\n%s' % (target_url, traceback.format_exc()), xbmc.LOGERROR)
        # shown, not only logged: otherwise a picker just finds an empty folder
        xbmcgui.Dialog().notification('Widget Bridge', '%s: %s' % (target_id, error), xbmcgui.NOTIFICATION_ERROR, 6000)
        if not state['answered']:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def list_addons():
    """Root: every enabled plugin add-on, each opening its own root through the bridge."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
               'params': {'type': 'xbmc.python.pluginsource', 'enabled': True, 'properties': ['name', 'thumbnail', 'fanart', 'summary']}}
    addons = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('addons', [])
    items = []
    for info in sorted(addons, key=lambda a: (a.get('name') or a['addonid']).lower()):
        if info['addonid'] == SELF_ID:
            continue
        item = xbmcgui.ListItem(info.get('name') or info['addonid'], offscreen=True)
        item.setArt({'icon': info.get('thumbnail', ''), 'thumb': info.get('thumbnail', ''), 'fanart': info.get('fanart', '')})
        item.getVideoInfoTag().setPlot(info.get('summary', ''))
        items.append((bridge_url('plugin://%s/' % info['addonid'], browse=True), item, True))
    xbmcplugin.addDirectoryItems(HANDLE, items, len(items))
    xbmcplugin.setContent(HANDLE, 'addons')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


if PARAMS.get('_w'):
    run_target(PARAMS['_w'], PARAMS.get('_b') == '1')
else:
    list_addons()
