# -*- coding: utf-8 -*-
# Module: widgetbridge
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Widget bridge: load another add-on's widget without going through its reused Python process.

Add-ons with reuselanguageinvoker=true can crash Kodi when several of their widgets load at once (home screen load,
skin reload): two requests race for the same reused interpreter. This add-on does NOT reuse its interpreter, so when
the skin routes a widget through here, each widget gets a fresh interpreter in which the target add-on's own plugin
code is run directly. Its directory items are added straight to this listing, and the items still point at the
target add-on, so opening or playing them goes back through the real add-on (and its fast reused interpreter).

Path format (the target path is passed raw after "&&", so it needs no extra encoding):
    plugin://script.shortfuse.helper/?info=widget_bridge&&plugin://plugin.video.example/?mode=list&page=1

This file is loaded by plugin.py on its own (not as part of the helper's "resources" package) so the target add-on
can import its own "resources" package without clashing with ours.
"""
import os
import sys
import traceback
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcvfs

LOG_PREFIX = '[script.shortfuse.helper] widget_bridge: '
HELPER_ID = 'script.shortfuse.helper'


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'{LOG_PREFIX}{msg}', level)


def get_target(paramstring):
    """ '?info=widget_bridge&&plugin://x/?a=1&b=2' -> 'plugin://x/?a=1&b=2' """
    return paramstring.partition('&&')[2]


def get_addon_root(addon_id):
    path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
    path = xbmcvfs.translatePath(path)
    return ET.parse(os.path.join(path, 'addon.xml')).getroot(), path


def get_entry_point(root, path):
    for ext in root.findall('extension'):
        if ext.get('point') == 'xbmc.python.pluginsource' and ext.get('library'):
            return os.path.join(path, ext.get('library'))


def get_module_paths(addon_id, seen=None):
    """ Library folders of an add-on's python module dependencies, the same ones Kodi would put on sys.path """
    seen = set() if seen is None else seen
    if not addon_id or addon_id in seen or addon_id.startswith('xbmc.') or addon_id.startswith('kodi.'):
        return []
    seen.add(addon_id)
    try:
        root, path = get_addon_root(addon_id)
    except Exception:  # Not installed / unreadable: Kodi would refuse to run the target anyway
        return []
    paths = [
        os.path.join(path, ext.get('library') or 'lib')
        for ext in root.findall('extension') if ext.get('point') == 'xbmc.python.module']
    for imp in root.findall('requires/import'):
        paths += get_module_paths(imp.get('addon'), seen)
    return paths


def run(handle, paramstring):
    target = get_target(paramstring)
    url = urlsplit(target)
    addon_id = url.netloc

    if url.scheme != 'plugin' or not addon_id or addon_id == HELPER_ID:
        log(f'not a bridgeable add-on path: {target}', xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)

    try:
        root, addon_path = get_addon_root(addon_id)
        entry = get_entry_point(root, addon_path)
        if not entry or not os.path.isfile(entry):
            raise ValueError(f'no plugin entry point for {addon_id}')
        dep_paths = get_module_paths(addon_id)
    except Exception as exc:
        log(f'cannot load {addon_id}: {exc}', xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(handle, succeeded=False)

    # Look like a normal Kodi call to the target: its folder first on sys.path, then its dependencies, none of ours
    helper_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    entry_dir = os.path.dirname(entry)
    sys.path[:] = [entry_dir] + dep_paths + [
        p for p in sys.path if p and not os.path.abspath(p).startswith(helper_root)]
    # No os.chdir() into the target's folder: the working directory belongs to the whole kodi.exe process, not this script,
    # and Kodi never sets it for add-ons. Left pointing into an add-on folder, Windows refuses to move that folder, so
    # Kodi's update of that add-on fails ("Failed to move old addon files") and the add-on disappears until restored.
    sys.argv = [f'plugin://{addon_id}{url.path or "/"}', str(handle), f'?{url.query}' if url.query else '', 'resume:false']

    # xbmcaddon.Addon() with no id would resolve to this helper (the running add-on); point it at the target instead
    real_addon = xbmcaddon.Addon

    def bridged_addon(id=None, *args, **kwargs):
        return real_addon(id or addon_id, *args, **kwargs)

    xbmcaddon.Addon = bridged_addon

    # Make sure the widget always gets an answer, even if the target errors out before finishing its directory
    real_end = xbmcplugin.endOfDirectory
    finished = []

    def bridged_end(*args, **kwargs):
        finished.append(True)
        return real_end(*args, **kwargs)

    xbmcplugin.endOfDirectory = bridged_end

    log(f'{addon_id} -> {target}')
    try:
        # Not runpy.run_path: it replaces sys.argv[0] (the plugin:// base the add-on builds its item URLs from)
        with open(entry, 'rb') as f:
            code = compile(f.read(), entry, 'exec')
        exec(code, {'__name__': '__main__', '__file__': entry, '__builtins__': __builtins__})
    except SystemExit:
        pass
    except Exception:
        log(f'{addon_id} raised while building the widget:\n{traceback.format_exc()}', xbmc.LOGERROR)
    finally:
        if not finished:
            real_end(handle, succeeded=False)
