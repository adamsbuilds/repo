# -*- coding: utf-8 -*-
# Module: default
# Author: jurialmunkey (script.shortfuse.helper), forked into script.shortfuse.helper by adamsbuilds
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import os
import sys

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))


def run_widget_bridge():
    """ Load resources/lib/widgetbridge.py on its own, without importing this add-on's "resources" package,
    so the bridged add-on can import its own modules (many are also called "resources") without a clash """
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        '_shortfuse_widgetbridge', os.path.join(ADDON_DIR, 'resources', 'lib', 'widgetbridge.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.run(int(sys.argv[1]), sys.argv[2])


if __name__ == '__main__':
    if sys.argv[2].startswith('?info=widget_bridge'):
        run_widget_bridge()
    else:
        # The jurialmunkey and infotagger libraries are bundled in resources/modules instead of separate add-ons
        sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'modules'))
        from resources.lib.plugin import Plugin
        Plugin(int(sys.argv[1]), sys.argv[2][1:]).run()
