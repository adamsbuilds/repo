# script.shortfuse.helper — licence and modification notice

Licence: GNU General Public License v3.0 or later (see `LICENSE.txt`).

This add-on is a modified, combined version of the following GPL-3.0-or-later works by **jurialmunkey**.
Their original author headers are kept in every source file.

| Original add-on | Version | Source |
|---|---|---|
| script.skinvariables | 2.2.9 | https://github.com/jurialmunkey/script.skinvariables |
| script.texturemaker (colour swatch list only) | 0.2.11 | https://github.com/jurialmunkey/script.texturemaker |
| script.module.jurialmunkey | 0.2.35 | https://github.com/jurialmunkey/script.module.jurialmunkey |
| script.module.infotagger | 0.1.0 | https://github.com/jurialmunkey/script.module.infotagger |

## Modifications by adamsbuilds (October 2026)
- Combined into one add-on, `script.shortfuse.helper`. jurialmunkey and infotagger are bundled in
  `resources/modules` and loaded from `script.py` / `plugin.py`.
- All add-on IDs and addon_data paths changed to `script.shortfuse.helper`.
- Removed `jurialmunkey/reqapi.py` (TMDb web API helper; unused, and it needed script.module.requests).
- Replaced script.texturemaker's PIL-based swatch generator with `resources/lib/lists/colorswatches.py`.
  It serves pre-rendered swatches, so script.module.pil is not required.
- Added the `get_color_swatches` plugin route. Renamed the shortcut picker's progress dialog title.
- Added `resources/lib/searchproviders.py` (new code by adamsbuilds) and the `set_search_provider` script route.
- Added `resources/lib/spotlight.py` (new code by adamsbuilds) and the `check_spotlight` script route.
- Added `resources/lib/widgetbridge.py` (new code by adamsbuilds) and the `info=widget_bridge` plugin route;
  `plugin.py` loads it on its own, before the rest of the helper.
- New `icon.png` and `fanart.jpg`.

This is an independent fork. It is not endorsed or supported by jurialmunkey.
The complete corresponding source code is the add-on itself (plain Python), as published in the adamsbuilds repository.
