# -*- coding: utf-8 -*-
# Module: reloadskin
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
One gate for every ReloadSkin() the skin or helper asks for.

Several things can want a reload from the same Home load (first-run setup, the shortcut template build,
the view rebuild, the variables generator). Fired independently they race each other, and a reload that lands
while another script's modal progress dialog is open - or over Kodi's own "keep this skin?" / "switch skin?"
prompt - deadlocks the GUI and Kodi has to be force closed.

So builders mark themselves busy with building(), wait for Kodi's prompts with wait_for_idle() before they
start, and ask for the reload with request_reload(). The first request takes the gate; later ones fold into it.
The gate holder waits for every builder to finish and every blocking dialog to close, checks Short Fuse is
still the active skin (the user may have said No to keeping it), then reloads once.
"""
import uuid
import xbmc
import xbmcgui
from contextlib import contextmanager

SKIN_ID = 'skin.shortfuse'
HOME = 10000
PROP_GATE = 'ShortFuse.ReloadGate'
PROP_BUILDING = 'ShortFuse.Building.{}'
BUILDERS = ('Views', 'Template', 'Variables')

# Dialogs a reload must never land on: Kodi's own skin prompts (yesno), and modal Python dialogs from any script.
COND_BLOCKING_DIALOG = (
    'Window.IsVisible(yesnodialog) | Window.IsVisible(okdialog) | Window.IsVisible(progressdialog) | '
    'Window.IsVisible(selectdialog) | Window.IsVisible(virtualkeyboard) | Window.IsVisible(numericinput)')

GRACE = 1.0  # Lets builders started from the same onload register as busy before the gate looks
TIMEOUT = 120


def _home():
    return xbmcgui.Window(HOME)


def is_active_skin():
    return xbmc.getSkinDir() == SKIN_ID


def is_blocked():
    return xbmc.getCondVisibility(COND_BLOCKING_DIALOG)


def is_building(skip=None):
    home = _home()
    return any(home.getProperty(PROP_BUILDING.format(i)) for i in BUILDERS if i != skip)


def wait_for_idle(builder=None, timeout=TIMEOUT, monitor=None):
    """ Wait for blocking dialogs (and other builders unless builder is None) to clear. False on abort/timeout/skin gone. """
    monitor = monitor or xbmc.Monitor()
    waited = 0.0
    while is_blocked() or (builder is not None and is_building(skip=builder)):
        if waited >= timeout or monitor.waitForAbort(0.25):
            return False
        waited += 0.25
    return is_active_skin()


@contextmanager
def building(name):
    """ Mark a builder busy for the gate. Always cleared, even if the build throws. """
    home = _home()
    home.setProperty(PROP_BUILDING.format(name), 'True')
    try:
        yield
    finally:
        home.clearProperty(PROP_BUILDING.format(name))


def _take_gate(monitor):
    """ Returns this request's token if it now holds the gate, else None. """
    home = _home()
    if home.getProperty(PROP_GATE):
        return None  # A reload is already queued and will include our changes
    token = uuid.uuid4().hex
    home.setProperty(PROP_GATE, token)
    monitor.waitForAbort(0.1)
    return token if home.getProperty(PROP_GATE) == token else None  # Same-instant requests: last writer wins, the other folds in


def _release_gate(token):
    home = _home()
    if home.getProperty(PROP_GATE) == token:
        home.clearProperty(PROP_GATE)


def request_reload(**kwargs):
    """ Reload the skin once it is safe. Returns True if this call performed the reload. """
    monitor = xbmc.Monitor()
    token = _take_gate(monitor)
    if not token:
        return False
    try:
        if monitor.waitForAbort(GRACE):
            return False
        waited = 0.0
        while is_building() or is_blocked():
            if waited >= TIMEOUT or monitor.waitForAbort(0.25):
                xbmc.log(f'[{SKIN_ID}] reload skipped: still busy after {TIMEOUT}s, changes load on next start', xbmc.LOGWARNING)
                return False
            waited += 0.25
        if not is_active_skin():
            return False  # User reverted to another skin while we waited
        _release_gate(token)  # Release first so a builder starting after this reload can queue its own
        xbmc.executebuiltin('ReloadSkin()')
        return True
    finally:
        _release_gate(token)
