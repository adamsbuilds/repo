# -*- coding: utf-8 -*-
# Module: default
# Author: jurialmunkey
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
from jurialmunkey.modimp import importmodule


class Script(object):
    def __init__(self, *args, paramstring=None):
        def map_args(arg):
            if '=' in arg:
                key, value = arg.split('=', 1)
                value = value.strip('\'').strip('"') if value else None
                return (key, value)
            return (arg, True)

        self.params = {}

        if paramstring:
            args = [i for i in args] + paramstring.split('&')

        for arg in args:
            k, v = map_args(arg)
            self.params[k] = v

    routing_table = {
        'set_animation':
            lambda **kwargs: importmodule('resources.lib.method', 'set_animation')(**kwargs),
        'set_slider':
            lambda **kwargs: importmodule('resources.lib.method', 'set_slider')(**kwargs),
        'run_executebuiltin':
            lambda **kwargs: importmodule('resources.lib.method', 'run_executebuiltin')(**kwargs),
        'run_dialog':
            lambda **kwargs: importmodule('resources.lib.method', 'run_dialog')(**kwargs),
        'run_progressdialog':
            lambda **kwargs: importmodule('resources.lib.method', 'run_progressdialog')(**kwargs),
        'run_selectfocusdialog':
            lambda **kwargs: importmodule('resources.lib.method', 'run_selectfocusdialog')(**kwargs),
        'set_player_subtitle':
            lambda **kwargs: importmodule('resources.lib.method', 'set_player_subtitle')(**kwargs),
        'set_player_audiostream':
            lambda **kwargs: importmodule('resources.lib.method', 'set_player_audiostream')(**kwargs),
        'set_editcontrol':
            lambda **kwargs: importmodule('resources.lib.method', 'set_editcontrol')(**kwargs),
        'set_dbid_tag':
            lambda **kwargs: importmodule('resources.lib.method', 'set_dbid_tag')(**kwargs),
        'get_jsonrpc':
            lambda **kwargs: importmodule('resources.lib.method', 'get_jsonrpc')(**kwargs),
        'add_skinstring_history':
            lambda **kwargs: importmodule('resources.lib.method', 'add_skinstring_history')(**kwargs),
        'set_search_provider':
            lambda **kwargs: importmodule('resources.lib.searchproviders', 'set_search_provider')(**kwargs),
        'check_spotlight':
            lambda **kwargs: importmodule('resources.lib.spotlight', 'check_spotlight')(**kwargs),
        'set_shortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.method', 'set_shortcut')(**kwargs),
        'copy_menufile':
            lambda **kwargs: importmodule('resources.lib.shortcuts.method', 'copy_menufile')(**kwargs),
        'copy_menufolder':
            lambda **kwargs: importmodule('resources.lib.shortcuts.method', 'copy_menufolder')(**kwargs),
        'set_listitem_to_menunode':
            lambda **kwargs: importmodule('resources.lib.shortcuts.method', 'set_listitem_to_menunode')(**kwargs),
        'add_skinshortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.skinshortcuts', 'get_skinshortcuts_menu')(route='add_skinshortcut', **kwargs),
        'del_skinshortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.skinshortcuts', 'get_skinshortcuts_menu')(route='del_skinshortcut', **kwargs),
        'mod_skinshortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.skinshortcuts', 'get_skinshortcuts_menu')(route='mod_skinshortcut', **kwargs),
        'imp_skinshortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.skinshortcuts', 'get_skinshortcuts_menu')(route='imp_skinshortcut', **kwargs),
        'mov_skinshortcut':
            lambda **kwargs: importmodule('resources.lib.shortcuts.skinshortcuts', 'get_skinshortcuts_menu')(route='mov_skinshortcut', **kwargs),
    }

    def run(self):
        if not self.params:
            return
        routes_available, params_given = set(self.routing_table.keys()), set(self.params.keys())
        try:
            route_taken = set.intersection(routes_available, params_given).pop()
        except KeyError:
            return self.router()
        return self.routing_table[route_taken](**self.params)

    def router(self):
        # Builders wait out Kodi's skin prompts (switch / keep this skin?) before they open dialogs or write files,
        # stay marked busy so the reload gate waits for them, and reload through the gate - never directly.
        # The skin raises the same busy flag right before RunScript (Python can take a second to start on slow
        # boxes); building() keeps it up for the whole run and clears it on every exit path.
        from resources.lib.reloadskin import wait_for_idle, building, request_reload

        if self.params.get('action') == 'reloadskin':
            return request_reload()

        if self.params.get('action') == 'buildviews':
            with building('Views'):
                if not wait_for_idle():
                    return
                from resources.lib.viewtypes import ViewTypes
                reload = ViewTypes().update_xml(skinfolder=self.params.get('folder'), **self.params)
            return request_reload() if reload else None

        if self.params.get('action') == 'buildtemplate':
            with building('Template'):
                if not wait_for_idle():
                    return
                from resources.lib.shortcuts.template import ShortcutsTemplate
                reload = ShortcutsTemplate(template=self.params.get('template')).update_xml(**self.params)
            return request_reload() if reload else None

        with building('Variables'):
            if not wait_for_idle():
                return
            from resources.lib.skinvariables import SkinVariables
            reload = SkinVariables(template=self.params.get('template'), skinfolder=self.params.get('folder')).update_xml(**self.params)
        return request_reload() if reload else None
