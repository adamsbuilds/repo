# -*- coding: utf-8 -*-
# Module: searchproviders
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Search providers for the Short Fuse search window (same idea as Nimbus Plus' search providers).

Providers are defined in the skin's shortcuts/searchproviders.json, plus optional user additions in
special://profile/addon_data/script.shortfuse.helper/searchproviders.json (same layout, merged on top).

Choosing a provider writes its search paths into skin strings that the skin's search rows read:
    Skin.String(Search.Provider)            provider id
    Skin.String(Search.Provider.Name)       display name
    Skin.String(Search.Provider.<category>) path up to the search parameter, e.g. ...&query=

RunScript(script.shortfuse.helper,set_search_provider)            -> select dialog
RunScript(script.shortfuse.helper,set_search_provider,provider=X) -> set provider X directly
RunScript(script.shortfuse.helper,set_search_provider,refresh)    -> re-apply the current provider (startup)
"""
import json
import xbmc
import xbmcgui
import xbmcvfs

CATEGORIES = (
    'movies', 'tvshows', 'anime', 'collections', 'people', 'people_movies', 'people_tvshows',
    'keywords_movies', 'keywords_tvshows', 'trakt_lists', 'trakt_lists_movies', 'trakt_lists_tvshows')
SKIN_FILE = 'special://skin/shortcuts/searchproviders.json'
USER_FILE = 'special://profile/addon_data/script.shortfuse.helper/searchproviders.json'
PREFIX = 'Search.Provider'


def _load(path):
    path = xbmcvfs.translatePath(path)
    if not xbmcvfs.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return (json.load(f) or {}).get('providers') or {}
    except (OSError, ValueError, AttributeError):
        xbmc.log(f'[script.shortfuse.helper] could not read search providers from {path}', xbmc.LOGWARNING)
        return {}


def get_providers():
    providers = _load(SKIN_FILE)
    providers.update(_load(USER_FILE))
    return providers


def _is_installed(provider):
    addon = provider.get('addon')
    return not addon or xbmc.getCondVisibility(f'System.HasAddon({addon}) + System.AddonIsEnabled({addon})')


def _set_string(key, value):
    if value:
        xbmc.executebuiltin(f'Skin.SetString({key},"{value}")')
    else:
        xbmc.executebuiltin(f'Skin.Reset({key})')


def apply_provider(provider_id, providers=None):
    providers = providers if providers is not None else get_providers()
    provider = providers.get(provider_id) if provider_id else None
    paths = (provider or {}).get('paths') or {}
    _set_string(PREFIX, provider_id if provider else '')
    _set_string(f'{PREFIX}.Name', (provider or {}).get('name', ''))
    for category in CATEGORIES:
        _set_string(f'{PREFIX}.{category}', paths.get(category, ''))


def set_search_provider(provider=None, refresh=None, **kwargs):
    providers = get_providers()

    if refresh:  # Keep the stored paths in step with the json after a skin update
        current = xbmc.getInfoLabel(f'Skin.String({PREFIX})')
        if current:
            apply_provider(current if current in providers else '', providers)
        return

    if provider:
        return apply_provider(provider if provider != 'none' else '', providers)

    current = xbmc.getInfoLabel(f'Skin.String({PREFIX})')
    ids = sorted(providers, key=lambda k: providers[k].get('name', k).lower())
    items = [xbmcgui.ListItem('None', 'Library search only')]
    for i in ids:
        p = providers[i]
        cats = ', '.join(k.replace('_', ' ') for k in CATEGORIES if (p.get('paths') or {}).get(k))
        label = p.get('name', i) if _is_installed(p) else f"[COLOR grey]{p.get('name', i)} (not installed)[/COLOR]"
        items.append(xbmcgui.ListItem(label, cats))
    preselect = ids.index(current) + 1 if current in ids else 0
    x = xbmcgui.Dialog().select('Search provider', items, preselect=preselect, useDetails=True)
    if x == -1:
        return
    apply_provider(ids[x - 1] if x > 0 else '', providers)
