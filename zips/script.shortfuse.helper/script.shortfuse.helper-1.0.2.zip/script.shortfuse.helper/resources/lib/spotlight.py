# -*- coding: utf-8 -*-
# Module: spotlight
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Empty-spotlight fallback for Short Fuse hubs.

On load a hub with a spotlight makes the spotlight (list 301) the active row and focuses its buttons (group 310)
before the list has loaded. If the list then comes back empty (e.g. the default library playlist with no library),
the buttons hide and nothing visible has focus. This waits for the list to finish loading and, only if it is empty,
makes the widgets the active row and moves focus to the first visible widget.

RunScript(script.shortfuse.helper,check_spotlight,window=Home)
"""
import xbmc

SPOTLIGHT_LIST = 301
SPOTLIGHT_GROUP = 310
WIDGET_IDS = (601, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510)  # same order as $VAR[Hub_Action_Widgets]
FALLBACK_FOCUS = 300  # menu
DEFAULT_WIDGET_CONTAINER = 501  # what the hub onload uses when there is no spotlight
MIN_WAIT = 2.0  # the list only reports IsUpdating once Kodi starts fetching it, so don't call it empty too early
TIMEOUT = 30.0
POLL = 0.1


def _cond(condition):
    return xbmc.getCondVisibility(condition)


def check_spotlight(window='Home', **kwargs):
    monitor = xbmc.Monitor()
    elapsed, seen_updating = 0.0, False

    while elapsed < TIMEOUT:
        if monitor.waitForAbort(POLL):
            return
        elapsed += POLL
        if not _cond(f'Window.IsActive({window})'):
            return
        if not _cond(f'Integer.IsEqual(Container({SPOTLIGHT_LIST}).NumItems,0)'):
            return  # spotlight has items, nothing to do
        if _cond(f'Container({SPOTLIGHT_LIST}).IsUpdating'):
            seen_updating = True
            continue
        if seen_updating or elapsed >= MIN_WAIT:
            break  # finished loading (or never started) with no items
    else:
        return  # still loading after TIMEOUT, leave it alone

    if xbmc.getInfoLabel(f'Window({window}).Property(AF3.WidgetContainer)') == str(SPOTLIGHT_LIST):
        xbmc.executebuiltin(f'SetProperty(AF3.WidgetContainer,{DEFAULT_WIDGET_CONTAINER},{window})')

    if not _cond(f'ControlGroup({SPOTLIGHT_GROUP}).HasFocus() | Control.HasFocus({SPOTLIGHT_LIST})'):
        return  # user has already moved somewhere else
    target = next((i for i in WIDGET_IDS if _cond(f'Control.IsVisible({i})')), FALLBACK_FOCUS)
    xbmc.executebuiltin(f'SetFocus({target})')
