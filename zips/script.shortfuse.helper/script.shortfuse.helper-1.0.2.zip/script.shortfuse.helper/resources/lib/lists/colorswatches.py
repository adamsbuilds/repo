# -*- coding: utf-8 -*-
# Module: default
# Author: jurialmunkey (script.texturemaker), forked into script.shortfuse.helper by adamsbuilds
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
plugin://script.shortfuse.helper/?info=get_color_swatches[&file=path/in/skin/colors.json]

Lists colours as label (aarrggbb) / label2 (colordiffuse value).
Replaces script.texturemaker's swatch list. The default palette ships with pre-rendered 16x16
swatch images, so PIL is no longer needed; a custom palette from the skin lists without images.
"""
import os
import json
import xbmcvfs
import xbmcaddon
from jurialmunkey.litems import ContainerDirectory

ADDONPATH = xbmcaddon.Addon().getAddonInfo('path')
COLORDEFS = os.path.join(ADDONPATH, 'resources', 'colors', 'colors.json')
SWATCHES = os.path.join(ADDONPATH, 'resources', 'colors', 'swatches')


class ListGetColorSwatches(ContainerDirectory):
    def get_directory(self, file=None, **kwargs):
        filename = xbmcvfs.translatePath(f'special://skin/{file}') if file else COLORDEFS
        try:
            with open(filename, 'r') as f:
                colors = json.load(f) or {}
        except (OSError, ValueError):
            colors = {}
        colors = colors or {'ffffffff': 'ffffffff'}

        items = []
        for k, v in colors.items():
            swatch = os.path.join(SWATCHES, f'{k}.png')
            items.append(self.get_list_item(k, v, swatch if os.path.exists(swatch) else '', is_folder=False))
        self.add_items(items)
