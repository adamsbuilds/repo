# -*- coding: utf-8 -*-
# Module: ratings
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Online ratings for Short Fuse - what TMDbHelper's service used to provide for the skin's rating slots.

If no MDbList or OMDb API key is set (Skin Settings > Details > Ratings) when Kodi starts, the service exits straight away
so it costs nothing; a key entered later takes effect after a Kodi restart (the skin says so while ShortFuse.Ratings.Running
is unset). While running and Short Fuse is the active skin, it follows the focused item (and the playing video) and sets
Window(Home) properties:

    ShortFuse.ListItem.<Name> / ShortFuse.Player.<Name>
    IMDb_Rating  IMDb_Votes  TMDb_Rating  Trakt_Rating  MetaCritic_Rating  RottenTomatoes_Rating  RottenTomatoes_UserMeter
    RottenTomatoes_Image  MDBList_Rating  Letterboxd_Rating  MyAnimeList_Rating  Oscar_Wins  Awards  HasRatings

The skin shows the item's own Kodi rating first where it has one (ListItem.Rating(imdb|tmdb|trakt)) and these as fallback.

Items are matched by IMDb / TMDb id (ListItem.UniqueID, IMDBNumber, the usual add-on properties, or the library TV show
for seasons and episodes); OMDb can fall back to title + year. Lookups wait for focus to settle, run on one worker thread,
and are cached on disk (hits 7 days, misses 1 day), so scrolling a widget does not hammer either API.
"""
import json
import os
import re
import ssl
import threading
import time
import xbmc
import xbmcgui
import xbmcvfs
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

SKIN_ID = 'skin.shortfuse'
HOME = 10000
PROPERTY = 'ShortFuse.{}.{}'
STATUS = 'ShortFuse.Ratings.Status'
STATUS_SOURCE = 'ShortFuse.Ratings.Status.Source'
RUNNING = 'ShortFuse.Ratings.Running'  # Set while the service runs; the skin shows "restart Kodi" for a key saved without it
FOCUS_CONTAINER = 'Window.Property(AF3.WidgetContainer)'
KEY_MDBLIST = 'Skin.String(Ratings.MDbList.APIKey)'
KEY_OMDB = 'Skin.String(Ratings.OMDb.APIKey)'

RATING_KEYS = (
    'IMDb_Rating', 'TMDb_Rating', 'Trakt_Rating', 'MetaCritic_Rating', 'RottenTomatoes_Rating',
    'RottenTomatoes_UserMeter', 'MDBList_Rating', 'Letterboxd_Rating', 'MyAnimeList_Rating', 'Oscar_Wins')
ALL_KEYS = RATING_KEYS + ('IMDb_Votes', 'RottenTomatoes_Image', 'Awards', 'HasRatings')

POLL = 0.25         # Focus check interval while active
DEBOUNCE = 0.35     # Focus must sit still this long before a lookup
TTL_HIT = 7 * 86400
TTL_MISS = 86400
CACHE_MAX = 3000
CACHE_SAVE = 60     # Seconds between cache writes when it has changed
BACKOFF = 600       # Seconds a source is left alone after a rate limit or network failure
TIMEOUT = 10
USER_AGENT = 'script.shortfuse.helper (Kodi)'

# ListItem.* means the info dialog's item while one is open; otherwise the skin's focus-tracking container, as TMDbHelper did.
CV_USE_LISTITEM = (
    'Window.IsVisible(movieinformation) | Window.IsVisible(addoninformation) | '
    'Window.IsVisible(pvrguideinfo) | Window.IsVisible(tvchannels) | Window.IsVisible(tvguide)')
CV_PAUSE = 'System.ScreenSaverActive | [Window.IsActive(fullscreenvideo) + !Window.IsVisible(videoosd) + !Window.IsVisible(DialogFullScreenInfo.xml)]'

MOVIE_TYPES = ('movie', )
TV_TYPES = ('tvshow', 'season', 'episode')


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[script.shortfuse.helper] ratings: {msg}', level)


def _num(value):
    try:
        value = str(value).replace(',', '').replace('%', '').strip()
        return float(value) if value and value.upper() != 'N/A' else None
    except (TypeError, ValueError):
        return None


def _ten(value):
    """ Score out of 10 with one decimal. Accepts 0-10 or 0-100 (MDbList gives TMDb / Trakt as percentages). """
    value = _num(value)
    if not value:
        return None
    return f'{value / 10 if value > 10 else value:.1f}'


def _pct(value):
    value = _num(value)
    return str(int(round(value))) if value else None


def _dec(value):
    value = _num(value)
    return f'{value:.1f}' if value else None


def _set(out, key, value):
    if value and not out.get(key):
        out[key] = value


# ---------------------------------------------------------------- APIs

class SourceError(Exception):
    def __init__(self, source, message, backoff=False):
        super().__init__(message)
        self.source, self.message, self.backoff = source, message, backoff


def _ssl_contexts():
    yield None  # Default context: honours SSL_CERT_FILE, which Kodi sets on Android/Windows/macOS
    try:
        import certifi
        yield ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    bundle = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
    if os.path.exists(bundle):
        yield ssl.create_default_context(cafile=bundle)


def get_json(source, url):
    request = Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'})
    last_error = None
    for context in _ssl_contexts():
        try:
            with urlopen(request, timeout=TIMEOUT, context=context) as response:
                return json.loads(response.read().decode('utf-8'))
        except HTTPError as exc:
            if exc.code in (401, 403):
                raise SourceError(source, 'Invalid API key')
            if exc.code == 429:
                raise SourceError(source, 'Daily limit reached', backoff=True)
            if exc.code == 404:
                return None
            raise SourceError(source, f'HTTP {exc.code}', backoff=exc.code >= 500)
        except URLError as exc:
            last_error = exc
            if isinstance(getattr(exc, 'reason', None), ssl.SSLError):
                continue  # Try the next certificate bundle
            break
        except ssl.SSLError as exc:
            last_error = exc
            continue
        except (ValueError, OSError) as exc:
            last_error = exc
            break
    raise SourceError(source, f'Network error ({last_error})', backoff=True)


def mdblist(api_key, mtype, imdb=None, tmdb=None):
    provider, media_id = ('imdb', imdb) if imdb else ('tmdb', tmdb)
    kind = 'movie' if mtype in MOVIE_TYPES else 'show'
    query = urlencode({'apikey': api_key, 'append_to_response': 'keyword'})
    data = get_json('MDbList', f'https://api.mdblist.com/{provider}/{kind}/{media_id}?{query}')
    if not isinstance(data, dict) or data.get('error'):
        if isinstance(data, dict) and 'api' in str(data.get('error', '')).lower():
            raise SourceError('MDbList', 'Invalid API key')
        return {}, None

    out = {}
    for rating in data.get('ratings') or []:
        source, value = rating.get('source'), rating.get('value')
        if source == 'imdb':
            _set(out, 'IMDb_Rating', _dec(value))
            _set(out, 'IMDb_Votes', _pct(rating.get('votes')))
        elif source == 'tmdb':
            _set(out, 'TMDb_Rating', _ten(value))
        elif source == 'trakt':
            _set(out, 'Trakt_Rating', _ten(value))
        elif source == 'metacritic':
            _set(out, 'MetaCritic_Rating', _pct(value))
        elif source == 'tomatoes':
            _set(out, 'RottenTomatoes_Rating', _pct(value))
        elif source in ('popcorn', 'tomatoesaudience'):
            _set(out, 'RottenTomatoes_UserMeter', _pct(value))
        elif source == 'letterboxd':
            _set(out, 'Letterboxd_Rating', _dec(value))  # Out of 5
        elif source == 'myanimelist':
            _set(out, 'MyAnimeList_Rating', _dec(value))
    _set(out, 'MDBList_Rating', _pct(data.get('score')))

    keywords = {(k.get('name') or '').lower() for k in data.get('keywords') or [] if isinstance(k, dict)}
    for keyword, image in (('certified-fresh', 'certified'), ('fresh', 'fresh'), ('rotten', 'rotten')):
        if keyword in keywords:
            out['RottenTomatoes_Image'] = image
            break

    found_imdb = (data.get('ids') or {}).get('imdb') or data.get('imdbid')
    return out, found_imdb


def omdb(api_key, mtype, imdb=None, title=None, year=None):
    params = {'apikey': api_key, 'tomatoes': 'true'}
    if imdb:
        params['i'] = imdb
    elif title:
        params['t'] = title
        params['type'] = 'movie' if mtype in MOVIE_TYPES else 'series'
        if year:
            params['y'] = year
    else:
        return {}, None
    data = get_json('OMDb', f'https://www.omdbapi.com/?{urlencode(params)}')
    if not isinstance(data, dict):
        return {}, None
    if data.get('Response') == 'False':
        error = data.get('Error') or ''
        if 'api key' in error.lower():
            raise SourceError('OMDb', 'Invalid API key')
        if 'limit' in error.lower():
            raise SourceError('OMDb', 'Daily limit reached', backoff=True)
        return {}, None

    out = {}
    _set(out, 'IMDb_Rating', _dec(data.get('imdbRating')))
    _set(out, 'IMDb_Votes', _pct(data.get('imdbVotes')))
    _set(out, 'MetaCritic_Rating', _pct(data.get('Metascore')))
    for rating in data.get('Ratings') or []:
        if rating.get('Source') == 'Rotten Tomatoes':
            _set(out, 'RottenTomatoes_Rating', _pct(rating.get('Value')))
    _set(out, 'RottenTomatoes_Rating', _pct(data.get('tomatoMeter')))
    _set(out, 'RottenTomatoes_UserMeter', _pct(data.get('tomatoUserMeter')))
    image = (data.get('tomatoImage') or '').lower()
    if image in ('certified', 'fresh', 'rotten'):
        _set(out, 'RottenTomatoes_Image', image)
    awards = data.get('Awards') or ''
    if awards and awards.upper() != 'N/A':
        out['Awards'] = awards
        oscars = re.search(r'Won (\d+) Oscars?', awards)
        _set(out, 'Oscar_Wins', oscars.group(1) if oscars else None)
    found_imdb = data.get('imdbID') if str(data.get('imdbID', '')).startswith('tt') else None
    return out, found_imdb


# ---------------------------------------------------------------- Cache

class Cache(object):
    def __init__(self):
        folder = xbmcvfs.translatePath('special://profile/addon_data/script.shortfuse.helper/')
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        self.path = os.path.join(folder, 'ratings_cache.json')
        self.lock = threading.Lock()
        self.dirty = False
        self.saved = time.time()
        try:
            with open(self.path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        except Exception:
            self.data = {}

    def get(self, key):
        with self.lock:
            entry = self.data.get(key)
        if not entry:
            return None
        stamp, value = entry
        if time.time() - stamp > (TTL_HIT if value else TTL_MISS):
            return None
        return value

    def put(self, key, value):
        with self.lock:
            self.data[key] = [time.time(), value]
            self.dirty = True

    def save(self, force=False):
        if not self.dirty or (not force and time.time() - self.saved < CACHE_SAVE):
            return
        with self.lock:
            now = time.time()
            items = [(k, v) for k, v in self.data.items() if now - v[0] <= (TTL_HIT if v[1] else TTL_MISS)]
            items = sorted(items, key=lambda kv: kv[1][0])[-CACHE_MAX:]
            self.data = dict(items)
            self.dirty = False
            self.saved = now
            snapshot = json.dumps(self.data)
        try:
            with open(self.path + '.tmp', 'w', encoding='utf-8') as f:
                f.write(snapshot)
            os.replace(self.path + '.tmp', self.path)
        except Exception as exc:
            log(f'cache save failed: {exc}', xbmc.LOGWARNING)


# ---------------------------------------------------------------- Item reading

def _label(prefix, name):
    return xbmc.getInfoLabel(f'{prefix}{name}')


def _first(prefix, names, test=None):
    for name in names:
        value = _label(prefix, name)
        if value and (test is None or test(value)):
            return value
    return ''


def _is_imdb(value):
    return value.startswith('tt')


def _is_number(value):
    return value.isdigit()


def read_item(service):
    """ (cache key, ids) for the focused item (service ListItem) or the playing video (service Player), or None """
    if service == 'Player':
        prefix = 'VideoPlayer.'
    elif xbmc.getCondVisibility(CV_USE_LISTITEM):
        prefix = 'ListItem.'
    else:
        widget = xbmc.getInfoLabel(FOCUS_CONTAINER)
        prefix = f'Container({widget}).ListItem.' if widget and widget.isdigit() else 'Container.ListItem.'

    mtype = _label(prefix, 'DBType')
    if mtype not in MOVIE_TYPES + TV_TYPES:
        return None

    ids = {'mtype': mtype, 'imdb': '', 'tmdb': '', 'title': '', 'year': '', 'tvshowdbid': ''}
    if mtype in ('movie', 'tvshow'):
        ids['imdb'] = _first(prefix, ('UniqueID(imdb)', 'IMDBNumber', 'Property(imdb_id)', 'Property(tvshow.imdb_id)'), _is_imdb)
        ids['tmdb'] = _first(prefix, ('UniqueID(tmdb)', 'Property(tmdb_id)', 'Property(tvshow.tmdb_id)'), _is_number)
        ids['title'] = _first(prefix, ('OriginalTitle', 'Title') if mtype == 'movie' else ('TVShowTitle', 'Title'))
        ids['year'] = _label(prefix, 'Year')
    else:
        # Seasons and episodes rate as their show (as upstream did): show ids from add-on properties or the library show
        ids['imdb'] = _first(prefix, ('Property(tvshow.imdb_id)', ), _is_imdb)
        ids['tmdb'] = _first(prefix, ('Property(tvshow.tmdb_id)', 'Property(tmdb_id)'), _is_number)
        ids['tvshowdbid'] = _first(prefix, ('TvShowDBID', ), _is_number)
        ids['title'] = _label(prefix, 'TVShowTitle')

    if not (ids['imdb'] or ids['tmdb'] or ids['tvshowdbid'] or ids['title']):
        return None

    kind = 'movie' if mtype in MOVIE_TYPES else 'tv'
    if ids['imdb'] or ids['tmdb']:
        key = f"{kind}|{ids['imdb']}|{ids['tmdb']}"
    elif ids['tvshowdbid']:
        key = f"{kind}|dbid:{ids['tvshowdbid']}"
    else:
        key = f"{kind}|t:{ids['title'].lower()}|{ids['year']}"
    return key, ids


def resolve_library_show(ids):
    """ Library seasons/episodes: get the show's ids from the video library """
    if ids.get('imdb') or ids.get('tmdb') or not ids.get('tvshowdbid'):
        return
    try:
        request = {
            'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.GetTVShowDetails',
            'params': {'tvshowid': int(ids['tvshowdbid']), 'properties': ['uniqueid', 'imdbnumber', 'year', 'title']}}
        details = json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result', {}).get('tvshowdetails', {})
    except Exception:
        return
    uniqueid = details.get('uniqueid') or {}
    imdb = uniqueid.get('imdb') or details.get('imdbnumber') or ''
    ids['imdb'] = imdb if imdb.startswith('tt') else ''
    ids['tmdb'] = str(uniqueid.get('tmdb') or '')
    ids['title'] = ids.get('title') or details.get('title') or ''
    ids['year'] = str(details.get('year') or '')


# ---------------------------------------------------------------- Startup check

def has_api_key():
    """ True if Short Fuse has an MDbList or OMDb key. Reads the skin's saved settings when another skin is active. """
    keys = ('Ratings.MDbList.APIKey', 'Ratings.OMDb.APIKey')
    if xbmc.getSkinDir() == SKIN_ID:
        return any(xbmc.getInfoLabel(f'Skin.String({k})').strip() for k in keys)
    try:
        import xml.etree.ElementTree as ET
        path = xbmcvfs.translatePath(f'special://profile/addon_data/{SKIN_ID}/settings.xml')
        root = ET.parse(path).getroot()
        return any((s.text or '').strip() for s in root.iter('setting') if s.get('id') in keys)
    except Exception:
        return False


# ---------------------------------------------------------------- Service

class RatingsService(object):
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.home = xbmcgui.Window(HOME)
        self.cache = Cache()
        self.state = {s: {'key': None, 'since': 0, 'requested': False, 'shown': {}} for s in ('ListItem', 'Player')}
        self.pending = {}
        self.cond = threading.Condition()
        self.backoff = {}
        self.keys = ('', '')
        self.worker = threading.Thread(target=self.work, name='ShortFuseRatings', daemon=True)

    # -- properties

    def show(self, service, data):
        data = data or {}
        values = {k: data.get(k) or '' for k in ALL_KEYS if k != 'HasRatings'}
        values['HasRatings'] = 'True' if any(data.get(k) for k in RATING_KEYS) else ''
        shown = self.state[service]['shown']
        for k, v in values.items():
            if shown.get(k, '') != v:
                self.home.setProperty(PROPERTY.format(service, k), v)
        self.state[service]['shown'] = values

    def clear(self, service):
        if any(self.state[service]['shown'].values()):
            self.show(service, {})
        self.state[service].update(key=None, requested=False)

    def set_status(self, source, message):
        self.home.setProperty(STATUS, message or '')
        self.home.setProperty(STATUS_SOURCE, source if message else '')

    # -- focus tracking (main thread)

    def update(self, service):
        item = read_item(service)
        state = self.state[service]
        if not item:
            return self.clear(service)
        key, ids = item
        now = time.time()
        if key != state['key']:
            state.update(key=key, since=now, requested=False)
            cached = self.cache.get(key)
            if cached is not None:
                state['requested'] = True
                return self.show(service, cached)
            self.show(service, {})  # Don't leave the previous item's ratings up while this one loads
        if not state['requested'] and now - state['since'] >= DEBOUNCE:
            state['requested'] = True
            with self.cond:
                self.pending[service] = (key, ids)
                self.cond.notify()

    # -- lookups (worker thread)

    def work(self):
        while not self.monitor.abortRequested():
            with self.cond:
                while not self.pending and not self.monitor.abortRequested():
                    self.cond.wait(1.0)
                if self.monitor.abortRequested():
                    return
                service = 'ListItem' if 'ListItem' in self.pending else next(iter(self.pending))
                key, ids = self.pending.pop(service)
            if self.state[service]['key'] != key:
                continue  # Focus moved on while queued
            data = self.lookup(key, dict(ids))
            if data is None:
                continue  # Nothing usable to cache (sources unavailable); try again on next focus
            self.cache.put(key, data)
            if self.state[service]['key'] == key:
                self.show(service, data)

    def available(self, source):
        return time.time() >= self.backoff.get(source, 0)

    def call(self, source, func, *args, **kwargs):
        try:
            result = func(*args, **kwargs)
            if self.home.getProperty(STATUS_SOURCE) == source:
                self.set_status(source, '')
            return result
        except SourceError as exc:
            log(f'{source}: {exc.message}', xbmc.LOGWARNING)
            self.set_status(source, exc.message)
            self.backoff[source] = time.time() + (BACKOFF if exc.backoff else 3600)
            return None

    def lookup(self, key, ids):
        mdblist_key, omdb_key = self.keys
        mtype = ids['mtype']
        resolve_library_show(ids)
        out, asked, answered = {}, False, False

        def from_mdblist():
            nonlocal asked, answered
            if not (mdblist_key and self.available('MDbList') and (ids['imdb'] or ids['tmdb'])):
                return
            asked = True
            result = self.call('MDbList', mdblist, mdblist_key, mtype, imdb=ids['imdb'], tmdb=ids['tmdb'])
            if result is None:
                return
            answered = True
            data, found_imdb = result
            for k, v in data.items():
                _set(out, k, v)
            ids['imdb'] = ids['imdb'] or found_imdb or ''

        from_mdblist()

        need_omdb = omdb_key and self.available('OMDb') and (ids['imdb'] or ids['title']) and (
            not out.get('IMDb_Rating') or not out.get('RottenTomatoes_Rating') or not out.get('MetaCritic_Rating')
            or (mtype in MOVIE_TYPES and 'Awards' not in out))
        if need_omdb:
            asked = True
            result = self.call(
                'OMDb', omdb, omdb_key, mtype, imdb=ids['imdb'],
                title=None if ids['imdb'] else ids['title'], year=ids['year'] if mtype in ('movie', 'tvshow') else None)
            if result is not None:
                answered = True
                data, found_imdb = result
                for k, v in data.items():
                    _set(out, k, v)
                if found_imdb and not ids['imdb']:
                    ids['imdb'] = found_imdb
                    if not any(out.get(k) for k in ('TMDb_Rating', 'Trakt_Rating', 'MDBList_Rating')):
                        from_mdblist()  # Title match gave us an IMDb id - MDbList can now fill in the rest

        if asked and not answered:
            return None  # Every source we tried failed (bad key / limit / network) - don't cache that as "no ratings"
        return out

    # -- main loop

    def run(self):
        log('service started', xbmc.LOGINFO)
        self.home.setProperty(RUNNING, 'True')
        self.worker.start()
        try:
            while not self.monitor.abortRequested():
                if xbmc.getSkinDir() != SKIN_ID:
                    self.clear('ListItem')
                    self.clear('Player')
                    self.cache.save()
                    if self.monitor.waitForAbort(5):
                        break
                    continue

                keys = (xbmc.getInfoLabel(KEY_MDBLIST).strip(), xbmc.getInfoLabel(KEY_OMDB).strip())
                if keys != self.keys:
                    self.keys, self.backoff = keys, {}  # New key: forget earlier failures
                    self.set_status('', '')
                    for service in self.state:
                        self.state[service].update(key=None, requested=False)
                if not any(self.keys):  # Keys removed while running: idle until one is set again
                    self.clear('ListItem')
                    self.clear('Player')
                    if self.monitor.waitForAbort(2):
                        break
                    continue

                if xbmc.getCondVisibility('Player.HasVideo'):
                    self.update('Player')
                else:
                    self.clear('Player')

                if not xbmc.getCondVisibility(CV_PAUSE):
                    self.update('ListItem')

                self.cache.save()
                if self.monitor.waitForAbort(POLL):
                    break
        finally:
            with self.cond:
                self.cond.notify_all()
            self.cache.save(force=True)
            self.home.clearProperty(RUNNING)
            log('service stopped', xbmc.LOGINFO)
