# -*- coding: utf-8 -*-
# Module: service
# Author: adamsbuilds (script.shortfuse.helper)
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
# Online ratings for the Short Fuse skin (see resources/lib/ratings.py). Exits at startup unless an MDbList or OMDb
# API key is set in Skin Settings > Details > Ratings (a key added later needs a Kodi restart), and idles while
# another skin is active.
import os
import sys

# The jurialmunkey and infotagger libraries are bundled in resources/modules instead of separate add-ons
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'modules'))

from resources.lib.ratings import RatingsService, has_api_key, log  # noqa: E402

if __name__ == '__main__':
    if has_api_key():
        RatingsService().run()
    else:
        log('no API key set - not running (restart Kodi after adding one)')
