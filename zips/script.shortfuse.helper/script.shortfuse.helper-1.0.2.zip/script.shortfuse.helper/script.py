# -*- coding: utf-8 -*-
# Module: default
# Author: jurialmunkey (script.shortfuse.helper), forked into script.shortfuse.helper by adamsbuilds
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import os
import sys

# The jurialmunkey and infotagger libraries are bundled in resources/modules instead of separate add-ons
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'modules'))

from resources.lib.script import Script  # noqa: E402

if __name__ == '__main__':
    Script(*sys.argv[1:]).run()
