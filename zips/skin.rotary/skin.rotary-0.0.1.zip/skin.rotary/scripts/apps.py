# -*- coding: utf-8 -*-
"""Rotary's Home script - part of the skin (addon.xml registers it as the skin's plugin source), so it
only runs when Home builds its grid or you add, move, edit or remove a shortcut; nothing runs in the
background.

plugin://skin.rotary/?info=home&grid=CxR&move=S        -> Home: a grid of spots, C across and R down (one
                                                         screen), with your shortcuts where you put them.
                                                         While an icon is being moved (move = its spot),
                                                         one spare row below lets you start a new screen.
RunPlugin(plugin://skin.rotary/?action=add_home[&slot=S&grid=CxR])  -> pick something and add it (at spot S)
RunPlugin(plugin://skin.rotary/?action=home)           -> edit Home shortcuts (Skin Settings)
RunPlugin(plugin://skin.rotary/?action=edit&n=N)       -> rename, new icon, new target or remove shortcut N
RunPlugin(plugin://skin.rotary/?action=remove&n=N)     -> take shortcut N off Home
RunPlugin(plugin://skin.rotary/?action=drop&from=S&to=T&grid=CxR) -> move the icon at spot S to spot T
                                                         (swaps with the icon there, if any)

Shortcuts are the skin strings rotary.home.N.label / .icon / .action (picker.py writes them, N = 1, 2 ...).
rotary.home.layout = "CxR|p1;p2;..." says where each one sits: spot numbers, row by row, for that grid.
When the grid changes (icon size or screen shape) those spots mean something else, so the icons go back
to sitting together from the top left, in the order they were in.
Every change bumps rotary.apps.rev, which is part of Home's content URL, so Home reloads straight away.
The shortcut picker and the editors live in picker.py and are only loaded for those actions.
"""
import json
import re
import sys
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

SELF = 'skin.rotary'
REV = 'rotary.apps.rev'
LAYOUT = 'rotary.home.layout'
HOME_MAX = 40
DEFAULT_GRID = '6x3'
TYPES = ('xbmc.python.pluginsource', 'xbmc.python.script')  # add-ons the picker offers (picker.all_addons)
TAGS = re.compile(r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR|COLOR[^\]]*)\]', re.I)


def log(msg):
    xbmc.log('[%s] %s' % (SELF, msg), xbmc.LOGINFO)


def rpc(method, **params):
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
        return res.get('result') or {}
    except Exception as exc:  # never break Home over a bad reply
        log('%s failed: %s' % (method, exc))
        return {}


def plain(name):
    return TAGS.sub('', name or '').strip()


def script_addons(properties):
    """Every enabled script add-on, whatever it provides (no content filter).  Scripts that don't say what
    they provide are program add-ons in Kodi's own lists, but Addons.GetAddons only matches content an
    add-on declares, so picker.all_addons adds these with a pass of their own."""
    result = rpc('Addons.GetAddons', type='xbmc.python.script', enabled=True, properties=properties)
    return [a for a in result.get('addons') or [] if a.get('addonid') and a['addonid'] != SELF]


def plugin_url(**params):
    return 'plugin://%s/?%s' % (SELF, urlencode(params))


def bump():
    xbmc.executebuiltin('Skin.SetString(%s,%d)' % (REV, int(time.time() * 1000) % 1000000000))


# ------------------------------------------------------------------ shortcuts and where they sit
def read_shortcuts():
    items = []
    for n in range(1, HOME_MAX + 1):
        action = xbmc.getInfoLabel('Skin.String(rotary.home.%d.action)' % n)
        if not action:
            break
        items.append({'label': xbmc.getInfoLabel('Skin.String(rotary.home.%d.label)' % n),
                      'icon': xbmc.getInfoLabel('Skin.String(rotary.home.%d.icon)' % n),
                      'action': action})
    return items


def parse_grid(grid):
    try:
        cols, rows = (int(x) for x in (grid or DEFAULT_GRID).lower().split('x'))
        if cols > 0 and rows > 0:
            return cols, rows
    except ValueError:
        pass
    return parse_grid(DEFAULT_GRID)


def read_layout():
    """-> (grid it was made for, [spot or None for each shortcut])"""
    sig, _, rest = xbmc.getInfoLabel('Skin.String(%s)' % LAYOUT).partition('|')
    spots = []
    for part in rest.split(';') if rest else []:
        spots.append(int(part) if part.isdigit() else None)
    return sig, spots


def write_layout(grid, spots):
    value = '%s|%s' % (grid, ';'.join('' if s is None else str(s) for s in spots))
    xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (LAYOUT, value))


def place(count, grid, sig=None, spots=None):
    """Where each of `count` shortcuts sits on `grid`: [spot], plus whether that differs from what is
    saved.  A layout made for another grid is dropped: the icons sit together from the top left, in
    the reading order they had.  Shortcuts without a free spot of their own take the first free one."""
    if sig is None:
        sig, spots = read_layout()
    spots = (list(spots or []) + [None] * count)[:count]
    if sig != grid:
        order = sorted(range(count), key=lambda i: (spots[i] is None, spots[i] or 0, i))
        placed = [0] * count
        for k, i in enumerate(order):
            placed[i] = k
        return placed, True
    taken, placed, changed = set(), [], False
    for s in spots:
        if s is None or s in taken:
            placed.append(None)
            changed = True
        else:
            taken.add(s)
            placed.append(s)
    free = (s for s in range(count * 2 + 1000) if s not in taken)
    for i, s in enumerate(placed):
        if s is None:
            placed[i] = next(free)
            taken.add(placed[i])
    return placed, changed


# ------------------------------------------------------------------ Home's grid
def shortcut_item(n, item, spot, grid):
    li = xbmcgui.ListItem(label=item['label'], offscreen=True)
    icon = item['icon'] or 'DefaultFolder.png'
    li.setArt({'icon': icon, 'thumb': icon})
    li.setProperty('rotary.action', item['action'])  # Home.xml runs it when the icon is tapped
    li.setProperty('rotary.slot', str(spot))
    li.setProperty('rotary.n', str(n))
    li.addContextMenuItems([
        ('Move', 'SetProperty(rotary.moving,%d,home)' % spot),  # Home.xml drops it on the next tap
        ('Edit', 'RunPlugin(%s)' % plugin_url(action='edit', n=n)),
        ('Remove from Home', 'RunPlugin(%s)' % plugin_url(action='remove', n=n)),
    ])
    return '', li, False


def empty_item(spot, grid):
    li = xbmcgui.ListItem(label='', offscreen=True)
    li.setProperty('rotary.empty', '1')  # drawn as nothing, or as a drop outline while moving
    li.setProperty('rotary.slot', str(spot))
    li.addContextMenuItems([
        ('Add a shortcut here', 'RunPlugin(%s)' % plugin_url(action='add_home', slot=spot, grid=grid)),
    ])
    return '', li, False


def key_targets(spot, real, cols, total_rows):
    """For an empty spot: where a key press that lands on it should go instead (Timers.xml:
    rotary_home_keyskip).  Keys don't stop on empty spots: moving left or right carries on along the row
    to the next icon; up or down carries on to the nearest icon in the next row that has one.  Each
    direction is keyed by the neighbour you came from: from_l / to_r means "arrived from the spot on the
    left, so go on to the right".  No icon that way: no to_ property, and the skin goes back to the icon
    you came from.  All numbers are spots, which are also list positions (0-based)."""
    row, col = divmod(spot, cols)
    props = {}
    if col > 0:
        props['from_l'] = spot - 1
        props['to_r'] = next((s for s in range(spot + 1, (row + 1) * cols) if s in real), None)
    if col < cols - 1:
        props['from_r'] = spot + 1
        props['to_l'] = next((s for s in range(spot - 1, row * cols - 1, -1) if s in real), None)

    def nearest(rows):
        for r in rows:
            hits = [r * cols + c for c in range(cols) if r * cols + c in real]
            if hits:
                return min(hits, key=lambda s: (abs(s % cols - col), s % cols))
        return None
    if row > 0:
        props['from_u'] = spot - cols
        props['to_d'] = nearest(range(row + 1, total_rows))
    if row < total_rows - 1:
        props['from_d'] = spot + cols
        props['to_u'] = nearest(range(row - 1, -1, -1))
    return {'rotary.' + k: str(v) for k, v in props.items() if v is not None}


def list_home(handle, grid, moving):
    cols, rows = parse_grid(grid)
    grid = '%dx%d' % (cols, rows)
    items = read_shortcuts()
    spots, changed = place(len(items), grid)
    if changed:
        write_layout(grid, spots)
    by_spot = {s: i for i, s in enumerate(spots)}
    used_rows = (max(spots) // cols + 1) if spots else 0
    total_rows = max(rows, used_rows) + (1 if moving else 0)
    real = set(by_spot)
    first = str(min(real)) if real else ''
    listing = []
    for spot in range(total_rows * cols):
        i = by_spot.get(spot)
        entry = shortcut_item(i + 1, items[i], spot, grid) if i is not None else empty_item(spot, grid)
        entry[1].setProperty('rotary.first', first)  # the first icon: where keys start out
        if i is None:
            for k, v in key_targets(spot, real, cols, total_rows).items():
                entry[1].setProperty(k, v)
        listing.append(entry)
    xbmcplugin.addDirectoryItems(handle, listing, len(listing))
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def drop(src, dst, grid):
    """Move the icon at spot src to spot dst (swapping with the icon there, if any)."""
    if src == dst:
        return
    items = read_shortcuts()
    spots, changed = place(len(items), grid)
    if src not in spots:
        return
    i = spots.index(src)
    if dst in spots:
        spots[spots.index(dst)] = src
    spots[i] = dst
    write_layout(grid, spots)
    bump()


def main():
    query = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else ''
    params = dict(parse_qsl(query))
    try:
        handle = int(sys.argv[1])
    except (IndexError, ValueError):
        handle = -1
    action = params.get('action')
    if action == 'drop':
        if params.get('from', '').isdigit() and params.get('to', '').isdigit():
            drop(int(params['from']), int(params['to']), '%dx%d' % parse_grid(params.get('grid')))
    elif action in ('add_home', 'home', 'edit', 'remove'):
        import picker  # only loaded for the editors
        if action == 'add_home':
            slot = params.get('slot', '')
            picker.add_home(int(slot) if slot.isdigit() else None, params.get('grid') or None)
        elif action == 'home':
            picker.edit_home()
        elif params.get('n', '').isdigit():
            {'edit': picker.edit_shortcut, 'remove': picker.remove_shortcut}[action](int(params['n']))
    elif handle >= 0:
        list_home(handle, params.get('grid'), params.get('move', ''))
    else:
        log('nothing to do for %s' % query)


if __name__ == '__main__':
    main()
