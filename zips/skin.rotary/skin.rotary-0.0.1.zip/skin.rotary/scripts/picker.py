# -*- coding: utf-8 -*-
"""Rotary's shortcut picker and the editor for Home shortcuts.

Loaded by apps.py only when one of these is opened from Skin Settings or a long-press on Home, so
none of it runs while you browse.

Everything is kept in skin strings (so it travels with the skin's own settings):
    rotary.home.N.label / .icon / .action    Home shortcuts, N = 1, 2, 3 ... with no gaps
    rotary.home.count                        how many there are (shown in Skin Settings)
    rotary.home.layout                       where each one sits on Home's grid (see apps.py)
.action is a ready-to-run Kodi command: Home runs it as it is when the shortcut is tapped.

Backing out of any step (picker, name, icon) changes nothing.
"""
import json
import os
import time
import xml.etree.ElementTree as ET
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

HOME_MAX = 40
REV = 'rotary.apps.rev'

# (label, icon, command, condition or None)
KODI_SCREENS = (
    ('Videos', 'tiles/videos.png', 'ActivateWindow(Videos,root,return)', None),
    ('Music', 'DefaultMusicAlbums.png', 'ActivateWindow(Music,root,return)', None),
    ('Pictures', 'DefaultPicture.png', 'ActivateWindow(Pictures,root,return)', None),
    ('Programs', 'DefaultAddonProgram.png', 'ActivateWindow(Programs,root,return)', None),
    ('Games', 'tiles/games.png', 'ActivateWindow(Games,root,return)', None),
    ('Favourites', 'tiles/favourites.png', 'ActivateWindow(FavouritesBrowser)', None),
    ('Add-ons', 'tiles/addons.png', 'ActivateWindow(AddonBrowser,addons://,return)', None),
    ('My add-ons', 'DefaultAddonsInstalled.png', 'ActivateWindow(AddonBrowser,addons://user/,return)', None),
    ('Video add-ons', 'DefaultAddonVideo.png', 'ActivateWindow(Videos,addons://sources/video/,return)', None),
    ('Program add-ons', 'DefaultAddonProgram.png', 'ActivateWindow(Programs,addons://sources/executable/,return)', None),
    ('Install from repository', 'DefaultAddonsRepo.png', 'ActivateWindow(AddonBrowser,addons://repos/,return)', None),
    ('Install from zip file', 'DefaultAddonsZip.png', 'InstallFromZip', None),
    ('Add-on updates', 'DefaultAddonsUpdates.png', 'ActivateWindow(AddonBrowser,addons://outdated/,return)', None),
    ('Recently updated add-ons', 'DefaultAddonsRecentlyUpdated.png', 'ActivateWindow(AddonBrowser,addons://recently_updated/,return)', None),
    ('Search add-ons', 'DefaultAddonsSearch.png', 'ActivateWindow(AddonBrowser,addons://search/,return)', None),
    ('File manager', 'tiles/filemanager.png', 'ActivateWindow(FileManager)', None),
    ('Video files', 'tiles/files.png', 'ActivateWindow(Videos,sources://video/,return)', None),
    ('Weather', 'DefaultAddonWeather.png', 'ActivateWindow(Weather)', None),
    ('Video playlist', 'DefaultVideoPlaylists.png', 'ActivateWindow(VideoPlaylist)', None),
    ('Music playlist', 'DefaultMusicPlaylists.png', 'ActivateWindow(MusicPlaylist)', None),
    ('Event log', 'tiles/eventlog.png', 'ActivateWindow(EventLog)', None),
    ('System information', 'tiles/systeminfo.png', 'ActivateWindow(SystemInfo)', None),
)
SETTINGS_SCREENS = (
    ('Settings', 'tiles/settings.png', 'ActivateWindow(Settings)', None),
    ('Skin settings', 'tiles/skin.png', 'ActivateWindow(SkinSettings)', None),
    ('Player', 'tiles/player.png', 'ActivateWindow(PlayerSettings)', None),
    ('Media', 'tiles/media.png', 'ActivateWindow(MediaSettings)', None),
    ('Interface', 'tiles/interface.png', 'ActivateWindow(InterfaceSettings)', None),
    ('System', 'tiles/system.png', 'ActivateWindow(SystemSettings)', None),
    ('Services', 'tiles/services.png', 'ActivateWindow(ServiceSettings)', None),
    ('Games', 'tiles/games.png', 'ActivateWindow(GameSettings)', None),
    ('Profiles', 'tiles/profiles.png', 'ActivateWindow(Profiles)', None),
    ('File manager', 'tiles/filemanager.png', 'ActivateWindow(FileManager)', None),
)
COMMANDS = (
    ('Power', 'tiles/power.png', 'ActivateWindow(ShutdownMenu)', None),
    ('Quit Kodi', 'tiles/exit.png', 'Quit', None),
    ('Restart the device', 'tiles/reboot.png', 'Reboot', 'System.CanReboot'),
    ('Shut down', 'tiles/power.png', 'Powerdown', 'System.CanPowerDown'),
    ('Suspend', 'tiles/suspend.png', 'Suspend', 'System.CanSuspend'),
    ('Hibernate', 'tiles/hibernate.png', 'Hibernate', 'System.CanHibernate'),
    ('Log off', 'tiles/logoff.png', 'System.LogOff', 'System.HasLoginScreen | Integer.IsGreater(System.ProfileCount,1)'),
    ('Update the video library', 'DefaultMovies.png', 'UpdateLibrary(video)', None),
    ('Update the music library', 'DefaultMusicAlbums.png', 'UpdateLibrary(music)', None),
    ('Clean the video library', 'DefaultMovies.png', 'CleanLibrary(video)', None),
    ('Clean the music library', 'DefaultMusicAlbums.png', 'CleanLibrary(music)', None),
    ('Check for add-on updates', 'DefaultAddonsUpdates.png', 'UpdateAddonRepos', None),
    ('Play / pause', 'tiles/player.png', 'PlayerControl(Play)', None),
    ('Stop playback', 'tiles/player.png', 'PlayerControl(Stop)', None),
    ('Music party mode', 'DefaultPartyMode.png', 'PlayerControl(PartyMode)', None),
    ('Mute', 'icons/volume_off.png', 'Mute', None),
    ('Start the screensaver', 'DefaultAddonScreensaver.png', 'ActivateScreensaver', None),
    ('Reload the skin', 'tiles/skin.png', 'ReloadSkin()', None),
)
# icons offered by "Pick a Rotary icon" (everything else in media/ is too specific): (file, name)
ICONS = (
    ('tiles/videos.png', 'Play'), ('tiles/addons.png', 'Add-ons'), ('tiles/favourites.png', 'Star'),
    ('tiles/files.png', 'Files'), ('tiles/filemanager.png', 'Folders'), ('tiles/settings.png', 'Settings'),
    ('tiles/skin.png', 'Skin'), ('tiles/power.png', 'Power'), ('tiles/games.png', 'Games'),
    ('tiles/media.png', 'Media'), ('tiles/player.png', 'Player'), ('tiles/interface.png', 'Interface'),
    ('tiles/system.png', 'System'), ('tiles/services.png', 'Network'), ('tiles/profiles.png', 'People'),
    ('tiles/systeminfo.png', 'Chip'), ('tiles/eventlog.png', 'Log'), ('tiles/timer.png', 'Timer'),
    ('tiles/exit.png', 'Exit'), ('tiles/reboot.png', 'Restart'),
    ('DefaultMovies.png', 'Movies'), ('DefaultTVShows.png', 'TV shows'), ('DefaultMusicVideos.png', 'Music videos'),
    ('DefaultVideo.png', 'Video'), ('DefaultRecentlyAddedMovies.png', 'New movies'),
    ('DefaultRecentlyAddedEpisodes.png', 'New episodes'), ('DefaultInProgressShows.png', 'In progress'),
    ('DefaultSets.png', 'Collections'), ('DefaultGenre.png', 'Genres'), ('DefaultYear.png', 'Years'),
    ('DefaultActor.png', 'Actors'), ('DefaultStudios.png', 'Studios'), ('DefaultMusicAlbums.png', 'Albums'),
    ('DefaultMusicArtists.png', 'Artists'), ('DefaultMusicSongs.png', 'Songs'), ('DefaultPicture.png', 'Pictures'),
    ('DefaultFolder.png', 'Folder'), ('DefaultPlaylist.png', 'Playlist'), ('DefaultFavourites.png', 'Favourites'),
    ('DefaultAddon.png', 'Add-on'), ('DefaultAddonVideo.png', 'Video add-on'),
    ('DefaultAddonProgram.png', 'Program add-on'), ('DefaultAddonWeather.png', 'Weather'),
    ('DefaultNetwork.png', 'Network share'), ('DefaultHardDisk.png', 'Drive'), ('DefaultScript.png', 'Script'),
    ('DefaultUser.png', 'User'), ('DefaultPVRChannels.png', 'Live TV'), ('DefaultAddSource.png', 'Plus'),
)
# window ids Kodi writes into favourites, as names
WINDOW_NAMES = {'10025': 'Videos', '10502': 'Music', '10001': 'Programs', '10002': 'Pictures',
                '10040': 'Add-ons', '10821': 'Games', '10000': 'Home'}
IMAGE_MASK = '.png|.jpg|.jpeg|.webp|.gif|.bmp'

# window -> the media type JSON-RPC wants when listing a folder for it
MEDIA = {'Videos': 'video', 'Music': 'music', 'Pictures': 'pictures', 'Programs': 'files', 'Games': 'files'}
# add-on content -> window it opens in
WINDOW_FOR = {'video': 'Videos', 'executable': 'Programs', 'audio': 'Music', 'image': 'Pictures', 'game': 'Games'}
CONTENT_LABEL = {'video': 'Video add-on', 'executable': 'Program add-on', 'audio': 'Music add-on',
                 'image': 'Picture add-on', 'game': 'Game add-on'}

BACK = '__back__'


def log(msg):
    xbmc.log('[skin.rotary] %s' % msg, xbmc.LOGINFO)


def rpc(method, **params):
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
        if 'error' in res:
            log('%s: %s' % (method, res['error']))
        return res.get('result') or {}
    except Exception as exc:
        log('%s failed: %s' % (method, exc))
        return {}


def cond(condition):
    return condition is None or xbmc.getCondVisibility(condition)


def quote(value):
    """One builtin parameter, quoted so commas, brackets and quotes inside it survive."""
    return '"%s"' % value.replace('\\', '\\\\').replace('"', '\\"')


def open_in(window, path):
    return 'ActivateWindow(%s,%s,return)' % (window, quote(path))


def row(label, label2='', icon='', value=None):
    li = xbmcgui.ListItem(label=label, label2=label2)
    if icon:
        li.setArt({'icon': icon, 'thumb': icon})
    return li, value


def select(heading, rows, preselect=-1):
    """rows: [(ListItem, value)] -> value or None.  preselect also ticks that row, so it is only
    used where a tick means "this is the current one"."""
    if not rows:
        return None
    picked = xbmcgui.Dialog().select(heading, [r[0] for r in rows], useDetails=True, preselect=preselect)
    if picked < 0:
        return None
    return rows[picked][1]


class Busy(object):
    def __enter__(self):
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

    def __exit__(self, *exc):
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def shortcut(label, icon, action):
    return {'label': label, 'icon': icon, 'action': action}


# ------------------------------------------------------------------ the picker
def pick(heading='Add a shortcut'):
    """Walk the user to a target.  Returns {'label', 'icon', 'action'} or None if they back out."""
    android = xbmc.getCondVisibility('System.Platform.Android')
    groups = [
        ('apps', 'Apps and add-ons', 'Open an add-on, or a folder inside one', 'DefaultAddon.png'),
        ('library', 'Library', 'Movies, TV shows, music videos and music in your library', 'DefaultMovies.png'),
        ('sources', 'Sources and files', 'Folders on this device or your network', 'DefaultHardDisk.png'),
        ('playlists', 'Playlists', 'Your saved and smart playlists', 'DefaultPlaylist.png'),
        ('favourites', 'Favourites', 'Anything you have saved in Kodi favourites', 'DefaultFavourites.png'),
        ('screens', 'Kodi screens', 'Videos, Music, Add-ons, File manager, Weather ...', 'tiles/videos.png'),
        ('settings', 'Settings', 'Kodi and skin settings pages', 'tiles/settings.png'),
        ('commands', 'Power and commands', 'Quit, restart, update the library, play / pause ...', 'tiles/power.png'),
    ]
    if android:
        groups.append(('android', 'Android apps', 'Start an app installed on this device', 'DefaultAddonProgram.png'))
    groups += [
        ('path', 'Type a path', 'Any folder or plugin:// address', 'DefaultFolder.png'),
        ('command', 'Type a Kodi command', 'Any builtin, e.g. RunScript(...) or ActivateWindow(...)', 'DefaultScript.png'),
    ]
    handlers = {
        'apps': pick_app, 'library': pick_library, 'sources': pick_source, 'playlists': pick_playlist,
        'favourites': pick_favourite, 'screens': lambda: pick_fixed('Kodi screens', KODI_SCREENS),
        'settings': lambda: pick_fixed('Settings', SETTINGS_SCREENS),
        'commands': lambda: pick_fixed('Power and commands', COMMANDS),
        'android': pick_android, 'path': type_path, 'command': type_command,
    }
    while True:
        rows = [row(g[1], g[2], g[3], g[0]) for g in groups]
        key = select(heading, rows)
        if key is None:
            return None
        target = handlers[key]()
        if target is None or target == BACK:
            continue  # backed out of the group: show the groups again
        named = name_step(target)
        if named is not None:
            return named


def name_step(target):
    """The last step of every pick: name it (pre-filled).  Cancel = back out."""
    name = xbmcgui.Dialog().input('Name', defaultt=target['label'])
    if not name.strip():
        return None
    target['label'] = name.strip()
    return target


def pick_fixed(heading, table):
    rows = [row(label, describe(action), icon, shortcut(label, icon, action))
            for label, icon, action, condition in table if cond(condition)]
    return select(heading, rows)


def all_addons():
    """Every add-on you can open: (addon dict with _content/_type) sorted by name."""
    from apps import TYPES, plain
    found = {}
    for content in ('video', 'executable', 'audio', 'image', 'game'):
        for addon_type in TYPES:
            result = rpc('Addons.GetAddons', type=addon_type, content=content, enabled=True,
                         properties=['name', 'thumbnail'])
            for addon in result.get('addons') or []:
                aid = addon.get('addonid')
                if not aid or aid == 'skin.rotary':
                    continue
                entry = found.setdefault(aid, dict(addon, _contents=[], _types=set()))
                if content not in entry['_contents']:
                    entry['_contents'].append(content)
                entry['_types'].add(addon_type)
    # scripts that declare no content: Kodi lists them as program add-ons (see apps.script_addons)
    from apps import script_addons
    for addon in script_addons(['name', 'thumbnail']):
        if addon['addonid'] not in found:
            found[addon['addonid']] = dict(addon, _contents=['executable'], _types={'xbmc.python.script'})
    addons = list(found.values())
    for a in addons:
        a['_name'] = plain(a.get('name')) or a['addonid']
    addons.sort(key=lambda a: a['_name'].lower())
    return addons


def pick_app():
    with Busy():
        addons = all_addons()
    if not addons:
        xbmcgui.Dialog().ok('Apps and add-ons', 'No add-ons are installed yet.')
        return None
    rows = []
    for a in addons:
        kind = CONTENT_LABEL.get(a['_contents'][0], 'Add-on')
        rows.append(row(a['_name'], kind + '  ·  ' + a['addonid'], a.get('thumbnail') or 'DefaultAddon.png', a))
    while True:
        addon = select('Apps and add-ons', rows)
        if addon is None:
            return BACK
        target = addon_target(addon)
        if target is not None:
            return target


def addon_target(addon):
    aid, name = addon['addonid'], addon['_name']
    icon = addon.get('thumbnail') or 'DefaultAddon.png'
    if 'xbmc.python.pluginsource' not in addon['_types']:
        return shortcut(name, icon, 'RunScript(%s)' % aid)
    contents = addon['_contents']
    choices = []
    for content in contents:
        window = WINDOW_FOR.get(content, 'Videos')
        path = 'plugin://%s/' % aid
        if len(contents) > 1:
            path += '?content_type=%s' % content
        where = ' (%s)' % CONTENT_LABEL[content].split()[0].lower() if len(contents) > 1 else ''
        choices.append(row('Open %s%s' % (name, where), 'Starts at the add-on\'s main menu', icon,
                           ('open', window, path)))
        choices.append(row('Choose a folder inside%s' % where, 'Browse in and pick any menu or list', 'DefaultFolder.png',
                           ('browse', window, path)))
    if 'xbmc.python.script' in addon['_types']:
        choices.append(row('Run it as a script', 'RunScript(%s)' % aid, 'DefaultScript.png', ('script', None, None)))
    while True:
        choice = select(name, choices)
        if choice is None:
            return None
        how, window, path = choice
        if how == 'open':
            return shortcut(name, icon, open_in(window, path))
        if how == 'script':
            return shortcut(name, icon, 'RunScript(%s)' % aid)
        target = browse(path, window, name, icon, can_type=True)
        if target is not None and target != BACK:
            return target


def list_folder(path, window):
    with Busy():
        result = rpc('Files.GetDirectory', directory=path, media=MEDIA.get(window, 'files'),
                     properties=['thumbnail'])
    return result.get('files') or []


def browse(root, window, root_label, root_icon, can_type=False):
    """A small file browser.  The first row always takes the folder you are in.

    Folders open, files (anything playable) become a "play this" shortcut.
    Returns a shortcut, BACK (left the root) or None (cancelled)."""
    stack = [(root, root_label, root_icon)]
    while True:
        path, label, icon = stack[-1]
        rows = [row('Use "%s"' % label, 'Opens this in %s' % window, icon or 'DefaultFolder.png',
                    ('use', None))]
        if len(stack) > 1:
            rows.append(row('..', 'Back', 'DefaultFolderBack.png', ('up', None)))
        if can_type and len(stack) == 1:
            rows.append(row('Type a path', 'If the add-on\'s menu won\'t list here, enter the address',
                            'DefaultScript.png', ('type', None)))
        for item in list_folder(path, window):
            ipath = item.get('file') or ''
            if not ipath:
                continue
            ilabel = strip_tags(item.get('label') or ipath)
            thumb = item.get('thumbnail') or ''
            if thumb.startswith('image://'):
                thumb = unquote(thumb[8:].rstrip('/'))
            if item.get('filetype') == 'directory':
                rows.append(row(ilabel, '', thumb or 'DefaultFolder.png', ('dir', (ipath, ilabel, thumb))))
            else:
                rows.append(row(ilabel, 'Plays it', thumb or 'DefaultVideo.png', ('file', (ipath, ilabel, thumb))))
        choice = select(label, rows)
        if choice is None:
            return None
        how, data = choice
        if how == 'use':
            return shortcut(label, icon or root_icon or 'DefaultFolder.png', open_in(window, path))
        if how == 'up':
            stack.pop()
        elif how == 'type':
            typed = xbmcgui.Dialog().input('Path', defaultt=path)
            if typed.strip():
                stack.append((typed.strip(), label, icon))
        elif how == 'dir':
            ipath, ilabel, thumb = data
            stack.append((ipath, ilabel, thumb or icon))
        else:
            ipath, ilabel, thumb = data
            return shortcut(ilabel, thumb or icon or 'DefaultVideo.png', 'PlayMedia(%s)' % quote(ipath))


def strip_tags(text):
    from apps import plain
    return plain(text)


def pick_library():
    roots = [row('Video library', 'Movies, TV shows, music videos ...', 'DefaultMovies.png',
                 ('library://video/', 'Videos', 'Video library', 'DefaultMovies.png')),
             row('Music library', 'Artists, albums, songs ...', 'DefaultMusicAlbums.png',
                 ('library://music/', 'Music', 'Music library', 'DefaultMusicAlbums.png'))]
    while True:
        root = select('Library', roots)
        if root is None:
            return BACK
        target = browse(*root)
        if target is not None and target != BACK:
            return target


def pick_source():
    kinds = (('video', 'Videos', 'Video source'), ('music', 'Music', 'Music source'),
             ('pictures', 'Pictures', 'Picture source'), ('files', 'Videos', 'File source'))
    rows, seen = [], set()
    with Busy():
        for media, window, kind in kinds:
            for source in rpc('Files.GetSources', media=media).get('sources') or []:
                path = source.get('file')
                if not path or path in seen:
                    continue
                seen.add(path)
                rows.append(row(source.get('label') or path, kind + '  ·  ' + path, 'DefaultHardDisk.png',
                                (path, window, source.get('label') or path, 'DefaultFolder.png')))
    rows.append(row('Type a path', 'Any folder this device can reach', 'DefaultScript.png', 'type'))
    while True:
        source = select('Sources and files', rows)
        if source is None:
            return BACK
        if source == 'type':
            return type_path()
        target = browse(*source)
        if target is not None and target != BACK:
            return target


def pick_playlist():
    rows = []
    with Busy():
        for folder, window, kind in (('video', 'Videos', 'Video playlist'), ('music', 'Music', 'Music playlist'),
                                     ('mixed', 'Music', 'Mixed playlist')):
            path = 'special://profile/playlists/%s/' % folder
            for item in rpc('Files.GetDirectory', directory=path, media='files').get('files') or []:
                ipath = item.get('file') or ''
                if not ipath:
                    continue
                name = strip_tags(item.get('label') or os.path.basename(ipath))
                name = os.path.splitext(name)[0] if name.lower().endswith(('.xsp', '.m3u', '.pls')) else name
                icon = 'DefaultVideoPlaylists.png' if window == 'Videos' else 'DefaultMusicPlaylists.png'
                rows.append(row(name, kind, icon, shortcut(name, icon, open_in(window, ipath))))
    if not rows:
        xbmcgui.Dialog().ok('Playlists', 'You have no saved playlists yet.')
        return BACK
    return select('Playlists', rows) or BACK


def pick_favourite():
    """Kodi's own favourites, read from favourites.xml so the command is exactly what Kodi runs."""
    rows = [row('The Favourites screen', 'Opens all your favourites', 'tiles/favourites.png',
                shortcut('Favourites', 'tiles/favourites.png', 'ActivateWindow(FavouritesBrowser)'))]
    try:
        with xbmcvfs.File('special://profile/favourites.xml') as fh:
            data = fh.read()
        for fav in ET.fromstring(data).iter('favourite'):
            command = (fav.text or '').strip()
            if not command:
                continue
            name = strip_tags(fav.get('name') or command)
            icon = fav.get('thumb') or 'DefaultFavourites.png'
            rows.append(row(name, describe(command), icon, shortcut(name, icon, command)))
    except Exception as exc:  # no favourites yet, or an unreadable file
        log('favourites: %s' % exc)
    return select('Favourites', rows) or BACK


def pick_android():
    rows = []
    for item in list_folder('androidapp://sources/apps/', 'Programs'):
        path = item.get('file') or ''
        package = path.rstrip('/').rsplit('/', 1)[-1]
        if not package:
            continue
        name = strip_tags(item.get('label') or package)
        icon = item.get('thumbnail') or 'DefaultAddonProgram.png'
        rows.append(row(name, package, icon, shortcut(name, icon, 'StartAndroidActivity(%s)' % quote(package))))
    rows.sort(key=lambda r: r[0].getLabel().lower())
    if not rows:
        xbmcgui.Dialog().ok('Android apps', 'Kodi could not list the apps on this device.')
        return BACK
    return select('Android apps', rows) or BACK


def type_path():
    path = xbmcgui.Dialog().input('Path (e.g. plugin://plugin.video.example/ or special://...)').strip()
    if not path:
        return BACK
    windows = [row(w, 'Open it in %s' % w, icon, w) for w, icon in
               (('Videos', 'tiles/videos.png'), ('Programs', 'DefaultAddonProgram.png'),
                ('Music', 'DefaultMusicAlbums.png'), ('Pictures', 'DefaultPicture.png'))]
    guess = 0
    if path.startswith(('musicdb://', 'library://music')) or '/playlists/music/' in path:
        guess = 2
    window = select('Open it in', windows, preselect=guess)
    if window is None:
        return BACK
    name = path.rstrip('/').rsplit('/', 1)[-1] or path
    return shortcut(name, 'DefaultFolder.png', open_in(window, path))


def type_command():
    command = xbmcgui.Dialog().input('Kodi command').strip()
    if not command:
        return BACK
    return shortcut(command.split('(', 1)[0], 'DefaultScript.png', command)


def describe(action):
    """A short line saying what a command does, for label2."""
    head, _, rest = action.partition('(')
    args = rest[:-1] if rest.endswith(')') else rest
    head_l = head.strip().lower()
    first, _, more = args.partition(',')
    if head_l == 'activatewindow':
        window = WINDOW_NAMES.get(first.strip(), first.strip())
        path = more.rsplit(',return', 1)[0].strip().strip('"')
        return '%s  ·  %s' % (window, path) if path else window
    if head_l == 'playmedia':
        return 'Plays  ·  ' + args.strip('"')
    if head_l in ('runscript', 'runaddon'):
        return 'Runs  ·  ' + first.strip('"')
    if head_l == 'startandroidactivity':
        return 'Android app  ·  ' + first.strip('"')
    return action


# ------------------------------------------------------------------ icons
def icon_step(current):
    rows = [row('Pick a Rotary icon', 'Round icons that match the skin', 'tiles/skin.png', 'skin'),
            row('Choose an image', 'Any picture on this device', 'DefaultPicture.png', 'file')]
    choice = select('Icon', rows)
    if choice == 'skin':
        icons = [row(name, '', path, path) for path, name in ICONS]
        files = [path for path, name in ICONS]
        preselect = files.index(current) if current in files else -1  # ticks the one in use
        return select('Pick an icon', icons, preselect=preselect)
    if choice == 'file':
        picked = xbmcgui.Dialog().browse(2, 'Choose an image', 'files', IMAGE_MASK, True, False, 'special://home/')
        if picked and picked != 'special://home/':
            return picked
    return None


# ------------------------------------------------------------------ storage
def read_slots(prefix, limit):
    items = []
    for n in range(1, limit + 1):
        action = xbmc.getInfoLabel('Skin.String(%s.%d.action)' % (prefix, n))
        if not action:
            break
        items.append(shortcut(xbmc.getInfoLabel('Skin.String(%s.%d.label)' % (prefix, n)),
                              xbmc.getInfoLabel('Skin.String(%s.%d.icon)' % (prefix, n)), action))
    return items


def set_string(name, value):
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (name, quote(value)))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % name)


def write_slots(prefix, items, old_count):
    """Write the list with no gaps; slots past the end are cleared."""
    for n, item in enumerate(items, 1):
        for key in ('label', 'icon', 'action'):
            set_string('%s.%d.%s' % (prefix, n, key), item[key])
    for n in range(len(items) + 1, old_count + 1):
        for key in ('label', 'icon', 'action'):
            set_string('%s.%d.%s' % (prefix, n, key), '')


def bump():
    xbmc.executebuiltin('Skin.SetString(%s,%d)' % (REV, int(time.time() * 1000) % 1000000000))


def home_items():
    """Home shortcuts, each with 'pos': the spot it sits in (apps.place), or None."""
    from apps import read_layout
    items = read_slots('rotary.home', HOME_MAX)
    sig, spots = read_layout()
    for item, spot in zip(items, spots + [None] * len(items)):
        item['pos'] = spot
    return items


def save_home(items, old_count, grid=None):
    """Write the shortcuts and where they sit; each item's 'pos' travels with it, so the layout keeps
    up with edits, removals and new shortcuts (no spot yet: Home gives them the first free one)."""
    from apps import read_layout, write_layout
    write_slots('rotary.home', items, old_count)
    set_string('rotary.home.count', str(len(items)) if items else '')
    write_layout(grid or read_layout()[0], [item.get('pos') for item in items])
    bump()  # Home's URL carries the rev, so Home rebuilds its grid


# ------------------------------------------------------------------ editors
def add_home(slot=None, grid=None):
    """Pick something and add it to Home - at spot `slot` of `grid` when added from an empty spot."""
    items = home_items()
    if len(items) >= HOME_MAX:
        xbmcgui.Dialog().ok('Home shortcuts', 'Home already has %d shortcuts.' % HOME_MAX)
        return
    target = pick('Add to Home')
    if not target:
        return
    if grid:  # where the others sit on this grid, so the new one can take the spot that was pressed
        from apps import place
        spots, changed = place(len(items), grid)
        for item, spot in zip(items, spots):
            item['pos'] = spot
        target['pos'] = slot if slot is not None and slot not in spots else None
    save_home(items + [target], len(items), grid)


def edit_home():
    edit_list('Home shortcuts', home_items, save_home, HOME_MAX, minimum=0,
              add_label='Add a shortcut', add_hint='It goes in the first free spot on Home')


def edit_shortcut(n):
    """Long-press > Edit on Home: the menu for shortcut n."""
    items = home_items()
    if 1 <= n <= len(items):
        changed = edit_one('Home shortcuts', items, n - 1, minimum=0)
        if changed is not None:
            save_home(changed, len(items))


def remove_shortcut(n):
    """Long-press > Remove from Home."""
    items = home_items()
    if 1 <= n <= len(items) and xbmcgui.Dialog().yesno('Home', 'Remove "%s" from Home?' % items[n - 1]['label']):
        save_home(items[:n - 1] + items[n:], len(items))


def edit_list(heading, load, save, limit, minimum, add_label, add_hint):
    # The list is read once and then kept here: Skin.SetString is queued, so reading the
    # strings straight back after a save could still return the old values.
    items = load()
    while True:
        rows = [row(it['label'], describe(it['action']), it['icon'] or 'DefaultFolder.png', ('item', i))
                for i, it in enumerate(items)]
        if len(items) < limit:
            rows.append(row(add_label, add_hint, 'DefaultAddSource.png', ('add', None)))
        choice = select(heading, rows)  # no preselect: the select dialog would tick it
        if choice is None:
            return
        how, index = choice
        if how == 'add':
            target = pick('Add to ' + heading)
            if target:
                save(items + [target], len(items))
                items = items + [target]
            continue
        changed = edit_one(heading, items, index, minimum)
        if changed is not None:
            save(changed, len(items))
            items = changed


def edit_one(heading, items, index, minimum):
    """The menu for one entry.  Returns the new list, or None if nothing changed."""
    item = items[index]
    n = len(items)
    actions = [row('Rename', item['label'], 'DefaultScript.png', 'rename'),
               row('Change icon', '', item['icon'] or 'DefaultFolder.png', 'icon'),
               row('Change what it opens', describe(item['action']), 'DefaultFolder.png', 'target')]
    if n > minimum:
        actions.append(row('Remove', 'Takes it off Home',
                           'DefaultIconError.png', 'remove'))
    what = select(item['label'], actions)
    if what is None:
        return None
    items = [dict(i) for i in items]
    if what == 'rename':
        name = xbmcgui.Dialog().input('Name', defaultt=item['label']).strip()
        if not name:
            return None
        items[index]['label'] = name
    elif what == 'icon':
        icon = icon_step(item['icon'])
        if not icon:
            return None
        items[index]['icon'] = icon
    elif what == 'target':
        target = pick('Change what "%s" opens' % item['label'])
        if not target:
            return None
        target['pos'] = item.get('pos')  # it stays in the same spot
        items[index] = target
    elif what == 'remove':
        if not xbmcgui.Dialog().yesno(heading, 'Remove "%s"?' % item['label']):
            return None
        items.pop(index)
    return items
