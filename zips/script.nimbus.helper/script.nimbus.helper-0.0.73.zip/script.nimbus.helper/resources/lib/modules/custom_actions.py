import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xml.etree.ElementTree as ET
from xml.dom import minidom
from threading import Timer
import sys, re
import requests
import json

KEYMAP_LOCATION = "special://userdata/keymaps/"
POSSIBLE_KEYMAP_NAMES = ["gen.xml", "keyboard.xml", "keymap.xml"]

dialog = xbmcgui.Dialog()
Listitem = xbmcgui.ListItem
DEFAULT_PATH = "addons://sources/video"

#Focus Home Menu on boot fixed for non android.
def fix_initial_home_focus():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return
    window = xbmcgui.Window(10000)
    for _ in range(50):
        if xbmc.getCondVisibility("ControlGroup(2000).HasFocus"):
            xbmc.executebuiltin("SetFocus(9000)")
        else:
            break
        xbmc.sleep(100)
    window.setProperty("NimbusFocusFixDone", "true")

def show_changelog():
    helper_addon = xbmcaddon.Addon("script.nimbus.helper")
    helper_version = helper_addon.getAddonInfo("version")
    skin_addon = xbmcaddon.Addon("skin.nimbus")
    skin_version = skin_addon.getAddonInfo("version")
    skin_name = skin_addon.getAddonInfo("name")
    changelog_path = xbmcvfs.translatePath("special://skin/nimbuschangelog.txt")
    with xbmcvfs.File(changelog_path) as file:
        changelog_text = file.read()
    if isinstance(changelog_text, bytes):
        changelog_text = changelog_text.decode("utf-8")
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \d+\.\d+\.\d+)\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \$INFO\[.*?\])\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    helper_pattern = r"Nimbus Helper: Latest: v([\d.]+) \[B\]\|\[/B\] Installed: v.*"
    helper_match = re.search(helper_pattern, changelog_text)
    if helper_match:
        latest_helper_version = helper_match.group(1)
        installed_part = f"Installed: v{helper_version}"
        if helper_version != latest_helper_version:
            installed_part = f"[COLOR red][B]{installed_part}[/B][/COLOR]"
            update_message = (
                "\n\n[COLOR red][B]An update is available for the Nimbus Helper. "
                "Please follow these instructions to update and get the latest features and ensure full continued functionality:[/B][/COLOR]"
                "\n\n1. Go to Settings [B]»[/B] System [B]»[/B] Addons tab [B]»[/B] Manage dependencies"
                "\n2. Find Nimbus Helper and click it"
                "\n3. Versions [B]»[/B] Click the latest version in ivarbrandt's Repository"
            )
        else:
            update_message = "\n\n[COLOR limegreen][B]Nimbus Helper up to date. No updates needed at this time.[/B][/COLOR]"
        new_helper_info = f"Nimbus Helper: Latest: v{latest_helper_version} [B]|[/B] {installed_part}{update_message}"
        changelog_text = re.sub(
            helper_pattern, new_helper_info, changelog_text, count=1
        )
    header = f"CHANGELOG: {skin_name} v{skin_version}"
    xbmcgui.Dialog().textviewer(header, changelog_text)


def set_widget_count():
    if len(sys.argv) >= 3:
        list_id = sys.argv[2]
        if len(list_id) in (4, 5):
            container_id = (
                f"{list_id[:2]}001" if len(list_id) == 5 else f"{list_id[0]}001"
            )
            num_items_str = xbmc.getInfoLabel(f"Container({container_id}).NumItems")
            if num_items_str and num_items_str.isdigit():
                num_widgets = int(num_items_str) * 2 - 1
                xbmc.executebuiltin(f"Skin.SetString(TotalWidgetCount,{num_widgets})")


def reset_widget_position():
    """Send the widget row we have just left back to its first item.

    Called from the row's onunfocus, so this is about the row being LEFT, not
    the one being entered. That rules out SetFocus: the row no longer has focus,
    and focusing it would drag the user backwards onto it. Control.Move is the
    only builtin that repositions a container without touching focus.

    Control.Move is relative, and these are fixedlists, which WRAP - a blanket
    "move back a lot" does not clamp at item 1, it wraps round and lands on
    offset modulo row length, which is why every row ended up somewhere
    different. So the offset has to be exact, and since skins have no
    arithmetic, working it out is the whole reason this lives in the helper:
    read Container.CurrentItem, subtract one, move back by precisely that much.
    """
    if len(sys.argv) < 3:
        return
    list_id = sys.argv[2]
    if not list_id.isdigit():
        return

    current_item = xbmc.getInfoLabel("Container(%s).CurrentItem" % list_id)
    if not current_item.isdigit():
        return

    # CurrentItem is 1-based, so item 1 needs no move at all.
    offset = int(current_item) - 1
    if offset <= 0:
        return

    # onunfocus also fires for transitions that get cancelled or bounce straight
    # back. If this row is somehow focused again by the time we run, leave it
    # alone rather than yanking the position out from under the user.
    if xbmc.getCondVisibility("Control.HasFocus(%s)" % list_id):
        return

    xbmc.executebuiltin("Control.Move(%s,-%d)" % (list_id, offset))


def set_image(params=None):
    params = params or {}
    start_path = params.get("path") or xbmc.getInfoLabel("Skin.String(LastImagePath)") or "special://home/"

    image_file = xbmcgui.Dialog().browse(
        2,
        "Choose Custom Background Image",
        "files",
        ".jpg|.png|.bmp",
        False,
        False,
        start_path
    )
    if image_file:
        xbmc.executebuiltin(f"Skin.SetString(LastImagePath,{image_file})")
        xbmc.executebuiltin(f"Skin.SetString(NimbusCustomBackground,{image_file})")


def play_trailer():
    is_episode = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,episode)")
    is_season = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,season)")
    if xbmc.getCondVisibility("Control.IsVisible(500) | Control.IsVisible(501)"):
        xbmc.executebuiltin(
            "Notification(Trailer Playback, Trailer playback is not available in this view, 3000)"
        )
    elif not (is_episode or is_season):
        trailer_source = xbmc.getInfoLabel("Skin.String(TrailerSource)")
        play_url = None
        if trailer_source == "0":
            play_url = xbmc.getInfoLabel("ListItem.Trailer")
        elif trailer_source == "1":
            play_url = xbmc.getInfoLabel("Skin.String(TrailerPlaybackURL)")
        if play_url:
            xbmc.executebuiltin("Skin.SetString(TrailerPlaying, true)")
            if xbmc.getCondVisibility("Control.IsVisible(50) | Control.IsVisible(51)"):
                xbmc.executebuiltin(f"PlayMedia({play_url},0,noresume)")
            else:
                xbmc.executebuiltin(f"PlayMedia({play_url},1,noresume)")


def check_api_key(api_key):
    api_url = "https://mdblist.com/api/"
    params = {"apikey": api_key, "i": "tt0111161"}
    try:
        response = requests.get(api_url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        return ("valid", "ratings" in data and len(data["ratings"]) > 0)
    except requests.RequestException:
        return ("error", None)


def validate_api_key(api_key, silent=True):
    if not api_key:
        xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        return
    xbmc.executebuiltin("Skin.SetString(checking_api_key,true)")
    try:
        status, is_valid = check_api_key(api_key)
        if status == "valid" and is_valid:
            xbmc.executebuiltin("Skin.SetString(valid_api_key,true)")
            if not silent:
                xbmcgui.Dialog().notification("Success", "Features activated", xbmcgui.NOTIFICATION_INFO, 3000)
        elif status == "valid" and not is_valid:
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            if not silent:
                xbmcgui.Dialog().notification("Connection Error", "Unable to reach MDbList", xbmcgui.NOTIFICATION_INFO, 3000)
    finally:
        xbmc.executebuiltin("Skin.Reset(checking_api_key)")


def set_api_key():
    current_key = xbmc.getInfoLabel("Skin.String(mdblist_api_key)")
    keyboard = xbmc.Keyboard(current_key, "Enter MDbList API Key")
    keyboard.doModal()
    if keyboard.isConfirmed():
        new_key = keyboard.getText()
        if not new_key:
            xbmc.executebuiltin("Skin.Reset(mdblist_api_key)")
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            xbmc.executebuiltin(f'Skin.SetString(mdblist_api_key,"{new_key}")')
            validate_api_key(new_key, silent=False)


def check_api_key_on_load():
    validate_api_key(xbmc.getInfoLabel("Skin.String(mdblist_api_key)"), silent=True)


def fix_black_screen():
    if xbmc.getCondVisibility("Skin.HasSetting(TrailerPlaying)"):
        xbmc.executebuiltin("Skin.Reset(TrailerPlaying)")


def set_blurradius():
    current_value = xbmc.getInfoLabel("Skin.String(BlurRadius)") or "30"
    value = xbmcgui.Dialog().numeric(0, "Enter blur radius value", current_value)
    if value == "":
        value = "30"
    xbmc.executebuiltin(f"Skin.SetString(BlurRadius,{value})")


def set_blursaturation():
    current_value = xbmc.getInfoLabel("Skin.String(BlurSaturation)") or "1.5"
    keyboard = xbmc.Keyboard(current_value, "Enter blur saturation value")
    keyboard.doModal()
    if keyboard.isConfirmed():
        text = keyboard.getText() or "1.5"
        xbmc.executebuiltin(f"Skin.SetString(BlurSaturation,{text})")


def set_autoendplaybackdelay():
    current_value = xbmc.getInfoLabel("Skin.String(PlaybackDelayMins)") or "30"
    value_mins = xbmcgui.Dialog().numeric(0, "Enter delay in minutes", current_value)
    if value_mins == "":
        value_mins, value_secs = "30", 1800
    else:
        value_secs = int(value_mins) * 60
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelayMins,{value_mins})")
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelaySecs,{value_secs})")


def make_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if not xbmcvfs.exists(backup_path):
        xbmcvfs.copy(keymap_path, backup_path)


def restore_from_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if xbmcvfs.exists(backup_path):
        xbmcvfs.delete(keymap_path)
        xbmcvfs.rename(backup_path, keymap_path)


def get_all_existing_keymap_paths():
    paths = []
    for name in POSSIBLE_KEYMAP_NAMES:
        p = xbmcvfs.translatePath(f"special://profile/keymaps/{name}")
        if xbmcvfs.exists(p):
            paths.append(p)
    return paths


def create_new_keymap_file():
    new_path = xbmcvfs.translatePath(f"{KEYMAP_LOCATION}gen.xml")
    ET.ElementTree(ET.Element("keymap")).write(new_path)
    return new_path


class KeyListener(xbmcgui.WindowXMLDialog):
    TIMEOUT = 7

    def __new__(cls):
        return super(KeyListener, cls).__new__(
            cls, "DialogNotification.xml", xbmcaddon.Addon().getAddonInfo("path")
        )

    def __init__(self):
        self.key = None

    def onInit(self):
        self.getControl(401).setLabel("Starting key listener...")
        self.getControl(402).setLabel("Be ready to press key")
        xbmc.sleep(2000)
        countdown_start = self.TIMEOUT - 2
        self.getControl(401).setLabel("Listening for key press...")
        self.getControl(402).setLabel(f"Timeout in {countdown_start} seconds")
        for i in range(countdown_start, 1, -1):
            self.getControl(402).setLabel(f"Timeout in {i} seconds")
            xbmc.sleep(1000)
        self.getControl(402).setLabel("Timeout in 1 second")
        xbmc.sleep(1000)
        self.close()

    def onAction(self, action):
        button_code = action.getButtonCode()
        action_id = action.getId()
        self.key = button_code if button_code != 0 else action_id
        self.getControl(401).setLabel("Key captured successfully!")
        self.getControl(402).setLabel(f"Captured key code: {self.key}")
        xbmc.sleep(2000)
        self.close()

    @staticmethod
    def record_key():
        dlg = KeyListener()
        timeout = Timer(KeyListener.TIMEOUT, dlg.close)
        timeout.start()
        dlg.doModal()
        timeout.cancel()
        key = dlg.key
        del dlg
        return key


def capture_user_key():
    listener = KeyListener()
    captured_key = listener.record_key()
    if captured_key:
        xbmc.executebuiltin(f"Skin.SetString(CapturedKeyCode, {captured_key})")
    del listener
    return captured_key


def modify_keymap():
    keymap_paths = get_all_existing_keymap_paths() or [create_new_keymap_file()]
    captured_key = xbmc.getInfoLabel("Skin.String(CapturedKeyCode)")
    if not captured_key:
        return
    setting_value = xbmc.getInfoLabel("Skin.String(trailerSetting)")
    for keymap_path in keymap_paths:
        if setting_value == "1":
            make_backup(keymap_path)
            tree = ET.parse(keymap_path)
            root = tree.getroot()
            found = False
            for key_tag in root.findall(".//key"):
                if key_tag.text == "RunScript(script.nimbus.helper, mode=play_trailer)":
                    key_tag.set("id", captured_key)
                    found = True
                    break
            if not found:
                global_tag = root.find("global") or ET.SubElement(root, "global")
                keyboard_tag = global_tag.find("keyboard") or ET.SubElement(global_tag, "keyboard")
                ET.SubElement(keyboard_tag, "key", id=captured_key).text = "RunScript(script.nimbus.helper, mode=play_trailer)"
            pretty_xml = minidom.parseString(ET.tostring(root, "utf-8")).toprettyxml(indent="  ")
            with xbmcvfs.File(keymap_path, "w") as xml_file:
                xml_file.write("\n".join([line for line in pretty_xml.split("\n") if line.strip()]))
        else:
            restore_from_backup(keymap_path)
    xbmc.executebuiltin("Action(reloadkeymaps)")


# -------- Submenu manager --------

WINDOW_TARGETS = [("Video Addons", "Videos"), ("Music Addons", "Music"), ("Picture Addons", "Pictures"), ("Program Addons", "Programs")]

WINDOW_DEFAULT_PATHS = {
    "Videos": "addons://sources/video",
    "Music": "addons://sources/music",
    "Pictures": "addons://sources/image",
    "Programs": "addons://sources/executable",
}

KODI_COMMANDS = [
    ("Addon Browser", "ActivateWindow(AddonBrowser)"),
    ("File Manager", "ActivateWindow(FileManager)"),
    ("Favourites", "ActivateWindow(Favourites)"),
    ("Weather", "ActivateWindow(Weather)"),
    ("Settings", "ActivateWindow(Settings)"),
    ("Reboot", "Reboot"),
    ("Shutdown", "ShutDown"),
    ("Hibernate", "Hibernate"),
    ("Suspend", "Suspend"),
    ("Quit Kodi", "Quit"),
    ("Activate Screensaver", "ActivateScreensaver"),
    ("Update Video Library", "UpdateLibrary(video)"),
    ("Update Music Library", "UpdateLibrary(music)"),
    ("Clean Video Library", "CleanLibrary(video)"),
    ("Clean Music Library", "CleanLibrary(music)"),
    ("Toggle Fullscreen", "Action(FullScreen)"),
    ("Mute", "Mute"),
]

# (display_label, ActivateWindow target, browse root) -- these reuse the
# existing addon-source browser, just rooted at the local library instead
# of addons://sources/... .
LIBRARY_TARGETS = [
    ("Video Library", "Videos", "videodb://"),
    ("Music Library", "Music", "musicdb://"),
]

LIVE_TV_COMMANDS = [
    ("TV Channels", "ActivateWindow(TVChannels)"),
    ("TV Guide", "ActivateWindow(TVGuide)"),
    ("TV Recordings", "ActivateWindow(TVRecordings)"),
    ("TV Timers", "ActivateWindow(TVTimers)"),
    ("Radio Channels", "ActivateWindow(RadioChannels)"),
    ("Radio Guide", "ActivateWindow(RadioGuide)"),
]


def _sanitize_skin_string(value):
    return (value or "").strip()


def _normalize_plugin_path(path):
    p = (path or "").strip()
    if p.startswith(("plugin.video.", "plugin.audio.", "plugin.image.", "plugin.program.")):
        p = f"plugin://{p}"
    elif p.startswith("plugin:/") and not p.startswith("plugin://"):
        p = p.replace("plugin:/", "plugin://", 1)
    return p


def _default_path_for_window(window_target):
    return WINDOW_DEFAULT_PATHS.get(window_target, DEFAULT_PATH)


def _set_submenu_item(menu_id, slot, label, action):
    safe_label = _sanitize_skin_string(label).replace('"', '\\"')
    safe_action = _sanitize_skin_string(action).replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.label,"{safe_label}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.action,"{safe_action}")')


def _set_submenu_target(menu_id, slot, window_target, target_path):
    wt = (window_target or "").replace('"', '\\"')
    tp = (target_path or "").replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.window,"{wt}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.target,"{tp}")')


def _clear_submenu_item(menu_id, slot):
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.label)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.action)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.window)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.target)")


def _clear_all_submenu_items(menu_id, max_items=50):
    """
    Clear every populated slot for this menu.

    Only slots that actually hold something are cleared. Each
    _clear_submenu_item() fires 4 xbmc.executebuiltin() calls, and those are
    queued onto Kodi's application message thread rather than run inline - so
    clearing blindly meant 22 menus x 50 slots x 4 = 4,400 queued builtins on
    a full reset, nearly all of them resetting strings that were never set.
    That flood is slow on any box and risks stalling weaker hardware.

    getInfoLabel() is a direct read, so probing first is far cheaper than
    clearing unconditionally: a fresh install now issues zero builtins here
    instead of 4,400.
    """
    for i in range(1, max_items + 1):
        if (xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.action)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.window)")):
            _clear_submenu_item(menu_id, i)


def _read_submenu_slot(menu_id, slot):
    """Read all four strings that make up one submenu item."""
    return {
        key: xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.{key})")
        for key in ("label", "action", "window", "target")
    }


def _write_submenu_slot(menu_id, slot, data):
    if not (data.get("action") or data.get("target")):
        _clear_submenu_item(menu_id, slot)
        return
    _set_submenu_item(menu_id, slot, data.get("label", ""), data.get("action", ""))
    _set_submenu_target(menu_id, slot, data.get("window", ""), data.get("target", ""))


def _occupied_submenu_slots(menu_id, max_items=50):
    return [
        i
        for i in range(1, max_items + 1)
        if xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.action)")
        or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
    ]


def _move_submenu_item(menu_id, slot, direction, max_items=50):
    """Swap a submenu item with its nearest occupied neighbour.

    Deliberately not a plain slot +-1 swap. Slots are sparse - remove item 3
    of 5 and you are left with 1, 2, 4, 5 - so stepping by one slot number
    would swap an item into a hole and change nothing on screen, which reads
    as "move up is broken". Stepping through the occupied slots instead
    means one press always moves the item exactly one visible row.

    Returns the slot the item now occupies, or None if nothing moved.
    """
    occupied = _occupied_submenu_slots(menu_id, max_items)
    if slot not in occupied:
        return None
    index = occupied.index(slot)
    new_index = index - 1 if direction == "up" else index + 1
    if new_index < 0 or new_index >= len(occupied):
        dialog.notification(
            "Nimbus",
            "Already at the %s" % ("top" if direction == "up" else "bottom"),
            xbmcgui.NOTIFICATION_INFO,
            1500,
        )
        return None

    other = occupied[new_index]
    this_item = _read_submenu_slot(menu_id, slot)
    other_item = _read_submenu_slot(menu_id, other)
    _write_submenu_slot(menu_id, slot, other_item)
    _write_submenu_slot(menu_id, other, this_item)
    # Skin.SetString/Reset are queued onto Kodi's application message thread,
    # so the slot list has to wait for them before it re-reads - otherwise
    # the move looks like it did nothing until you back out and return.
    xbmc.sleep(150)
    return other


def _choose_slot(menu_id, title="Choose submenu slot", max_items=50):
    items = []
    for i in range(1, max_items + 1):
        label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
        target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
        text = f"{i}. {label}" if target else f"{i}. [Empty]"
        items.append(xbmcgui.ListItem(text, target if target else ""))
    idx = dialog.select(title, items, useDetails=True)
    return None if idx == -1 else idx + 1
    
ALL_SUBMENU_IDS = [
    "movies", "tvshows",
    "custom1", "custom2", "custom3", "custom4", "custom5",
    "custom6", "custom7", "custom8", "custom9", "custom10",
    "music", "musicvideos", "livetv", "radio", "addons",
    "pictures", "video", "games", "favorites", "weather",
]

def reset_all_submenus():
    """
    Clears every submenu slot for every menu that supports submenus.
    No defaults are re-seeded - every menu is simply left empty after
    clearing.
    """
    for menu_id in ALL_SUBMENU_IDS:
        _clear_all_submenu_items(menu_id)


def _input_label(default_text):
    kb = xbmc.Keyboard(default_text or "", "Set submenu label")
    kb.doModal()
    if not kb.isConfirmed():
        return None
    t = kb.getText().strip()
    return t if t else None


def _files_get_directory(directory, properties=None):
    properties = properties or ["title", "file", "thumbnail"]
    command = {
        "jsonrpc": "2.0",
        "id": "script.nimbus.helper",
        "method": "Files.GetDirectory",
        "params": {"directory": directory, "media": "files", "properties": properties},
    }
    response = xbmc.executeJSONRPC(json.dumps(command))
    result = json.loads(response).get("result", {})
    files = result.get("files", [])
    # This was originally written for addons:// browsing, where every
    # real entry is a plugin:// path - fine there, but it silently
    # filtered out EVERYTHING when browsing the Video/Music Library
    # (videodb:// / musicdb://), since those entries never start with
    # plugin://. That left the picker with zero items, which returned
    # {} with no dialog shown at all, so creating a submenu item from
    # Video/Music Library silently did nothing.
    browsable_schemes = ("plugin://", "videodb://", "musicdb://")
    return [i for i in files if i.get("file", "").startswith(browsable_schemes) and i.get("filetype") == "directory"]


def _strip_formatting(label):
    if not label:
        return ""
    s = label.replace("[B]", "").replace("[/B]", "")
    while "[COLOR" in s:
        start = s.find("[COLOR")
        end = s.find("]", start) + 1
        s = s[:start] + s[end:]
    return s.replace("[/COLOR]", "")


def _choose_window_target():
    options = (
        [i[0] for i in WINDOW_TARGETS]
        + ["Kodi Commands"]
        + [i[0] for i in LIBRARY_TARGETS]
        + ["Live TV / PVR"]
    )
    idx = dialog.select("Choose target type", options)
    if idx == -1:
        return None

    if idx < len(WINDOW_TARGETS):
        return WINDOW_TARGETS[idx][1]
    idx -= len(WINDOW_TARGETS)

    if idx == 0:
        return "__KODI_COMMANDS__"
    idx -= 1

    if idx < len(LIBRARY_TARGETS):
        return f"__LIBRARY__{idx}"

    return "__LIVE_TV__"


def _submenu_path_browser(label="", file=DEFAULT_PATH, thumbnail="", window_target="Videos", start_root=None, parent_history=None):
    if parent_history is None:
        parent_history = []
    root = start_root or DEFAULT_PATH
    label_clean = _strip_formatting(label)
    results = _files_get_directory(file)
    items = []

    # ".. (Back)" - only once we're at least one level deep, matching a
    # normal file browser: Cancel at the very top still just cancels the
    # whole flow (nowhere within this recursion to go up to), but Cancel
    # at any deeper level used to cancel EVERYTHING too - this gives an
    # actual way to step back up one directory instead of losing the
    # whole browse.
    if parent_history:
        back_li = Listitem("[B].. (Back)[/B]", "Go up one directory", offscreen=True)
        back_li.setProperty("go_up", "true")
        items.append(back_li)

    if file != root:
        use_li = Listitem(
            f"Use [B]{label_clean}[/B] as menu item target",
            f"Set as target ({window_target})",
            offscreen=True
        )
        use_li.setArt({"icon": thumbnail})
        use_li.setProperty("item", json.dumps({
            "label": label_clean,
            "file": file,
            "thumbnail": thumbnail,
            "window_target": window_target,
            "is_final": True
        }))
        items.append(use_li)

    for i in results:
        stripped_label = _strip_formatting(i.get("label", ""))
        li = Listitem(f"{stripped_label} »", "Browse path...", offscreen=True)
        li.setArt({"icon": i.get("thumbnail", "")})
        li.setProperty("item", json.dumps({
            "label": i.get("label", ""),
            "file": i.get("file", ""),
            "thumbnail": i.get("thumbnail", ""),
            "window_target": window_target,
            "is_final": False
        }))
        items.append(li)

    if not items or (len(items) == 1 and parent_history):
        # Not a bug - this genuinely happens when the chosen source
        # (most commonly Video/Music Library) has nothing scanned
        # into it yet. Confirmed via diagnostic logging:
        # Files.GetDirectory("videodb://") returns a literal empty
        # file list on an empty library, not even the static
        # Movies/TV Shows category folders. Silently returning here
        # looked identical to a real failure, so tell the user why.
        dialog.ok("Nimbus", f"No items found in {window_target}. If you "
                             "picked Video or Music Library, make sure it "
                             "has content scanned into it first.")
        return {}

    choice = dialog.select("Choose path", items, useDetails=True)
    if choice == -1:
        return {}

    if items[choice].getProperty("go_up") == "true":
        previous = parent_history[-1]
        return _submenu_path_browser(
            label=previous["label"],
            file=previous["file"],
            thumbnail=previous["thumbnail"],
            window_target=window_target,
            start_root=root,
            parent_history=parent_history[:-1],
        )

    chosen = json.loads(items[choice].getProperty("item"))
    if chosen.get("is_final") or chosen["file"] == file:
        return chosen

    return _submenu_path_browser(
        label=chosen.get("label", ""),
        file=chosen.get("file", ""),
        thumbnail=chosen.get("thumbnail", ""),
        window_target=window_target,
        start_root=root,
        parent_history=parent_history + [
            {"label": label, "file": file, "thumbnail": thumbnail}
        ],
    )


def _build_submenu_action_from_path(path, window_target):
    p = _normalize_plugin_path(path)
    return f"ActivateWindow({window_target},{p},return)"


def _set_or_edit_slot_from_kodi_command(menu_id, slot):
    idx = dialog.select("Choose a Kodi command", [c[0] for c in KODI_COMMANDS])
    if idx == -1:
        return

    command_label, action = KODI_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    # No real browsable path exists for these -> store the action itself
    # as the "target" so slot-occupied checks elsewhere still work.
    _set_submenu_target(menu_id, slot, "System", action)

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_live_tv(menu_id, slot):
    idx = dialog.select("Choose a Live TV / PVR destination", [c[0] for c in LIVE_TV_COMMANDS])
    if idx == -1:
        return

    command_label, action = LIVE_TV_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, "System", action)

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_browser(menu_id, slot):
    window_target = _choose_window_target()
    if not window_target:
        return

    if window_target == "__KODI_COMMANDS__":
        _set_or_edit_slot_from_kodi_command(menu_id, slot)
        return

    if window_target == "__LIVE_TV__":
        _set_or_edit_slot_from_live_tv(menu_id, slot)
        return

    if window_target.startswith("__LIBRARY__"):
        lib_idx = int(window_target.replace("__LIBRARY__", ""))
        _, real_window_target, start_path = LIBRARY_TARGETS[lib_idx]
        window_target = real_window_target
    else:
        start_path = _default_path_for_window(window_target)

    result = _submenu_path_browser(file=start_path, window_target=window_target, start_root=start_path)
    if not result:
        return

    target_path = _normalize_plugin_path(result.get("file"))
    if not target_path:
        return

    default_label = _strip_formatting(result.get("label", "")) or "New Item"
    label = _input_label(default_label)
    if label is None:
        return

    action = _build_submenu_action_from_path(target_path, window_target)
    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, window_target, target_path)

    dialog.notification("Nimbus", f"Saved submenu item in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def manage_submenu_items(menu_id, max_items=50):
    """
    Submenu manager UX: shows the list of slots first (each labelled with
    its current content, or [Empty]). Picking an empty slot goes straight
    into browse+label; picking a filled slot offers change/rename/remove
    for that one slot. Loops back to the slot list after every action,
    so repeat edits don't require re-opening the manager. A trailing
    "Clear all" entry handles the one action that isn't slot-specific.

    Storage/generation is unchanged from before - this only replaces the
    old "what do you want to do first" menu.
    """
    if not menu_id:
        dialog.ok("Nimbus", "Missing menu id")
        return

    while True:
        items = []
        for i in range(1, max_items + 1):
            label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
            target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
            text = f"{i}. {label}" if target else f"{i}. [Empty]"
            items.append(xbmcgui.ListItem(text, target if target else ""))
        clear_all_item = xbmcgui.ListItem("Clear all submenu items", "")
        items.append(clear_all_item)

        idx = dialog.select(f"Submenu Items ({menu_id})", items, useDetails=True)
        if idx == -1:
            return

        if idx == max_items:
            if dialog.yesno("Nimbus", f"Clear all submenu items for '{menu_id}'?"):
                _clear_all_submenu_items(menu_id)
                xbmc.sleep(100)
                dialog.notification("Nimbus", f"Cleared all submenu items for {menu_id}", xbmcgui.NOTIFICATION_INFO, 2500)
            continue

        slot = idx + 1
        current_target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.target)")

        if not current_target:
            # Empty slot: go straight into browsing + labeling.
            _set_or_edit_slot_from_browser(menu_id, slot)
            xbmc.sleep(100)
            continue

        # Filled slot: offer per-slot actions.
        slot_actions = [
            ("Move up", "move_up"),
            ("Move down", "move_down"),
            ("Change target (browse)", "change"),
            ("Rename", "rename"),
            ("Remove", "remove"),
        ]
        current_label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.label)")
        slot_choice = dialog.select(
            current_label or f"Slot {slot}",
            [i[0] for i in slot_actions],
        )
        if slot_choice == -1:
            continue
        slot_action = slot_actions[slot_choice][1]

        if slot_action in ("move_up", "move_down"):
            _move_submenu_item(
                menu_id, slot, "up" if slot_action == "move_up" else "down", max_items
            )

        elif slot_action == "change":
            _set_or_edit_slot_from_browser(menu_id, slot)
            xbmc.sleep(100)

        elif slot_action == "rename":
            new_label = _input_label(current_label)
            if new_label is None:
                continue
            current_action = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.action)")
            _set_submenu_item(menu_id, slot, new_label, current_action)
            xbmc.sleep(100)
            dialog.notification("Nimbus", f"Renamed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

        elif slot_action == "remove":
            if dialog.yesno("Nimbus", f"Remove submenu item in slot {slot}?"):
                _clear_submenu_item(menu_id, slot)
                xbmc.sleep(100)
                dialog.notification("Nimbus", f"Removed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

def apply_splash_setting():
    """
    Reads the skin's disable.splashscreen toggle and adds/removes the
    <splash>false</splash> line in special://userdata/advancedsettings.xml
    accordingly, preserving any other existing advancedsettings content.
    Requires a full Kodi restart to actually take effect, since the
    splash screen shows before the skin/Python ever run.
    """
    import xbmcvfs
    import xml.etree.ElementTree as ET

    disable_splash = xbmc.getCondVisibility("Skin.HasSetting(disable.splashscreen)")
    path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")

    if xbmcvfs.exists(path):
        try:
            tree = ET.parse(path)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element("advancedsettings")
            tree = ET.ElementTree(root)
    else:
        root = ET.Element("advancedsettings")
        tree = ET.ElementTree(root)

    splash_el = root.find("splash")

    if disable_splash:
        if splash_el is None:
            splash_el = ET.SubElement(root, "splash")
        splash_el.text = "false"
    else:
        if splash_el is not None:
            root.remove(splash_el)

    tree.write(path, encoding="UTF-8", xml_declaration=True)

    dialog.notification(
        "Nimbus",
        "Splash screen disabled - restart Kodi to apply"
        if disable_splash
        else "Splash screen enabled - restart Kodi to apply",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )

def apply_disable_background_playback_setting():
    """
    Adds or removes a dedicated keymap file that makes Back (keyboard
    Backspace, id 61448) stop playback instead of leaving it running
    in the background, while fullscreen video is playing.
    """
    import xbmcvfs

    enabled = xbmc.getCondVisibility("Skin.HasSetting(disable.backgroundplayback)")
    keymap_dir = xbmcvfs.translatePath("special://userdata/keymaps/")
    keymap_path = keymap_dir + "nimbus_back_stops_playback.xml"

    if enabled:
        if not xbmcvfs.exists(keymap_dir):
            xbmcvfs.mkdirs(keymap_dir)
        with xbmcvfs.File(keymap_path, "w") as f:
            f.write(
                '<keymap><fullscreenvideo><keyboard><key id="61448">stop</key>'
                "</keyboard></fullscreenvideo></keymap>"
            )
    else:
        if xbmcvfs.exists(keymap_path):
            xbmcvfs.delete(keymap_path)

    xbmc.executebuiltin("Action(reloadkeymaps)")

    dialog.notification(
        "Nimbus",
        "Background playback disabled" if enabled else "Background playback re-enabled",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )