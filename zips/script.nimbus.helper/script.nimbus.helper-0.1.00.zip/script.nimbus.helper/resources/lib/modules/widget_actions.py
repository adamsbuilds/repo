# -*- coding: utf-8 -*-
"""Widget row jobs that need to start quickly: putting focus back into the
widget rows, and the main menu's "Refresh widgets" context menu.

Kept apart from custom_actions.py on purpose. recover_widget_focus runs while
focus is parked on an invisible control, often while a row of add-ons is
loading, so every moment spent importing is a moment the screen has no focus.
Only xbmc and xbmcgui are imported here; cpath_maker is imported where needed.
"""
import time

import xbmc
import xbmcgui
import xbmcvfs

LOG_PREFIX = "[script.nimbus.helper] widgets: "
LAST_ROW_PROPERTY = "nimbus_last_widget_row"

# Search result rows, top to bottom (Includes_Search.xml). Which ones exist
# depends on the search provider; a missing row reports 0 items and is skipped.
SEARCH_ROW_IDS = tuple(range(19011, 19023))

# How long SetFocus gets to show up on the row, about 200ms in all. It goes
# through Kodi's message queue, so it hasn't happened when executebuiltin returns.
FOCUS_CHECKS = 5
FOCUS_CHECK_MS = 40

# An empty looking stack is looked at this many times, 200ms apart, before
# believing it. Nothing may have started yet just after a search, and Kodi
# answers for the top dialog rather than this window while one is open, so
# every row can look empty for a moment.
EMPTY_STACK_CHECKS = 4
EMPTY_STACK_CHECK_MS = 200

KEYMAP_DIR = "special://userdata/keymaps/"
KEYMAP_NAME = "nimbus_home_context.xml"

# Home's main menu is a static list, and Kodi only opens the context menu for
# lists that come from a directory - on these items the action does nothing
# and a kodi.context.item never gets asked. So the buttons Kodi normally binds
# to ContextMenu (system/keymaps) are bound to home_context_menu for the Home
# window only, and that passes the action on whenever focus isn't on the menu.
# A long press with Enable Touch on is left to nimbus_touch_submenu.xml, which
# loads after this file and so takes over the mouse long click as well.
_CONTEXT_ACTION = "RunScript(script.nimbus.helper,mode=home_context_menu)"
KEYMAP_CONTENT = (
    "<keymap><Home>"
    "<keyboard>"
    "<c>{0}</c><menu>{0}</menu>"
    '<return mod="longpress">{0}</return><enter mod="longpress">{0}</enter>'
    "</keyboard>"
    "<remote><menu>{0}</menu><title>{0}</title></remote>"
    "<gamepad><white>{0}</white></gamepad>"
    '<joystick profile="game.controller.default">'
    '<x>{0}</x><a holdtime="500">{0}</a>'
    "</joystick>"
    '<mouse><rightclick>{0}</rightclick><longclick id="0">{0}</longclick></mouse>'
    "</Home></keymap>"
).format(_CONTEXT_ACTION)


def log(message):
    xbmc.log("%s%s" % (LOG_PREFIX, message), xbmc.LOGINFO)


def _row_can_take_focus(row_id):
    """Kodi lets a list hold focus while it has items or is still updating.
    Rows are probed this way rather than by visibility because a row that
    finished empty is hidden by now, and a missing container reports 0 items
    and is never updating."""
    return xbmc.getCondVisibility(
        "Integer.IsGreater(Container({0}).NumItems,0) | "
        "Container({0}).IsUpdating".format(row_id)
    )


def _focus_row(row_id):
    """Move focus to a row and report whether it really got there. A row that
    looked fine can finish empty a moment later, and with rows loading side by
    side that happens often. SetFocus on such a row doesn't just fail: Kodi
    takes focus off the current control first, leaving nothing focused."""
    xbmc.executebuiltin("SetFocus(%d,0,absolute)" % row_id)
    for _ in range(FOCUS_CHECKS):
        xbmc.sleep(FOCUS_CHECK_MS)
        if xbmc.getCondVisibility("Control.HasFocus(%d)" % row_id):
            return True
    return False


def focus_first_available_row(row_ids):
    """Focus the first of these rows that will take it. Returns its id, or
    None if none would."""
    for row_id in row_ids:
        if _row_can_take_focus(row_id) and _focus_row(row_id):
            return row_id
    return None


def focus_first_search_row():
    """Start a search on the first row that has, or may yet have, results,
    rather than always aiming at Movies. Returns False if there are none."""
    for check in range(EMPTY_STACK_CHECKS):
        if check:
            xbmc.sleep(EMPTY_STACK_CHECK_MS)
        if focus_first_available_row(SEARCH_ROW_IDS):
            return True
    return False


def _leave_widget_stack():
    """Nothing in the stack can take focus, so the left-hand list is the right
    place after all. On the search window that list is hidden once history is
    empty, so fall back to the toolbar there."""
    home_window = xbmcgui.Window(10000)
    xbmc.executebuiltin("SetFocus(9000)")
    if not xbmc.getCondVisibility("Window.IsActive(1121)"):
        return
    for _ in range(FOCUS_CHECKS):
        xbmc.sleep(FOCUS_CHECK_MS)
        if xbmc.getCondVisibility("Control.HasFocus(9000)"):
            return
    home_window.clearProperty(LAST_ROW_PROPERTY)
    xbmc.executebuiltin("SetFocus(700)")


def announce_no_results():
    """Being dropped back on the recent-searches list looked like the search
    had silently failed, so say so. Home has nothing to announce: an empty
    stack there is normal (a menu with no widgets set up)."""
    search_term = xbmcgui.Window(10000).getProperty("nimbus.search.input")
    if search_term:
        message = 'Nothing found for "%s"' % search_term
    else:
        message = "Nothing found in any category"
    xbmcgui.Dialog().notification("No results found", message, xbmcgui.NOTIFICATION_INFO, 4000)


def finish_empty_search():
    _leave_widget_stack()
    announce_no_results()


def recover_widget_focus():
    """Called by control 20099 (the <defaultcontrol> on Home and on the search
    results window) when Kodi has bounced focus there.

    Kodi hands focus to a window's defaultcontrol whenever the focused control
    can no longer hold it. A widget row that finishes loading with 0 items
    can't, and if you were standing on that row when it went, that is exactly
    what happens - which used to drop you on 9000 (the main menu on Home, the
    recent-searches sidebar on the search window) and looked like the screen
    had thrown you out.

    Deliberate exits never get here - WidgetListCommon routes Left/Back (Back
    only, on the search window) from a row straight to 9000 - so reaching this
    function means we genuinely fell out of a row, and nimbus_last_widget_row
    tells us which one.

    Row ids are laid out as <menu><slot>, e.g. movies widgets are 19011,
    19012, ... (base 19010 plus the slot number, see cpath_maker) and the
    older built-in rows use the same leading digits with hundreds offsets
    (7011, 7100, 7200 ...). In both schemes ascending id order matches
    top-to-bottom screen order, so "the next row down" is just the next
    candidate id in the same family that can take focus. Prefer the next row
    down, which is what the eye expects, and only if nothing below can take
    focus look back up the stack.

    Rows still loading count as targets. With every row loading at once the
    one below may well finish empty too, so each attempt is checked (see
    _focus_row) and the search carries on down the list. If the row we land on
    finishes empty later on, it kicks out again and this runs again from there.
    """
    home_window = xbmcgui.Window(10000)
    raw_id = home_window.getProperty(LAST_ROW_PROPERTY)
    if not raw_id.isdigit():
        xbmc.executebuiltin("SetFocus(9000)")
        return

    window_id = xbmcgui.getCurrentWindowId()
    on_search_window = xbmc.getCondVisibility("Window.IsActive(1121)")
    family, slot = divmod(int(raw_id), 1000)
    # Generated widget slots land in 11-99; the older built-in rows sit on
    # round hundreds. Union of both, ascending, covers every row type.
    candidates = sorted(set(range(11, 100)) | {h * 100 for h in range(1, 10)})
    row_ids = [family * 1000 + s for s in candidates if s > slot]
    row_ids += [family * 1000 + s for s in candidates if s < slot]

    for check in range(EMPTY_STACK_CHECKS):
        if check:
            xbmc.sleep(EMPTY_STACK_CHECK_MS)
        # Back from here, or a window change, ends this: not ours to undo.
        if (
            home_window.getProperty(LAST_ROW_PROPERTY) != raw_id
            or xbmcgui.getCurrentWindowId() != window_id
        ):
            return
        row_id = focus_first_available_row(row_ids)
        if row_id:
            log("row %s went empty, moved to row %s" % (raw_id, row_id))
            return

    log("row %s went empty and no other row can take focus" % raw_id)
    # Whole stack is empty - there is genuinely nothing to focus.
    _leave_widget_stack()
    if on_search_window:
        announce_no_results()


def _menu_widget_rows(menu_id):
    """A main menu item's generated widget rows as (list_id, path). Main menu
    ids are the skin's ("movies"), cpath types the helper's ("movie"). Built-in
    menus have no generated rows."""
    from modules.cpath_maker import CPaths, WIDGET_LIST_ID_BASES

    menu = {"movies": "movie", "tvshows": "tvshow"}.get(menu_id, menu_id)
    if menu not in WIDGET_LIST_ID_BASES:
        return []
    base = WIDGET_LIST_ID_BASES[menu]
    widgets = CPaths("%s.widget" % menu).fetch_current_cpaths()
    return [
        (base + slot, widget["cpath_path"])
        for slot, widget in widgets.items()
        if isinstance(slot, int)
    ]


def refresh_menu_widgets(rows):
    """Make Kodi fetch every add-on widget in a main menu again by changing
    each row's reload token (see cpath_maker.widget_content_path). Library
    widgets refresh on their own and have no token."""
    addon_rows = [list_id for list_id, path in rows if path.startswith("plugin://")]
    if not addon_rows:
        xbmcgui.Dialog().notification(
            "Nimbus", "Library widgets update on their own", xbmcgui.NOTIFICATION_INFO, 2500
        )
        return

    home_window = xbmcgui.Window(10000)
    token = str(int(time.time() * 1000))
    # Kodi doesn't update a hidden container, so a row that loaded empty would
    # never see its new path. nimbus.widgets.refreshing shows every row for a
    # moment (Includes_Home.xml): long enough to start loading, and from then
    # on IsUpdating keeps it up until its results are in.
    home_window.setProperty("nimbus.widgets.refreshing", "true")
    for list_id in addon_rows:
        home_window.setProperty("nimbus.widget_reload.%d" % list_id, token)
    log("refreshing %d widgets: %s" % (len(addon_rows), addon_rows))
    xbmcgui.Dialog().notification(
        "Nimbus", "Refreshing widgets", xbmcgui.NOTIFICATION_INFO, 1500
    )
    xbmc.sleep(500)
    home_window.clearProperty("nimbus.widgets.refreshing")


def show_main_menu_context():
    """Context menu for the focused main menu item. Items with no widgets
    (Settings, Weather ...) have nothing to offer, so nothing opens."""
    menu_id = xbmc.getInfoLabel("Container(9000).ListItem.Property(id)")
    rows = _menu_widget_rows(menu_id)
    if rows and xbmcgui.Dialog().contextmenu(["Refresh widgets"]) == 0:
        refresh_menu_widgets(rows)


def home_context_menu():
    """Keymap target for the context menu buttons on Home (see KEYMAP_CONTENT).
    Anywhere but the main menu this hands the action straight back, so widget
    context menus work as normal, as they do in any other skin."""
    if xbmc.getSkinDir() == "skin.nimbus" and xbmc.getCondVisibility("Control.HasFocus(9000)"):
        show_main_menu_context()
    else:
        xbmc.executebuiltin("Action(ContextMenu)")


def sync_home_context_keymap():
    """Keep the keymap in place only while Nimbus Plus is the active skin, in
    its own file so the user's own keymaps are never touched. The service
    calls this at startup and when the skin changes."""
    keymap_dir = xbmcvfs.translatePath(KEYMAP_DIR)
    keymap_path = keymap_dir + KEYMAP_NAME
    exists = xbmcvfs.exists(keymap_path)

    if xbmc.getSkinDir() == "skin.nimbus":
        if exists:
            with xbmcvfs.File(keymap_path) as f:
                if f.read() == KEYMAP_CONTENT:
                    return
        elif not xbmcvfs.exists(keymap_dir):
            xbmcvfs.mkdirs(keymap_dir)
        with xbmcvfs.File(keymap_path, "w") as f:
            f.write(KEYMAP_CONTENT)
    elif exists:
        xbmcvfs.delete(keymap_path)
    else:
        return

    xbmc.executebuiltin("Action(reloadkeymaps)")
