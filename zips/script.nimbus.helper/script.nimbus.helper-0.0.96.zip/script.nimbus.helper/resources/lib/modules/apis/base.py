import requests

# Seconds to wait on MDbList/TMDb before giving up (connect and read). Without
# a timeout a stalled connection never returns, leaving the ratings thread
# stuck for the rest of the session. A timeout raises
# requests.Timeout, a RequestException, which every caller already catches.
REQUEST_TIMEOUT = 10

class BaseAPIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create and configure a requests session."""
        session = requests.Session()
        session.mount(self.base_url, requests.adapters.HTTPAdapter(pool_maxsize=100))
        return session