import sqlite3
import datetime as dt
from contextlib import contextmanager
from datetime import datetime, timedelta
import json
import time
from typing import Optional, Tuple, Dict, Any
from ..config import RATINGS_DATABASE_PATH, CACHE_DURATION_DAYS
import xbmcgui, xbmcvfs


# Timestamps are stored as explicit text in this exact format, rather than
# handing sqlite3 a datetime object and letting it convert. That automatic
# conversion (the "default datetime adapter") has been deprecated since
# Python 3.12 - Kodi 22 ships 3.14 and warns on it, and once it's removed
# every ratings write would fail outright. Kodi 21 (Python 3.8/3.11) is
# happy with plain text too, so this is the same on both.
#
# It also fixes a quiet bug in the old conversion: it wrote the fractional
# seconds only when they were non-zero, so a write landing on exactly .000000
# stored "YYYY-MM-DD HH:MM:SS" with no ".%f", which the reader below then
# failed to parse - and that read runs unguarded in the service loop.
# strftime("%f") always writes all six digits.
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
# Rows written before this change may still hold the short form.
_TIMESTAMP_FALLBACK_FORMAT = "%Y-%m-%d %H:%M:%S"


def _now_text() -> str:
    return datetime.now().strftime(TIMESTAMP_FORMAT)


class RatingsDatabase:
    def __init__(self):
        self.db_path = RATINGS_DATABASE_PATH
        self._initialize_database()

    @contextmanager
    def _connect(self):
        """Open a connection, commit on success, and ALWAYS close it.

        `with sqlite3.connect(...) as conn:` looks like it closes the
        connection but doesn't - sqlite3's context manager only commits or
        rolls back. The connection stayed open until garbage collection,
        which Python 3.13+ now reports as an unclosed-database ResourceWarning.
        """
        conn = sqlite3.connect(self.db_path, timeout=60)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _initialize_database(self) -> None:
        """Create database tables if they don't exist."""
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS ratings (
                    imdb_id TEXT,
                    tmdb_id TEXT,
                    ratings TEXT,
                    last_updated TIMESTAMP,
                    PRIMARY KEY (imdb_id, tmdb_id)
                )
            """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS id_mappings (
                    title TEXT,
                    year TEXT,
                    media_type TEXT,
                    imdb_id TEXT,
                    tmdb_id TEXT,
                    last_updated TIMESTAMP,
                    PRIMARY KEY (title, year, media_type)
                )
            """
            )

    def datetime_workaround(self, data, str_format):
        try:
            datetime_object = dt.datetime.strptime(data, str_format)
        except:
            datetime_object = dt.datetime(*(time.strptime(data, str_format)[0:6]))
        return datetime_object

    def _parse_timestamp(self, value) -> Optional[datetime]:
        """Read a stored timestamp in either the current or the older short
        format. Returns None for anything unreadable, which the caller treats
        as expired - a bad row means a fresh API fetch, never an exception.
        """
        if not value:
            return None
        for str_format in (TIMESTAMP_FORMAT, _TIMESTAMP_FALLBACK_FORMAT):
            try:
                return self.datetime_workaround(str(value), str_format)
            except (ValueError, TypeError):
                continue
        return None

    def get_cached_ratings(self, id_to_check: str) -> Optional[Dict[str, Any]]:
        """Get cached ratings if they exist and are not expired."""
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT ratings, last_updated FROM ratings 
                WHERE imdb_id=? OR tmdb_id=?
                """,
                (id_to_check, id_to_check),
            )
            result = cursor.fetchone()

        if result:
            ratings_data, last_updated = result
            last_updated_date = self._parse_timestamp(last_updated)
            if last_updated_date is not None and dt.datetime.now() - last_updated_date < dt.timedelta(
                days=CACHE_DURATION_DAYS
            ):
                try:
                    return json.loads(ratings_data)
                except (ValueError, TypeError):
                    return None
        return None

    def update_ratings(self, primary_id: str, result: Dict[str, Any]) -> None:
        """Update or insert ratings data, using primary_id as fallback."""
        # Extract IDs from result
        imdb_id = result.get(
            "imdbid", primary_id if primary_id.startswith("tt") else None
        )
        tmdb_id = result.get("tmdbid", primary_id if primary_id.isdigit() else None)
        if not imdb_id and not tmdb_id:
            return

        imdb_id = imdb_id or ""
        tmdb_id = tmdb_id or ""

        # Create a clean copy of the ratings data without IDs
        ratings_data = result.copy()
        ratings_data.pop("imdbid", None)
        ratings_data.pop("tmdbid", None)

        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT OR REPLACE INTO ratings (imdb_id, tmdb_id, ratings, last_updated)
                VALUES (?, ?, ?, ?)
                """,
                (imdb_id, tmdb_id, json.dumps(ratings_data), _now_text()),
            )

    def get_cached_ids(
        self, title: str, year: str, media_type: str
    ) -> Tuple[Optional[str], Optional[str]]:
        """Get cached ID mappings."""
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT imdb_id, tmdb_id FROM id_mappings 
                WHERE title=? AND year=? AND media_type=?
                """,
                (title, year, media_type),
            )
            result = cursor.fetchone()
            return result if result else (None, None)

    def cache_ids(
        self,
        title: str,
        year: str,
        media_type: str,
        imdb_id: Optional[str],
        tmdb_id: Optional[str],
    ) -> None:
        """Cache ID mappings."""
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT OR REPLACE INTO id_mappings 
                (title, year, media_type, imdb_id, tmdb_id, last_updated)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    title,
                    str(year) if year else "",
                    media_type,
                    imdb_id,
                    tmdb_id,
                    _now_text(),
                ),
            )

    # def delete_all_ratings(self):
    #     with sqlite3.connect(self.db_path, timeout=60) as conn:
    #         cursor = conn.cursor()
    #     cursor.execute("DELETE FROM ratings")
    #     dialog = xbmcgui.Dialog()
    #     dialog.ok("Nimbus", "All ratings have been cleared from the database.")

    def delete_all_ratings(self):
        with self._connect() as conn:
            cursor = conn.cursor()
            cursor.execute("DROP TABLE IF EXISTS ratings")

            # Recreate the table with new schema
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS ratings (
                    imdb_id TEXT,
                    tmdb_id TEXT,
                    ratings TEXT,
                    last_updated TIMESTAMP,
                    PRIMARY KEY (imdb_id, tmdb_id)
                );
                """
            )
        # Shown after the connection is committed and closed - the dialog is
        # modal, and holding the database open behind it would lock out the
        # ratings service for as long as the user leaves it on screen.
        dialog = xbmcgui.Dialog()
        dialog.ok("Nimbus", "All ratings have been cleared from the database.")
