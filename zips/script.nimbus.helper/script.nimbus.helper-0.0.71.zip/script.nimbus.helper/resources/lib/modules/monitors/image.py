import xbmc
import threading
from typing import Optional, Type
from dataclasses import dataclass
from ..image import ImageBlur


@dataclass
class ImageAnalysisConfig:
    enabled: bool = False
    radius: str = "30"  # Changed default to match original
    saturation: str = "1.5"

    @classmethod
    def from_skin_settings(cls):
        """Create config from current skin settings"""
        return cls(
            enabled=xbmc.getCondVisibility("Skin.HasSetting(Enable.BackgroundBlur)"),
            radius=xbmc.getInfoLabel("Skin.String(BlurRadius)") or "30",
            saturation=xbmc.getInfoLabel("Skin.String(BlurSaturation)") or "1.5",
        )


class ImageMonitor(threading.Thread):
    """Monitors and analyzes images in a separate thread."""

    def __init__(
        self,
        analyzer_class: Type[ImageBlur],
        config: Optional[ImageAnalysisConfig] = None,
    ):
        super().__init__()
        self.analyzer_class = analyzer_class
        self.config = config or ImageAnalysisConfig()
        self._stop_event = threading.Event()
        self.daemon = True

    def run(self) -> None:
        """Main monitoring loop.

        Every wait here checks its return value and breaks. waitForAbort returns
        True the moment Kodi wants to shut down, and once that happens EVERY
        wait returns instantly - so a loop that ignores the result stops
        sleeping and starts spinning, re-reading skin settings and re-running
        image analysis as fast as it can until Kodi gives up and hard-kills the
        script five seconds later ("script didn't stop in 5 seconds" in the
        log). That burn lands at the worst possible moment: during a skin or
        helper update, on whatever hardware the user has.

        The _stop_event test on the while is kept as well, so Service can end
        this thread on its own terms without waiting for a Kodi-wide abort.
        """
        monitor = xbmc.Monitor()
        while not self._stop_event.is_set():
            try:
                if self._is_paused():
                    if monitor.waitForAbort(2):
                        break
                    continue

                if self._not_nimbus():
                    if monitor.waitForAbort(15):
                        break
                    continue

                current_config = ImageAnalysisConfig.from_skin_settings()

                if current_config.enabled:
                    self.analyzer_class(
                        radius=current_config.radius,
                        saturation=current_config.saturation,
                    )
                    if monitor.waitForAbort(0.2):
                        break
                else:
                    if monitor.waitForAbort(3):
                        break

            except Exception as e:
                # This wait needs the same check as the rest. An error that
                # recurs every pass (a missing texture, a bad skin string)
                # would otherwise keep the loop alive through shutdown, which
                # is exactly the case the break is here to stop.
                xbmc.log(f"Image analysis error: {str(e)}", xbmc.LOGERROR)
                if monitor.waitForAbort(0.2):
                    break

    def _is_paused(self) -> bool:
        return xbmc.getInfoLabel("Window(Home).Property(pause_services)") == "true"

    def _not_nimbus(self) -> bool:
        return xbmc.getSkinDir() != "skin.nimbus"

    def stop(self) -> None:
        self._stop_event.set()