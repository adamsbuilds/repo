# -*- coding: utf-8 -*-
"""
Eager widget-image pre-caching, run once per category per Kodi session.

The idea: by the time a widget row scrolls into view, Kodi's texture cache
often hasn't fetched its images yet, so there's a visible pop-in/blank-art
moment. A JSON-RPC call alone (e.g. Files.PrepareDownload) does not
actually fetch or cache anything by itself - it only returns transport
details for a client to do that download separately. The way Kodi's
texture cache actually gets warmed (the same mechanism the well-known
community texturecache.py tool relies on) is by requesting an image
through Kodi's own built-in webserver at:

    http://<host>:<port>/image/<url-encoded original image path>

Requesting that URL is what makes Kodi resolve, fetch, and store the image
in Textures13.db + the Thumbnails folder.

This only works if Kodi's "Allow remote control via HTTP(S)" webserver
setting is switched on. If it's off, this module is a deliberate no-op -
a user who never enables it sees zero difference in behaviour from before
this feature existed.

History:
- Originally ran once at Kodi startup, scanning every known widget
  container. Testing showed Kodi's skin only actually populates the
  container(s) for whichever menu category is currently active - other
  categories stay empty until visited - so a single startup pass could
  only ever catch whichever category happened to be showing at boot.
  Rebuilt to run once per category instead, triggered from
  Includes_Home.xml's onfocus the first time each is genuinely entered.
- That version used a fixed 3-second sleep before reading container
  content, which wasn't long enough for plugin/scraper-backed widgets.
  Replaced with polling until content stabilises, plus per-URL session
  dedupe so already-cached images never get re-fetched.
- Both versions used a hardcoded list of widget list_ids, scraped once
  from this skin's baseline Home.xml. That only ever covered this fork's
  9 built-in categories (addons, music, videos, etc.) - it had no way to
  see list_ids for movies/tvshows or any custom1-10 slot, because those
  are generated per-installation by this fork's own widget/menu
  customization system into separate files, not part of the static
  baseline. A hardcoded list could never be correct for any user's actual
  configuration, only ever a snapshot of one. Replaced with runtime
  discovery: read Home.xml (the built-in categories) and every generated
  script-nimbus-widget_*.xml file (movies/tvshows/custom1-10, whatever a
  given user actually has configured) directly off disk, and pull every
  list_id out of them. Adapts automatically to any user's setup, and to
  changes made mid-session (new widget added via the widget manager) too.

Scope: rather than re-querying a category's own content source (library,
addons://, plugin, etc.), this reads whatever art Kodi has ALREADY
resolved for that category's widget containers' currently-loaded items.
That works uniformly across every content type without needing to know
what kind of widget it is.
"""
import hashlib
import json
import re
import sys
import time
from urllib.parse import quote, unquote

import xbmc
import xbmcgui
import xbmcvfs

from modules.logger import logger

try:
    import requests
except Exception:
    requests = None

MAX_ITEMS_PER_ROW = 24
ART_TYPES = ("thumb", "poster", "fanart", "icon", "landscape")
REQUEST_TIMEOUT = 5  # seconds, per image

# Content-readiness polling: check every POLL_INTERVAL seconds, proceed
# once two consecutive checks find the same set of populated containers
# (stable), capped at MAX_WAIT so a genuinely slow/broken widget doesn't
# leave this waiting forever.
POLL_INTERVAL = 2
MAX_WAIT = 20

# Home window properties. Neither is reset on Home onload (unlike the skin
# string that triggers this in the first place) - both need to persist
# across repeated visits within one session, which is the whole point of
# the dedupe.
PRECACHED_CATEGORIES_PROPERTY = "nimbus_precached_categories"
PRECACHED_URL_HASHES_PROPERTY = "nimbus_precached_url_hashes"

WIDGET_FILE_PATTERN = re.compile(r"^script-nimbus-widget_.*\.xml$", re.IGNORECASE)
LIST_ID_PATTERN = re.compile(r'<param\s+name="list_id"\s+value="(\d+)"')


def _extract_list_ids_from_xml(content):
    """Pulls every <param name="list_id" value="..."/> out of a skin XML
    file's content, via regex rather than a proper XML parser. Deliberate:
    a real generated widget file was found containing an unescaped '<'
    inside an attribute value (invalid XML by strict spec, but Kodi's own
    parser tolerates it and renders the widget fine) - a DOM parser aborts
    the whole file on that, silently losing every list_id in it, which is
    exactly the kind of gap this feature has already lost time to once.
    Regex has no such all-or-nothing failure mode."""
    return {int(match) for match in LIST_ID_PATTERN.findall(content)}


def _read_file(file_path):
    try:
        f = xbmcvfs.File(file_path)
        try:
            return f.read()
        finally:
            f.close()
    except Exception:
        return None


def _discover_widget_list_ids():
    """Discovers every widget list_id by reading the skin's own XML files
    off disk at runtime, rather than a fixed list - see module docstring
    for why. Home.xml covers the built-in categories; every
    script-nimbus-widget_*.xml file found alongside it covers whatever
    movies/tvshows/custom slots this particular user actually has
    configured."""
    list_ids = set()
    skin_xml_dir = xbmcvfs.translatePath("special://skin/xml/")
    if not skin_xml_dir.endswith(("/", "\\")):
        skin_xml_dir += "/"

    home_content = _read_file(skin_xml_dir + "Home.xml")
    if home_content:
        list_ids |= _extract_list_ids_from_xml(home_content)

    try:
        _, files = xbmcvfs.listdir(skin_xml_dir)
    except Exception:
        files = []

    widget_files_read = 0
    for filename in files:
        if WIDGET_FILE_PATTERN.match(filename):
            content = _read_file(skin_xml_dir + filename)
            if content:
                list_ids |= _extract_list_ids_from_xml(content)
                widget_files_read += 1

    logger(
        "NimbusImagePrecache",
        "discovery: %d list_ids from Home.xml + %d generated widget file(s)"
        % (len(list_ids), widget_files_read),
    )
    return sorted(list_ids)


def _get_setting(setting_id):
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Settings.GetSettingValue",
        "params": {"setting": setting_id},
    }
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        return result.get("result", {}).get("value")
    except Exception:
        return None


def _webserver_config():
    """Returns (base_url, auth) if Kodi's webserver is on, else None."""
    if not _get_setting("services.webserver"):
        return None

    port = _get_setting("services.webserverport") or 8080
    username = _get_setting("services.webserverusername") or ""
    password = _get_setting("services.webserverpassword") or ""
    base_url = "http://127.0.0.1:%s/image/" % port
    auth = (username, password) if username else None
    return base_url, auth


def _collect_art_urls(list_ids):
    """Reads whatever art Kodi has already resolved for each given widget
    container's currently-loaded items.

    Returns (urls, populated_list_ids) - the second is used both for
    diagnostics and as the readiness-polling signal.
    """
    urls = set()
    populated_list_ids = []
    for list_id in list_ids:
        row_had_items = False
        for i in range(MAX_ITEMS_PER_ROW):
            label = xbmc.getInfoLabel("Container(%s).ListItem(%d).Label" % (list_id, i))
            if not label:
                break  # end of this row's items
            row_had_items = True
            for art_type in ART_TYPES:
                url = xbmc.getInfoLabel(
                    "Container(%s).ListItem(%d).Art(%s)" % (list_id, i, art_type)
                )
                if url and _is_cacheable_url(url):
                    urls.add(url)
        if row_had_items:
            populated_list_ids.append(list_id)
    return urls, populated_list_ids


def _is_cacheable_url(url):
    """Filters out Kodi's own bundled default icons (DefaultFolder.png,
    DefaultAddon.png, etc.) - bare filenames with no real path, resolved
    from inside Kodi itself rather than fetched. They load instantly
    regardless and were never things this feature could speed up, so
    sending them through the image-proxy only ever produced a 404 that
    looked like a failure but never actually was one."""
    return "/" in url or "\\" in url


def _wait_for_stable_content(list_ids):
    """Polls _collect_art_urls() until the set of populated containers
    stops changing between two consecutive checks, rather than assuming a
    fixed delay is enough - plugin/scraper-backed widgets can take much
    longer than a local library query to populate, and that varies too
    much to guess at with a constant sleep."""
    previous = None
    waited = 0
    urls, populated = _collect_art_urls(list_ids)
    while waited < MAX_WAIT:
        current = frozenset(populated)
        if current == previous:
            break
        previous = current
        xbmc.sleep(POLL_INTERVAL * 1000)
        waited += POLL_INTERVAL
        urls, populated = _collect_art_urls(list_ids)
    return urls, populated, waited


def _hash(url):
    return hashlib.md5(url.encode("utf-8")).hexdigest()


def _fetch_and_cache(urls, home_window):
    """Requests each art URL through the webserver's image-proxy endpoint
    (what actually warms Kodi's texture cache), skipping any URL already
    successfully cached earlier this session. Returns
    (new_count, cached_count, failed_count, failure_reasons)."""
    config = _webserver_config()
    if config is None:
        return None
    base_url, auth = config

    already_hashed = home_window.getProperty(PRECACHED_URL_HASHES_PROPERTY)
    already = set(already_hashed.split(",")) if already_hashed else set()

    new_urls = [u for u in urls if _hash(u) not in already]

    cached, failed = 0, 0
    failure_reasons = {}
    newly_hashed = set()
    sample_failures = []
    for art_url in new_urls:
        try:
            # Kodi's texture cache only gets warmed by requesting its own
            # image:// VFS wrapper around the raw URL, not the raw URL
            # itself - and that wrapped path needs encoding TWICE: once
            # for what Kodi's image:// unwrapping will decode, once more
            # because the outer layer gets consumed by HTTP request
            # parsing before Kodi's handler even sees it. A bare single-
            # encoded raw URL (what this used to send) 404s for literally
            # every image, not just unusual ones - confirmed against a
            # working reference implementation that does exactly this.
            #
            # unquote() first because some source addons report art URLs
            # that already contain percent-encoding of their own (e.g. a
            # literal "%20" in place of a space) - double-encoding that
            # as-is stacks an extra, unintended layer of escaping on top
            # and produces a URL Kodi can't correctly unwrap. Normalizing
            # back to the true, fully-decoded form first means both
            # already-encoded and never-encoded source URLs converge on
            # the same correct result. A no-op for the common case where
            # there was nothing to decode.
            normalized = unquote(art_url)
            double_encoded = quote(quote(normalized, safe=""), safe="")
            target = base_url + "image://" + double_encoded
            response = requests.get(target, auth=auth, timeout=REQUEST_TIMEOUT)
            if response.status_code == 200:
                cached += 1
                newly_hashed.add(_hash(art_url))
            else:
                failed += 1
                key = "HTTP %d" % response.status_code
                failure_reasons[key] = failure_reasons.get(key, 0) + 1
                if len(sample_failures) < 3:
                    sample_failures.append((art_url, target))
        except Exception as exc:
            failed += 1
            key = type(exc).__name__
            failure_reasons[key] = failure_reasons.get(key, 0) + 1

    if sample_failures:
        for raw, wrapped in sample_failures:
            logger("NimbusImagePrecache", "sample failure - raw=%r wrapped=%r" % (raw, wrapped))

    if newly_hashed:
        home_window.setProperty(
            PRECACHED_URL_HASHES_PROPERTY, ",".join(already | newly_hashed)
        )

    return len(new_urls), cached, failed, failure_reasons


def precache_category():
    """Entry point - called via RunScript(...,mode=precache_category,<widget_menu>)
    from Includes_Home.xml, once per genuine category change. No-ops
    immediately if this category was already precached earlier in the
    session."""
    if len(sys.argv) < 3:
        return
    widget_menu = sys.argv[2]
    if not widget_menu:
        return

    home_window = xbmcgui.Window(10000)
    already_done = home_window.getProperty(PRECACHED_CATEGORIES_PROPERTY)
    done_list = already_done.split(",") if already_done else []
    if widget_menu in done_list:
        return

    def _mark_category_done():
        done_list.append(widget_menu)
        home_window.setProperty(PRECACHED_CATEGORIES_PROPERTY, ",".join(done_list))

    if requests is None:
        logger("NimbusImagePrecache", "script.module.requests unavailable - skipping")
        _mark_category_done()
        return

    if not _get_setting("services.webserver"):
        logger(
            "NimbusImagePrecache",
            "category=%s: webserver disabled - skipping, no behaviour change" % widget_menu,
        )
        _mark_category_done()
        return

    start = time.time()
    list_ids = _discover_widget_list_ids()
    urls, populated_list_ids, waited = _wait_for_stable_content(list_ids)
    result = _fetch_and_cache(urls, home_window)
    _mark_category_done()

    if result is None:
        return  # webserver was on moments ago but isn't now - rare, just skip
    new_count, cached, failed, failure_reasons = result

    logger(
        "NimbusImagePrecache",
        "category=%s settled after %ds, populated_containers=%s"
        % (widget_menu, waited, populated_list_ids),
    )
    if failure_reasons:
        logger("NimbusImagePrecache", "category=%s failure reasons: %s" % (widget_menu, failure_reasons))
    logger(
        "NimbusImagePrecache",
        "category=%s found=%d new=%d cached=%d failed=%d total=%dms"
        % (widget_menu, len(urls), new_count, cached, failed, int((time.time() - start) * 1000)),
    )