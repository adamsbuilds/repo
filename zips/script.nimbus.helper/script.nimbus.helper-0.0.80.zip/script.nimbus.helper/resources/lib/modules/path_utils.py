# -*- coding: utf-8 -*-
"""Shared helpers for keeping any path Nimbus writes into a Skin.String,
a submenu action/target, or the cpath database in the portable
special:// form instead of a machine-specific OS-native absolute path.

Where this matters: Dialog().browse() (used by set_image() for the
custom background picker) and Files.GetDirectory (used by both
cpath_maker.path_browser() and custom_actions._submenu_path_browser()
when walking a third-party addon's own menu) can both hand back an
absolute OS path - e.g. C:\\Users\\ADMIN\\AppData\\Roaming\\Kodi\\...
on Windows - instead of a special:// one. The addon case is usually a
third-party addon embedding its own local icon/fanart path inside the
plugin:// URL it hands back for one of its menu items (thechains and
mp3streams both do this), not anything Nimbus put there - but once
captured verbatim into a skin string or the cpath database, it's
indistinguishable from one Nimbus wrote, and it ships the same way.

Either way, once that raw path lands in a skin string or the cpath
database, it survives into a packaged/exported settings.xml and breaks
on any other machine or platform: confirmed case was a Windows-built
settings.xml installed on Android, still pointing at C:\\Users\\...
paths that don't exist there. special:// paths resolve per-install, so
they're the only form safe to persist.
"""
import re
import xbmcvfs
from urllib.parse import quote, unquote

# Ordered so the most specific (longest translated prefix) is tried
# first - special://profile can resolve underneath special://home on
# some setups, so checking home first could match too early and produce
# a needlessly-deep special://home/... path instead of the closer
# special://profile/... one. _special_prefixes() re-sorts by actual
# translated length anyway, but keep this listed narrowest-first too.
_SPECIAL_ROOTS = ["masterprofile", "profile", "temp", "home", "xbmcbin", "xbmc", "userdata"]

# Matches a Windows drive-letter path (C:\... or C:/...) embedded
# inside a larger string, stopping at whitespace or a character that
# would end a query-string value (&, quotes, angle brackets) - or, now
# that this also runs against a whole Kodi favourite entry, a comma or
# closing paren, since favourites.xml wraps its target in something
# like ActivateWindow(...,return) with no separator between the path
# and that ",return)" tail. Without stopping there, a path with nothing
# else after it would swallow ",return)" straight into the "path" and
# mangle the action - caught by testing against a realistic favourite
# entry, not just a bare URL. This can pull a path out of the middle of
# a plugin:// URL without eating the rest of the URL. The lookbehind
# requires the letter to sit at a real boundary (start of string, =, &,
# or similar) rather than mid-word - without it, "https://..." would
# false-match on the "s:" in "https:" and get mangled as if "s:" were a
# drive letter.
_ABS_PATH_RE = re.compile(r'(?<![A-Za-z0-9])[A-Za-z]:[\\/][^&"\'<>\s,()]*')

# Same idea, but for a drive-letter path that's been percent-encoded into
# a URL query value rather than dropped in literally - confirmed case:
# mp3streams builds its own iconimage= query param this way, so
# "C:\Users\..." shows up as "C%3A%5CUsers%5C..." instead. Plain-text
# _ABS_PATH_RE can't see this at all: there's no literal ":" or "\" in
# the string for it to match. %3A/%5C/%2F are matched case-insensitively
# since percent-encoding case isn't consistent between addons (or even
# within one addon's own URLs).
_ENCODED_ABS_PATH_RE = re.compile(
    r'(?<![A-Za-z0-9%])[A-Za-z]%3[Aa](?:%5[Cc]|%2[Ff])[^&"\'<>\s,()]*'
)

# Android/Linux-style absolute path - NOT a bare leading slash (that's
# still indistinguishable from an ordinary URL path segment, so still
# deliberately not matched - see sanitize_embedded_paths' docstring).
# This instead recognizes a narrow set of real, well-known Android
# device-storage prefixes that never legitimately appear as a segment
# inside a normal plugin:// URL: confirmed case is an addon computing
# its own live Android install path (e.g. via ADDON.getAddonInfo('path'))
# on-device and that value getting captured/frozen into a stored widget
# URL the same way a Windows C:\ path was - same disease, different OS.
# Covers the modern scoped-storage layout (/storage/emulated/0/...),
# external/SD card storage (/storage/<volume-id>/...), older direct
# data-partition layouts (/data/data/... and /data/user/<n>/...), and
# the legacy /sdcard symlink.
_ANDROID_PATH_RE = re.compile(
    r'(?<![A-Za-z0-9])/(?:storage/(?:emulated/\d+|[A-Za-z0-9\-]+)'
    r'|data/(?:data|user/\d+)|sdcard)/[^&"\'<>\s,()]*'
)

# Same paths, percent-encoded - the leading "/" becomes "%2F". Confirmed
# necessary for the same reason as _ENCODED_ABS_PATH_RE: an addon can
# encode this same value into one of its own query params.
_ENCODED_ANDROID_PATH_RE = re.compile(
    r'(?<![A-Za-z0-9%])%2[Ff](?:storage%2F(?:emulated%2F\d+|[A-Za-z0-9\-]+)'
    r'|data%2F(?:data|user%2F\d+)|sdcard)%2F[^&"\'<>\s,()]*',
    re.IGNORECASE,
)


def _special_prefixes():
    prefixes = []
    for root in _SPECIAL_ROOTS:
        translated = xbmcvfs.translatePath("special://%s/" % root).replace("\\", "/")
        # translatePath() echoes the input back unchanged for a root it
        # doesn't recognise - skip those rather than matching against
        # the literal string "special://root/".
        if translated and translated != "special://%s/" % root:
            prefixes.append((root, translated))
    prefixes.sort(key=lambda item: len(item[1]), reverse=True)
    return prefixes


def to_special_path(path):
    """Converts a single OS-native absolute path back to special:// form
    when it falls under one of Kodi's own special:// roots. Returns the
    path unchanged if it's already special:// (or any other Kodi VFS
    protocol, e.g. plugin://), or if it doesn't fall under any known
    special:// root (e.g. a genuinely external drive/folder) - there's
    no portable equivalent for those, so leave it as-is rather than
    silently rewriting into something wrong.
    """
    if not path or "://" in path:
        return path
    # Collapse any RUN of backslashes into a single slash, not a strict
    # 1:1 swap. Confirmed case: mp3streams double-escapes backslashes in
    # one of the two embedded copies of the same path it writes into its
    # own menu URL (see the "list=...<>...<>..." segment - the iconimage=
    # copy right next to it uses single backslashes). A plain .replace("\\",
    # "/") turns that doubled "\\\\" into a doubled "//", which then fails
    # to match a special:// prefix (always single-slash) and silently
    # passes through unconverted.
    normalized = re.sub(r"\\+", "/", path)
    for root, prefix in _special_prefixes():
        if normalized.lower().startswith(prefix.lower()):
            remainder = normalized[len(prefix):]
            return "special://%s/%s" % (root, remainder)
    return path


def sanitize_embedded_paths(text):
    """Scans a string (e.g. a captured plugin:// URL or an
    ActivateWindow(...) action built from one) for any embedded absolute
    path - Windows drive-letter or Android device-storage, plain or
    percent-encoded - and rewrites each one through to_special_path().
    Leaves everything else untouched, including any match that isn't
    under a known special:// root. Safe to call on any string - a no-op
    when nothing matches.

    Both path families are matched narrowly on purpose: a bare leading
    slash is indistinguishable from an ordinary URL path segment once
    it's embedded inside a larger string, so only a real drive letter
    (C:\\...) or one of a handful of well-known, unambiguous Android
    storage prefixes (/storage/emulated/0/..., /data/data/..., etc.) is
    matched - not "any absolute-looking path" - to avoid mangling
    unrelated URL content.
    """
    if not text:
        return text

    def _replace_plain(match):
        return to_special_path(match.group(0))

    def _replace_encoded(match):
        decoded = unquote(match.group(0))
        converted = to_special_path(decoded)
        if converted == decoded:
            # Nothing to convert (not under a known special:// root) -
            # leave the original encoded text exactly as it was rather
            # than re-encoding it into a possibly different-looking but
            # equivalent string.
            return match.group(0)
        # quote() only the parts a URL needs escaped - ':' and '/' stay
        # literal, matching how a special:// path normally appears
        # elsewhere in these same URLs.
        return quote(converted, safe=":/")

    text = _ABS_PATH_RE.sub(_replace_plain, text)
    text = _ENCODED_ABS_PATH_RE.sub(_replace_encoded, text)
    text = _ANDROID_PATH_RE.sub(_replace_plain, text)
    text = _ENCODED_ANDROID_PATH_RE.sub(_replace_encoded, text)
    return text