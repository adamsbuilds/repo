# -*- coding: utf-8 -*-
import xbmc
from xbmcgui import Window
from xbmc import sleep, getInfoLabel
from xbmcvfs import translatePath
from xbmcaddon import Addon
import json
import os

# from modules.logger import logger

window = Window(10000)

PROFILE_PATH = os.path.join(
    translatePath("special://userdata/addon_data/script.nimbus.helper"),
    "current_profile.json",
)


# The last skin version we ran a remake for.
#
# This used to live only in a Window(10000) property, which made the whole
# "restore the user's menus after a skin update" feature depend on winning a
# race: the property had to still hold the OLD version at the moment Home's
# onload fired after the update. If the update landed before Home's first
# onload of the session, that onload recorded the NEW version, the comparison
# matched, and the remake never ran - not then, not ever. Kodi applies addon
# updates on a timer shortly after startup, so which side of that race you
# land on can shift between Kodi releases without anything here changing.
#
# So the version now goes to disk, exactly like current_profile.json below,
# with the window property kept only as a fast path to skip a file read on
# every Home load.
#
# special://profile rather than userdata, matching SETTINGS_PATH in config.py,
# so each Kodi profile tracks its own skin version - a per-profile remake is
# pointless if every profile shares one version file.
VERSION_PATH = os.path.join(
    translatePath("special://profile/addon_data/script.nimbus.helper"),
    "installed_version.json",
)


def _read_saved_version(skin_id):
    """Last version we remade for: window property first, then disk."""
    property_version = window.getProperty("%s.installed_version" % skin_id)
    if property_version:
        return property_version
    try:
        with open(VERSION_PATH, "r") as f:
            saved = json.load(f)
    except (IOError, OSError, ValueError):
        # Missing (first run after this change), unreadable, or corrupt - all
        # three mean we have nothing to compare against.
        return None
    if not isinstance(saved, dict):
        return None
    version = saved.get(skin_id)
    if version:
        # Warm the property so later Home loads this session skip the read.
        window.setProperty("%s.installed_version" % skin_id, version)
    return version


# One flag for BOTH callers, not one each. Home's onload fires check_for_update
# and check_for_profile_change as two separate RunScript invocations, so they are
# two independent interpreters that can be inside remake_all_cpaths at the same
# moment - writing the same 24 generated files over each other. Whichever gets
# here first does the work; the other returns and lets it.
#
# It is a window property because a module-level flag is invisible across those
# interpreters. If a script is killed outright the flag stays set for the rest of
# the Kodi session and blocks retries until the next start. Deliberate: whatever
# just killed one remake mid-flight is unlikely to let the next one finish.
REMAKE_FLAG = "nimbus.helper.remake_running"


def _guarded_remake(record):
    """Rebuild every generated file, persist `record`, then reload the skin.

    The order is the whole point. `record` used to run BEFORE the remake, so an
    interrupted rebuild was permanent - the new version or profile was already
    stored, every later Home load saw it as up to date and returned early, and
    the half-written files could only be repaired by a manual "Remake menus and
    widgets". Recording only after the writes succeed means an interrupted run
    stores nothing and the next Home load simply tries again.

    It still has to be recorded BEFORE the reload, though: the reload re-runs
    Home's onload, which calls straight back into here. Without the record in
    place first, that would restart the remake indefinitely.
    """
    if window.getProperty(REMAKE_FLAG) == "true":
        return
    window.setProperty(REMAKE_FLAG, "true")
    try:
        from modules.cpath_maker import remake_all_cpaths

        remake_all_cpaths(silent=True, reload_skin=False)
        record()
    finally:
        window.setProperty(REMAKE_FLAG, "")
    xbmc.executebuiltin("ReloadSkin()")


def check_for_update(skin_id):
    try:
        installed_version = Addon(id=skin_id).getAddonInfo("version")
    except Exception:
        # Mid-reload the addon can briefly be unavailable. Do nothing rather
        # than record a bad value - the next Home load tries again.
        return
    if not installed_version:
        return

    saved_version = _read_saved_version(skin_id)

    if not saved_version:
        # Nothing on record: either a genuinely fresh install, or the first run
        # after this change shipped. Both want the same thing - record the
        # version so the NEXT update is caught. Deliberately no remake here; a
        # fresh install has nothing to restore.
        return set_installed_version(skin_id, installed_version)

    if saved_version == installed_version:
        return

    sleep(1000)
    _guarded_remake(lambda: set_installed_version(skin_id, installed_version))


def set_installed_version(skin_id, installed_version):
    window.setProperty("%s.installed_version" % skin_id, installed_version)

    # Merge rather than overwrite: one file keyed by skin id, so this still
    # behaves if it is ever called for more than one skin.
    try:
        with open(VERSION_PATH, "r") as f:
            saved = json.load(f)
        if not isinstance(saved, dict):
            saved = {}
    except (IOError, OSError, ValueError):
        saved = {}

    saved[skin_id] = installed_version

    try:
        dir_path = os.path.dirname(VERSION_PATH)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
        with open(VERSION_PATH, "w") as f:
            json.dump(saved, f)
    except (IOError, OSError):
        # Read-only userdata, permissions, full disk. The window property is
        # still set, so this session behaves as it always did; only the
        # across-restart guarantee is lost.
        pass


def set_current_profile(skin_id, current_profile):
    dir_path = os.path.dirname(PROFILE_PATH)
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    with open(PROFILE_PATH, "w") as f:
        json.dump(current_profile, f)
    window.setProperty("%s.current_profile" % skin_id, current_profile)

def get_profile_count():
    json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Profiles.GetProfiles", "id": 1}')
    json_response = json.loads(json_query)
    if 'result' in json_response and 'profiles' in json_response['result']:
        return len(json_response['result']['profiles'])
    return 0

def check_for_profile_change(skin_id):
    if get_profile_count() <= 1:
        return 
    current_profile = getInfoLabel("System.ProfileName")
    saved_profile = window.getProperty("%s.current_profile" % skin_id)
    try:
        with open(PROFILE_PATH, "r") as f:
            saved_profile = json.load(f)
    except FileNotFoundError:
        saved_profile = None
    if not saved_profile:
        set_current_profile(skin_id, current_profile)
        return
    if saved_profile == current_profile:
        return

    xbmc.sleep(200)
    _guarded_remake(lambda: set_current_profile(skin_id, current_profile))


# def check_for_profile_change(skin_id):
#     current_profile = getInfoLabel("System.ProfileName")
#     saved_profile = window.getProperty("%s.current_profile" % skin_id)
#     try:
#         with open(PROFILE_PATH, "r") as f:
#             saved_profile = json.load(f)
#     except FileNotFoundError:
#         saved_profile = None
#     if not saved_profile:
#         set_current_profile(skin_id, current_profile)
#         return
#     if saved_profile == current_profile:
#         return
#     from modules.cpath_maker import remake_all_cpaths

#     set_current_profile(skin_id, current_profile)
#     sleep(200)
#     remake_all_cpaths(silent=True)