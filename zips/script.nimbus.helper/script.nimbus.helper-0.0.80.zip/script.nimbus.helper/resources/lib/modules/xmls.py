# -*- coding: utf-8 -*-

media_xml_start = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{main_include}">'''

media_xml_end = '''
  </include>'''

# Per-slot scroll animation for the home screen widget stack.
# Each row gets one conditional slide whose offset matches that row's own
# layout height, so mixed-height rows (e.g. Category pills) stay in sync.
widget_slide_start = '''
  <include name="{main_include}Slide">'''

# One animation PER ROW, holding while the stack is scrolled below that row, so
# the active ones sum to the current scroll offset.
#
# This replaced a Position-based model (one step per grouplist position, offset
# looked up from a dense list of every configured row). That could not survive a
# row disappearing, and rows disappear routinely: a widget whose directory comes
# back empty hides itself, and while a row is still loading it briefly shows a
# busy spinner as an EXTRA grouplist child. Both change how many positions a row
# contributes - 2 normally, 3 while loading, 0 when empty - so the dense
# position->row mapping silently shifted and every row below the gap scrolled by
# the wrong amount. It only showed up with mixed row heights, because with
# uniform rows the wrong advance happens to equal the right one.
#
# Keying off the rows themselves removes the whole class of bug: each row
# contributes its own height, gated on its own visibility, and nothing depends
# on counting positions.
#
# The $EXP[widget_scroll_hold] term (Expressions.xml) drops the whole sum when
# focus leaves the widgets and FocusTopWidgetOnHome is set, animating the rows
# back down to the top of the stack.
widget_slide_body = '''
    <animation effect="slide" end="0,{offset}" time="500" tween="cubic" easing="inout" reversible="true" condition="{condition}">Conditional</animation>'''

widget_slide_end = '''
  </include>
</includes>'''

media_xml_body = '''
    <include content="{cpath_type}">
      <param name="content_path" value="{cpath_path}"/>
      <param name="widget_header" value="{cpath_header}"/>
      <param name="widget_target" value="videos"/>
      <param name="list_id" value="{cpath_list_id}"/>
      <param name="widget_slot" value="{widget_slot}"/>
      <param name="widget_menu" value="{widget_menu}"/>
    </include>'''

history_xml_body = '''
    <item>
      <label>$NUMBER[{spath}]</label>
      <onclick>RunScript(script.nimbus.helper,mode=re_search)</onclick>
    </item>'''

main_menu_movies_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="MoviesMainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[19000]</property>
      <property name="id">movies</property>
      <visible>!Skin.HasSetting(HomeMenuNoMovieButton)</visible>
    </item>
  </include>
</includes>'''

main_menu_tvshows_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="TVShowsMainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[22000]</property>
      <property name="id">tvshows</property>
      <visible>!Skin.HasSetting(HomeMenuNoTVShowButton)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom1_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom1MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[23000]</property>
      <property name="id">custom1</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom1Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom2_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom2MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[24000]</property>
      <property name="id">custom2</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom2Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom3_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom3MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[25000]</property>
      <property name="id">custom3</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom3Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom4_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom4MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[26000]</property>
      <property name="id">custom4</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom4Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom5_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom5MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[27000]</property>
      <property name="id">custom5</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom5Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom6_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom6MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[28000]</property>
      <property name="id">custom6</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom6Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom7_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom7MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[29000]</property>
      <property name="id">custom7</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom7Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom8_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom8MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[30000]</property>
      <property name="id">custom8</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom8Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom9_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom9MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[31000]</property>
      <property name="id">custom9</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom9Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_custom10_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="Custom10MainMenu">
    <item>
      <label>{cpath_header}</label>
      <onclick>ActivateWindow({window_target},{main_menu_path},return)</onclick>
      <property name="menu_id">$NUMBER[32000]</property>
      <property name="id">custom10</property>
      <visible>!Skin.HasSetting(HomeMenuNoCustom10Button)</visible>
    </item>
  </include>
</includes>'''

main_menu_submenu_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{main_include}">
    <item>
      <label>{cpath_header}</label>
      <onclick>SetProperty(nimbus_submenu_id,{id},Home)</onclick>
      <onclick>SetProperty(nimbus_return_focus,9000,Home)</onclick>
      <onclick>ActivateWindow(1122)</onclick>
      <property name="menu_id">$NUMBER[{menu_id}]</property>
      <property name="id">{id}</property>
      <visible>!Skin.HasSetting({visible_setting})</visible>
    </item>
  </include>
</includes>'''

# A raw, user-supplied action (e.g. PlayMedia(...), or any other builtin) -
# used verbatim, unlike main_menu_xml which always wraps a captured path in
# ActivateWindow(window_target,...,return). Shared across all media types,
# same reasoning as main_menu_submenu_xml above: this doesn't need a
# per-media-type window_target/main_menu_path pair at all.
main_menu_custom_action_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{main_include}">
    <item>
      <label>{cpath_header}</label>
      <onclick>{custom_action}</onclick>
      <property name="menu_id">$NUMBER[{menu_id}]</property>
      <property name="id">{id}</property>
      <visible>!Skin.HasSetting({visible_setting})</visible>
    </item>
  </include>
</includes>'''

# --- Home menu item ordering -------------------------------------------------
# The home menu's item order used to be baked into Home.xml's <content>.
# It is now a generated include: Home.xml just pulls in MainMenuOrder, and
# this file lists the per-item includes (MainMenuItem_<id>, defined in the
# skin's Includes_HomeMenuItems.xml) in the user's chosen order.
#
# Reordering therefore never touches item definitions, only their sequence -
# every menu_id / id property, submenu trigger and widget panel keeps working
# untouched, because all of those key off the item's own properties rather
# than its position in the list.
main_menu_order_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="MainMenuOrder">{items}
  </include>
</includes>'''

main_menu_order_body = '''
    <include content="MainMenuItem_{item_id}" />'''

search_history_xml = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="SearchHistory">
    <item>
      <label>{spath}</label>
      <onclick>RunScript(script.nimbus.helper,mode=re_search)</onclick>
    </item>
  </include>
</includes>'''

default_widget = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{includes_type}">
  </include>
  <include name="{includes_type}Slide">
  </include>
</includes>'''

default_main_menu = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{includes_type}">
  </include>
</includes>'''

default_history = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <include name="{includes_type}">
  </include>
</includes>'''