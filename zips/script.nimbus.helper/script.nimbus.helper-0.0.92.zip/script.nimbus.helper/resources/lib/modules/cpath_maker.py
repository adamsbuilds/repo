# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs
import json
import sqlite3 as database
from threading import Thread
from xml.sax.saxutils import unescape as xml_unescape
from modules import xmls
from modules import path_utils
from modules import custom_actions

# from modules.logger import logger

dialog = xbmcgui.Dialog()
window = xbmcgui.Window(10000)
Listitem = xbmcgui.ListItem
max_widgets = 50

settings_path = xbmcvfs.translatePath(
    "special://profile/addon_data/script.nimbus.helper/"
)
database_path = xbmcvfs.translatePath(
    "special://profile/addon_data/script.nimbus.helper/cpath_cache.db"
)
(
    movies_widgets_xml,
    tvshows_widgets_xml,
    custom1_widgets_xml,
    custom2_widgets_xml,
    custom3_widgets_xml,
    custom4_widgets_xml,
    custom5_widgets_xml,
    custom6_widgets_xml,
    custom7_widgets_xml,
    custom8_widgets_xml,
    custom9_widgets_xml,
    custom10_widgets_xml,
) = (
    "script-nimbus-widget_movies",
    "script-nimbus-widget_tvshows",
    "script-nimbus-widget_custom1",
    "script-nimbus-widget_custom2",
    "script-nimbus-widget_custom3",
    "script-nimbus-widget_custom4",
    "script-nimbus-widget_custom5",
    "script-nimbus-widget_custom6",
    "script-nimbus-widget_custom7",
    "script-nimbus-widget_custom8",
    "script-nimbus-widget_custom9",
    "script-nimbus-widget_custom10",
)
(
    movies_main_menu_xml,
    tvshows_main_menu_xml,
    custom1_main_menu_xml,
    custom2_main_menu_xml,
    custom3_main_menu_xml,
    custom4_main_menu_xml,
    custom5_main_menu_xml,
    custom6_main_menu_xml,
    custom7_main_menu_xml,
    custom8_main_menu_xml,
    custom9_main_menu_xml,
    custom10_main_menu_xml,
) = (
    "script-nimbus-main_menu_movies",
    "script-nimbus-main_menu_tvshows",
    "script-nimbus-main_menu_custom1",
    "script-nimbus-main_menu_custom2",
    "script-nimbus-main_menu_custom3",
    "script-nimbus-main_menu_custom4",
    "script-nimbus-main_menu_custom5",
    "script-nimbus-main_menu_custom6",
    "script-nimbus-main_menu_custom7",
    "script-nimbus-main_menu_custom8",
    "script-nimbus-main_menu_custom9",
    "script-nimbus-main_menu_custom10",
)
default_xmls = {
    "movie.widget": (movies_widgets_xml, xmls.default_widget, "MovieWidgets"),
    "tvshow.widget": (tvshows_widgets_xml, xmls.default_widget, "TVShowWidgets"),
    "custom1.widget": (custom1_widgets_xml, xmls.default_widget, "Custom1Widgets"),
    "custom2.widget": (custom2_widgets_xml, xmls.default_widget, "Custom2Widgets"),
    "custom3.widget": (custom3_widgets_xml, xmls.default_widget, "Custom3Widgets"),
    "custom4.widget": (custom4_widgets_xml, xmls.default_widget, "Custom4Widgets"),
    "custom5.widget": (custom5_widgets_xml, xmls.default_widget, "Custom5Widgets"),
    "custom6.widget": (custom6_widgets_xml, xmls.default_widget, "Custom6Widgets"),
    "custom7.widget": (custom7_widgets_xml, xmls.default_widget, "Custom7Widgets"),
    "custom8.widget": (custom8_widgets_xml, xmls.default_widget, "Custom8Widgets"),
    "custom9.widget": (custom9_widgets_xml, xmls.default_widget, "Custom9Widgets"),
    "custom10.widget": (custom10_widgets_xml, xmls.default_widget, "Custom10Widgets"),
    "movie.main_menu": (movies_main_menu_xml, xmls.default_main_menu, "MoviesMainMenu"),
    "tvshow.main_menu": (
        tvshows_main_menu_xml,
        xmls.default_main_menu,
        "TVShowsMainMenu",
    ),
    "custom1.main_menu": (
        custom1_main_menu_xml,
        xmls.default_main_menu,
        "Custom1MainMenu",
    ),
    "custom2.main_menu": (
        custom2_main_menu_xml,
        xmls.default_main_menu,
        "Custom2MainMenu",
    ),
    "custom3.main_menu": (
        custom3_main_menu_xml,
        xmls.default_main_menu,
        "Custom3MainMenu",
    ),
    "custom4.main_menu": (
        custom4_main_menu_xml,
        xmls.default_main_menu,
        "Custom4MainMenu",
    ),
    "custom5.main_menu": (
        custom5_main_menu_xml,
        xmls.default_main_menu,
        "Custom5MainMenu",
    ),
    "custom6.main_menu": (
        custom6_main_menu_xml,
        xmls.default_main_menu,
        "Custom6MainMenu",
    ),
    "custom7.main_menu": (
        custom7_main_menu_xml,
        xmls.default_main_menu,
        "Custom7MainMenu",
    ),
    "custom8.main_menu": (
        custom8_main_menu_xml,
        xmls.default_main_menu,
        "Custom8MainMenu",
    ),
    "custom9.main_menu": (
        custom9_main_menu_xml,
        xmls.default_main_menu,
        "Custom9MainMenu",
    ),
    "custom10.main_menu": (
        custom10_main_menu_xml,
        xmls.default_main_menu,
        "Custom10MainMenu",
    ),
}
main_include_dict = {
    "movie": {"main_menu": None, "widget": "MovieWidgets"},
    "tvshow": {"main_menu": None, "widget": "TVShowWidgets"},
    "custom1": {"main_menu": None, "widget": "Custom1Widgets"},
    "custom2": {"main_menu": None, "widget": "Custom2Widgets"},
    "custom3": {"main_menu": None, "widget": "Custom3Widgets"},
    "custom4": {"main_menu": None, "widget": "Custom4Widgets"},
    "custom5": {"main_menu": None, "widget": "Custom5Widgets"},
    "custom6": {"main_menu": None, "widget": "Custom6Widgets"},
    "custom7": {"main_menu": None, "widget": "Custom7Widgets"},
    "custom8": {"main_menu": None, "widget": "Custom8Widgets"},
    "custom9": {"main_menu": None, "widget": "Custom9Widgets"},
    "custom10": {"main_menu": None, "widget": "Custom10Widgets"},
}
widget_types = (
    ("Poster", "WidgetListPoster"),
    ("Landscape", "WidgetListLandscape"),
    ("Large Poster", "WidgetListLargePoster"),
    ("Large Landscape", "WidgetListLargeLandscape"),
    ("Square", "WidgetListCategory"),
    ("Category", "WidgetListPill"),
)

# --- Home screen widget row geometry -----------------------------------------
# The home screen scrolls its widget stack with conditional slide animations,
# one per row. A row's slide MUST equal that row's real layout advance in the
# grouplist, or the stack drifts as you scroll.
#
# The real advance is NOT simply the fixedlist <height>: the grouplist uses
# usecontrolcoords with a negative itemgap, so it can't be derived from the XML
# reliably. These values are calibrated by observation instead.
#
# CALIBRATING A ROW TYPE:
#   Scroll down through several rows of that type and watch the focused row.
#     focused row creeps DOWN the screen -> pitch is too small, increase it
#     focused row creeps UP the screen   -> pitch is too large, decrease it
#   Adjust by roughly the per-step drift you see, then re-save any widget in
#   the slot to regenerate the XML.
#
# TIGHTENING A ROW TYPE (less vertical space per row):
#   Lower that type's <height> in Includes_Home.xml, then lower its pitch here
#   by the SAME number.  The two move together 1:1 - a row's scroll step and
#   its layout footprint are the same quantity measured two ways.
#   Keep <height> above ~110 so the 72px pill itemlayout still fits.
widget_row_heights = {
    "WidgetListPoster": 346,
    "WidgetListLandscape": 346,
    "WidgetListLargePoster": 433,  # 346 x 1.25
    "WidgetListLargeLandscape": 433,
    "WidgetListCategory": 346,
    "WidgetListPill": 110,  # with top 122
}
DEFAULT_ROW_ADVANCE = 368
# Number of conditional slide steps to emit per slot. Must comfortably exceed
# the highest Container.Position a widget stack can reach; the original shared
# animation used 58.
# Retained for reference only. The scroll animation is no longer built from a
# fixed number of position-indexed steps - see make_widget_slide_xml, which now
# emits one entry per row - so nothing reads this.
MAX_SLIDE_STEPS = 120

# Container.Position advances by TWO per widget row (each row contributes two
# counted children to the grouplist), so every step down activates a PAIR of
# animations. We put the whole slide on the odd member of each pair and 0 on
# the even one, which keeps one row == one value.
#
# advance[T] is the vertical space a row of type T occupies, i.e. the slide
# needed to scroll one row of that type off the top. A step's slide depends
# only on the row being LEFT, not the row arrived at.
#
# Calibrated by observation. To re-measure: give every row the same type,
# scroll down, and adjust until the focused row holds its screen position.
# The advances below all satisfy advance = fixedlist top + fixedlist height - 80,
# which holds for every row type in the skin (368 = 102 + 346 - 80 for the image
# rows, 152 = 122 + 110 - 80 for the pill row). The -80 is CategoryLabel's top:
# a row's occupied span starts at the header, not at y=0. The Large rows keep
# top at 102 and raise height to 433, giving 102 + 433 - 80 = 455.
widget_row_advances = {
    "WidgetListPoster": 368,
    "WidgetListLandscape": 368,
    "WidgetListLargePoster": 455,
    "WidgetListLargeLandscape": 455,
    "WidgetListCategory": 368,
    "WidgetListPill": 152,
}
POSITIONS_PER_ROW = 2


def row_advance(cpath_type):
    return widget_row_advances.get(cpath_type, DEFAULT_ROW_ADVANCE)


# --- Home menu item order ----------------------------------------------------
# Every item that can appear in the home menu (fixedlist 9000), in the
# order the skin has always shipped them. Tuple layout:
#   (item id, fallback display name, skin string holding the user's own
#    label or None, the condition under which the item is SHOWN)
#
# The fourth field is a full boolean expression, not just a "hide this item"
# setting name, and it must mirror the matching wrapper condition in the
# skin's Includes_HomeMenuItems.xml. Most items are a plain skin-setting
# check, but two are not: disc only appears with a disc in the drive, and
# games also needs Kodi's own game support switched on. Evaluating the whole
# expression is what lets the reorder list mark those two as hidden instead
# of listing them as if they were on screen.
#
# The item id is what the skin's Includes_HomeMenuItems.xml keys its
# MainMenuItem_<id> includes on, and also what each item already exposes as
# its <property name="id"> - which is what the submenu triggers and widget
# panels match on. That is why reordering is safe: nothing downstream cares
# where an item sits, only what its id is.
MAIN_MENU_ITEMS = (
    ("movies", "Movies", "MenuMovieLabel", "!Skin.HasSetting(HomeMenuNoMoviesButton)"),
    ("tvshows", "TV Shows", "MenuTVShowLabel", "!Skin.HasSetting(HomeMenuNoTVShowsButton)"),
    ("custom1", "Custom 1", "MenuCustom1Label", "!Skin.HasSetting(HomeMenuNoCustom1Button)"),
    ("custom2", "Custom 2", "MenuCustom2Label", "!Skin.HasSetting(HomeMenuNoCustom2Button)"),
    ("custom3", "Custom 3", "MenuCustom3Label", "!Skin.HasSetting(HomeMenuNoCustom3Button)"),
    ("custom4", "Custom 4", "MenuCustom4Label", "!Skin.HasSetting(HomeMenuNoCustom4Button)"),
    ("custom5", "Custom 5", "MenuCustom5Label", "!Skin.HasSetting(HomeMenuNoCustom5Button)"),
    ("custom6", "Custom 6", "MenuCustom6Label", "!Skin.HasSetting(HomeMenuNoCustom6Button)"),
    ("custom7", "Custom 7", "MenuCustom7Label", "!Skin.HasSetting(HomeMenuNoCustom7Button)"),
    ("custom8", "Custom 8", "MenuCustom8Label", "!Skin.HasSetting(HomeMenuNoCustom8Button)"),
    ("custom9", "Custom 9", "MenuCustom9Label", "!Skin.HasSetting(HomeMenuNoCustom9Button)"),
    ("custom10", "Custom 10", "MenuCustom10Label", "!Skin.HasSetting(HomeMenuNoCustom10Button)"),
    ("music", "Music", None, "!Skin.HasSetting(HomeMenuNoMusicButton)"),
    ("disc", "Disc", None, "System.HasMediaDVD"),
    ("musicvideos", "Music Videos", None, "!Skin.HasSetting(HomeMenuNoMusicVideoButton)"),
    ("livetv", "Live TV", None, "!Skin.HasSetting(HomeMenuNoTVButton)"),
    ("radio", "Radio", None, "!Skin.HasSetting(HomeMenuNoRadioButton)"),
    ("games", "Games", None, "System.GetBool(gamesgeneral.enable) + !Skin.HasSetting(HomeMenuNoGamesButton)"),
    ("addons", "Add-ons", None, "!Skin.HasSetting(HomeMenuNoProgramsButton)"),
    ("pictures", "Pictures", None, "!Skin.HasSetting(HomeMenuNoPicturesButton)"),
    ("video", "Videos", None, "!Skin.HasSetting(HomeMenuNoVideosButton)"),
    ("favorites", "Favourites", None, "!Skin.HasSetting(HomeMenuNoFavButton)"),
    ("weather", "Weather", None, "!Skin.HasSetting(HomeMenuNoWeatherButton)"),
)
MAIN_MENU_DEFAULT_ORDER = [i[0] for i in MAIN_MENU_ITEMS]
MAIN_MENU_ITEM_META = {i[0]: i for i in MAIN_MENU_ITEMS}
main_menu_order_xml_file = "script-nimbus-main_menu_order"

default_path = "addons://sources/video"
SUBMENU_LAUNCHER_PATH = "OPENSUBMENU"
# Stored in cpath_type (which otherwise doubles as window_target for a
# normal ActivateWindow-wrapped path) to mark a row as a raw, user-supplied
# action rather than a captured path - make_main_menu_xml() checks this to
# pick the unwrapped template instead of ActivateWindow(window_target,...).
CUSTOM_ACTION_MARKER = "__CUSTOM_ACTION__"

# Some addons' root path (plugin://<addon_id>/) is not a real content route -
# it just launches something else (a startup script, a modal GUI, a
# first-run wizard) and returns no directory items, so Files.GetDirectory
# can never succeed there no matter how it's asked or how long it waits.
# Confirmed for Mad Titan Sports by decompiling its default.py: root()
# fires RunScript(changelog.py, auto, gui/list) and returns nothing: the
# real listing lives at a sibling route, /main_list, which is a normal
# well-behaved plugin route. Add an entry here for any other addon found
# to have the same problem - key is the addon id exactly as it appears in
# its plugin:// URL, value is the working route to use instead of "/".
KNOWN_BROKEN_ADDON_ROOTS = {
    "plugin.video.madtitansports": "main_list",
}


def resolve_addon_root(path):
    """Silently substitutes a known-good route for an addon's dead root,
    so browsing into it lands on real content the same way it would for a
    well-behaved addon, instead of stalling at a route that was never
    going to answer. No-op for every path not in KNOWN_BROKEN_ADDON_ROOTS.
    """
    for addon_id, real_route in KNOWN_BROKEN_ADDON_ROOTS.items():
        prefix = "plugin://%s/" % addon_id
        if path in (prefix, prefix.rstrip("/")):
            return prefix + real_route
    return path


addon_source_types = (
    ("Video addons", "addons://sources/video"),
    ("Music addons", "addons://sources/audio"),
    ("Picture addons", "addons://sources/image"),
    ("Program addons", "addons://sources/executable"),
    ("Game addons", "addons://sources/game"),
)


class CPaths:
    def __init__(self, cpath_setting):
        self.connect_database()
        self.cpath_setting = cpath_setting
        self.cpath_lookup = "'%s'" % (self.cpath_setting + "%")
        self.media_type, self.path_type = self.cpath_setting.split(".")
        self.main_include = main_include_dict[self.media_type][self.path_type]
        self.refresh_cpaths, self.last_cpath = False, None

    def connect_database(self):
        if not xbmcvfs.exists(settings_path):
            xbmcvfs.mkdir(settings_path)
        self.dbcon = database.connect(database_path, timeout=20)
        self.dbcon.execute(
            "CREATE TABLE IF NOT EXISTS custom_paths (cpath_setting text unique, cpath_path text, cpath_header text, cpath_type text, cpath_label text)"
        )
        self.dbcur = self.dbcon.cursor()

    def add_cpath_to_database(
        self, cpath_setting, cpath_path, cpath_header, cpath_type, cpath_label
    ):
        self.refresh_cpaths = True
        self.dbcur.execute(
            "INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)",
            (cpath_setting, cpath_path, cpath_header, cpath_type, cpath_label),
        )
        self.dbcon.commit()

    def update_cpath_in_database(
        self, cpath_setting, cpath_path, cpath_header, cpath_type, cpath_label
    ):
        self.refresh_cpaths = True
        self.dbcur.execute(
            """
            UPDATE custom_paths
            SET cpath_path = ?, cpath_header = ?, cpath_type = ?, cpath_label = ?
            WHERE cpath_setting = ?
        """,
            (cpath_path, cpath_header, cpath_type, cpath_label, cpath_setting),
        )
        self.dbcon.commit()

    def remove_cpath_from_database(self, cpath_setting):
        self.refresh_cpaths = True
        self.dbcur.execute(
            "DELETE FROM custom_paths WHERE cpath_setting = ?", (cpath_setting,)
        )
        self.dbcon.commit()

    def get_skin_variable(self, variable_name):
        return xbmc.getInfoLabel(f"$VAR[{variable_name}]")

    def sanitize_stored_paths(self):
        """Rewrites any embedded drive-letter path in this row's own
        cpath_path through path_utils.sanitize_embedded_paths(). Only
        touches rows that actually change, so a normal remake with
        nothing to clean up does zero writes. This is what lets a
        legacy entry (captured before path_utils existed, or from a
        setup where sanitize_embedded_paths() genuinely couldn't
        resolve a special:// root, e.g. a since-uninstalled addon)
        get cleaned up retroactively the next time menus/widgets are
        remade, instead of only being caught at the moment it's first
        set.
        """
        rows = self.dbcur.execute(
            "SELECT cpath_setting, cpath_path FROM custom_paths WHERE cpath_setting LIKE %s"
            % self.cpath_lookup
        ).fetchall()
        for cpath_setting, cpath_path in rows:
            cleaned = path_utils.sanitize_embedded_paths(cpath_path)
            if cleaned != cpath_path:
                self.dbcur.execute(
                    "UPDATE custom_paths SET cpath_path = ? WHERE cpath_setting = ?",
                    (cleaned, cpath_setting),
                )
        self.dbcon.commit()

    def fetch_current_cpaths(self):
        results = self.dbcur.execute(
            "SELECT * FROM custom_paths WHERE cpath_setting LIKE %s" % self.cpath_lookup
        ).fetchall()
        try:
            results.sort(key=lambda k: int(k[0].split(".")[-1]))
        except:
            pass
        current_dict = {}
        for item in results:
            try:
                key = int(item[0].split(".")[-1])
            except:
                key = item[0]
            data = {
                "cpath_setting": item[0],
                "cpath_path": item[1],
                "cpath_header": item[2],
                "cpath_type": item[3],
                "cpath_label": item[4],
            }
            current_dict[key] = data
        return current_dict

    def fetch_one_cpath(self, cpath_setting):
        result = self.dbcur.execute(
            "SELECT * FROM custom_paths WHERE cpath_setting = ?", (cpath_setting,)
        ).fetchone()
        if result is None:
            return None
        return {
            "cpath_setting": result[0],
            "cpath_path": result[1],
            "cpath_header": result[2],
            "cpath_type": result[3],
            "cpath_label": result[4],
        }

    def choose_addon_source_type(self):
        choice = dialog.select(
            "Choose addon type", [i[0] for i in addon_source_types]
        )
        if choice == -1:
            return None
        return addon_source_types[choice][1]

    def choose_main_menu_source(self):
        """
        Main menu items were previously locked to video addons (plus a
        movies/tvshows-only local-library shortcut baked into path_browser).
        That's because every main_menu_*_xml template hardcodes
        ActivateWindow(Videos,...) - fine for video addons and the movie/
        tvshow library, but wrong for a music/picture/program/game addon or
        the Music Library, which need Music/Pictures/Programs instead.

        This offers the same addon-type choice as widgets, plus explicit
        Video/Music Library entries (matching the submenu picker), and
        returns (window_target, start_path) so the caller can store the
        correct window alongside the path rather than assuming Videos.
        """
        library_targets = [
            ("Video Library", "Videos", "videodb://"),
            ("Music Library", "Music", "musicdb://"),
        ]
        addon_window_for_path = {
            "addons://sources/video": "Videos",
            "addons://sources/audio": "Music",
            "addons://sources/image": "Pictures",
            "addons://sources/executable": "Programs",
            "addons://sources/game": "Programs",
        }
        options = [i[0] for i in addon_source_types] + [i[0] for i in library_targets]
        choice = dialog.select("Choose main menu source", options)
        if choice == -1:
            return None, None

        if choice < len(addon_source_types):
            _, start_path = addon_source_types[choice]
            return addon_window_for_path.get(start_path, "Videos"), start_path

        _, window_target, start_path = library_targets[choice - len(addon_source_types)]
        return window_target, start_path

    def path_browser(self, label="", file=default_path, thumbnail="", parent_history=None):
        if parent_history is None:
            parent_history = []
        file = resolve_addon_root(file)
        show_busy_dialog()
        label = self.clean_header(label)
        results = files_get_directory(file)
        hide_busy_dialog()
        if results is None:
            # files_get_directory returns None when the Files.GetDirectory
            # JSON-RPC call itself fails - typically a misbehaving addon
            # (crashes, times out, or returns something Kodi can't parse)
            # rather than anything Nimbus did. Surface that plainly instead
            # of crashing with an unhandled TypeError a few lines below.
            dialog.ok(
                "Nimbus",
                "Couldn't browse this location - the addon may have errored "
                "or is not responding. Try again, or pick a different addon.",
            )
            return {}
        list_items = []
        label_color = self.get_skin_variable("FocusedTextColor")

        # ".. (Back)" - only once we're at least one level deep, matching a
        # normal file browser: pressing Back/Cancel at the very top still
        # just cancels the whole flow (there's nowhere within path_browser's
        # own recursion to go up to), but Cancel at any deeper level used to
        # cancel EVERYTHING too - this gives an actual way to step back up
        # one directory instead of losing the whole browse.
        if parent_history:
            listitem = Listitem(
                "[COLOR {}][B].. (Back)[/B][/COLOR]".format(label_color),
                "Go up one directory",
                offscreen=True,
            )
            listitem.setProperty("go_up", "true")
            list_items.append(listitem)

        # Offer Kodi's own local library as a zero-addon-required option.
        # Only shown at the top level, and only for media types that have
        # a real native library path to point at.
        if file == default_path:
            native_library_paths = {
                "movie": ("Movies", "videodb://movies/titles/"),
                "tvshow": ("TV Shows", "videodb://tvshows/titles/"),
            }
            native = native_library_paths.get(self.media_type)
            if native:
                native_label, native_path = native
                listitem = Listitem(
                    "[COLOR {}][B]Use my local Kodi library ({})[/B][/COLOR]".format(
                        label_color, native_label
                    ),
                    "No addon required",
                    offscreen=True,
                )
                listitem.setArt({"icon": "DefaultVideoPlaylists.png"})
                listitem.setProperty(
                    "item",
                    json.dumps(
                        {"label": native_label, "file": native_path, "thumbnail": ""}
                    ),
                )
                list_items.append(listitem)

        if file != default_path:
            listitem = Listitem(
                "Use [COLOR {}][B]%s[/B][/COLOR] as path".format(label_color) % label,
                "Set as path",
                offscreen=True,
            )
            listitem.setArt({"icon": thumbnail})
            listitem.setProperty(
                "item",
                json.dumps({"label": label, "file": file, "thumbnail": thumbnail}),
            )
            list_items.append(listitem)
        for i in results:
            stripped_label = i["label"]
            stripped_label = stripped_label.replace("[B]", "").replace("[/B]", "")
            while "[COLOR" in stripped_label:
                start = stripped_label.find("[COLOR")
                end = stripped_label.find("]", start) + 1
                stripped_label = stripped_label[:start] + stripped_label[end:]
            stripped_label = stripped_label.replace("[/COLOR]", "")
            listitem = Listitem(
                "%s »" % stripped_label, "Browse path...", offscreen=True
            )
            listitem.setArt({"icon": i["thumbnail"]})
            listitem.setProperty(
                "item",
                json.dumps(
                    {
                        "label": i["label"],
                        "file": i["file"],
                        "thumbnail": i["thumbnail"],
                    }
                ),
            )
            list_items.append(listitem)
        choice = dialog.select("Choose path", list_items, useDetails=True)
        if choice == -1:
            return {}
        if list_items[choice].getProperty("go_up") == "true":
            previous = parent_history[-1]
            return self.path_browser(
                label=previous["label"],
                file=previous["file"],
                thumbnail=previous["thumbnail"],
                parent_history=parent_history[:-1],
            )
        choice = json.loads(list_items[choice].getProperty("item"))
        if choice["file"] == file:
            return choice
        else:
            return self.path_browser(
                parent_history=parent_history + [
                    {"label": label, "file": file, "thumbnail": thumbnail}
                ],
                **choice
            )

    def main_menu_meta(self):
        if self.media_type == "movie":
            return "MoviesMainMenu", 19000, "HomeMenuNoMovieButton", "movies"
        if self.media_type == "tvshow":
            return "TVShowsMainMenu", 22000, "HomeMenuNoTVShowButton", "tvshows"
        n = int(self.media_type.replace("custom", ""))
        return (
            "Custom%dMainMenu" % n,
            23000 + (n - 1) * 1000,
            "HomeMenuNoCustom%dButton" % n,
            "custom%d" % n,
        )

    def make_main_menu_xml(self, active_cpaths, reload_skin=True):
        if not self.refresh_cpaths:
            return
        if not active_cpaths:
            self.make_default_xml(reload_skin=reload_skin)
        media_types = {
            "movie": (
                movies_main_menu_xml,
                xmls.main_menu_movies_xml,
                "movie.main_menu",
            ),
            "tvshow": (
                tvshows_main_menu_xml,
                xmls.main_menu_tvshows_xml,
                "tvshow.main_menu",
            ),
            "custom1": (
                custom1_main_menu_xml,
                xmls.main_menu_custom1_xml,
                "custom1.main_menu",
            ),
            "custom2": (
                custom2_main_menu_xml,
                xmls.main_menu_custom2_xml,
                "custom2.main_menu",
            ),
            "custom3": (
                custom3_main_menu_xml,
                xmls.main_menu_custom3_xml,
                "custom3.main_menu",
            ),
            "custom4": (
                custom4_main_menu_xml,
                xmls.main_menu_custom4_xml,
                "custom4.main_menu",
            ),
            "custom5": (
                custom5_main_menu_xml,
                xmls.main_menu_custom5_xml,
                "custom5.main_menu",
            ),
            "custom6": (
                custom6_main_menu_xml,
                xmls.main_menu_custom6_xml,
                "custom6.main_menu",
            ),
            "custom7": (
                custom7_main_menu_xml,
                xmls.main_menu_custom7_xml,
                "custom7.main_menu",
            ),
            "custom8": (
                custom8_main_menu_xml,
                xmls.main_menu_custom8_xml,
                "custom8.main_menu",
            ),
            "custom9": (
                custom9_main_menu_xml,
                xmls.main_menu_custom9_xml,
                "custom9.main_menu",
            ),
            "custom10": (
                custom10_main_menu_xml,
                xmls.main_menu_custom10_xml,
                "custom10.main_menu",
            ),
        }
        media_values = media_types.get(self.media_type)
        if media_values:
            menu_xml_file, main_menu_xml, key = media_values
        xml_file = "special://skin/xml/%s.xml" % (menu_xml_file)
        if active_cpaths[key]["cpath_path"] == SUBMENU_LAUNCHER_PATH:
            main_include, menu_id, visible_setting, id_prop = self.main_menu_meta()
            final_format = xmls.main_menu_submenu_xml.format(
                main_include=main_include,
                cpath_header=active_cpaths[key].get("cpath_header", ""),
                menu_id=menu_id,
                visible_setting=visible_setting,
                id=id_prop,
            )
        elif active_cpaths[key].get("cpath_type") == CUSTOM_ACTION_MARKER:
            main_include, menu_id, visible_setting, id_prop = self.main_menu_meta()
            final_format = xmls.main_menu_custom_action_xml.format(
                main_include=main_include,
                cpath_header=active_cpaths[key].get("cpath_header", ""),
                menu_id=menu_id,
                visible_setting=visible_setting,
                id=id_prop,
                custom_action=active_cpaths[key]["cpath_path"],
            )
        else:
            # cpath_type doubles as the destination window for main menu
            # paths (previously unused for this path_type). Existing saved
            # paths from before this existed have cpath_type="", which
            # falls back to Videos - exactly what they always behaved as.
            window_target = active_cpaths[key].get("cpath_type") or "Videos"
            # Quoted, matching exactly what Kodi itself writes into
            # favourites.xml for the same ActivateWindow call - confirmed
            # by direct side-by-side testing to behave differently on
            # Back for at least one real addon (madtitansports) versus
            # the previously-unquoted path, even though both parse to the
            # same forward destination. Escaped in case a path happens to
            # contain a literal " itself.
            quoted_path = '"%s"' % active_cpaths[key]["cpath_path"].replace('"', '\\"')
            final_format = main_menu_xml.format(
                main_menu_path=quoted_path,
                cpath_header=active_cpaths[key].get("cpath_header", ""),
                window_target=window_target,
            )
        if not "&amp;" in final_format:
            final_format = final_format.replace("&", "&amp;")
        self.write_xml(xml_file, final_format, reload_skin=reload_skin)
        self.update_skin_strings()

    def make_widget_xml(self, active_cpaths, reload_skin=True):
        if not self.refresh_cpaths:
            return
        if not active_cpaths:
            self.make_default_xml(reload_skin=reload_skin)
        media_type_to_xml = {
            "movie": movies_widgets_xml,
            "tvshow": tvshows_widgets_xml,
            "custom1": custom1_widgets_xml,
            "custom2": custom2_widgets_xml,
            "custom3": custom3_widgets_xml,
            "custom4": custom4_widgets_xml,
            "custom5": custom5_widgets_xml,
            "custom6": custom6_widgets_xml,
            "custom7": custom7_widgets_xml,
            "custom8": custom8_widgets_xml,
            "custom9": custom9_widgets_xml,
            "custom10": custom10_widgets_xml,
        }
        xml_filename = media_type_to_xml.get(self.media_type)
        xml_file = "special://skin/xml/%s.xml" % xml_filename
        media_type_id = {
            "movie": 19010,
            "tvshow": 22010,
            "custom1": 23010,
            "custom2": 24010,
            "custom3": 25010,
            "custom4": 26010,
            "custom5": 27010,
            "custom6": 28010,
            "custom7": 29010,
            "custom8": 30010,
            "custom9": 31010,
            "custom10": 32010,
        }
        list_id = media_type_id.get(self.media_type)
        # The grouplist that holds this slot's widget rows, e.g. 26010 -> 26001.
        container_id = list_id - 9
        final_format = xmls.media_xml_start.format(main_include=self.main_include)
        row_types, row_list_ids = [], []
        for k, v in active_cpaths.items():
            cpath_list_id = list_id + k
            cpath_path, cpath_header, cpath_type, cpath_label = (
                v["cpath_path"],
                v["cpath_header"],
                v["cpath_type"],
                v["cpath_label"],
            )
            row_types.append(cpath_type)
            row_list_ids.append(cpath_list_id)
            body = xmls.media_xml_body.format(
                cpath_type=cpath_type,
                cpath_path=cpath_path,
                cpath_header=cpath_header,
                cpath_list_id=cpath_list_id,
                widget_slot=k,
                widget_menu=self.media_type,
            )
            if not "&amp;" in body:
                final_format += body.replace("&", "&amp;")
        if not active_cpaths:
            # An empty <include> body isn't registered as a valid include at
            # all by Kodi - any later reference to it (Home.xml's per-slot
            # group) logs "Skin has invalid include" even though the name is
            # textually present in this file. A harmless always-hidden
            # control is enough content for Kodi to register the include.
            final_format += '''
    <control type="group">
      <visible>false</visible>
    </control>'''
        final_format += xmls.media_xml_end
        final_format += self.make_widget_slide_xml(row_types, row_list_ids)
        self.write_xml(xml_file, final_format, reload_skin=reload_skin)

    def make_widget_slide_xml(self, row_types, row_list_ids):
        """Build the stack's scroll animation, one entry per row.

        Row R's entry contributes R's own height, and holds whenever the stack
        is parked on any row BELOW R. Summed, the active entries equal the
        distance the stack has scrolled - the same result the old
        position-indexed version produced, but derived from the rows instead of
        from grouplist positions.

        That difference is the whole point. A row does not always occupy the
        same number of grouplist positions: two normally, three while it is
        loading (the busy spinner is an extra child), and none at all once an
        empty directory hides it. Any of those shifted the old dense
        position->row mapping and sent every row below the gap the wrong
        distance. Here each row is named explicitly, so nothing shifts.

        Control.IsVisible is what handles the empty case: a hidden row occupies
        no space, so its height must not be added, and its own entry simply
        stops firing.

        "Parked on a row below R" is tested against nimbus_scroll_<menu>, a
        window property each row sets on focus (WidgetListCommon in
        Includes_Home.xml). It is deliberately NOT Control.HasFocus: the stack
        has to keep its offset while the home menu has focus, and nothing has
        focus then. It is per menu so switching main menu items and coming back
        restores that menu's own scroll rather than inheriting another's.

        Emits one entry per row except the last - you can never be parked below
        the bottom row, so its height never contributes.
        """
        slide = xmls.widget_slide_start.format(main_include=self.main_include)
        for index, list_id in enumerate(row_list_ids[:-1]):
            below = " | ".join(
                "String.IsEqual(Window(Home).Property(nimbus_scroll_%s),%s)"
                % (self.media_type, lower_id)
                for lower_id in row_list_ids[index + 1 :]
            )
            condition = (
                "$EXP[widget_scroll_hold] + Control.IsVisible(%s) + [%s]"
                % (list_id, below)
            )
            slide += xmls.widget_slide_body.format(
                offset=-row_advance(row_types[index]),
                condition=condition,
            )
        if len(row_list_ids) <= 1:
            # Same empty-include problem as the widgets body above: a slot
            # with 0 or exactly 1 widget never enters the loop (only rows
            # before the last one get an entry), leaving this include with
            # no content for Kodi to register. This animation never
            # actually triggers - it's here purely so the include exists.
            slide += '''
    <animation effect="fade" time="0" condition="false">Conditional</animation>'''
        slide += xmls.widget_slide_end
        return slide

    def write_xml(self, xml_file, final_format, reload_skin=True):
        with xbmcvfs.File(xml_file, "w") as f:
            f.write(final_format)
        if reload_skin:
            Thread(target=self.reload_skin).start()

    def handle_path_browser_results(self, cpath_setting, context):
        window_target = "Videos"
        if context == "widget":
            source_choice = dialog.select(
                "Set widget source",
                ["Browse for a target", "Enter a path manually"],
            )
            if source_choice == -1:
                return None
            if source_choice == 1:
                result = self.manual_path_entry()
            else:
                start_path = self.choose_addon_source_type()
                if not start_path:
                    return None
                result = self.path_browser(file=start_path)
        elif context == "main_menu":
            window_target, start_path = self.choose_main_menu_source()
            if not start_path:
                return None
            result = self.path_browser(file=start_path)
        else:
            result = self.path_browser()
        if not result:
            return None
        cpath_path = result.get("file", None)
        if not cpath_path:
            return None
        # Same risk as the submenu path browser: a third-party addon's
        # own directory listing can embed its own local icon/fanart path
        # as a query param inside the plugin:// URL it hands back. Clean
        # it up here, before it's written to the cpath database, so a
        # widget or main-menu path captured this way doesn't ship a
        # machine-specific path either.
        cpath_path = path_utils.sanitize_embedded_paths(cpath_path)
        default_header = result.get("label", None)
        if context == "widget":
            cpath_header = self.widget_header(default_header)
            if not cpath_header:
                return None
            self.create_and_update_widget(cpath_setting, cpath_path, cpath_header)
        else:
            cpath_header = self.main_menu_header(default_header)
            if not cpath_header:
                return None
            self.add_cpath_to_database(cpath_setting, cpath_path, cpath_header, window_target, "")
            self.update_skin_strings()
        return True

    def manual_path_entry(self):
        """Let the user type/paste a content path directly, bypassing the
        Files.GetDirectory browse entirely.

        Exists for addons whose root can't be listed via
        Files.GetDirectory/CDirectory at all (Mad Titan confirmed: its root
        route just fires a RunScript launcher and returns no directory
        items - it's not a real content route, so no amount of retrying
        the browse could ever succeed there). The addon's actual content
        routes (for Mad Titan, .../main_list) are normal, well-behaved
        plugin routes and work fine once pointed at directly - this is
        how you reach one without needing to browse into it.
        """
        path = dialog.input("Enter the content path (e.g. plugin://plugin.video.name/main_list)")
        if not path:
            return None
        return {"label": "", "file": path, "thumbnail": ""}

    def manage_action_and_check(self, cpath_setting, context):
        action_choice = self.manage_action(cpath_setting, context)
        if action_choice == "clear_path":
            self.make_default_xml()
            dialog.ok("Nimbus", "Path cleared")
            return None
        if action_choice is None:
            return None
        return True

    def set_main_menu_as_submenu_launcher(self):
        active_cpaths = self.fetch_current_cpaths()
        default_header = active_cpaths.get(self.cpath_setting, {}).get(
            "cpath_header"
        )
        cpath_header = self.main_menu_header(default_header)
        if not cpath_header:
            return None
        self.add_cpath_to_database(
            self.cpath_setting, SUBMENU_LAUNCHER_PATH, cpath_header, "", ""
        )
        self.update_skin_strings()
        return True

    def set_main_menu_as_custom_action(self):
        active_cpaths = self.fetch_current_cpaths()
        default_action = active_cpaths.get(self.cpath_setting, {}).get("cpath_path")
        # A raw builtin the user typed or pasted (e.g. from a Kodi favourite
        # that starts with PlayMedia(... rather than a plain browsable path) -
        # used verbatim in the generated XML's <onclick>, no ActivateWindow
        # wrapping applied at all. Sanitized the same as any other captured
        # path, in case it happens to embed a device-specific absolute path.
        custom_action = dialog.input(
            "Enter the full action (e.g. PlayMedia(...) or ActivateWindow(...))",
            defaultt=default_action if default_action != SUBMENU_LAUNCHER_PATH else "",
        )
        if not custom_action:
            return None
        # A pasted Kodi favourite's action comes straight out of an XML
        # file's element text, where a literal & is written as &amp; (and <
        # / > likewise) - that escaping only ever made sense for the XML
        # parser that read it there. This value is stored via a direct
        # Skin.SetString() builtin call further down, never through any XML
        # parser, so &amp; would otherwise reach Kodi's plugin URL parser
        # completely literally - which splits query-string parameters on a
        # real &, not the four-character text "&amp;" - silently merging
        # every parameter after the first into one. Undo it here, once,
        # before anything else touches the string.
        custom_action = xml_unescape(custom_action)
        custom_action = path_utils.sanitize_embedded_paths(custom_action)
        default_header = active_cpaths.get(self.cpath_setting, {}).get(
            "cpath_header"
        )
        cpath_header = self.main_menu_header(default_header)
        if not cpath_header:
            return None
        self.add_cpath_to_database(
            self.cpath_setting, custom_action, cpath_header, CUSTOM_ACTION_MARKER, ""
        )
        self.update_skin_strings()
        return True

    def manage_main_menu_path(self):
        active_cpaths = self.fetch_current_cpaths()
        if active_cpaths and not self.manage_action_and_check(
            self.cpath_setting, "main_menu"
        ):
            return
        action_choice = dialog.select(
            "Set main menu action",
            ["Browse for a target", "Open Sub Menu instead", "Enter Manually"],
        )
        if action_choice == -1:
            return
        if action_choice == 1:
            if not self.set_main_menu_as_submenu_launcher():
                return
            return self.make_main_menu_xml(self.fetch_current_cpaths())
        if action_choice == 2:
            if not self.set_main_menu_as_custom_action():
                return
            return self.make_main_menu_xml(self.fetch_current_cpaths())
        if not self.handle_path_browser_results(self.cpath_setting, "main_menu"):
            return self.make_main_menu_xml(active_cpaths)
        self.make_main_menu_xml(self.fetch_current_cpaths())

    def manage_widgets(self):
        """
        Widget manager UX: mirrors manage_submenu_items' approach - shows
        only occupied slots (each labelled with its own widget label),
        numbered by visible position rather than the underlying storage
        slot. "Add New Widget" only appears once there's a free slot left,
        and finds the lowest free slot itself so there's no way to land in
        the middle of a stretch of empties by scrolling too far, which the
        old show-all-50-slots list made possible.

        Storage/generation is unchanged - this only replaces the old
        "show every slot, empty or not" list.
        """
        active_cpaths = self.fetch_current_cpaths()
        occupied = sorted(k for k in active_cpaths if isinstance(k, int))
        has_room = len(occupied) < 50

        widget_choices = [
            "%s. %s"
            % (position, active_cpaths[slot_num].get("cpath_label", "") or "Widget %s" % slot_num)
            for position, slot_num in enumerate(occupied, 1)
        ]
        create_new_index = None
        if has_room:
            widget_choices.append("Add New Widget")
            create_new_index = len(widget_choices) - 1

        if xbmc.getCondVisibility("Window.IsActive(home)"):
            selected_label = xbmc.getInfoLabel("Container(9000).ListItem.Label")
            title = "Choose widget ({})".format(selected_label)
        else:
            title = "Choose widget"
        choice = dialog.select(title, widget_choices)
        if choice == -1:
            return self.make_widget_xml(active_cpaths)

        if choice == create_new_index:
            occupied_set = set(occupied)
            next_slot = next(i for i in range(1, 51) if i not in occupied_set)
            cpath_setting = "%s.%s" % (self.cpath_setting, next_slot)
        else:
            slot_num = occupied[choice]
            cpath_setting = active_cpaths[slot_num]["cpath_setting"]
            if not self.manage_action_and_check(cpath_setting, "widget"):
                return self.manage_widgets()

        if not self.handle_path_browser_results(cpath_setting, "widget"):
            return self.manage_widgets()
        return self.manage_widgets()

    def widget_header(self, default_header):
        header = dialog.input("Set widget label", defaultt=default_header)
        return header or None

    def main_menu_header(self, default_header):
        header = dialog.input("Set Main Menu label", defaultt=default_header)
        return header or None

    def get_widget_type(self, cpath_type):
        for widget_type, widget_list_type in widget_types:
            if widget_list_type == cpath_type:
                return widget_type
        return None

    def widget_type(self, label="Choose widget display type", type_limit=len(widget_types)):
        choice = dialog.select(label, [i[0] for i in widget_types[0:type_limit]])
        if choice == -1:
            return None
        return widget_types[choice]

    def update_skin_strings(self):
        movie_cpath = self.fetch_one_cpath("movie.main_menu")
        tvshow_cpath = self.fetch_one_cpath("tvshow.main_menu")
        movie_cpath_header = movie_cpath.get("cpath_header") if movie_cpath else None
        tvshow_cpath_header = tvshow_cpath.get("cpath_header") if tvshow_cpath else None
        default_movie_string_id = 342
        default_tvshow_string_id = 20343
        default_movie_value = (
            xbmc.getLocalizedString(default_movie_string_id)
            if not movie_cpath_header
            else movie_cpath_header
        )
        default_tvshow_value = (
            xbmc.getLocalizedString(default_tvshow_string_id)
            if not tvshow_cpath_header
            else tvshow_cpath_header
        )
        xbmc.executebuiltin("Skin.SetString(MenuMovieLabel,%s)" % default_movie_value)
        xbmc.executebuiltin("Skin.SetString(MenuTVShowLabel,%s)" % default_tvshow_value)

        for n in range(1, 11):
            custom_cpath = self.fetch_one_cpath("custom%d.main_menu" % n)
            custom_cpath_header = (
                custom_cpath.get("cpath_header") if custom_cpath else None
            )
            default_custom_value = (
                "Custom %d" % n if not custom_cpath_header else custom_cpath_header
            )
            xbmc.executebuiltin(
                "Skin.SetString(MenuCustom%dLabel,%s)" % (n, default_custom_value)
            )

    def manage_action(self, cpath_setting, context="widget"):
        choices = [
            ("Rename", "rename_path"),
            ("Remake", "remake_path"),
            ("Remove", "clear_path"),
        ]
        if context == "widget":
            choices = [
                ("Move up", "move_up"),
                ("Move down", "move_down"),
                ("Display type", "display_type"),
                ("Set widget limit", "set_widget_limit"),
            ] + choices

        if xbmc.getCondVisibility("Window.IsActive(home)"):
            selected_label = xbmc.getInfoLabel("Container(9000).ListItem.Label")
            title = "%s options ({})".format(
                selected_label
            ) % self.path_type.capitalize().replace("_", " ")
        else:
            title = "%s options" % self.path_type.capitalize().replace("_", " ")

        choice = dialog.select(title, [i[0] for i in choices])
        if choice == -1:
            return None

        action = choices[choice][1]

        if action in ["move_up", "move_down"]:
            parts = cpath_setting.split(".")
            if len(parts) < 3 or not parts[-1].isdigit():
                dialog.ok("Nimbus", "Cannot move this widget")
                return None
            current_order = int(parts[-1])
            # Move relative to the OCCUPIED slots, not the raw slot numbers.
            # Slots are sparse (a widget can sit in 1, 2 and 7), so stepping
            # by +-1 could swap a widget with an empty slot: the display
            # order would be unchanged while the widget quietly drifted down
            # the numbering, eventually parking itself in slot 50. Walking
            # the occupied list instead means one press always moves the
            # widget exactly one visible row, and the ends are hard stops
            # rather than wrapping around.
            occupied = sorted(
                k for k in self.fetch_current_cpaths().keys() if isinstance(k, int)
            )
            if current_order not in occupied:
                dialog.ok("Nimbus", "Cannot move this widget")
                return None
            index = occupied.index(current_order)
            new_index = index - 1 if action == "move_up" else index + 1
            if new_index < 0 or new_index >= len(occupied):
                dialog.notification(
                    "Nimbus",
                    "Already the %s widget"
                    % ("first" if action == "move_up" else "last"),
                    xbmcgui.NOTIFICATION_INFO,
                    1500,
                )
                return None
            self.swap_widgets(parts, current_order, occupied[new_index])

        elif action == "set_widget_limit":
            parts = cpath_setting.split(".")
            # expected: movie.widget.1 etc.
            if len(parts) < 3 or not parts[-1].isdigit():
                dialog.ok("Nimbus", "Unable to determine widget slot")
                return None

            menu_key = parts[0]  # movie/tvshow/custom1/custom2/custom3
            slot = parts[-1]
            limit_key = f"WidgetLimit.{menu_key}.{slot}"

            current_value = xbmc.getInfoLabel(f"Skin.String({limit_key})")
            if not current_value:
                current_value = "0"

            value = dialog.numeric(
                0, f"Set item limit ({menu_key} widget {slot}) - 0 = unlimited", current_value
            )

            if value is None:
                return None

            # Empty = clear override, same as leaving it unset (unlimited)
            if value == "":
                xbmc.executebuiltin(f"Skin.Reset({limit_key})")
                dialog.ok("Nimbus", "Widget limit reset to unlimited")
                return None

            try:
                ivalue = int(value)
            except ValueError:
                dialog.ok("Nimbus", "Please enter a valid number")
                return None

            # 0 = unlimited, so only clamp genuinely negative entries up to 0
            if ivalue < 0:
                ivalue = 0
            elif ivalue > 200:
                ivalue = 200

            xbmc.executebuiltin(f"Skin.SetString({limit_key},{ivalue})")
            dialog.ok("Nimbus", f"Widget limit set to {ivalue}")
            return None

        elif action == "remake_path":
            # NOTE: this deliberately does NOT delete the existing row first.
            # It used to, immediately and unconditionally - but there are
            # three separate cancel points below (source picker, path
            # browser, label prompt), and backing out at any of them left the
            # category with no row at all and nothing to restore it. Worse,
            # it failed silently: manage_action_and_check only regenerates
            # the skin XML for "clear_path", so on a cancelled remake the
            # generated file kept its old contents and everything looked
            # fine - right up until the next skin update overwrote that file
            # with the shipped empty stub and the restore found no row to
            # rebuild from. Confirmed cause of a main menu item losing its
            # target (and its widgets/submenus becoming unreachable) on
            # update, with the trigger potentially weeks earlier.
            # add_cpath_to_database is INSERT OR REPLACE, so a COMPLETED
            # remake still overwrites the row exactly as before - the delete
            # was never doing anything a completed run needed.
            if context == "main_menu":
                remake_choice = dialog.select(
                    "Set main menu action",
                    ["Browse for a target", "Open Sub Menu instead", "Enter Manually"],
                )
                if remake_choice == -1:
                    return None
                if remake_choice == 1:
                    # Mirrors manage_main_menu_path's own first-time-setup
                    # branch (set_main_menu_as_submenu_launcher relies on
                    # self.cpath_setting, which always matches the
                    # cpath_setting passed in here - this action only ever
                    # reaches main_menu context via that same call chain).
                    if self.set_main_menu_as_submenu_launcher():
                        self.make_main_menu_xml(self.fetch_current_cpaths())
                        dialog.ok("Nimbus", "Main menu remade")
                    return None
                if remake_choice == 2:
                    if self.set_main_menu_as_custom_action():
                        self.make_main_menu_xml(self.fetch_current_cpaths())
                        dialog.ok("Nimbus", "Main menu remade")
                    return None
                window_target, start_path = self.choose_main_menu_source()
                if not start_path:
                    return None
                result = self.path_browser(file=start_path)
            elif context == "widget":
                # Was previously calling self.path_browser() with no
                # arguments here, which silently falls back to
                # default_path = "addons://sources/video" - meaning a
                # widget remake only ever offered video addons, unlike a
                # first-time widget (handle_path_browser_results) which
                # offers the same Video/Music/Picture/Program/Game choice
                # as main_menu already correctly gets on remake, above.
                # Matching that same choice here for consistency between
                # the two entry points.
                start_path = self.choose_addon_source_type()
                if not start_path:
                    return None
                result = self.path_browser(file=start_path)
            else:
                result = self.path_browser()
            if result:
                cpath_path = result.get("file", None)
                # This branch captures a fresh browse result directly - it
                # doesn't go through handle_path_browser_results, so it needs
                # its own sanitize call for the same reason: a third-party
                # addon's own directory listing can embed its own local
                # icon/fanart path in the URL it hands back.
                cpath_path = path_utils.sanitize_embedded_paths(cpath_path)
                if context == "widget":
                    self.handle_widget_remake(result, cpath_setting)
                elif context == "main_menu":
                    default_header = result.get("label", None)
                    cpath_header = self.main_menu_header(default_header)
                    if not cpath_header:
                        return None
                    self.add_cpath_to_database(
                        cpath_setting, cpath_path, cpath_header, window_target, ""
                    )
                    self.make_main_menu_xml(self.fetch_current_cpaths())
                    dialog.ok("Nimbus", "Main menu remade")

        elif action == "rename_path":
            result = self.fetch_one_cpath(cpath_setting)
            if not result:
                return None
            cpath_path = result.get("cpath_path", None)
            cpath_type = result.get("cpath_type", None)
            cpath_label = result.get("cpath_label", None)
            if not cpath_path:
                return None
            default_header = result.get("cpath_header", None)
            if context == "widget":
                cpath_header = self.widget_header(default_header)
                if not cpath_header:
                    return None
                widget_type = self.get_widget_type(result["cpath_type"])
                if not widget_type:
                    return None
                cpath_label = "%s | %s" % (cpath_header, widget_type)
                self.update_cpath_in_database(
                    cpath_setting,
                    cpath_path,
                    cpath_header,
                    result["cpath_type"],
                    cpath_label,
                )
            if context == "main_menu":
                cpath_header = self.main_menu_header(default_header)
                if not cpath_header or cpath_header.strip() == "":
                    cpath_map = {
                        "movie.main_menu": xbmc.getLocalizedString(342),
                        "tvshow.main_menu": xbmc.getLocalizedString(20343),
                        "custom1.main_menu": "Custom 1",
                        "custom2.main_menu": "Custom 2",
                        "custom3.main_menu": "Custom 3",
                        "custom4.main_menu": "Custom 4",
                        "custom5.main_menu": "Custom 5",
                        "custom6.main_menu": "Custom 6",
                        "custom7.main_menu": "Custom 7",
                        "custom8.main_menu": "Custom 8",
                        "custom9.main_menu": "Custom 9",
                        "custom10.main_menu": "Custom 10",
                    }
                    cpath_header = cpath_map.get(
                        cpath_setting, "Default main menu label not found"
                    )
                self.update_cpath_in_database(
                    cpath_setting, cpath_path, cpath_header, cpath_type, ""
                )
                self.make_main_menu_xml(self.fetch_current_cpaths())

        elif action == "display_type":
            result = self.fetch_one_cpath(cpath_setting)
            if not result:
                return None
            cpath_path = result.get("cpath_path", None)
            cpath_header = result.get("cpath_header", None)
            cpath_label = result.get("cpath_label", None)
            if not cpath_path:
                return None
            self.create_and_update_widget(
                cpath_setting, cpath_path, cpath_header, add_to_db=False
            )

        elif action == "clear_path":
            self.remove_cpath_from_database(cpath_setting)
            if context == "main_menu":
                self.make_default_xml()
                dialog.ok("Nimbus", "Path cleared")
            else:
                self.compact_widget_slots()

        return None

    def swap_widgets(self, parts, current_order, new_order):
        current_widget = f"{parts[0]}.{parts[1]}.{current_order}"
        adjacent_widget = f"{parts[0]}.{parts[1]}.{new_order}"
        self.refresh_cpaths = True
        self.dbcur.execute(
            "UPDATE custom_paths SET cpath_setting = ? WHERE cpath_setting = ?",
            (f"{parts[0]}.{parts[1]}.temp", current_widget),
        )
        self.dbcur.execute(
            "UPDATE custom_paths SET cpath_setting = ? WHERE cpath_setting = ?",
            (current_widget, adjacent_widget),
        )
        self.dbcur.execute(
            "UPDATE custom_paths SET cpath_setting = ? WHERE cpath_setting = ?",
            (adjacent_widget, f"{parts[0]}.{parts[1]}.temp"),
        )
        self.dbcon.commit()
        self.swap_widget_limits(parts[0], current_order, new_order)

    def compact_widget_slots(self):
        """Close gaps in the slot numbering after a widget is removed.

        Delete widget 2 of 3 and the survivors used to sit in slots 1 and 3.
        Nothing on the home screen cared - rows render in slot order with no
        space for the gap - but the widget manager lists all 50 slots by number,
        so you saw an empty "Widget 2" between them and reasonably expected Move
        up to fill it. Move up walks the OCCUPIED slots instead (one press = one
        visible row), so it jumped the gap, which read as the move failing.

        Renumbering on delete removes the disagreement rather than papering over
        it: slot order and display order become the same thing, so both readings
        of "move up" agree from then on.

        Ascending order is safe - every widget only ever moves to a lower slot
        that has already been vacated, so no two rows collide on the unique
        cpath_setting.
        """
        rows = self.fetch_current_cpaths()
        keys = sorted(k for k in rows.keys() if isinstance(k, int))
        if keys == list(range(1, len(keys) + 1)):
            return

        # Per-widget limits are keyed by slot number, so read them all BEFORE
        # renumbering - otherwise they stay behind on the old slots.
        limits = {
            old: xbmc.getInfoLabel(
                "Skin.String(WidgetLimit.%s.%d)" % (self.media_type, old)
            )
            for old in keys
        }

        for new, old in enumerate(keys, 1):
            if new == old:
                continue
            self.dbcur.execute(
                "UPDATE custom_paths SET cpath_setting = ? WHERE cpath_setting = ?",
                (
                    "%s.%d" % (self.cpath_setting, new),
                    "%s.%d" % (self.cpath_setting, old),
                ),
            )
        self.dbcon.commit()

        for new, old in enumerate(keys, 1):
            limit_key = "WidgetLimit.%s.%d" % (self.media_type, new)
            value = limits.get(old)
            if value:
                xbmc.executebuiltin("Skin.SetString(%s,%s)" % (limit_key, value))
            else:
                xbmc.executebuiltin("Skin.Reset(%s)" % limit_key)

        # Compacting frees the slots above the new count. Clear their limits too,
        # or the next widget added there silently inherits a limit set for a
        # widget that no longer exists.
        for stale in range(len(keys) + 1, max(keys) + 1):
            xbmc.executebuiltin(
                "Skin.Reset(WidgetLimit.%s.%d)" % (self.media_type, stale)
            )
        xbmc.sleep(100)
        self.refresh_cpaths = True

    def swap_widget_limits(self, menu_key, current_order, new_order):
        """Move per-widget item limits along with the widget itself.

        The limit override lives in a skin string keyed by slot number
        (WidgetLimit.<menu>.<slot>), not by widget, so a plain database swap
        would leave the limit behind: move a 50-item widget up and it would
        silently inherit whatever limit the widget it displaced had.
        """
        key_current = f"WidgetLimit.{menu_key}.{current_order}"
        key_new = f"WidgetLimit.{menu_key}.{new_order}"
        value_current = xbmc.getInfoLabel(f"Skin.String({key_current})")
        value_new = xbmc.getInfoLabel(f"Skin.String({key_new})")
        if not value_current and not value_new:
            return
        for key, value in ((key_current, value_new), (key_new, value_current)):
            if value:
                xbmc.executebuiltin(f"Skin.SetString({key},{value})")
            else:
                xbmc.executebuiltin(f"Skin.Reset({key})")
        # Skin.SetString/Reset are queued onto Kodi's application message
        # thread, so give them a moment to flush before anything re-reads.
        xbmc.sleep(100)

    def handle_widget_remake(self, result, cpath_setting):
        cpath_path, default_header = result.get("file", None), result.get("label", None)
        # Same reasoning as handle_path_browser_results: this is a fresh
        # browse result, so it can carry a third-party addon's own embedded
        # local path and needs its own sanitize pass before it's stored.
        cpath_path = path_utils.sanitize_embedded_paths(cpath_path)
        cpath_header = self.widget_header(default_header)
        if not cpath_header:
            # Cancelled at the label prompt. Leave the existing widget alone
            # rather than writing an entry with no header.
            return None
        return self.create_and_update_widget(cpath_setting, cpath_path, cpath_header)

    def create_and_update_widget(
        self, cpath_setting, cpath_path, cpath_header, add_to_db=True
    ):
        widget_type = self.widget_type()
        if not widget_type:
            # Cancelled at the display-type picker. Previously this fell
            # straight into widget_type[1] and raised a TypeError on None.
            return None
        cpath_type, cpath_label = widget_type[1], "%s | %s" % (
            cpath_header,
            widget_type[0],
        )
        if add_to_db:
            self.add_cpath_to_database(
                cpath_setting, cpath_path, cpath_header, cpath_type, cpath_label
            )
        else:
            self.update_cpath_in_database(
                cpath_setting, cpath_path, cpath_header, cpath_type, cpath_label
            )

    def reload_skin(self):
        reload_skin_when_ready()

    def clean_header(self, header):
        return header.replace("[B]", "").replace("[/B]", "").replace(" >>", "")

    def remake_main_menus(self, reload_skin=True):
        self.refresh_cpaths = True
        active_cpaths = self.fetch_current_cpaths()
        if active_cpaths:
            self.make_main_menu_xml(active_cpaths, reload_skin=reload_skin)
        else:
            self.make_default_xml(reload_skin=reload_skin)

    def remake_widgets(self, reload_skin=True):
        self.refresh_cpaths = True
        active_cpaths = self.fetch_current_cpaths()
        if active_cpaths:
            self.make_widget_xml(active_cpaths, reload_skin=reload_skin)
        else:
            self.make_default_xml(reload_skin=reload_skin)

    def make_default_xml(self, reload_skin=True):
        item = default_xmls[self.cpath_setting]
        final_format = item[1].format(includes_type=item[2])
        xml_file = "special://skin/xml/%s.xml" % item[0]
        with xbmcvfs.File(xml_file, "w") as f:
            f.write(final_format)
        self.update_skin_strings()
        if reload_skin:
            Thread(target=self.reload_skin).start()


def reload_skin_when_ready():
    """Reload the skin, but never while the skin settings window is open.

    Reloading out from under window 10035 loses the user's place (and can
    leave settings mid-edit), so wait it out first. Guarded by a window
    property so several callers firing at once still produce one reload.
    """
    if window.getProperty("nimbus.clear_path_refresh") == "true":
        return
    window.setProperty("nimbus.clear_path_refresh", "true")
    while xbmcgui.getCurrentWindowId() == 10035:
        xbmc.sleep(500)
    window.setProperty("nimbus.clear_path_refresh", "")
    xbmc.sleep(200)
    xbmc.executebuiltin("ReloadSkin()")


# --- Home menu ordering ------------------------------------------------------
# The order lives in the same sqlite database as the custom paths rather than
# in a skin string, for two reasons: it survives a skin settings reset the
# same way widgets do, and reading it back is a direct query instead of a
# getInfoLabel that may not have caught up with a just-queued Skin.SetString.


def _order_database():
    if not xbmcvfs.exists(settings_path):
        xbmcvfs.mkdir(settings_path)
    con = database.connect(database_path, timeout=20)
    con.execute(
        "CREATE TABLE IF NOT EXISTS menu_order (order_key text unique, order_value text)"
    )
    return con


def get_main_menu_order():
    """Return the stored order, reconciled against the items that exist now.

    Unknown ids are dropped and missing ones appended, so a future version
    that adds a menu item doesn't leave it invisible for anyone who had
    already saved an order - it simply lands at the bottom of the list.
    """
    con = _order_database()
    try:
        row = con.execute(
            "SELECT order_value FROM menu_order WHERE order_key = ?", ("main_menu",)
        ).fetchone()
    finally:
        con.close()
    stored = [i for i in (row[0].split(",") if row and row[0] else []) if i]
    order = [i for i in stored if i in MAIN_MENU_ITEM_META]
    order += [i for i in MAIN_MENU_DEFAULT_ORDER if i not in order]
    return order


def save_main_menu_order(order):
    con = _order_database()
    try:
        con.execute(
            "INSERT OR REPLACE INTO menu_order VALUES (?, ?)",
            ("main_menu", ",".join(order)),
        )
        con.commit()
    finally:
        con.close()


def make_main_menu_order_xml(order=None, reload_skin=True):
    """Write the generated include that sets the home menu's item sequence."""
    order = order or get_main_menu_order()
    items = "".join(
        xmls.main_menu_order_body.format(item_id=item_id) for item_id in order
    )
    final_format = xmls.main_menu_order_xml.format(items=items)
    xml_file = "special://skin/xml/%s.xml" % main_menu_order_xml_file
    with xbmcvfs.File(xml_file, "w") as f:
        f.write(final_format)
    if reload_skin:
        Thread(target=reload_skin_when_ready).start()


def main_menu_item_label(item_id):
    _, fallback, skin_string, visible_condition = MAIN_MENU_ITEM_META[item_id]
    label = xbmc.getInfoLabel("Skin.String(%s)" % skin_string) if skin_string else ""
    label = label or fallback
    # Worth surfacing: an item can be in the order but not on screen, and
    # without this the user just sees a list that doesn't match their home
    # screen and assumes the reorder didn't take.
    #
    # Note this is a snapshot of right now, so disc correctly loses the
    # marker the moment a disc goes in the drive.
    if visible_condition and not xbmc.getCondVisibility(visible_condition):
        label = "%s  [ hidden ]" % label
    return label


def manage_main_menu_order():
    """Reorder the home menu items, one move per action, list stays open."""
    order = get_main_menu_order()
    changed = False
    while True:
        choices = [
            "%d. %s" % (n + 1, main_menu_item_label(item_id))
            for n, item_id in enumerate(order)
        ]
        choices.append("Reset to default order")
        choice = dialog.select("Home Menu Order", choices)
        if choice == -1:
            break

        if choice == len(order):
            if dialog.yesno(
                "Nimbus", "Reset the home menu to its default order?"
            ):
                order = list(MAIN_MENU_DEFAULT_ORDER)
                save_main_menu_order(order)
                make_main_menu_order_xml(order, reload_skin=False)
                changed = True
            continue

        move = dialog.select(
            main_menu_item_label(order[choice]),
            ["Move up", "Move down", "Move to top", "Move to bottom"],
        )
        if move == -1:
            continue

        item_id = order.pop(choice)
        if move == 0:
            new_index = max(0, choice - 1)
        elif move == 1:
            new_index = min(len(order), choice + 1)
        elif move == 2:
            new_index = 0
        else:
            new_index = len(order)
        order.insert(new_index, item_id)

        save_main_menu_order(order)
        make_main_menu_order_xml(order, reload_skin=False)
        changed = True

    # One reload once the user is done, rather than one per move.
    if changed:
        Thread(target=reload_skin_when_ready).start()


def files_get_directory(directory, properties=["title", "file", "thumbnail"]):
    command = {
        "jsonrpc": "2.0",
        "id": "plugin.video.fen",
        "method": "Files.GetDirectory",
        "params": {"directory": directory, "media": "files", "properties": properties},
    }
    try:
        results = [
            i
            for i in get_jsonrpc(command).get("files")
            if i["file"].startswith("plugin://") and i["filetype"] == "directory"
        ]
    except:
        results = None
    return results


def get_jsonrpc(request):
    response = xbmc.executeJSONRPC(json.dumps(request))
    result = json.loads(response)
    return result.get("result", None)


def remake_all_cpaths(silent=False, reload_skin=True):
    # Each individual write can trigger its own background reload thread
    # (see write_xml). Across 24 files that means up to 24 competing
    # ReloadSkin() calls firing while later files in this same loop are
    # still being written, which can leave the skin showing a partially
    # stale set of files until something reloads it again. Suppress all
    # of those here and do exactly one reload after every file is done.
    all_cpath_settings = (
        "movie.widget", "tvshow.widget",
        "custom1.widget", "custom2.widget", "custom3.widget", "custom4.widget",
        "custom5.widget", "custom6.widget", "custom7.widget", "custom8.widget",
        "custom9.widget", "custom10.widget",
        "movie.main_menu", "tvshow.main_menu",
        "custom1.main_menu", "custom2.main_menu", "custom3.main_menu", "custom4.main_menu",
        "custom5.main_menu", "custom6.main_menu", "custom7.main_menu", "custom8.main_menu",
        "custom9.main_menu", "custom10.main_menu",
    )
    # Sanitize before rebuilding, not after: remake_widgets()/remake_main_menus()
    # below regenerate XML straight from whatever is already in the database,
    # so a legacy embedded C:\ path needs cleaning up here first or it just
    # gets faithfully copied into the freshly rebuilt XML unchanged. This runs
    # on every manual "Remake menus and widgets" AND on every automatic
    # skin-update rebuild (see version_monitor._guarded_remake), so a path
    # missed at capture time - or one path_utils genuinely couldn't resolve
    # back then (e.g. the addon wasn't installed yet) - still gets a chance
    # to be cleaned up later.
    for item in all_cpath_settings:
        CPaths(item).sanitize_stored_paths()
    # Submenus have no database row to sweep above - they're pure Skin.String
    # values - so they get their own pass here, on the same trigger.
    custom_actions.sanitize_all_submenu_paths()
    # Regenerate every category's on-screen submenu include file from
    # whatever's actually occupied right now. Runs unconditionally on
    # every remake (manual button press, and the automatic one
    # version_monitor triggers on every skin update) rather than only
    # when something is known to have changed, so this doubles as the
    # one-time catch-up for anyone updating from a version that never
    # generated these files at all - their existing Skin.String data is
    # untouched either way, only the rendering gets rebuilt from it.
    custom_actions.make_all_submenu_xml()
    # Kodi's native Favourites file is a different system again (see
    # sanitize_favourites_file's own docstring) - same trigger, same reason.
    custom_actions.sanitize_favourites_file()
    for item in (
        "movie.widget",
        "tvshow.widget",
        "custom1.widget",
        "custom2.widget",
        "custom3.widget",
        "custom4.widget",
        "custom5.widget",
        "custom6.widget",
        "custom7.widget",
        "custom8.widget",
        "custom9.widget",
        "custom10.widget",
    ):
        CPaths(item).remake_widgets(reload_skin=False)
    for item in (
        "movie.main_menu",
        "tvshow.main_menu",
        "custom1.main_menu",
        "custom2.main_menu",
        "custom3.main_menu",
        "custom4.main_menu",
        "custom5.main_menu",
        "custom6.main_menu",
        "custom7.main_menu",
        "custom8.main_menu",
        "custom9.main_menu",
        "custom10.main_menu",
    ):
        CPaths(item).remake_main_menus(reload_skin=False)
    # Regenerate the order include too. It lives in the skin's xml folder,
    # so a skin update replaces it with the shipped default - rebuilding it
    # here from the database is what restores the user's own order.
    make_main_menu_order_xml(reload_skin=False)
    # reload_skin=False lets a caller do the reload itself AFTER it has recorded
    # that this remake finished - see version_monitor.check_for_update. The
    # reload re-runs Home's onload, so anything the caller needs to be true by
    # then has to be in place before the reload, not after it.
    if reload_skin:
        xbmc.executebuiltin("ReloadSkin()")
    if not silent:
        xbmcgui.Dialog().ok("Nimbus", "Menus and widgets remade")


def show_busy_dialog():
    return xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

def reset_all_to_defaults(silent=False, welcome=False):
    """
    Wipes all saved custom widget/menu paths and resets each category:
      - Movies / TV Shows main menu -> Kodi's own local video library
        (so those menu items work out of the box, no addon required)
      - All widgets, and Custom1-10 main menu paths -> empty/hidden
        (fully user-defined, no sensible default to seed)
      - All submenu items (all 22 menus) -> cleared, no defaults
        re-seeded (fully user-defined, same as widgets)
    """
    # The welcome screen used to call this with silent=true, so its OK button
    # wiped every widget, main menu path and submenu item with no confirmation.
    # That is correct for a genuine first install, but the welcome screen also
    # appears whenever the skin's settings.xml cannot be read - which happens if
    # Kodi is killed mid-write, e.g. by a crash during playback. In that case an
    # existing user's setup is intact but firsttimerun has been lost along with
    # the rest of the file, so the screen is indistinguishable from a fresh
    # install and OK would silently destroy a working configuration.
    #
    # Asked from that context the question needs different wording to the
    # deliberate "Reset all" in skin settings: the person may have no idea why
    # they are being shown this, so the prompt has to explain both cases rather
    # than just asking them to confirm. Defaults to the non-destructive button,
    # so dismissing it or mashing Enter keeps the existing setup.
    if welcome:
        if not dialog.yesno(
            "Nimbus Plus",
            "Set up Nimbus Plus with default menus and widgets?[CR][CR]"
            "Choose [B]Reset to defaults[/B] if this is a new installation.[CR][CR]"
            "Choose [B]Keep my setup[/B] if you have used Nimbus Plus before. "
            "This screen can also appear after a crash damages the skin's "
            "settings file, and resetting would erase your widgets, main menu "
            "paths and submenu items.",
            nolabel="Keep my setup",
            yeslabel="Reset to defaults",
            defaultbutton=xbmcgui.DLG_YESNO_NO_BTN,
        ):
            return
    elif not silent:
        if not dialog.yesno(
            "Nimbus",
            "This will erase all your configured widgets, main menu "
            "paths, and submenu items, and reset them to defaults. Continue?",
        ):
            return
    if not xbmcvfs.exists(settings_path):
        xbmcvfs.mkdir(settings_path)
    con = database.connect(database_path, timeout=20)
    con.execute(
        "CREATE TABLE IF NOT EXISTS custom_paths (cpath_setting text unique, cpath_path text, cpath_header text, cpath_type text, cpath_label text)"
    )
    con.execute("DELETE FROM custom_paths")
    con.execute(
        "CREATE TABLE IF NOT EXISTS menu_order (order_key text unique, order_value text)"
    )
    con.execute("DELETE FROM menu_order")
    # Seed Movies / TV Shows main menu with Kodi's native library so
    # they aren't blank on a fresh install with no video addons.
    native_main_menu_defaults = (
        ("movie.main_menu", "videodb://movies/titles/", "Movies"),
        ("tvshow.main_menu", "videodb://tvshows/titles/", "TV Shows"),
    )
    for cpath_setting, cpath_path, cpath_header in native_main_menu_defaults:
        con.execute(
            "INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)",
            (cpath_setting, cpath_path, cpath_header, "", ""),
        )
    con.commit()
    con.close()
    # Rebuild every category from the (now-seeded) database: Movies
    # and TV Shows main menus pick up the native paths above; every
    # other category has no rows left, so it falls through to the
    # clean empty default template.
    # (reload_skin=False here for the same reason as remake_all_cpaths:
    # avoid a pile of competing per-file reload threads firing while
    # later files in this loop, and reset_all_submenus() below, are
    # still being written. The single ReloadSkin() at the end of this
    # function is the only reload that actually runs.)
    for item in (
        "movie.widget", "tvshow.widget",
        "custom1.widget", "custom2.widget", "custom3.widget",
        "custom4.widget", "custom5.widget", "custom6.widget",
        "custom7.widget", "custom8.widget", "custom9.widget",
        "custom10.widget",
    ):
        CPaths(item).remake_widgets(reload_skin=False)
    for item in (
        "movie.main_menu", "tvshow.main_menu",
        "custom1.main_menu", "custom2.main_menu", "custom3.main_menu",
        "custom4.main_menu", "custom5.main_menu", "custom6.main_menu",
        "custom7.main_menu", "custom8.main_menu", "custom9.main_menu",
        "custom10.main_menu",
    ):
        CPaths(item).remake_main_menus(reload_skin=False)

    # Clear submenu items across every menu that supports them
    # (movies/tvshows/custom1-10/music/musicvideos/livetv/radio/
    # addons/pictures/video/games/favorites/weather). No defaults
    # are re-seeded - left empty, same as widgets.
    from modules.custom_actions import reset_all_submenus
    reset_all_submenus()

    # menu_order was emptied above, so this writes the shipped default order.
    make_main_menu_order_xml(reload_skin=False)

    dialog.notification(
        "Nimbus", "All widgets, main menus, and submenus reset to defaults",
        xbmcgui.NOTIFICATION_INFO, 2500
    )
    xbmc.executebuiltin("ReloadSkin()")

def hide_busy_dialog():
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    xbmc.executebuiltin("Dialog.Close(busydialog)")