import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xml.etree.ElementTree as ET
from xml.dom import minidom
from xml.sax.saxutils import unescape as xml_unescape
from threading import Timer, Thread
import sys, re
import html
import requests
import json
from modules import path_utils

KEYMAP_LOCATION = "special://userdata/keymaps/"
POSSIBLE_KEYMAP_NAMES = ["gen.xml", "keyboard.xml", "keymap.xml"]

dialog = xbmcgui.Dialog()
Listitem = xbmcgui.ListItem
DEFAULT_PATH = "addons://sources/video"

# Some addons' root path (plugin://<addon_id>/) is not a real content route -
# it just launches something else (a startup script, a modal GUI, a
# first-run wizard) and returns no directory items, so Files.GetDirectory
# can never succeed there no matter how it's asked or how long it waits.
# Confirmed for Mad Titan Sports by decompiling its default.py: root()
# fires RunScript(changelog.py, auto, gui/list) and returns nothing: the
# real listing lives at a sibling route, /main_list, which is a normal
# well-behaved plugin route. Kept in sync with the same table in
# cpath_maker.py (widget/main-menu browsing) - add an entry here AND there
# for any other addon found to have the same problem.
KNOWN_BROKEN_ADDON_ROOTS = {
    "plugin.video.madtitansports": "main_list",
}


def resolve_addon_root(path):
    """Silently substitutes a known-good route for an addon's dead root,
    so browsing into it lands on real content the same way it would for a
    well-behaved addon, instead of stalling at a route that was never
    going to answer. No-op for every path not in KNOWN_BROKEN_ADDON_ROOTS.
    """
    for addon_id, real_route in KNOWN_BROKEN_ADDON_ROOTS.items():
        prefix = "plugin://%s/" % addon_id
        if path in (prefix, prefix.rstrip("/")):
            return prefix + real_route
    return path

#Focus Home Menu on boot fixed for non android.
def fix_initial_home_focus():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return
    window = xbmcgui.Window(10000)
    for _ in range(50):
        if xbmc.getCondVisibility("ControlGroup(2000).HasFocus"):
            xbmc.executebuiltin("SetFocus(9000)")
        else:
            break
        xbmc.sleep(100)
    window.setProperty("NimbusFocusFixDone", "true")

MENU_LISTING_INCLUDE_PATH = "special://profile/addon_data/script.nimbus.helper/menulist_include.txt"

_MENU_LISTING_STARTER_HEADER = (
    "# One Kodi plugin id per line, e.g. plugin.video.example\n"
    "# Lines starting with # are ignored. Blank lines are ignored.\n"
)

# Kodi's own label-formatting tags (COLOR takes a name/hex attribute; the
# rest are bare). Some addons bake these directly into their own display
# name (confirmed case: mp3streams' own provider-name is literally
# "[COLOR crimson]King Krimson[/COLOR]"), and the multiselect dialog renders
# them like anywhere else in Kodi - fighting with the dialog's own selection
# highlight color, which is the whole point of using a checkbox list here.
_KODI_LABEL_TAG_RE = re.compile(
    r"\[/?(?:COLOR(?:\s+[^\]]*)?|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]",
    re.IGNORECASE,
)


def _strip_label_formatting(text):
    """Removes Kodi's [COLOR]/[B]/[I]/etc. formatting tags from a display
    name, so it renders as plain text and doesn't visually compete with the
    multiselect dialog's own selection-state color change.
    """
    return _KODI_LABEL_TAG_RE.sub("", text or "")


def _read_menu_listing_include():
    """Reads menulist_include.txt (one plugin id per line; blank lines and
    lines starting with # are skipped) and returns them as a plain Python
    list, in file order. Creates an empty, commented starter file on first
    run so there's something findable to edit rather than a silently-missing
    file. Shared by load_menu_listing_include() (which needs the
    pipe-wrapped string form for the skin condition - see that function) and
    manage_menu_listing_include() (which needs the plain list to preselect
    the multiselect dialog).
    """
    path = xbmcvfs.translatePath(MENU_LISTING_INCLUDE_PATH)
    if not xbmcvfs.exists(path):
        f = xbmcvfs.File(path, "w")
        try:
            f.write(_MENU_LISTING_STARTER_HEADER.encode("utf-8"))
        finally:
            f.close()
        return []

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.readBytes().decode("utf-8", errors="replace")
    finally:
        f.close()

    plugin_ids = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        plugin_ids.append(line)
    return plugin_ids


def _write_menu_listing_include(plugin_ids):
    """Writes plugin_ids back out, one per line, under the same starter
    comment header every file already opens with - so the file stays
    self-documenting even after being edited entirely through the Forced
    Menu List Plugins dialog rather than by hand. Any other free-text
    comment a user had added by hand is not preserved: the dialog always
    regenerates the whole file from the current selection.
    """
    path = xbmcvfs.translatePath(MENU_LISTING_INCLUDE_PATH)
    body = _MENU_LISTING_STARTER_HEADER + "\n".join(sorted(plugin_ids)) + ("\n" if plugin_ids else "")
    f = xbmcvfs.File(path, "w")
    try:
        f.write(body.encode("utf-8"))
    finally:
        f.close()


def load_menu_listing_include():
    """Populates NimbusMenuListingInclude, the one window property
    Expressions.xml's isMenuListing reads to add "or this addon is listed in
    menulist_include.txt" as an extra OR alongside its existing item 0/1
    metadata heuristic (see Expressions.xml's own comment on isMenuListing
    for what that heuristic already does and why it can misfire for some
    addons - e.g. correct on page 1, wrongly forced into poster view on page
    2 of the same addon, same content shape).

    Kodi's XML conditions cannot read a text file directly, so this one
    small bridge is unavoidable: read the file once here, store the result
    as a window property, and the condition checks the property instead.

    menulist_include.txt lives in script.nimbus.helper's own addon_data,
    not the skin folder - addon_data survives a skin (or helper) update,
    where anything under skin.nimbus/ itself would be wiped and replaced,
    silently destroying a builder's list on the next update.

    Not gated behind a "done" property like fix_initial_home_focus - this
    re-runs on every Home onload, so editing the file (by hand, or via
    manage_menu_listing_include() below) and reloading the skin picks the
    change up immediately rather than needing a full Kodi restart.
    """
    plugin_ids = _read_menu_listing_include()

    # Wrapped in a leading/trailing pipe (not just joined between entries) so
    # Expressions.xml's plain String.Contains() check - a substring test, not
    # an exact match - can't false-match a listed "plugin.video.foo" against
    # the unrelated, longer "plugin.video.foobar" simply because "foo" is a
    # literal substring of "foobar". Only protects that one direction (the
    # listed id being the shorter string) - Container.PluginName itself is
    # passed bare/unwrapped in the condition, since embedding it inside
    # $INFO[] there is what broke a much larger part of the skin last time
    # this was tried (see conversation) - not valid syntax for a boolean
    # expression argument, only for string-display contexts like <label>.
    value = "|" + "|".join(plugin_ids) + "|" if plugin_ids else ""
    xbmcgui.Window(10000).setProperty("NimbusMenuListingInclude", value)


def manage_menu_listing_include():
    """Skin settings > Customization > "Select Addons for List View Basic
    Artwork". Shows
    every installed plugin addon in a native multiselect dialog - checkboxes
    pre-ticked for whatever's already in menulist_include.txt, plain-text
    labels with any [COLOR]/[B]/[I]/etc. formatting an addon baked into its
    own name stripped out first (see _strip_label_formatting - otherwise an
    addon's own colored/bold name visually fights with the dialog's own
    selection-state color change, which is the whole point of a checkbox
    list). Writes the toggled selection straight back to
    menulist_include.txt, then refreshes NimbusMenuListingInclude
    immediately, so the change is live on the very next listing without
    waiting for a Home reload.
    """
    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.GetAddons",
        # xbmc.python.pluginsource covers plugin.video.*, plugin.audio.*,
        # plugin.image.*, and plugin.program.* alike - Kodi differentiates
        # them by the addon's own "provides" attribute, not a separate
        # extension point, so one query covers every plugin.* addon id a
        # builder would actually want to list here.
        "params": {
            "type": "xbmc.python.pluginsource",
            "enabled": True,
            "properties": ["name"],
        },
    })
    response = json.loads(xbmc.executeJSONRPC(request))
    addons = (response.get("result") or {}).get("addons") or []
    if not addons:
        xbmcgui.Dialog().notification("Nimbus", "No installed plugin addons found", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for a in addons:
        a["_plain_name"] = _strip_label_formatting(a.get("name") or a["addonid"])
    addons.sort(key=lambda a: a["_plain_name"].lower())

    addon_ids = [a["addonid"] for a in addons]
    labels = ["%s  [%s]" % (a["_plain_name"], a["addonid"]) for a in addons]

    current_ids = set(_read_menu_listing_include())
    preselect = [i for i, aid in enumerate(addon_ids) if aid in current_ids]

    chosen = xbmcgui.Dialog().multiselect("Select Addons for List View Basic Artwork", labels, preselect=preselect)
    if chosen is None:
        # Cancelled - leave the file exactly as it was.
        return

    new_ids = [addon_ids[i] for i in chosen]
    _write_menu_listing_include(new_ids)
    load_menu_listing_include()


def reset_stored_views():
    """Skin settings > Customization > "Reset Stored Views". Deletes Kodi's
    own per-path view-memory database (ViewModes*.db, under
    special://database/ - matched by pattern rather than today's exact
    filename, since the numeric suffix is a schema version Kodi has bumped
    before - ViewModes6.db as of v20/Nexus onward - and could again).

    This is NOT a Nimbus-specific reset, unlike everything else this skin
    tracks itself: ViewModes*.db is Kodi's own system-level database and
    remembers the view choice for every path ever browsed, across every
    skin ever used on this Kodi profile - not scoped to Nimbus at all.
    Nimbus's own equivalent (Skin.ForcedView.<content>) was fully removed
    in an earlier pass in favor of relying on this same native mechanism,
    so this is what's actually doing the remembering now.

    Confirmed by direct testing (Windows): the file deletes cleanly while
    Kodi is running, but is NOT recreated in the same session - Kodi only
    creates a fresh one on its own next launch. So a successful delete is
    followed immediately by Quit, rather than leaving Kodi running with no
    view-memory database at all until the user thinks to restart it
    themselves.
    """
    special_dir = "special://database/"
    real_dir = xbmcvfs.translatePath(special_dir)
    dirs, files = xbmcvfs.listdir(real_dir)
    targets = [f for f in files if f.lower().startswith("viewmodes") and f.lower().endswith(".db")]

    if not targets:
        xbmcgui.Dialog().ok("Nimbus", "No ViewModes*.db file found - nothing to reset.")
        return

    if not xbmcgui.Dialog().yesno("Nimbus", "Wipe viewmode*.db and exit Kodi?"):
        return

    failed = []
    for fname in targets:
        file_real_path = xbmcvfs.translatePath(special_dir + fname)
        if not xbmcvfs.delete(file_real_path):
            failed.append(fname)

    if failed:
        xbmcgui.Dialog().ok(
            "Nimbus",
            "Could not delete: %s\nKodi was not closed." % ", ".join(failed),
        )
        return

    xbmc.executebuiltin("Quit")


def show_changelog():
    helper_addon = xbmcaddon.Addon("script.nimbus.helper")
    helper_version = helper_addon.getAddonInfo("version")
    skin_addon = xbmcaddon.Addon("skin.nimbus")
    skin_version = skin_addon.getAddonInfo("version")
    skin_name = skin_addon.getAddonInfo("name")
    changelog_path = xbmcvfs.translatePath("special://skin/nimbuschangelog.txt")
    with xbmcvfs.File(changelog_path) as file:
        changelog_text = file.read()
    if isinstance(changelog_text, bytes):
        changelog_text = changelog_text.decode("utf-8")
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \d+\.\d+\.\d+)\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \$INFO\[.*?\])\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    helper_pattern = r"Nimbus Helper: Latest: v([\d.]+) \[B\]\|\[/B\] Installed: v.*"
    helper_match = re.search(helper_pattern, changelog_text)
    if helper_match:
        latest_helper_version = helper_match.group(1)
        installed_part = f"Installed: v{helper_version}"
        if helper_version != latest_helper_version:
            installed_part = f"[COLOR red][B]{installed_part}[/B][/COLOR]"
            update_message = (
                "\n\n[COLOR red][B]An update is available for the Nimbus Helper. "
                "Please follow these instructions to update and get the latest features and ensure full continued functionality:[/B][/COLOR]"
                "\n\n1. Go to Settings [B]»[/B] System [B]»[/B] Addons tab [B]»[/B] Manage dependencies"
                "\n2. Find Nimbus Helper and click it"
                "\n3. Versions [B]»[/B] Click the latest version in ivarbrandt's Repository"
            )
        else:
            update_message = "\n\n[COLOR limegreen][B]Nimbus Helper up to date. No updates needed at this time.[/B][/COLOR]"
        new_helper_info = f"Nimbus Helper: Latest: v{latest_helper_version} [B]|[/B] {installed_part}{update_message}"
        changelog_text = re.sub(
            helper_pattern, new_helper_info, changelog_text, count=1
        )
    header = f"CHANGELOG: {skin_name} v{skin_version}"
    xbmcgui.Dialog().textviewer(header, changelog_text)


def set_widget_count():
    if len(sys.argv) >= 3:
        list_id = sys.argv[2]
        if len(list_id) in (4, 5):
            container_id = (
                f"{list_id[:2]}001" if len(list_id) == 5 else f"{list_id[0]}001"
            )
            num_items_str = xbmc.getInfoLabel(f"Container({container_id}).NumItems")
            if num_items_str and num_items_str.isdigit():
                num_widgets = int(num_items_str) * 2 - 1
                xbmc.executebuiltin(f"Skin.SetString(TotalWidgetCount,{num_widgets})")


def reset_widget_position():
    """Send the widget row we have just left back to its first item.

    Called from the row's onunfocus, so this is about the row being LEFT, not
    the one being entered. That rules out SetFocus: the row no longer has focus,
    and focusing it would drag the user backwards onto it. Control.Move is the
    only builtin that repositions a container without touching focus.

    Control.Move is relative, and these are fixedlists, which WRAP - a blanket
    "move back a lot" does not clamp at item 1, it wraps round and lands on
    offset modulo row length, which is why every row ended up somewhere
    different. So the offset has to be exact, and since skins have no
    arithmetic, working it out is the whole reason this lives in the helper:
    read Container.CurrentItem, subtract one, move back by precisely that much.
    """
    if len(sys.argv) < 3:
        return
    list_id = sys.argv[2]
    if not list_id.isdigit():
        return

    current_item = xbmc.getInfoLabel("Container(%s).CurrentItem" % list_id)
    if not current_item.isdigit():
        return

    # CurrentItem is 1-based, so item 1 needs no move at all.
    offset = int(current_item) - 1
    if offset <= 0:
        return

    # onunfocus also fires for transitions that get cancelled or bounce straight
    # back. If this row is somehow focused again by the time we run, leave it
    # alone rather than yanking the position out from under the user.
    if xbmc.getCondVisibility("Control.HasFocus(%s)" % list_id):
        return

    xbmc.executebuiltin("Control.Move(%s,-%d)" % (list_id, offset))


def set_image(params=None):
    params = params or {}
    start_path = params.get("path") or xbmc.getInfoLabel("Skin.String(LastImagePath)") or "special://home/"

    image_file = xbmcgui.Dialog().browse(
        2,
        "Choose Custom Background Image",
        "files",
        ".jpg|.png|.bmp",
        False,
        False,
        start_path
    )
    if image_file:
        # Dialog().browse() returns whatever form the underlying OS file
        # picker uses - on Windows that's a raw C:\Users\... path, not a
        # special:// one. Convert it back to special:// (when the picked
        # file falls under one of Kodi's own special:// roots) before it
        # gets written into a skin string, so a settings.xml built on one
        # machine still resolves on another.
        image_file = path_utils.to_special_path(image_file)
        xbmc.executebuiltin(f"Skin.SetString(LastImagePath,{image_file})")
        xbmc.executebuiltin(f"Skin.SetString(NimbusCustomBackground,{image_file})")


def play_trailer():
    is_episode = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,episode)")
    is_season = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,season)")
    if xbmc.getCondVisibility("Control.IsVisible(500) | Control.IsVisible(501)"):
        xbmc.executebuiltin(
            "Notification(Trailer Playback, Trailer playback is not available in this view, 3000)"
        )
    elif not (is_episode or is_season):
        trailer_source = xbmc.getInfoLabel("Skin.String(TrailerSource)")
        play_url = None
        if trailer_source == "0":
            play_url = xbmc.getInfoLabel("ListItem.Trailer")
        elif trailer_source == "1":
            play_url = xbmc.getInfoLabel("Skin.String(TrailerPlaybackURL)")
        if play_url:
            xbmc.executebuiltin("Skin.SetString(TrailerPlaying, true)")
            if xbmc.getCondVisibility("Control.IsVisible(50) | Control.IsVisible(51)"):
                xbmc.executebuiltin(f"PlayMedia({play_url},0,noresume)")
            else:
                xbmc.executebuiltin(f"PlayMedia({play_url},1,noresume)")


def check_api_key(api_key):
    api_url = "https://mdblist.com/api/"
    params = {"apikey": api_key, "i": "tt0111161"}
    try:
        response = requests.get(api_url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        return ("valid", "ratings" in data and len(data["ratings"]) > 0)
    except requests.RequestException:
        return ("error", None)


def validate_api_key(api_key, silent=True):
    if not api_key:
        xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        return
    xbmc.executebuiltin("Skin.SetString(checking_api_key,true)")
    try:
        status, is_valid = check_api_key(api_key)
        if status == "valid" and is_valid:
            xbmc.executebuiltin("Skin.SetString(valid_api_key,true)")
            if not silent:
                xbmcgui.Dialog().notification("Success", "Features activated", xbmcgui.NOTIFICATION_INFO, 3000)
        elif status == "valid" and not is_valid:
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            if not silent:
                xbmcgui.Dialog().notification("Connection Error", "Unable to reach MDbList", xbmcgui.NOTIFICATION_INFO, 3000)
    finally:
        xbmc.executebuiltin("Skin.Reset(checking_api_key)")


def set_api_key():
    current_key = xbmc.getInfoLabel("Skin.String(mdblist_api_key)")
    keyboard = xbmc.Keyboard(current_key, "Enter MDbList API Key")
    keyboard.doModal()
    if keyboard.isConfirmed():
        new_key = keyboard.getText()
        if not new_key:
            xbmc.executebuiltin("Skin.Reset(mdblist_api_key)")
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            xbmc.executebuiltin(f'Skin.SetString(mdblist_api_key,"{new_key}")')
            validate_api_key(new_key, silent=False)


def check_api_key_on_load():
    validate_api_key(xbmc.getInfoLabel("Skin.String(mdblist_api_key)"), silent=True)


def fix_black_screen():
    if xbmc.getCondVisibility("Skin.HasSetting(TrailerPlaying)"):
        xbmc.executebuiltin("Skin.Reset(TrailerPlaying)")


def set_blurradius():
    current_value = xbmc.getInfoLabel("Skin.String(BlurRadius)") or "30"
    value = xbmcgui.Dialog().numeric(0, "Enter blur radius value", current_value)
    if value == "":
        value = "30"
    xbmc.executebuiltin(f"Skin.SetString(BlurRadius,{value})")


def set_blursaturation():
    current_value = xbmc.getInfoLabel("Skin.String(BlurSaturation)") or "1.5"
    keyboard = xbmc.Keyboard(current_value, "Enter blur saturation value")
    keyboard.doModal()
    if keyboard.isConfirmed():
        text = keyboard.getText() or "1.5"
        xbmc.executebuiltin(f"Skin.SetString(BlurSaturation,{text})")


def set_autoendplaybackdelay():
    current_value = xbmc.getInfoLabel("Skin.String(PlaybackDelayMins)") or "30"
    value_mins = xbmcgui.Dialog().numeric(0, "Enter delay in minutes", current_value)
    if value_mins == "":
        value_mins, value_secs = "30", 1800
    else:
        value_secs = int(value_mins) * 60
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelayMins,{value_mins})")
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelaySecs,{value_secs})")


# Named color options offered by pick_skin_color() below, via Dialog().select()
# rather than Kodi's native colorpicker() window - that native dialog kept
# returning in ~150ms on this build with nothing ever shown on screen (see
# chat history), so this uses Dialog().select(), Kodi's plain list-select
# dialog, which every addon relies on and doesn't depend on the skin having
# (or Kodi correctly opening) a working DialogColorPicker.xml window.
COLOR_PICKER_PALETTE = [
    ("Dark Red", "FF8B0000"),
    ("Grey", "FF666666"),
    ("White", "FFFFFFFF"),
    ("Light Grey", "FFCCCCCC"),
    ("Silver", "FFC0C0C0"),
    ("Black", "FF000000"),
    ("Dark Grey", "FF333333"),
    ("Red", "FFFF0000"),
    ("Crimson", "FFDC143C"),
    ("Orange", "FFFFA500"),
    ("Gold", "FFFFD700"),
    ("Yellow", "FFFFFF00"),
    ("Lime", "FF00FF00"),
    ("Green", "FF008000"),
    ("Teal", "FF008080"),
    ("Cyan", "FF00FFFF"),
    ("Sky Blue", "FF87CEEB"),
    ("Blue", "FF0000FF"),
    ("Navy", "FF000080"),
    ("Purple", "FF800080"),
    ("Violet", "FF8A2BE2"),
    ("Magenta", "FFFF00FF"),
    ("Pink", "FFFF69B4"),
    ("Hot Pink", "FFFF1493"),
    ("Brown", "FF8B4513"),
    ("Beige", "FFF5F5DC"),
]


def _contrasting_text_color(hexcolor):
    # Mirrors the blur+Adaptive system's own idea (pair a computed highlight
    # color with a computed, readable text color) but for a user-picked
    # Custom color instead of a sampled artwork color - there's no image to
    # sample here, so this just does the arithmetic directly on the hex.
    # Standard perceptive luminance weighting; threshold picked to match
    # where this skin's own light/dark text split already sits.
    hexcolor = hexcolor.strip().lstrip("#")
    if len(hexcolor) == 8:
        hexcolor = hexcolor[2:]  # drop the alpha channel
    if len(hexcolor) != 6:
        return "focused_text"
    try:
        r = int(hexcolor[0:2], 16)
        g = int(hexcolor[2:4], 16)
        b = int(hexcolor[4:6], 16)
    except ValueError:
        return "focused_text"
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    return "FF141415" if luminance > 150 else "FFFFFFFF"


def _store_picked_color(setting, picked, textsetting=None):
    xbmc.executebuiltin(f"Skin.SetString({setting},{picked})")
    if textsetting:
        xbmc.executebuiltin(f"Skin.SetString({textsetting},{_contrasting_text_color(picked)})")


def pick_skin_color(params=None):
    # Generic color-picker hookup for any user-customizable skin color.
    # Called via RunScript(script.nimbus.helper,mode=pick_skin_color,
    # setting=<SkinStringName>,default=<AARRGGBB>,header=<dialog title>
    # [,textsetting=<SkinStringName>]). textsetting is optional - when given,
    # a companion readable text color is computed from the picked color and
    # stored there too (see _contrasting_text_color above).
    # Uses Dialog().select() - a named-color list plus a "Custom hex" entry -
    # rather than the native colorpicker() window, which never actually
    # opened on this build (see chat history for the diagnosis trail; the
    # real bug turned out to be upstream in router.py's argv handling, not
    # in this dialog choice, but select() is the safer primitive to keep
    # since it's already proven reliable via manage_widgets/manage_submenu_items).
    params = params or {}
    setting = params.get("setting")
    if not setting:
        return
    default_color = params.get("default", "FFFFFFFF")
    header = params.get("header", "Select color")
    textsetting = params.get("textsetting")

    # Tint each entry's own name to its actual color via Kodi's [COLOR] tag -
    # Dialog().select() renders labels through the normal label control, so
    # this works with no extra dialog mode or ListItem plumbing needed. The
    # hex code stays untinted for legibility against colors close to the
    # dialog's own background. Whichever palette entry matches THIS call's
    # own default (passed in via the RunScript default= param) is marked
    # "(default)" dynamically, rather than baking a fixed label onto any one
    # palette entry - the same shared palette is used for the seekbar colors,
    # the accent/focus theme custom colors, and anything else that reuses
    # this function, and each one has its own idea of what "default" means.
    custom_label = "Custom (enter hex code)..."
    options = []
    for name, hexval in COLOR_PICKER_PALETTE:
        label = f"{name} (default)" if hexval.upper() == default_color.upper() else name
        options.append(f"[COLOR {hexval}]{label}[/COLOR]  ({hexval})")
    options.append(custom_label)

    choice = xbmcgui.Dialog().select(header, options)
    if choice < 0:
        return  # cancelled

    if choice == len(COLOR_PICKER_PALETTE):
        current_color = xbmc.getInfoLabel(f"Skin.String({setting})") or default_color
        keyboard = xbmc.Keyboard(current_color, "Enter color as AARRGGBB hex (e.g. FF8B0000)")
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return
        text = keyboard.getText().strip().upper()
        if not text:
            return
        _store_picked_color(setting, text, textsetting)
        return

    picked = COLOR_PICKER_PALETTE[choice][1]
    _store_picked_color(setting, picked, textsetting)


def make_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if not xbmcvfs.exists(backup_path):
        xbmcvfs.copy(keymap_path, backup_path)


def restore_from_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if xbmcvfs.exists(backup_path):
        xbmcvfs.delete(keymap_path)
        xbmcvfs.rename(backup_path, keymap_path)


def get_all_existing_keymap_paths():
    paths = []
    for name in POSSIBLE_KEYMAP_NAMES:
        p = xbmcvfs.translatePath(f"special://profile/keymaps/{name}")
        if xbmcvfs.exists(p):
            paths.append(p)
    return paths


def create_new_keymap_file():
    new_path = xbmcvfs.translatePath(f"{KEYMAP_LOCATION}gen.xml")
    ET.ElementTree(ET.Element("keymap")).write(new_path)
    return new_path


class KeyListener(xbmcgui.WindowXMLDialog):
    TIMEOUT = 7

    def __new__(cls):
        return super(KeyListener, cls).__new__(
            cls, "DialogNotification.xml", xbmcaddon.Addon().getAddonInfo("path")
        )

    def __init__(self):
        self.key = None

    def onInit(self):
        self.getControl(401).setLabel("Starting key listener...")
        self.getControl(402).setLabel("Be ready to press key")
        xbmc.sleep(2000)
        countdown_start = self.TIMEOUT - 2
        self.getControl(401).setLabel("Listening for key press...")
        self.getControl(402).setLabel(f"Timeout in {countdown_start} seconds")
        for i in range(countdown_start, 1, -1):
            self.getControl(402).setLabel(f"Timeout in {i} seconds")
            xbmc.sleep(1000)
        self.getControl(402).setLabel("Timeout in 1 second")
        xbmc.sleep(1000)
        self.close()

    def onAction(self, action):
        button_code = action.getButtonCode()
        action_id = action.getId()
        self.key = button_code if button_code != 0 else action_id
        self.getControl(401).setLabel("Key captured successfully!")
        self.getControl(402).setLabel(f"Captured key code: {self.key}")
        xbmc.sleep(2000)
        self.close()

    @staticmethod
    def record_key():
        dlg = KeyListener()
        timeout = Timer(KeyListener.TIMEOUT, dlg.close)
        timeout.start()
        dlg.doModal()
        timeout.cancel()
        key = dlg.key
        del dlg
        return key


def capture_user_key():
    listener = KeyListener()
    captured_key = listener.record_key()
    if captured_key:
        xbmc.executebuiltin(f"Skin.SetString(CapturedKeyCode, {captured_key})")
    del listener
    return captured_key


def modify_keymap():
    keymap_paths = get_all_existing_keymap_paths() or [create_new_keymap_file()]
    captured_key = xbmc.getInfoLabel("Skin.String(CapturedKeyCode)")
    if not captured_key:
        return
    setting_value = xbmc.getInfoLabel("Skin.String(trailerSetting)")
    for keymap_path in keymap_paths:
        if setting_value == "1":
            make_backup(keymap_path)
            tree = ET.parse(keymap_path)
            root = tree.getroot()
            found = False
            for key_tag in root.findall(".//key"):
                if key_tag.text == "RunScript(script.nimbus.helper, mode=play_trailer)":
                    key_tag.set("id", captured_key)
                    found = True
                    break
            if not found:
                global_tag = root.find("global") or ET.SubElement(root, "global")
                keyboard_tag = global_tag.find("keyboard") or ET.SubElement(global_tag, "keyboard")
                ET.SubElement(keyboard_tag, "key", id=captured_key).text = "RunScript(script.nimbus.helper, mode=play_trailer)"
            pretty_xml = minidom.parseString(ET.tostring(root, "utf-8")).toprettyxml(indent="  ")
            with xbmcvfs.File(keymap_path, "w") as xml_file:
                xml_file.write("\n".join([line for line in pretty_xml.split("\n") if line.strip()]))
        else:
            restore_from_backup(keymap_path)
    xbmc.executebuiltin("Action(reloadkeymaps)")


# -------- Submenu manager --------

WINDOW_TARGETS = [("Video Addons", "Videos"), ("Music Addons", "Music"), ("Picture Addons", "Pictures"), ("Program Addons", "Programs")]

WINDOW_DEFAULT_PATHS = {
    "Videos": "addons://sources/video",
    "Music": "addons://sources/audio",
    "Pictures": "addons://sources/image",
    "Programs": "addons://sources/executable",
}

KODI_COMMANDS = [
    ("Addon Browser", "ActivateWindow(AddonBrowser)"),
    ("File Manager", "ActivateWindow(FileManager)"),
    ("Favourites", "ActivateWindow(Favourites)"),
    ("Weather", "ActivateWindow(Weather)"),
    ("Settings", "ActivateWindow(Settings)"),
    ("Reboot", "Reboot"),
    ("Shutdown", "ShutDown"),
    ("Hibernate", "Hibernate"),
    ("Suspend", "Suspend"),
    ("Quit Kodi", "Quit"),
    ("Activate Screensaver", "ActivateScreensaver"),
    ("Update Video Library", "UpdateLibrary(video)"),
    ("Update Music Library", "UpdateLibrary(music)"),
    ("Clean Video Library", "CleanLibrary(video)"),
    ("Clean Music Library", "CleanLibrary(music)"),
    ("Toggle Fullscreen", "Action(FullScreen)"),
    ("Mute", "Mute"),
]

# (display_label, ActivateWindow target, browse root) -- these reuse the
# existing addon-source browser, just rooted at the local library instead
# of addons://sources/... .
LIBRARY_TARGETS = [
    ("Video Library", "Videos", "videodb://"),
    ("Music Library", "Music", "musicdb://"),
]

LIVE_TV_COMMANDS = [
    ("TV Channels", "ActivateWindow(TVChannels)"),
    ("TV Guide", "ActivateWindow(TVGuide)"),
    ("TV Recordings", "ActivateWindow(TVRecordings)"),
    ("TV Timers", "ActivateWindow(TVTimers)"),
    ("Radio Channels", "ActivateWindow(RadioChannels)"),
    ("Radio Guide", "ActivateWindow(RadioGuide)"),
]


def _sanitize_skin_string(value):
    return (value or "").strip()


def _normalize_plugin_path(path):
    p = (path or "").strip()
    if p.startswith(("plugin.video.", "plugin.audio.", "plugin.image.", "plugin.program.")):
        p = f"plugin://{p}"
    elif p.startswith("plugin:/") and not p.startswith("plugin://"):
        p = p.replace("plugin:/", "plugin://", 1)
    return p


def _default_path_for_window(window_target):
    return WINDOW_DEFAULT_PATHS.get(window_target, DEFAULT_PATH)


def _set_submenu_item(menu_id, slot, label, action):
    safe_label = _sanitize_skin_string(label).replace('"', '\\"')
    safe_action = _sanitize_skin_string(action).replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.label,"{safe_label}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.action,"{safe_action}")')


def _set_submenu_target(menu_id, slot, window_target, target_path):
    wt = (window_target or "").replace('"', '\\"')
    tp = (target_path or "").replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.window,"{wt}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.target,"{tp}")')


# Submenu items are stored via Skin.SetString()/Skin.Reset() - unlike the
# home menu order feature's own SQLite table, there's no way to hold the
# canonical state in one Python object and only persist it out at the end.
#
# Re-reading Skin.String() via getInfoLabel() fresh on every loop iteration
# (matching what this used to do) turned out to be unreliable within one
# script session: confirmed on a real device that a move/compact's own
# writes could still read back as stale immediately afterward, even after
# deliberately waiting up to 3000ms - ruling out a queued-builtin timing
# race, since no builtin queue takes anywhere near that long to drain.
# Backing all the way out and back in (a genuinely fresh window) always
# showed the correct result, meaning the underlying data was right the
# whole time - only the immediate re-read was unreliable, most likely due
# to Kodi's own InfoManager caching Skin.String() values in a way that
# doesn't invalidate on a timer.
#
# This cache sidesteps the read path entirely, the same way
# manage_main_menu_order() already does with its own in-memory list: read
# once per slot, keep every subsequent read local, and let the real
# Skin.String() writes happen only for the skin's own benefit (it has to
# read Skin.String() to render the actual submenu - that's a separate,
# unrelated read path from this dialog's own display).
_submenu_cache = {}

# Backs _read_submenu_slot's cache-miss path. Populated by reading
# settings.xml directly off disk rather than through Skin.String()/
# getInfoLabel() - reading a skin string that's never been set is what
# was quietly re-registering it with Kodi's live settings map in the
# first place (the same underlying cause as the old 50-slot skin XML
# checks this whole change was meant to get away from, just reached via
# Python instead of the skin this time - see make_submenu_xml, which
# calls _occupied_submenu_slots for all 22 categories on every remake).
# A plain file read never touches that live map, so it can't re-register
# anything no matter how many IDs get checked. None means "not loaded
# yet this session" - distinct from {} (file legitimately doesn't exist,
# e.g. a fresh install with nothing ever set).
_settings_file_map = None

_SETTINGS_LINE_RE = re.compile(
    r'^\s*<setting id="([^"]+)" type="[^"]+">(.*)</setting>\s*$'
)


def _load_settings_file_map():
    global _settings_file_map
    if _settings_file_map is not None:
        return _settings_file_map
    _settings_file_map = {}
    path = xbmcvfs.translatePath("special://profile/addon_data/skin.nimbus/settings.xml")
    if not xbmcvfs.exists(path):
        return _settings_file_map
    with xbmcvfs.File(path, "r") as f:
        raw = f.read()
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")
    for line in raw.splitlines():
        m = _SETTINGS_LINE_RE.match(line)
        if m:
            # The regex captures raw XML text - still escaped (a literal
            # "&amp;", not a real "&"). A live Skin.String()/getInfoLabel()
            # read always hands back the decoded value, so anything built
            # from this map has to match that or it silently breaks: an
            # un-decoded "&amp;" fed into a freshly-built action string and
            # then written back out via the real Skin.SetString() API gets
            # escaped a second time by Kodi's own writer, turning it into
            # "&amp;amp;" on disk (confirmed on a real device - every
            # backfilled Trakt list action came out this way). html.unescape
            # covers the full XML/HTML entity set (&amp; &lt; &gt; &quot;
            # &apos; and numeric refs), not just the three
            # xml.sax.saxutils.unescape handles by default.
            _settings_file_map[m.group(1)] = html.unescape(m.group(2))
    return _settings_file_map


def _reset_submenu_cache():
    global _settings_file_map
    _submenu_cache.clear()
    _settings_file_map = None


def _clear_submenu_item(menu_id, slot):
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.label)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.action)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.window)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.target)")
    _submenu_cache[(menu_id, slot)] = {"label": "", "action": "", "window": "", "target": ""}


def _clear_all_submenu_items(menu_id, max_items=50):
    """
    Clear every populated slot for this menu.

    Only slots that actually hold something are cleared. Each
    _clear_submenu_item() fires 4 xbmc.executebuiltin() calls, and those are
    queued onto Kodi's application message thread rather than run inline - so
    clearing blindly meant 22 menus x 50 slots x 4 = 4,400 queued builtins on
    a full reset, nearly all of them resetting strings that were never set.
    That flood is slow on any box and risks stalling weaker hardware.

    Probing via _load_settings_file_map() (a plain file read, not
    Skin.String()/getInfoLabel()) is what makes probing first actually safe
    to do unconditionally across all 50 slots - a live read of an ID that's
    never been set is exactly what re-registers it as an empty entry with
    Kodi's own settings store, which a plain file read never does. A fresh
    install still issues zero builtins here.
    """
    settings_map = _load_settings_file_map()
    for i in range(1, max_items + 1):
        if any(
            settings_map.get(f"Submenu.{menu_id}.{i}.{field}")
            for field in ("action", "label", "target", "window")
        ):
            _clear_submenu_item(menu_id, i)


def _read_submenu_slot(menu_id, slot):
    """Read all four strings that make up one submenu item.

    Cached: only actually reads the first time a given slot is asked for
    in this session. Every write below updates the same cache entry
    directly, so nothing after the first read for a slot ever depends on
    a stale value.

    Sourced from settings.xml directly (via _load_settings_file_map),
    not from Skin.String()/getInfoLabel() - see that function's own
    comment for why a live read is what re-registers empty IDs with Kodi
    in the first place. A write still has to go through the real
    Skin.String() API below (there's no safe way to write that file
    directly while Kodi's running - see the settings.xml cleanup work),
    but a read never needs to.
    """
    key = (menu_id, slot)
    if key not in _submenu_cache:
        settings_map = _load_settings_file_map()
        _submenu_cache[key] = {
            field: settings_map.get(f"Submenu.{menu_id}.{slot}.{field}", "")
            for field in ("label", "action", "window", "target")
        }
    return dict(_submenu_cache[key])


def _write_submenu_slot(menu_id, slot, data):
    if not (data.get("action") or data.get("target")):
        _clear_submenu_item(menu_id, slot)
        return
    _set_submenu_item(menu_id, slot, data.get("label", ""), data.get("action", ""))
    _set_submenu_target(menu_id, slot, data.get("window", ""), data.get("target", ""))
    _submenu_cache[(menu_id, slot)] = {
        "label": data.get("label", ""),
        "action": data.get("action", ""),
        "window": data.get("window", ""),
        "target": data.get("target", ""),
    }


def _occupied_submenu_slots(menu_id, max_items=50):
    occupied = []
    for i in range(1, max_items + 1):
        slot_data = _read_submenu_slot(menu_id, i)
        if slot_data.get("action") or slot_data.get("target"):
            occupied.append(i)
    return occupied


def _compact_submenu_slots(menu_id, max_items=50):
    """Close gaps in the slot numbering after a submenu item is removed.

    Mirrors CPaths.compact_widget_slots()'s own reasoning exactly (see that
    function's docstring in cpath_maker.py): the submenu manager lists all
    slots by number, and Move up/Move down walk the OCCUPIED slots (one
    press = one visible row), so a gap left by a removed item made moving
    an item past that gap look like it was skipping or failing. Renumbering
    on delete keeps slot order and display order the same thing, the same
    fix applied to widgets.

    Ascending order is safe here too: every occupied slot's data is read
    before it's ever written to as a lower-numbered target in a later
    iteration, so nothing is overwritten before it's been copied forward.
    """
    keys = _occupied_submenu_slots(menu_id, max_items)
    if keys == list(range(1, len(keys) + 1)):
        return

    for new, old in enumerate(keys, 1):
        if new == old:
            continue
        data = _read_submenu_slot(menu_id, old)
        _write_submenu_slot(menu_id, new, data)

    # Compacting frees the slots above the new count - clear them, or the
    # next item added there silently inherits data left over from a slot
    # that no longer exists.
    for stale in range(len(keys) + 1, max(keys) + 1):
        _clear_submenu_item(menu_id, stale)

    # This dialog's own re-read of submenu state goes through
    # _submenu_cache now (updated by _write_submenu_slot/_clear_submenu_item
    # above), not back through Skin.String(), so this pause isn't for that
    # anymore. Kept for the real skin's own submenu rendering, which does
    # still read Skin.String() directly and needs the queued
    # Skin.SetString()/Skin.Reset() calls above to have actually landed.
    xbmc.sleep(100)


def _submenu_include_name(menu_id):
    return "SubmenuItems_%s" % menu_id


def make_submenu_xml(menu_id, max_items=50):
    """
    Regenerates this category's on-screen submenu include file
    (special://skin/xml/script-nimbus-submenu_<menu_id>.xml), listing only
    the slots _occupied_submenu_slots() actually reports as occupied -
    mirrors cpath_maker.make_widget_xml()'s own reasoning: build the real
    list here in Python, once, instead of the skin checking all 50
    possible slots every time a submenu is opened. This is what
    Custom_1122_SubMenus.xml's per-category <content> block now includes,
    replacing the old hardcoded 1-50 blocks that were quietly registering
    every one of those IDs with Kodi's skin-settings store the moment the
    submenu was opened, empty or not.

    Deliberately does NOT bake in the label or action text itself - each
    generated <item> still reads its label/action live via
    $INFO[Skin.String(...)], exactly as the old hardcoded blocks did, so
    editing an existing item's label/action doesn't need a regenerate at
    all (see the callers below for exactly when the occupied SET can
    change, which is the only thing that does need one).

    Items are written in ascending real-slot-number order, not "occupied
    position" order - matches the old file's own layout exactly (slot 1
    through 50 in order, only occupied ones visible). That's what makes
    _move_submenu_item's data-swap-only approach keep working unchanged:
    a move never needs to regenerate this file, since swapping data
    between two already-occupied slots doesn't change which slot numbers
    are occupied, only what's at them - and those are read live.
    """
    occupied = _occupied_submenu_slots(menu_id, max_items)

    if not occupied:
        items_xml = "<item><label>Back to Home menu</label><onclick>Dialog.Close(1122)</onclick></item>"
    else:
        items_xml = "".join(
            '<item><label>$INFO[Skin.String(Submenu.%s.%d.label)]</label>'
            '<onclick>AlarmClock(nimbus_sub_%s_%d,$INFO[Skin.String(Submenu.%s.%d.action)],00:00,silent)</onclick>'
            '<onclick>Dialog.Close(1122)</onclick></item>'
            % (menu_id, slot, menu_id, slot, menu_id, slot)
            for slot in occupied
        )

    final_format = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<includes>\n"
        '  <include name="%s">\n'
        "    %s\n"
        "  </include>\n"
        "</includes>\n"
    ) % (_submenu_include_name(menu_id), items_xml)

    xml_file = "special://skin/xml/script-nimbus-submenu_%s.xml" % menu_id
    with xbmcvfs.File(xml_file, "w") as f:
        f.write(final_format)


def make_all_submenu_xml():
    """Regenerates every category's submenu include file. Called from
    cpath_maker.remake_all_cpaths(), both as the standing safety net on
    every manual/automatic remake and, critically, as the one-time
    catch-up for anyone updating from a version that didn't generate these
    files at all yet - their existing Skin.String data is untouched by
    this either way, only the on-screen rendering is regenerated from it.
    """
    for menu_id in ALL_SUBMENU_IDS:
        make_submenu_xml(menu_id)


def _regenerate_submenu(menu_id):
    """Regenerate one category's submenu file and reload the skin so the
    on-screen submenu actually picks up the change - Kodi parses
    <include file="..."> references once at (re)load time, so overwriting
    the file on disk alone doesn't do anything until that happens.
    Deferred via reload_skin_when_ready (the same one cpath_maker already
    uses for every other generated-file change) so it never interrupts an
    open settings window.
    """
    make_submenu_xml(menu_id)
    from modules.cpath_maker import reload_skin_when_ready

    Thread(target=reload_skin_when_ready).start()


def _move_submenu_item(menu_id, slot, direction, max_items=50):
    """Swap a submenu item with its nearest occupied neighbour.

    Deliberately not a plain slot +-1 swap. Slots are sparse - remove item 3
    of 5 and you are left with 1, 2, 4, 5 - so stepping by one slot number
    would swap an item into a hole and change nothing on screen, which reads
    as "move up is broken". Stepping through the occupied slots instead
    means one press always moves the item exactly one visible row.

    Returns the slot the item now occupies, or None if nothing moved.
    """
    occupied = _occupied_submenu_slots(menu_id, max_items)
    if slot not in occupied:
        return None
    index = occupied.index(slot)
    new_index = index - 1 if direction == "up" else index + 1
    if new_index < 0 or new_index >= len(occupied):
        dialog.notification(
            "Nimbus",
            "Already at the %s" % ("top" if direction == "up" else "bottom"),
            xbmcgui.NOTIFICATION_INFO,
            1500,
        )
        return None

    other = occupied[new_index]
    this_item = _read_submenu_slot(menu_id, slot)
    other_item = _read_submenu_slot(menu_id, other)
    _write_submenu_slot(menu_id, slot, other_item)
    _write_submenu_slot(menu_id, other, this_item)
    # This dialog's own re-read of this data goes through _submenu_cache
    # now (updated by _write_submenu_slot above), not back through
    # Skin.String(), so this pause isn't for the slot list's own display
    # anymore. Kept for the real skin's own submenu rendering, which does
    # still read Skin.String() directly and needs the queued
    # Skin.SetString()/Reset() calls above to have actually landed.
    xbmc.sleep(150)
    return other


def _move_submenu_item_to_end(menu_id, slot, position, max_items=50):
    """Move an item to the very first/last occupied slot, shifting every
    item between its old and new position over by one to make room - a
    generalized version of _move_submenu_item's single-step swap above.

    position is "top" or "bottom". Returns True if anything moved.
    """
    occupied = _occupied_submenu_slots(menu_id, max_items)
    if slot not in occupied:
        return False
    index = occupied.index(slot)
    if (position == "top" and index == 0) or (
        position == "bottom" and index == len(occupied) - 1
    ):
        return False

    # Read every occupied slot's data, in occupied order, then reinsert the
    # moving item's data at the front/back of that sequence - everything
    # else keeps its relative order, just shifts to close the gap it left
    # behind and open one at the new position.
    data_in_order = [_read_submenu_slot(menu_id, s) for s in occupied]
    moving = data_in_order.pop(index)
    if position == "top":
        data_in_order.insert(0, moving)
    else:
        data_in_order.append(moving)

    for slot_num, data in zip(occupied, data_in_order):
        _write_submenu_slot(menu_id, slot_num, data)

    # Same reasoning as _move_submenu_item above - kept for the real
    # skin's own submenu rendering, not this dialog's own re-read (which
    # goes through _submenu_cache now, not back through Skin.String()).
    xbmc.sleep(150)
    return True


ALL_SUBMENU_IDS = [
    "movies", "tvshows",
    "custom1", "custom2", "custom3", "custom4", "custom5",
    "custom6", "custom7", "custom8", "custom9", "custom10",
    "music", "musicvideos", "livetv", "radio", "addons",
    "pictures", "video", "games", "favorites", "weather",
]

FAVOURITES_PATH = "special://profile/favourites.xml"


def sanitize_favourites_file():
    """Cleans embedded drive-letter paths out of Kodi's own native
    Favourites file.

    This is a genuinely different system from everything else this fix
    touches: "Add to Favourites" is a built-in Kodi feature - Kodi's own
    core writes special://profile/favourites.xml directly when the user
    picks it from a context menu. No Nimbus code is in that path at all;
    Home's Favourites panel only reads it back via <content>favourites://
    </content>. But the same root cause still applies: whatever addon
    supplied the favourited item's thumbnail can hand Kodi a raw OS path
    instead of a portable one (confirmed case: mp3streams and thechains
    both do this for their own menu items - see path_utils.py), and Kodi
    writes that thumb value into favourites.xml exactly as given. That
    file travels with an exported/packaged build the same as everything
    else here, so it has the identical PC-built/Android-broken symptom -
    just via a path this fix didn't originally cover.

    Cleans both the thumb= attribute and each favourite's own action
    text, since the action can itself be a plugin:// URL with the same
    kind of addon-embedded path (see _build_submenu_action_from_path for
    the identical pattern in Nimbus's own submenu targets). Only writes
    the file back if something actually changed. Silently does nothing
    if the file doesn't exist yet, is empty, or fails to parse as XML -
    this is Kodi's own file, not Nimbus's, so an unexpected shape is a
    reason to leave it alone rather than guess.
    """
    path = xbmcvfs.translatePath(FAVOURITES_PATH)
    if not xbmcvfs.exists(path):
        return

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.readBytes()
    finally:
        f.close()
    if not raw or not raw.strip():
        return

    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return

    changed = False
    for fav in root.findall("favourite"):
        thumb = fav.get("thumb")
        if thumb:
            cleaned_thumb = path_utils.sanitize_embedded_paths(thumb)
            if cleaned_thumb != thumb:
                fav.set("thumb", cleaned_thumb)
                changed = True
        if fav.text:
            cleaned_text = path_utils.sanitize_embedded_paths(fav.text)
            if cleaned_text != fav.text:
                fav.text = cleaned_text
                changed = True

    if not changed:
        return

    new_bytes = (
        b'<?xml version="1.0" encoding="utf-8" standalone="yes" ?>\n'
        + ET.tostring(root, encoding="utf-8")
    )
    f = xbmcvfs.File(path, "w")
    try:
        f.write(new_bytes)
    finally:
        f.close()


def _fully_unescape(value):
    """Resolves however many extra rounds of XML entity-escaping a value
    picked up, one html.unescape() pass at a time, stopping once a pass
    changes nothing. A single call only undoes one level - "&amp;amp;"
    needs two passes to fully resolve to a real "&" - so this loops
    rather than assuming one pass is always enough.
    """
    while "&amp;" in value:
        new_value = html.unescape(value)
        if new_value == value:
            break
        value = new_value
    return value


def sanitize_all_submenu_paths():
    """Rewrites any embedded drive-letter path in every occupied submenu
    slot's action/target strings through path_utils.sanitize_embedded_paths(),
    backfills any slot whose .action is empty but whose .window/.target
    are populated, and repairs any action/target that's over-escaped from
    a version of the backfill below that ran before the read-path fix in
    _load_settings_file_map(): that function used to hand back raw,
    still-escaped XML text (a literal "&amp;", not a real "&") instead of
    the decoded value a live Skin.String() read always returns. Feeding
    that into _build_submenu_action_from_path() and writing the result
    back through the real Skin.SetString() API meant Kodi's own writer
    escaped it a second time on the way to disk, landing as "&amp;amp;"
    (confirmed on a real device against several backfilled Trakt list
    items). The read path is fixed now, but slots already written by the
    broken version stay broken until repaired here - html.unescape,
    looped until stable, since a single pass only resolves one level of
    escaping and this needs two to fully undo.

    Backfills any slot whose .action is empty but whose .window/.target
    are populated - legacy data from an older version of this add-on that
    stored window+target but never derived .action from them at write time
    (confirmed against a real settings.xml: several older Trakt-list items
    were exactly this shape). The on-screen submenu click handler only ever
    reads .action, so a slot in that shape isn't just missing a nicety, it's
    fully non-functional - clicking it fires AlarmClock with an empty
    command, which is what shows Kodi's generic "alarm went off, nothing to
    run" notification instead of navigating anywhere.

    Submenus have no database backing (see reset_all_submenus above) - they
    live purely as Skin.String values - so they're outside cpath_maker's
    database-driven remake_all_cpaths() sweep entirely and need this
    separate pass. Only writes a slot back if something actually changed.
    """
    for menu_id in ALL_SUBMENU_IDS:
        for slot in _occupied_submenu_slots(menu_id):
            data = _read_submenu_slot(menu_id, slot)
            action = data.get("action", "")
            target = data.get("target", "")
            window = data.get("window", "")

            repaired_action = _fully_unescape(action)
            repaired_target = _fully_unescape(target)
            if repaired_action != action or repaired_target != target:
                data["action"] = repaired_action
                data["target"] = repaired_target
                _write_submenu_slot(menu_id, slot, data)
                action, target = repaired_action, repaired_target

            if not action and target and window:
                # Same derivation _set_or_edit_slot_from_browser already
                # uses for brand new items - quoted, matching what Kodi
                # itself writes into favourites.xml for the same call.
                data["action"] = _build_submenu_action_from_path(target, window)
                _write_submenu_slot(menu_id, slot, data)
                continue

            cleaned_action = path_utils.sanitize_embedded_paths(action)
            cleaned_target = path_utils.sanitize_embedded_paths(target)
            if cleaned_action != action or cleaned_target != target:
                data["action"] = cleaned_action
                data["target"] = cleaned_target
                _write_submenu_slot(menu_id, slot, data)


def reset_all_submenus():
    """
    Clears every submenu slot for every menu that supports submenus.
    No defaults are re-seeded - every menu is simply left empty after
    clearing.
    """
    for menu_id in ALL_SUBMENU_IDS:
        _clear_all_submenu_items(menu_id)
    # Every category's occupied set just changed (to empty) - regenerate
    # all of them. No reload here; the caller (reset_all_to_defaults, in
    # cpath_maker.py) already does one big ReloadSkin() once everything
    # it touches is done, so doing our own here would just be a second,
    # redundant reload.
    for menu_id in ALL_SUBMENU_IDS:
        make_submenu_xml(menu_id)


def _input_label(default_text):
    kb = xbmc.Keyboard(default_text or "", "Set submenu label")
    kb.doModal()
    if not kb.isConfirmed():
        return None
    t = kb.getText().strip()
    return t if t else None


def _files_get_directory(directory, properties=None):
    properties = properties or ["title", "file", "thumbnail"]
    command = {
        "jsonrpc": "2.0",
        "id": "script.nimbus.helper",
        "method": "Files.GetDirectory",
        "params": {"directory": directory, "media": "files", "properties": properties},
    }
    response = xbmc.executeJSONRPC(json.dumps(command))
    result = json.loads(response).get("result", {})
    files = result.get("files", [])
    # This was originally written for addons:// browsing, where every
    # real entry is a plugin:// path - fine there, but it silently
    # filtered out EVERYTHING when browsing the Video/Music Library
    # (videodb:// / musicdb://), since those entries never start with
    # plugin://. That left the picker with zero items, which returned
    # {} with no dialog shown at all, so creating a submenu item from
    # Video/Music Library silently did nothing.
    browsable_schemes = ("plugin://", "videodb://", "musicdb://")
    return [i for i in files if i.get("file", "").startswith(browsable_schemes) and i.get("filetype") == "directory"]


def _strip_formatting(label):
    if not label:
        return ""
    s = label.replace("[B]", "").replace("[/B]", "")
    while "[COLOR" in s:
        start = s.find("[COLOR")
        end = s.find("]", start) + 1
        s = s[:start] + s[end:]
    return s.replace("[/COLOR]", "")


def _choose_window_target():
    options = (
        [i[0] for i in WINDOW_TARGETS]
        + ["Kodi Commands"]
        + [i[0] for i in LIBRARY_TARGETS]
        + ["Live TV / PVR"]
    )
    idx = dialog.select("Choose target type", options)
    if idx == -1:
        return None

    if idx < len(WINDOW_TARGETS):
        return WINDOW_TARGETS[idx][1]
    idx -= len(WINDOW_TARGETS)

    if idx == 0:
        return "__KODI_COMMANDS__"
    idx -= 1

    if idx < len(LIBRARY_TARGETS):
        return f"__LIBRARY__{idx}"

    return "__LIVE_TV__"


def _submenu_path_browser(label="", file=DEFAULT_PATH, thumbnail="", window_target="Videos", start_root=None, parent_history=None):
    if parent_history is None:
        parent_history = []
    file = resolve_addon_root(file)
    root = start_root or DEFAULT_PATH
    label_clean = _strip_formatting(label)
    results = _files_get_directory(file)
    items = []

    # ".. (Back)" - only once we're at least one level deep, matching a
    # normal file browser: Cancel at the very top still just cancels the
    # whole flow (nowhere within this recursion to go up to), but Cancel
    # at any deeper level used to cancel EVERYTHING too - this gives an
    # actual way to step back up one directory instead of losing the
    # whole browse.
    if parent_history:
        back_li = Listitem("[B].. (Back)[/B]", "Go up one directory", offscreen=True)
        back_li.setProperty("go_up", "true")
        items.append(back_li)

    if file != root:
        use_li = Listitem(
            f"Use [B]{label_clean}[/B] as menu item target",
            f"Set as target ({window_target})",
            offscreen=True
        )
        use_li.setArt({"icon": thumbnail})
        use_li.setProperty("item", json.dumps({
            "label": label_clean,
            "file": file,
            "thumbnail": thumbnail,
            "window_target": window_target,
            "is_final": True
        }))
        items.append(use_li)

    for i in results:
        stripped_label = _strip_formatting(i.get("label", ""))
        li = Listitem(f"{stripped_label} »", "Browse path...", offscreen=True)
        li.setArt({"icon": i.get("thumbnail", "")})
        li.setProperty("item", json.dumps({
            "label": i.get("label", ""),
            "file": i.get("file", ""),
            "thumbnail": i.get("thumbnail", ""),
            "window_target": window_target,
            "is_final": False
        }))
        items.append(li)

    if not items or (len(items) == 1 and parent_history):
        # Not a bug - this genuinely happens when the chosen source
        # (most commonly Video/Music Library) has nothing scanned
        # into it yet. Confirmed via diagnostic logging:
        # Files.GetDirectory("videodb://") returns a literal empty
        # file list on an empty library, not even the static
        # Movies/TV Shows category folders. Silently returning here
        # looked identical to a real failure, so tell the user why.
        dialog.ok("Nimbus", f"No items found in {window_target}. If you "
                             "picked Video or Music Library, make sure it "
                             "has content scanned into it first.")
        return {}

    choice = dialog.select("Choose path", items, useDetails=True)
    if choice == -1:
        return {}

    if items[choice].getProperty("go_up") == "true":
        previous = parent_history[-1]
        return _submenu_path_browser(
            label=previous["label"],
            file=previous["file"],
            thumbnail=previous["thumbnail"],
            window_target=window_target,
            start_root=root,
            parent_history=parent_history[:-1],
        )

    chosen = json.loads(items[choice].getProperty("item"))
    if chosen.get("is_final") or chosen["file"] == file:
        return chosen

    return _submenu_path_browser(
        label=chosen.get("label", ""),
        file=chosen.get("file", ""),
        thumbnail=chosen.get("thumbnail", ""),
        window_target=window_target,
        start_root=root,
        parent_history=parent_history + [
            {"label": label, "file": file, "thumbnail": thumbnail}
        ],
    )


def _build_submenu_action_from_path(path, window_target):
    p = _normalize_plugin_path(path)
    # Some third-party addons (confirmed: thechains, mp3streams) embed
    # their own local icon/fanart path as a query param inside the
    # plugin:// URL their own directory listing returns - not something
    # Nimbus put there, but once captured verbatim it's stored the same
    # way, and ships just as broken to another machine. Clean those up
    # here too, at the one place every submenu target action gets built,
    # rather than trying to catch it at every capture site.
    p = path_utils.sanitize_embedded_paths(p)
    # Quoted, matching exactly what Kodi itself writes into favourites.xml
    # for the same ActivateWindow call - confirmed by direct side-by-side
    # testing to behave differently on Back for at least one real addon
    # (madtitansports) versus the previously-unquoted path, even though
    # both parse to the same forward destination. Escaped in case a path
    # happens to contain a literal " itself.
    quoted_p = '"%s"' % p.replace('"', '\\"')
    return f"ActivateWindow({window_target},{quoted_p},return)"


def _set_or_edit_slot_from_kodi_command(menu_id, slot):
    idx = dialog.select("Choose a Kodi command", [c[0] for c in KODI_COMMANDS])
    if idx == -1:
        return

    command_label, action = KODI_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    # No real browsable path exists for these -> store the action itself
    # as the "target" so slot-occupied checks elsewhere still work.
    _set_submenu_target(menu_id, slot, "System", action)
    _submenu_cache[(menu_id, slot)] = {"label": label, "action": action, "window": "System", "target": action}

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_live_tv(menu_id, slot):
    idx = dialog.select("Choose a Live TV / PVR destination", [c[0] for c in LIVE_TV_COMMANDS])
    if idx == -1:
        return

    command_label, action = LIVE_TV_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, "System", action)
    _submenu_cache[(menu_id, slot)] = {"label": label, "action": action, "window": "System", "target": action}

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_manual_entry(menu_id, slot):
    kb = xbmc.Keyboard("", "Enter the full action (e.g. PlayMedia(...) or ActivateWindow(...))")
    kb.doModal()
    if not kb.isConfirmed():
        return
    action = kb.getText().strip()
    if not action:
        return
    # A pasted Kodi favourite's action comes straight out of an XML file's
    # element text, where a literal & is written as &amp; (and < / >
    # likewise) - that escaping only ever made sense for the XML parser
    # that read it there. _set_submenu_item/_set_submenu_target below store
    # this value via a direct Skin.SetString() builtin call, never through
    # any XML parser, so &amp; would otherwise reach Kodi's plugin URL
    # parser completely literally - which splits query-string parameters
    # on a real &, not the four-character text "&amp;" - silently merging
    # every parameter after the first into one. Undo it here, once, before
    # anything else touches the string.
    action = xml_unescape(action)
    # Sanitized the same as any other captured path, in case a pasted
    # favourite action happens to embed a device-specific absolute path.
    action = path_utils.sanitize_embedded_paths(action)

    label = _input_label("New Item")
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    # No real browsable path exists for a raw manual action - store the
    # action itself as the "target", matching the Kodi Commands/Live TV
    # pattern, so slot-occupied checks elsewhere still work.
    _set_submenu_target(menu_id, slot, "System", action)
    _submenu_cache[(menu_id, slot)] = {"label": label, "action": action, "window": "System", "target": action}

    dialog.notification("Nimbus", f"Saved submenu item in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_browser(menu_id, slot):
    # A level above _choose_window_target's own list (which mixes Videos/
    # Music/etc, Kodi Commands, Library targets, and Live TV all together) -
    # "Browse for a target" leads into that exact, unchanged flow; "Enter
    # Manually" bypasses it entirely for a raw, user-supplied action.
    entry_choice = dialog.select("Set submenu target", ["Browse for a target", "Enter Manually"])
    if entry_choice == -1:
        return
    if entry_choice == 1:
        _set_or_edit_slot_from_manual_entry(menu_id, slot)
        return

    window_target = _choose_window_target()
    if not window_target:
        return

    if window_target == "__KODI_COMMANDS__":
        _set_or_edit_slot_from_kodi_command(menu_id, slot)
        return

    if window_target == "__LIVE_TV__":
        _set_or_edit_slot_from_live_tv(menu_id, slot)
        return

    if window_target.startswith("__LIBRARY__"):
        lib_idx = int(window_target.replace("__LIBRARY__", ""))
        _, real_window_target, start_path = LIBRARY_TARGETS[lib_idx]
        window_target = real_window_target
    else:
        start_path = _default_path_for_window(window_target)

    result = _submenu_path_browser(file=start_path, window_target=window_target, start_root=start_path)
    if not result:
        return

    target_path = _normalize_plugin_path(result.get("file"))
    if not target_path:
        return
    # .action and .target are two SEPARATE stored skin strings for the same
    # path (see _write_submenu_slot). Sanitizing target_path here, before
    # either one is derived/stored, is what keeps them in sync - previously
    # only _build_submenu_action_from_path's own copy got cleaned, so a
    # brand new item came out with a clean .action but a still-dirty
    # .target, only fixed later by the next sanitize_all_submenu_paths()
    # sweep rather than at creation time.
    target_path = path_utils.sanitize_embedded_paths(target_path)

    default_label = _strip_formatting(result.get("label", "")) or "New Item"
    label = _input_label(default_label)
    if label is None:
        return

    action = _build_submenu_action_from_path(target_path, window_target)
    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, window_target, target_path)
    _submenu_cache[(menu_id, slot)] = {"label": label, "action": action, "window": window_target, "target": target_path}

    dialog.notification("Nimbus", f"Saved submenu item in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def manage_submenu_items(menu_id, max_items=50):
    """
    Submenu manager UX: shows only occupied slots (each labelled with its
    content), numbered by visible position rather than the underlying
    storage slot - the raw slot number is an implementation detail the
    user shouldn't need to think about. "Create New Sub Menu Item" finds
    the lowest free slot itself, so there's no way to land in the middle
    of a stretch of empties by scrolling too far, which the old
    show-all-50-slots list made possible. "Clear all" only appears once
    there's something to clear; an empty submenu shows just the one
    Create New option. Picking a filled item offers change/rename/remove
    for that one slot. Loops back to the slot list after every action, so
    repeat edits don't require re-opening the manager.

    Storage/generation is unchanged from before - this only replaces the
    old "what do you want to do first" menu.
    """
    if not menu_id:
        dialog.ok("Nimbus", "Missing menu id")
        return

    # Read once per slot for this whole session (see _submenu_cache's own
    # comment above _read_submenu_slot for why re-reading Skin.String() on
    # every loop iteration was unreliable). A fresh reset here, not inside
    # the loop, so every subsequent read in this session comes from what
    # this script itself already knows is correct, matching how
    # manage_main_menu_order() keeps its own order list in memory instead
    # of re-reading its database on every iteration too.
    _reset_submenu_cache()

    while True:
        occupied = _occupied_submenu_slots(menu_id, max_items)
        has_room = len(occupied) < max_items

        items = []
        for position, slot_num in enumerate(occupied, 1):
            slot_data = _read_submenu_slot(menu_id, slot_num)
            items.append(xbmcgui.ListItem(
                f"{position}. {slot_data.get('label', '')}",
                slot_data.get("target", ""),
            ))

        create_new_index = None
        clear_all_index = None
        if has_room:
            items.append(xbmcgui.ListItem("Create New Sub Menu Item", ""))
            create_new_index = len(items) - 1
        if occupied:
            items.append(xbmcgui.ListItem("Clear all submenu items", ""))
            clear_all_index = len(items) - 1

        idx = dialog.select(f"Submenu Items ({menu_id})", items, useDetails=True)
        if idx == -1:
            return

        if idx == create_new_index:
            occupied_set = set(occupied)
            next_slot = next(i for i in range(1, max_items + 1) if i not in occupied_set)
            _set_or_edit_slot_from_browser(menu_id, next_slot)
            xbmc.sleep(100)
            # Occupancy just grew by one slot - the generated submenu file
            # (and the on-screen popup it feeds) needs to know that.
            _regenerate_submenu(menu_id)
            continue

        if idx == clear_all_index:
            if dialog.yesno("Nimbus", f"Clear all submenu items for '{menu_id}'?"):
                _clear_all_submenu_items(menu_id)
                xbmc.sleep(100)
                _regenerate_submenu(menu_id)
                dialog.notification("Nimbus", f"Cleared all submenu items for {menu_id}", xbmcgui.NOTIFICATION_INFO, 2500)
            continue

        slot = occupied[idx]

        # Filled slot: offer per-slot actions. Move to top/bottom only
        # offered when there's actually somewhere further to go - matches
        # how the position-based hiding already works for Move up/down's
        # own "already at the top/bottom" case, just visible up front here
        # instead of as a notification after the fact.
        is_first = slot == occupied[0]
        is_last = slot == occupied[-1]

        slot_actions = [
            ("Move up", "move_up"),
            ("Move down", "move_down"),
        ]
        if not is_first:
            slot_actions.append(("Move to top", "move_top"))
        if not is_last:
            slot_actions.append(("Move to bottom", "move_bottom"))
        slot_actions += [
            ("Change target (browse)", "change"),
            ("Change target (manual)", "change_manual"),
            ("Rename", "rename"),
            ("Remove", "remove"),
        ]
        current_label = _read_submenu_slot(menu_id, slot).get("label", "")
        slot_choice = dialog.select(
            current_label or f"Slot {slot}",
            [i[0] for i in slot_actions],
        )
        if slot_choice == -1:
            continue
        slot_action = slot_actions[slot_choice][1]

        if slot_action in ("move_up", "move_down"):
            _move_submenu_item(
                menu_id, slot, "up" if slot_action == "move_up" else "down", max_items
            )

        elif slot_action in ("move_top", "move_bottom"):
            _move_submenu_item_to_end(
                menu_id, slot, "top" if slot_action == "move_top" else "bottom", max_items
            )

        elif slot_action == "change":
            _set_or_edit_slot_from_browser(menu_id, slot)
            xbmc.sleep(100)

        elif slot_action == "change_manual":
            _set_or_edit_slot_from_manual_entry(menu_id, slot)
            xbmc.sleep(100)

        elif slot_action == "rename":
            new_label = _input_label(current_label)
            if new_label is None:
                continue
            # Through _write_submenu_slot rather than _set_submenu_item
            # directly, so the cache picks up the change too - otherwise
            # a rename's own result wouldn't show until the next full
            # session, the same staleness this cache exists to prevent.
            slot_data = _read_submenu_slot(menu_id, slot)
            slot_data["label"] = new_label
            _write_submenu_slot(menu_id, slot, slot_data)
            xbmc.sleep(100)
            dialog.notification("Nimbus", f"Renamed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

        elif slot_action == "remove":
            if dialog.yesno("Nimbus", f"Remove submenu item in slot {slot}?"):
                _clear_submenu_item(menu_id, slot)
                # _clear_submenu_item's own cache update already makes the
                # immediately-following _compact_submenu_slots() see this
                # slot as free, regardless of this pause - kept for the
                # real skin's own submenu rendering, which does still read
                # Skin.String() directly and needs the queued
                # Skin.Reset() calls above to have actually landed.
                xbmc.sleep(100)
                _compact_submenu_slots(menu_id)
                # Occupancy shrank, and compaction may have shifted which
                # real slot numbers are occupied - the generated file's
                # list needs to match the new set either way.
                _regenerate_submenu(menu_id)
                dialog.notification("Nimbus", f"Removed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

def apply_splash_setting():
    """
    Reads the skin's disable.splashscreen toggle and adds/removes the
    <splash>false</splash> line in special://userdata/advancedsettings.xml
    accordingly, preserving any other existing advancedsettings content.
    Requires a full Kodi restart to actually take effect, since the
    splash screen shows before the skin/Python ever run.
    """
    import xbmcvfs
    import xml.etree.ElementTree as ET

    disable_splash = xbmc.getCondVisibility("Skin.HasSetting(disable.splashscreen)")
    path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")

    if xbmcvfs.exists(path):
        try:
            tree = ET.parse(path)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element("advancedsettings")
            tree = ET.ElementTree(root)
    else:
        root = ET.Element("advancedsettings")
        tree = ET.ElementTree(root)

    splash_el = root.find("splash")

    if disable_splash:
        if splash_el is None:
            splash_el = ET.SubElement(root, "splash")
        splash_el.text = "false"
    else:
        if splash_el is not None:
            root.remove(splash_el)

    tree.write(path, encoding="UTF-8", xml_declaration=True)

    dialog.notification(
        "Nimbus",
        "Splash screen disabled - restart Kodi to apply"
        if disable_splash
        else "Splash screen enabled - restart Kodi to apply",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )

def apply_disable_background_playback_setting():
    """
    Adds or removes a dedicated keymap file that makes Back (keyboard
    Backspace, id 61448) stop playback instead of leaving it running
    in the background, while fullscreen video is playing.
    """
    import xbmcvfs

    enabled = xbmc.getCondVisibility("Skin.HasSetting(disable.backgroundplayback)")
    keymap_dir = xbmcvfs.translatePath("special://userdata/keymaps/")
    keymap_path = keymap_dir + "nimbus_back_stops_playback.xml"

    if enabled:
        if not xbmcvfs.exists(keymap_dir):
            xbmcvfs.mkdirs(keymap_dir)
        with xbmcvfs.File(keymap_path, "w") as f:
            f.write(
                '<keymap><fullscreenvideo><keyboard><key id="61448">stop</key>'
                "</keyboard></fullscreenvideo></keymap>"
            )
    else:
        if xbmcvfs.exists(keymap_path):
            xbmcvfs.delete(keymap_path)

    xbmc.executebuiltin("Action(reloadkeymaps)")

    dialog.notification(
        "Nimbus",
        "Background playback disabled" if enabled else "Background playback re-enabled",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )


_SETTING_LINE_RE = re.compile(
    r'^(\s*)<setting id="([^"]+)" type="([^"]+)">(.*)</setting>\s*$'
)


def clean_settings_file():
    """
    One-time cleanup of skin.nimbus's own persisted settings.xml (the
    Skin.String/Skin.SetString data file at
    special://profile/addon_data/skin.nimbus/settings.xml - NOT this
    add-on's own settings, and not SkinSettings.xml, the UI definitions
    file that renders the settings screens).

    Does two things:
      - Migrates every leftover lowercase "submenu.*" entry that still
        holds a real value onto its correctly-cased "Submenu.*" ID,
        instead of just discarding it. This used to just delete these
        outright - confirmed against a real device that some of them
        held the only surviving copy of a submenu item's .action after
        an old, since-fixed casing bug split a handful of items' data
        across both casings (label/window/target correctly cased,
        .action landing on the lowercase id instead). Never overwrites a
        target ID that already holds a real value - the correctly-cased
        copy always wins if both exist.
      - Removes every <setting type="string"> entry whose value is empty
        (after migration, so nothing needed is dropped along the way).
        Bool and number entries are never touched, even if their value
        looks like a "default" (false/0) - only empty STRING entries are
        debris, and current code (see _occupied_submenu_slots and
        friends) already only ever writes occupied slots, so this
        shouldn't refill from normal use going forward.

    Ported from the standalone cleanup_nimbus_settings.py script (tested
    against a real ~4,700-line export before this version was written) -
    same line-based approach, kept deliberately dumb: every non-blank line
    inside <settings>...</settings> must match the flat, one-setting-per-
    line <setting id="..." type="...">value</setting> format this file has
    always used, or nothing is written at all. A timestamped backup is
    made before any change.

    IMPORTANT LIMITATION, surfaced to the user via the confirmation dialog
    below rather than done silently: Kodi loads settings.xml into memory
    once at startup and, after that, only ever writes memory -> disk (on
    any Skin.SetString/Reset call, or on exit) - it never re-reads the
    file mid-session. So a direct file edit like this only sticks until
    the very next skin-setting write, at which point Kodi flushes its
    still-bloated in-memory copy straight back over it - and that can
    happen from perfectly ordinary navigation (view state, last-focused
    item, cache size, etc.), not just from deliberately changing a
    setting. Confirmed on a real device: backing out to Home before
    manually exiting Kodi was enough to undo the cleanup before Kodi ever
    closed. There is no supported way to make Kodi drop entries from its
    live in-memory settings map short of actually closing the process, so
    rather than leave that race up to chance, this closes Kodi itself
    immediately after writing the cleaned file - no navigating back
    through the settings screens first, nothing else gets a chance to
    trigger another flush in between.
    """
    path = xbmcvfs.translatePath("special://profile/addon_data/skin.nimbus/settings.xml")

    if not xbmcvfs.exists(path):
        dialog.notification("Nimbus", "Couldn't find skin.nimbus's settings.xml", xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    if not dialog.yesno(
        "Nimbus",
        "Clean settings.xml and force close Kodi?",
    ):
        return

    with xbmcvfs.File(path, "r") as f:
        raw = f.read()
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")

    original_lines = raw.splitlines(keepends=True)

    # Pass 1: parse every line and record every ID's value up front, so
    # pass 2 can decide what to do with a lowercase entry regardless of
    # whether its correctly-cased counterpart appears earlier or later in
    # the file - order in the file was never guaranteed either way.
    parsed = []
    current_values = {}
    unrecognized = []
    for line in original_lines:
        stripped = line.strip()
        if stripped in ("", "<settings>", "</settings>"):
            parsed.append((line, None, None, None, None))
            continue
        m = _SETTING_LINE_RE.match(line)
        if not m:
            unrecognized.append(line)
            parsed.append((line, None, None, None, None))
            continue
        indent, setting_id, setting_type, value = m.group(1), m.group(2), m.group(3), m.group(4)
        parsed.append((line, indent, setting_id, setting_type, value))
        current_values[setting_id] = value

    if unrecognized:
        xbmc.log(
            "Nimbus: clean_settings_file aborted - %d line(s) in settings.xml "
            "didn't match the expected <setting id=\"...\" type=\"...\">value</setting> "
            "format, refusing to guess." % len(unrecognized),
            xbmc.LOGWARNING,
        )
        dialog.ok(
            "Clean settings.xml",
            "Found %d line(s) that don't match the expected format - stopped "
            "without changing anything. Check the Kodi log for details."
            % len(unrecognized),
        )
        return

    # Decide, up front, exactly which lowercase entries are migrating and
    # to which target ID - so pass 2 can also drop the correctly-cased
    # empty duplicate that migration is about to replace, rather than
    # leaving two lines for the same target ID in the output.
    migrations = {}  # target_id -> (indent, value)
    for line, indent, setting_id, setting_type, value in parsed:
        if setting_id and setting_id.startswith("submenu.") and value.strip():
            target_id = "Submenu." + setting_id[len("submenu."):]
            if not current_values.get(target_id, "").strip():
                migrations[target_id] = (indent, value)

    kept_lines = []
    migrated = 0
    dropped_lowercase = 0
    dropped_empty = 0

    for line, indent, setting_id, setting_type, value in parsed:
        if setting_id is None:
            kept_lines.append(line)
            continue

        if setting_id.startswith("submenu."):
            target_id = "Submenu." + setting_id[len("submenu."):]
            if target_id in migrations:
                # This exact lowercase line is the one being migrated -
                # re-emit it under the correct ID instead of dropping it.
                mig_indent, mig_value = migrations[target_id]
                if mig_indent == indent and mig_value == value:
                    kept_lines.append(
                        '%s<setting id="%s" type="string">%s</setting>\r\n'
                        % (indent, target_id, value)
                    )
                    migrated += 1
                    continue
            dropped_lowercase += 1
            continue

        if setting_id in migrations:
            # The correctly-cased empty duplicate a migration is replacing -
            # same accounting bucket as any other empty string entry, since
            # that's exactly what this is (its emptiness is the whole
            # reason it was eligible for migration in the first place).
            # The migrated line above already covers this ID.
            dropped_empty += 1
            continue

        if setting_type == "string" and value.strip() == "":
            dropped_empty += 1
            continue

        kept_lines.append(line)

    total_before = sum(1 for _, _, sid, _, _ in parsed if sid is not None)
    total_after = sum(1 for l in kept_lines if _SETTING_LINE_RE.match(l))
    expected_after = total_before - dropped_lowercase - dropped_empty
    if total_after != expected_after:
        xbmc.log(
            "Nimbus: clean_settings_file aborted - kept/dropped entry count "
            "didn't add up, refusing to write.",
            xbmc.LOGWARNING,
        )
        dialog.ok("Clean settings.xml", "Something didn't add up during the cleanup - stopped without changing anything.")
        return

    if migrated == 0 and dropped_lowercase == 0 and dropped_empty == 0:
        dialog.notification("Nimbus", "Nothing to clean up - settings.xml is already tidy", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    from datetime import datetime
    backup_path = "%s.bak-%s" % (path, datetime.now().strftime("%Y%m%d-%H%M%S"))
    with xbmcvfs.File(path, "r") as src, xbmcvfs.File(backup_path, "w") as dst:
        dst.write(src.read())

    with xbmcvfs.File(path, "w") as f:
        f.write("".join(kept_lines))

    # Deliberately no dialog.ok() here - even a modal "done!" popup means
    # one more round trip through the message loop before the process
    # actually ends, and the whole point is to leave zero room for
    # anything else to sneak in a settings write first. A brief
    # non-blocking notification plus a short pause to let it actually be
    # seen, then straight to killing the process - nothing after this.
    dialog.notification(
        "Nimbus",
        "Migrated %d, removed %d lowercase leftovers and %d empty entries (%d -> %d) - closing Kodi to lock it in"
        % (migrated, dropped_lowercase, dropped_empty, total_before, total_after),
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )
    xbmc.sleep(4000)

    # Quit() alone isn't enough - confirmed on a real device: it's a
    # GRACEFUL shutdown, and Kodi's own graceful-shutdown sequence
    # includes flushing its in-memory settings map back to settings.xml
    # one more time on the way out, which overwrites the clean file this
    # function just wrote with the still-bloated in-memory copy before the
    # process actually exits - the same underlying problem as backing out
    # to Home, just moved to the very end instead of the start.
    #
    # This add-on's Python runs embedded directly inside Kodi's own
    # process (not a separate subprocess), so os._exit() terminates that
    # whole process immediately at the OS level - it skips every C++ and
    # Python cleanup path entirely, including the one rewriting
    # settings.xml, rather than asking Kodi to shut down through its
    # normal routine. The file this function wrote just above is already
    # fully flushed and closed by this point (the "with" block above has
    # already returned), so there's nothing left in flight for an abrupt
    # exit to lose - it only skips work we specifically don't want run.
    import os

    os._exit(0)