# -*- coding: utf-8 -*-
# "Refresh widget" context menu item (addon.xml kodi.context.item).
from modules.custom_actions import refresh_focused_widget

refresh_focused_widget()
