import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xml.etree.ElementTree as ET
from xml.dom import minidom
from xml.sax.saxutils import unescape as xml_unescape
from threading import Timer
import sys, re
import requests
import json
from modules import path_utils

KEYMAP_LOCATION = "special://userdata/keymaps/"
POSSIBLE_KEYMAP_NAMES = ["gen.xml", "keyboard.xml", "keymap.xml"]

dialog = xbmcgui.Dialog()
Listitem = xbmcgui.ListItem
DEFAULT_PATH = "addons://sources/video"

# Some addons' root path (plugin://<addon_id>/) is not a real content route -
# it just launches something else (a startup script, a modal GUI, a
# first-run wizard) and returns no directory items, so Files.GetDirectory
# can never succeed there no matter how it's asked or how long it waits.
# Confirmed for Mad Titan Sports by decompiling its default.py: root()
# fires RunScript(changelog.py, auto, gui/list) and returns nothing: the
# real listing lives at a sibling route, /main_list, which is a normal
# well-behaved plugin route. Kept in sync with the same table in
# cpath_maker.py (widget/main-menu browsing) - add an entry here AND there
# for any other addon found to have the same problem.
KNOWN_BROKEN_ADDON_ROOTS = {
    "plugin.video.madtitansports": "main_list",
}


def resolve_addon_root(path):
    """Silently substitutes a known-good route for an addon's dead root,
    so browsing into it lands on real content the same way it would for a
    well-behaved addon, instead of stalling at a route that was never
    going to answer. No-op for every path not in KNOWN_BROKEN_ADDON_ROOTS.
    """
    for addon_id, real_route in KNOWN_BROKEN_ADDON_ROOTS.items():
        prefix = "plugin://%s/" % addon_id
        if path in (prefix, prefix.rstrip("/")):
            return prefix + real_route
    return path

#Focus Home Menu on boot fixed for non android.
def fix_initial_home_focus():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return
    window = xbmcgui.Window(10000)
    for _ in range(50):
        if xbmc.getCondVisibility("ControlGroup(2000).HasFocus"):
            xbmc.executebuiltin("SetFocus(9000)")
        else:
            break
        xbmc.sleep(100)
    window.setProperty("NimbusFocusFixDone", "true")

MENU_LISTING_INCLUDE_PATH = "special://profile/addon_data/script.nimbus.helper/menulist_include.txt"

_MENU_LISTING_STARTER_HEADER = (
    "# One Kodi plugin id per line, e.g. plugin.video.example\n"
    "# Lines starting with # are ignored. Blank lines are ignored.\n"
)

# Kodi's own label-formatting tags (COLOR takes a name/hex attribute; the
# rest are bare). Some addons bake these directly into their own display
# name (confirmed case: mp3streams' own provider-name is literally
# "[COLOR crimson]King Krimson[/COLOR]"), and the multiselect dialog renders
# them like anywhere else in Kodi - fighting with the dialog's own selection
# highlight color, which is the whole point of using a checkbox list here.
_KODI_LABEL_TAG_RE = re.compile(
    r"\[/?(?:COLOR(?:\s+[^\]]*)?|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]",
    re.IGNORECASE,
)


def _strip_label_formatting(text):
    """Removes Kodi's [COLOR]/[B]/[I]/etc. formatting tags from a display
    name, so it renders as plain text and doesn't visually compete with the
    multiselect dialog's own selection-state color change.
    """
    return _KODI_LABEL_TAG_RE.sub("", text or "")


def _read_menu_listing_include():
    """Reads menulist_include.txt (one plugin id per line; blank lines and
    lines starting with # are skipped) and returns them as a plain Python
    list, in file order. Creates an empty, commented starter file on first
    run so there's something findable to edit rather than a silently-missing
    file. Shared by load_menu_listing_include() (which needs the
    pipe-wrapped string form for the skin condition - see that function) and
    manage_menu_listing_include() (which needs the plain list to preselect
    the multiselect dialog).
    """
    path = xbmcvfs.translatePath(MENU_LISTING_INCLUDE_PATH)
    if not xbmcvfs.exists(path):
        f = xbmcvfs.File(path, "w")
        try:
            f.write(_MENU_LISTING_STARTER_HEADER.encode("utf-8"))
        finally:
            f.close()
        return []

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.readBytes().decode("utf-8", errors="replace")
    finally:
        f.close()

    plugin_ids = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        plugin_ids.append(line)
    return plugin_ids


def _write_menu_listing_include(plugin_ids):
    """Writes plugin_ids back out, one per line, under the same starter
    comment header every file already opens with - so the file stays
    self-documenting even after being edited entirely through the Forced
    Menu List Plugins dialog rather than by hand. Any other free-text
    comment a user had added by hand is not preserved: the dialog always
    regenerates the whole file from the current selection.
    """
    path = xbmcvfs.translatePath(MENU_LISTING_INCLUDE_PATH)
    body = _MENU_LISTING_STARTER_HEADER + "\n".join(sorted(plugin_ids)) + ("\n" if plugin_ids else "")
    f = xbmcvfs.File(path, "w")
    try:
        f.write(body.encode("utf-8"))
    finally:
        f.close()


def load_menu_listing_include():
    """Populates NimbusMenuListingInclude, the one window property
    Expressions.xml's isMenuListing reads to add "or this addon is listed in
    menulist_include.txt" as an extra OR alongside its existing item 0/1
    metadata heuristic (see Expressions.xml's own comment on isMenuListing
    for what that heuristic already does and why it can misfire for some
    addons - e.g. correct on page 1, wrongly forced into poster view on page
    2 of the same addon, same content shape).

    Kodi's XML conditions cannot read a text file directly, so this one
    small bridge is unavoidable: read the file once here, store the result
    as a window property, and the condition checks the property instead.

    menulist_include.txt lives in script.nimbus.helper's own addon_data,
    not the skin folder - addon_data survives a skin (or helper) update,
    where anything under skin.nimbus/ itself would be wiped and replaced,
    silently destroying a builder's list on the next update.

    Not gated behind a "done" property like fix_initial_home_focus - this
    re-runs on every Home onload, so editing the file (by hand, or via
    manage_menu_listing_include() below) and reloading the skin picks the
    change up immediately rather than needing a full Kodi restart.
    """
    plugin_ids = _read_menu_listing_include()

    # Wrapped in a leading/trailing pipe (not just joined between entries) so
    # Expressions.xml's plain String.Contains() check - a substring test, not
    # an exact match - can't false-match a listed "plugin.video.foo" against
    # the unrelated, longer "plugin.video.foobar" simply because "foo" is a
    # literal substring of "foobar". Only protects that one direction (the
    # listed id being the shorter string) - Container.PluginName itself is
    # passed bare/unwrapped in the condition, since embedding it inside
    # $INFO[] there is what broke a much larger part of the skin last time
    # this was tried (see conversation) - not valid syntax for a boolean
    # expression argument, only for string-display contexts like <label>.
    value = "|" + "|".join(plugin_ids) + "|" if plugin_ids else ""
    xbmcgui.Window(10000).setProperty("NimbusMenuListingInclude", value)


def manage_menu_listing_include():
    """Skin settings > Customization > "Select Addons for List View Basic
    Artwork". Shows
    every installed plugin addon in a native multiselect dialog - checkboxes
    pre-ticked for whatever's already in menulist_include.txt, plain-text
    labels with any [COLOR]/[B]/[I]/etc. formatting an addon baked into its
    own name stripped out first (see _strip_label_formatting - otherwise an
    addon's own colored/bold name visually fights with the dialog's own
    selection-state color change, which is the whole point of a checkbox
    list). Writes the toggled selection straight back to
    menulist_include.txt, then refreshes NimbusMenuListingInclude
    immediately, so the change is live on the very next listing without
    waiting for a Home reload.
    """
    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.GetAddons",
        # xbmc.python.pluginsource covers plugin.video.*, plugin.audio.*,
        # plugin.image.*, and plugin.program.* alike - Kodi differentiates
        # them by the addon's own "provides" attribute, not a separate
        # extension point, so one query covers every plugin.* addon id a
        # builder would actually want to list here.
        "params": {
            "type": "xbmc.python.pluginsource",
            "enabled": True,
            "properties": ["name"],
        },
    })
    response = json.loads(xbmc.executeJSONRPC(request))
    addons = (response.get("result") or {}).get("addons") or []
    if not addons:
        xbmcgui.Dialog().notification("Nimbus", "No installed plugin addons found", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for a in addons:
        a["_plain_name"] = _strip_label_formatting(a.get("name") or a["addonid"])
    addons.sort(key=lambda a: a["_plain_name"].lower())

    addon_ids = [a["addonid"] for a in addons]
    labels = ["%s  [%s]" % (a["_plain_name"], a["addonid"]) for a in addons]

    current_ids = set(_read_menu_listing_include())
    preselect = [i for i, aid in enumerate(addon_ids) if aid in current_ids]

    chosen = xbmcgui.Dialog().multiselect("Select Addons for List View Basic Artwork", labels, preselect=preselect)
    if chosen is None:
        # Cancelled - leave the file exactly as it was.
        return

    new_ids = [addon_ids[i] for i in chosen]
    _write_menu_listing_include(new_ids)
    load_menu_listing_include()


def reset_stored_views():
    """Skin settings > Customization > "Reset Stored Views". Deletes Kodi's
    own per-path view-memory database (ViewModes*.db, under
    special://database/ - matched by pattern rather than today's exact
    filename, since the numeric suffix is a schema version Kodi has bumped
    before - ViewModes6.db as of v20/Nexus onward - and could again).

    This is NOT a Nimbus-specific reset, unlike everything else this skin
    tracks itself: ViewModes*.db is Kodi's own system-level database and
    remembers the view choice for every path ever browsed, across every
    skin ever used on this Kodi profile - not scoped to Nimbus at all.
    Nimbus's own equivalent (Skin.ForcedView.<content>) was fully removed
    in an earlier pass in favor of relying on this same native mechanism,
    so this is what's actually doing the remembering now.

    Confirmed by direct testing (Windows): the file deletes cleanly while
    Kodi is running, but is NOT recreated in the same session - Kodi only
    creates a fresh one on its own next launch. So a successful delete is
    followed immediately by Quit, rather than leaving Kodi running with no
    view-memory database at all until the user thinks to restart it
    themselves.
    """
    special_dir = "special://database/"
    real_dir = xbmcvfs.translatePath(special_dir)
    dirs, files = xbmcvfs.listdir(real_dir)
    targets = [f for f in files if f.lower().startswith("viewmodes") and f.lower().endswith(".db")]

    if not targets:
        xbmcgui.Dialog().ok("Nimbus", "No ViewModes*.db file found - nothing to reset.")
        return

    if not xbmcgui.Dialog().yesno("Nimbus", "Wipe viewmode*.db and exit Kodi?"):
        return

    failed = []
    for fname in targets:
        file_real_path = xbmcvfs.translatePath(special_dir + fname)
        if not xbmcvfs.delete(file_real_path):
            failed.append(fname)

    if failed:
        xbmcgui.Dialog().ok(
            "Nimbus",
            "Could not delete: %s\nKodi was not closed." % ", ".join(failed),
        )
        return

    xbmc.executebuiltin("Quit")


def show_changelog():
    helper_addon = xbmcaddon.Addon("script.nimbus.helper")
    helper_version = helper_addon.getAddonInfo("version")
    skin_addon = xbmcaddon.Addon("skin.nimbus")
    skin_version = skin_addon.getAddonInfo("version")
    skin_name = skin_addon.getAddonInfo("name")
    changelog_path = xbmcvfs.translatePath("special://skin/nimbuschangelog.txt")
    with xbmcvfs.File(changelog_path) as file:
        changelog_text = file.read()
    if isinstance(changelog_text, bytes):
        changelog_text = changelog_text.decode("utf-8")
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \d+\.\d+\.\d+)\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    changelog_text = re.sub(
        r"\[COLOR \w+\](Version \$INFO\[.*?\])\[/COLOR\]",
        r"[COLOR $VAR[MenuSelectorColor]]\1[/COLOR]",
        changelog_text,
    )
    helper_pattern = r"Nimbus Helper: Latest: v([\d.]+) \[B\]\|\[/B\] Installed: v.*"
    helper_match = re.search(helper_pattern, changelog_text)
    if helper_match:
        latest_helper_version = helper_match.group(1)
        installed_part = f"Installed: v{helper_version}"
        if helper_version != latest_helper_version:
            installed_part = f"[COLOR red][B]{installed_part}[/B][/COLOR]"
            update_message = (
                "\n\n[COLOR red][B]An update is available for the Nimbus Helper. "
                "Please follow these instructions to update and get the latest features and ensure full continued functionality:[/B][/COLOR]"
                "\n\n1. Go to Settings [B]»[/B] System [B]»[/B] Addons tab [B]»[/B] Manage dependencies"
                "\n2. Find Nimbus Helper and click it"
                "\n3. Versions [B]»[/B] Click the latest version in ivarbrandt's Repository"
            )
        else:
            update_message = "\n\n[COLOR limegreen][B]Nimbus Helper up to date. No updates needed at this time.[/B][/COLOR]"
        new_helper_info = f"Nimbus Helper: Latest: v{latest_helper_version} [B]|[/B] {installed_part}{update_message}"
        changelog_text = re.sub(
            helper_pattern, new_helper_info, changelog_text, count=1
        )
    header = f"CHANGELOG: {skin_name} v{skin_version}"
    xbmcgui.Dialog().textviewer(header, changelog_text)


def set_widget_count():
    if len(sys.argv) >= 3:
        list_id = sys.argv[2]
        if len(list_id) in (4, 5):
            container_id = (
                f"{list_id[:2]}001" if len(list_id) == 5 else f"{list_id[0]}001"
            )
            num_items_str = xbmc.getInfoLabel(f"Container({container_id}).NumItems")
            if num_items_str and num_items_str.isdigit():
                num_widgets = int(num_items_str) * 2 - 1
                xbmc.executebuiltin(f"Skin.SetString(TotalWidgetCount,{num_widgets})")


def reset_widget_position():
    """Send the widget row we have just left back to its first item.

    Called from the row's onunfocus, so this is about the row being LEFT, not
    the one being entered. That rules out SetFocus: the row no longer has focus,
    and focusing it would drag the user backwards onto it. Control.Move is the
    only builtin that repositions a container without touching focus.

    Control.Move is relative, and these are fixedlists, which WRAP - a blanket
    "move back a lot" does not clamp at item 1, it wraps round and lands on
    offset modulo row length, which is why every row ended up somewhere
    different. So the offset has to be exact, and since skins have no
    arithmetic, working it out is the whole reason this lives in the helper:
    read Container.CurrentItem, subtract one, move back by precisely that much.
    """
    if len(sys.argv) < 3:
        return
    list_id = sys.argv[2]
    if not list_id.isdigit():
        return

    current_item = xbmc.getInfoLabel("Container(%s).CurrentItem" % list_id)
    if not current_item.isdigit():
        return

    # CurrentItem is 1-based, so item 1 needs no move at all.
    offset = int(current_item) - 1
    if offset <= 0:
        return

    # onunfocus also fires for transitions that get cancelled or bounce straight
    # back. If this row is somehow focused again by the time we run, leave it
    # alone rather than yanking the position out from under the user.
    if xbmc.getCondVisibility("Control.HasFocus(%s)" % list_id):
        return

    xbmc.executebuiltin("Control.Move(%s,-%d)" % (list_id, offset))


def set_image(params=None):
    params = params or {}
    start_path = params.get("path") or xbmc.getInfoLabel("Skin.String(LastImagePath)") or "special://home/"

    image_file = xbmcgui.Dialog().browse(
        2,
        "Choose Custom Background Image",
        "files",
        ".jpg|.png|.bmp",
        False,
        False,
        start_path
    )
    if image_file:
        # Dialog().browse() returns whatever form the underlying OS file
        # picker uses - on Windows that's a raw C:\Users\... path, not a
        # special:// one. Convert it back to special:// (when the picked
        # file falls under one of Kodi's own special:// roots) before it
        # gets written into a skin string, so a settings.xml built on one
        # machine still resolves on another.
        image_file = path_utils.to_special_path(image_file)
        xbmc.executebuiltin(f"Skin.SetString(LastImagePath,{image_file})")
        xbmc.executebuiltin(f"Skin.SetString(NimbusCustomBackground,{image_file})")


def play_trailer():
    is_episode = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,episode)")
    is_season = xbmc.getCondVisibility("String.IsEqual(ListItem.DBType,season)")
    if xbmc.getCondVisibility("Control.IsVisible(500) | Control.IsVisible(501)"):
        xbmc.executebuiltin(
            "Notification(Trailer Playback, Trailer playback is not available in this view, 3000)"
        )
    elif not (is_episode or is_season):
        trailer_source = xbmc.getInfoLabel("Skin.String(TrailerSource)")
        play_url = None
        if trailer_source == "0":
            play_url = xbmc.getInfoLabel("ListItem.Trailer")
        elif trailer_source == "1":
            play_url = xbmc.getInfoLabel("Skin.String(TrailerPlaybackURL)")
        if play_url:
            xbmc.executebuiltin("Skin.SetString(TrailerPlaying, true)")
            if xbmc.getCondVisibility("Control.IsVisible(50) | Control.IsVisible(51)"):
                xbmc.executebuiltin(f"PlayMedia({play_url},0,noresume)")
            else:
                xbmc.executebuiltin(f"PlayMedia({play_url},1,noresume)")


def check_api_key(api_key):
    api_url = "https://mdblist.com/api/"
    params = {"apikey": api_key, "i": "tt0111161"}
    try:
        response = requests.get(api_url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        return ("valid", "ratings" in data and len(data["ratings"]) > 0)
    except requests.RequestException:
        return ("error", None)


def validate_api_key(api_key, silent=True):
    if not api_key:
        xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        return
    xbmc.executebuiltin("Skin.SetString(checking_api_key,true)")
    try:
        status, is_valid = check_api_key(api_key)
        if status == "valid" and is_valid:
            xbmc.executebuiltin("Skin.SetString(valid_api_key,true)")
            if not silent:
                xbmcgui.Dialog().notification("Success", "Features activated", xbmcgui.NOTIFICATION_INFO, 3000)
        elif status == "valid" and not is_valid:
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            if not silent:
                xbmcgui.Dialog().notification("Connection Error", "Unable to reach MDbList", xbmcgui.NOTIFICATION_INFO, 3000)
    finally:
        xbmc.executebuiltin("Skin.Reset(checking_api_key)")


def set_api_key():
    current_key = xbmc.getInfoLabel("Skin.String(mdblist_api_key)")
    keyboard = xbmc.Keyboard(current_key, "Enter MDbList API Key")
    keyboard.doModal()
    if keyboard.isConfirmed():
        new_key = keyboard.getText()
        if not new_key:
            xbmc.executebuiltin("Skin.Reset(mdblist_api_key)")
            xbmc.executebuiltin("Skin.Reset(valid_api_key)")
        else:
            xbmc.executebuiltin(f'Skin.SetString(mdblist_api_key,"{new_key}")')
            validate_api_key(new_key, silent=False)


def check_api_key_on_load():
    validate_api_key(xbmc.getInfoLabel("Skin.String(mdblist_api_key)"), silent=True)


def fix_black_screen():
    if xbmc.getCondVisibility("Skin.HasSetting(TrailerPlaying)"):
        xbmc.executebuiltin("Skin.Reset(TrailerPlaying)")


def set_blurradius():
    current_value = xbmc.getInfoLabel("Skin.String(BlurRadius)") or "30"
    value = xbmcgui.Dialog().numeric(0, "Enter blur radius value", current_value)
    if value == "":
        value = "30"
    xbmc.executebuiltin(f"Skin.SetString(BlurRadius,{value})")


def set_blursaturation():
    current_value = xbmc.getInfoLabel("Skin.String(BlurSaturation)") or "1.5"
    keyboard = xbmc.Keyboard(current_value, "Enter blur saturation value")
    keyboard.doModal()
    if keyboard.isConfirmed():
        text = keyboard.getText() or "1.5"
        xbmc.executebuiltin(f"Skin.SetString(BlurSaturation,{text})")


def set_autoendplaybackdelay():
    current_value = xbmc.getInfoLabel("Skin.String(PlaybackDelayMins)") or "30"
    value_mins = xbmcgui.Dialog().numeric(0, "Enter delay in minutes", current_value)
    if value_mins == "":
        value_mins, value_secs = "30", 1800
    else:
        value_secs = int(value_mins) * 60
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelayMins,{value_mins})")
    xbmc.executebuiltin(f"Skin.SetString(PlaybackDelaySecs,{value_secs})")


def make_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if not xbmcvfs.exists(backup_path):
        xbmcvfs.copy(keymap_path, backup_path)


def restore_from_backup(keymap_path):
    backup_path = f"{keymap_path}.backup"
    if xbmcvfs.exists(backup_path):
        xbmcvfs.delete(keymap_path)
        xbmcvfs.rename(backup_path, keymap_path)


def get_all_existing_keymap_paths():
    paths = []
    for name in POSSIBLE_KEYMAP_NAMES:
        p = xbmcvfs.translatePath(f"special://profile/keymaps/{name}")
        if xbmcvfs.exists(p):
            paths.append(p)
    return paths


def create_new_keymap_file():
    new_path = xbmcvfs.translatePath(f"{KEYMAP_LOCATION}gen.xml")
    ET.ElementTree(ET.Element("keymap")).write(new_path)
    return new_path


class KeyListener(xbmcgui.WindowXMLDialog):
    TIMEOUT = 7

    def __new__(cls):
        return super(KeyListener, cls).__new__(
            cls, "DialogNotification.xml", xbmcaddon.Addon().getAddonInfo("path")
        )

    def __init__(self):
        self.key = None

    def onInit(self):
        self.getControl(401).setLabel("Starting key listener...")
        self.getControl(402).setLabel("Be ready to press key")
        xbmc.sleep(2000)
        countdown_start = self.TIMEOUT - 2
        self.getControl(401).setLabel("Listening for key press...")
        self.getControl(402).setLabel(f"Timeout in {countdown_start} seconds")
        for i in range(countdown_start, 1, -1):
            self.getControl(402).setLabel(f"Timeout in {i} seconds")
            xbmc.sleep(1000)
        self.getControl(402).setLabel("Timeout in 1 second")
        xbmc.sleep(1000)
        self.close()

    def onAction(self, action):
        button_code = action.getButtonCode()
        action_id = action.getId()
        self.key = button_code if button_code != 0 else action_id
        self.getControl(401).setLabel("Key captured successfully!")
        self.getControl(402).setLabel(f"Captured key code: {self.key}")
        xbmc.sleep(2000)
        self.close()

    @staticmethod
    def record_key():
        dlg = KeyListener()
        timeout = Timer(KeyListener.TIMEOUT, dlg.close)
        timeout.start()
        dlg.doModal()
        timeout.cancel()
        key = dlg.key
        del dlg
        return key


def capture_user_key():
    listener = KeyListener()
    captured_key = listener.record_key()
    if captured_key:
        xbmc.executebuiltin(f"Skin.SetString(CapturedKeyCode, {captured_key})")
    del listener
    return captured_key


def modify_keymap():
    keymap_paths = get_all_existing_keymap_paths() or [create_new_keymap_file()]
    captured_key = xbmc.getInfoLabel("Skin.String(CapturedKeyCode)")
    if not captured_key:
        return
    setting_value = xbmc.getInfoLabel("Skin.String(trailerSetting)")
    for keymap_path in keymap_paths:
        if setting_value == "1":
            make_backup(keymap_path)
            tree = ET.parse(keymap_path)
            root = tree.getroot()
            found = False
            for key_tag in root.findall(".//key"):
                if key_tag.text == "RunScript(script.nimbus.helper, mode=play_trailer)":
                    key_tag.set("id", captured_key)
                    found = True
                    break
            if not found:
                global_tag = root.find("global") or ET.SubElement(root, "global")
                keyboard_tag = global_tag.find("keyboard") or ET.SubElement(global_tag, "keyboard")
                ET.SubElement(keyboard_tag, "key", id=captured_key).text = "RunScript(script.nimbus.helper, mode=play_trailer)"
            pretty_xml = minidom.parseString(ET.tostring(root, "utf-8")).toprettyxml(indent="  ")
            with xbmcvfs.File(keymap_path, "w") as xml_file:
                xml_file.write("\n".join([line for line in pretty_xml.split("\n") if line.strip()]))
        else:
            restore_from_backup(keymap_path)
    xbmc.executebuiltin("Action(reloadkeymaps)")


# -------- Submenu manager --------

WINDOW_TARGETS = [("Video Addons", "Videos"), ("Music Addons", "Music"), ("Picture Addons", "Pictures"), ("Program Addons", "Programs")]

WINDOW_DEFAULT_PATHS = {
    "Videos": "addons://sources/video",
    "Music": "addons://sources/audio",
    "Pictures": "addons://sources/image",
    "Programs": "addons://sources/executable",
}

KODI_COMMANDS = [
    ("Addon Browser", "ActivateWindow(AddonBrowser)"),
    ("File Manager", "ActivateWindow(FileManager)"),
    ("Favourites", "ActivateWindow(Favourites)"),
    ("Weather", "ActivateWindow(Weather)"),
    ("Settings", "ActivateWindow(Settings)"),
    ("Reboot", "Reboot"),
    ("Shutdown", "ShutDown"),
    ("Hibernate", "Hibernate"),
    ("Suspend", "Suspend"),
    ("Quit Kodi", "Quit"),
    ("Activate Screensaver", "ActivateScreensaver"),
    ("Update Video Library", "UpdateLibrary(video)"),
    ("Update Music Library", "UpdateLibrary(music)"),
    ("Clean Video Library", "CleanLibrary(video)"),
    ("Clean Music Library", "CleanLibrary(music)"),
    ("Toggle Fullscreen", "Action(FullScreen)"),
    ("Mute", "Mute"),
]

# (display_label, ActivateWindow target, browse root) -- these reuse the
# existing addon-source browser, just rooted at the local library instead
# of addons://sources/... .
LIBRARY_TARGETS = [
    ("Video Library", "Videos", "videodb://"),
    ("Music Library", "Music", "musicdb://"),
]

LIVE_TV_COMMANDS = [
    ("TV Channels", "ActivateWindow(TVChannels)"),
    ("TV Guide", "ActivateWindow(TVGuide)"),
    ("TV Recordings", "ActivateWindow(TVRecordings)"),
    ("TV Timers", "ActivateWindow(TVTimers)"),
    ("Radio Channels", "ActivateWindow(RadioChannels)"),
    ("Radio Guide", "ActivateWindow(RadioGuide)"),
]


def _sanitize_skin_string(value):
    return (value or "").strip()


def _normalize_plugin_path(path):
    p = (path or "").strip()
    if p.startswith(("plugin.video.", "plugin.audio.", "plugin.image.", "plugin.program.")):
        p = f"plugin://{p}"
    elif p.startswith("plugin:/") and not p.startswith("plugin://"):
        p = p.replace("plugin:/", "plugin://", 1)
    return p


def _default_path_for_window(window_target):
    return WINDOW_DEFAULT_PATHS.get(window_target, DEFAULT_PATH)


def _set_submenu_item(menu_id, slot, label, action):
    safe_label = _sanitize_skin_string(label).replace('"', '\\"')
    safe_action = _sanitize_skin_string(action).replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.label,"{safe_label}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.action,"{safe_action}")')


def _set_submenu_target(menu_id, slot, window_target, target_path):
    wt = (window_target or "").replace('"', '\\"')
    tp = (target_path or "").replace('"', '\\"')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.window,"{wt}")')
    xbmc.executebuiltin(f'Skin.SetString(Submenu.{menu_id}.{slot}.target,"{tp}")')


def _clear_submenu_item(menu_id, slot):
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.label)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.action)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.window)")
    xbmc.executebuiltin(f"Skin.Reset(Submenu.{menu_id}.{slot}.target)")


def _clear_all_submenu_items(menu_id, max_items=50):
    """
    Clear every populated slot for this menu.

    Only slots that actually hold something are cleared. Each
    _clear_submenu_item() fires 4 xbmc.executebuiltin() calls, and those are
    queued onto Kodi's application message thread rather than run inline - so
    clearing blindly meant 22 menus x 50 slots x 4 = 4,400 queued builtins on
    a full reset, nearly all of them resetting strings that were never set.
    That flood is slow on any box and risks stalling weaker hardware.

    getInfoLabel() is a direct read, so probing first is far cheaper than
    clearing unconditionally: a fresh install now issues zero builtins here
    instead of 4,400.
    """
    for i in range(1, max_items + 1):
        if (xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.action)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
                or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.window)")):
            _clear_submenu_item(menu_id, i)


def _read_submenu_slot(menu_id, slot):
    """Read all four strings that make up one submenu item."""
    return {
        key: xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.{key})")
        for key in ("label", "action", "window", "target")
    }


def _write_submenu_slot(menu_id, slot, data):
    if not (data.get("action") or data.get("target")):
        _clear_submenu_item(menu_id, slot)
        return
    _set_submenu_item(menu_id, slot, data.get("label", ""), data.get("action", ""))
    _set_submenu_target(menu_id, slot, data.get("window", ""), data.get("target", ""))


def _occupied_submenu_slots(menu_id, max_items=50):
    return [
        i
        for i in range(1, max_items + 1)
        if xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.action)")
        or xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
    ]


def _compact_submenu_slots(menu_id, max_items=50):
    """Close gaps in the slot numbering after a submenu item is removed.

    Mirrors CPaths.compact_widget_slots()'s own reasoning exactly (see that
    function's docstring in cpath_maker.py): the submenu manager lists all
    slots by number, and Move up/Move down walk the OCCUPIED slots (one
    press = one visible row), so a gap left by a removed item made moving
    an item past that gap look like it was skipping or failing. Renumbering
    on delete keeps slot order and display order the same thing, the same
    fix applied to widgets.

    Ascending order is safe here too: every occupied slot's data is read
    before it's ever written to as a lower-numbered target in a later
    iteration, so nothing is overwritten before it's been copied forward.
    """
    keys = _occupied_submenu_slots(menu_id, max_items)
    if keys == list(range(1, len(keys) + 1)):
        return

    for new, old in enumerate(keys, 1):
        if new == old:
            continue
        data = _read_submenu_slot(menu_id, old)
        _write_submenu_slot(menu_id, new, data)

    # Compacting frees the slots above the new count - clear them, or the
    # next item added there silently inherits data left over from a slot
    # that no longer exists.
    for stale in range(len(keys) + 1, max(keys) + 1):
        _clear_submenu_item(menu_id, stale)

    # All of the above are Skin.SetString()/Skin.Reset() builtins, queued
    # onto Kodi's message thread rather than applied inline - a caller that
    # reads submenu state (or re-renders a slot list) immediately after this
    # returns could otherwise still see the pre-compaction values.
    xbmc.sleep(100)


def _move_submenu_item(menu_id, slot, direction, max_items=50):
    """Swap a submenu item with its nearest occupied neighbour.

    Deliberately not a plain slot +-1 swap. Slots are sparse - remove item 3
    of 5 and you are left with 1, 2, 4, 5 - so stepping by one slot number
    would swap an item into a hole and change nothing on screen, which reads
    as "move up is broken". Stepping through the occupied slots instead
    means one press always moves the item exactly one visible row.

    Returns the slot the item now occupies, or None if nothing moved.
    """
    occupied = _occupied_submenu_slots(menu_id, max_items)
    if slot not in occupied:
        return None
    index = occupied.index(slot)
    new_index = index - 1 if direction == "up" else index + 1
    if new_index < 0 or new_index >= len(occupied):
        dialog.notification(
            "Nimbus",
            "Already at the %s" % ("top" if direction == "up" else "bottom"),
            xbmcgui.NOTIFICATION_INFO,
            1500,
        )
        return None

    other = occupied[new_index]
    this_item = _read_submenu_slot(menu_id, slot)
    other_item = _read_submenu_slot(menu_id, other)
    _write_submenu_slot(menu_id, slot, other_item)
    _write_submenu_slot(menu_id, other, this_item)
    # Skin.SetString/Reset are queued onto Kodi's application message thread,
    # so the slot list has to wait for them before it re-reads - otherwise
    # the move looks like it did nothing until you back out and return.
    xbmc.sleep(150)
    return other


def _choose_slot(menu_id, title="Choose submenu slot", max_items=50):
    items = []
    for i in range(1, max_items + 1):
        label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
        target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
        text = f"{i}. {label}" if target else f"{i}. [Empty]"
        items.append(xbmcgui.ListItem(text, target if target else ""))
    idx = dialog.select(title, items, useDetails=True)
    return None if idx == -1 else idx + 1
    
ALL_SUBMENU_IDS = [
    "movies", "tvshows",
    "custom1", "custom2", "custom3", "custom4", "custom5",
    "custom6", "custom7", "custom8", "custom9", "custom10",
    "music", "musicvideos", "livetv", "radio", "addons",
    "pictures", "video", "games", "favorites", "weather",
]

FAVOURITES_PATH = "special://profile/favourites.xml"


def sanitize_favourites_file():
    """Cleans embedded drive-letter paths out of Kodi's own native
    Favourites file.

    This is a genuinely different system from everything else this fix
    touches: "Add to Favourites" is a built-in Kodi feature - Kodi's own
    core writes special://profile/favourites.xml directly when the user
    picks it from a context menu. No Nimbus code is in that path at all;
    Home's Favourites panel only reads it back via <content>favourites://
    </content>. But the same root cause still applies: whatever addon
    supplied the favourited item's thumbnail can hand Kodi a raw OS path
    instead of a portable one (confirmed case: mp3streams and thechains
    both do this for their own menu items - see path_utils.py), and Kodi
    writes that thumb value into favourites.xml exactly as given. That
    file travels with an exported/packaged build the same as everything
    else here, so it has the identical PC-built/Android-broken symptom -
    just via a path this fix didn't originally cover.

    Cleans both the thumb= attribute and each favourite's own action
    text, since the action can itself be a plugin:// URL with the same
    kind of addon-embedded path (see _build_submenu_action_from_path for
    the identical pattern in Nimbus's own submenu targets). Only writes
    the file back if something actually changed. Silently does nothing
    if the file doesn't exist yet, is empty, or fails to parse as XML -
    this is Kodi's own file, not Nimbus's, so an unexpected shape is a
    reason to leave it alone rather than guess.
    """
    path = xbmcvfs.translatePath(FAVOURITES_PATH)
    if not xbmcvfs.exists(path):
        return

    f = xbmcvfs.File(path, "r")
    try:
        raw = f.readBytes()
    finally:
        f.close()
    if not raw or not raw.strip():
        return

    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return

    changed = False
    for fav in root.findall("favourite"):
        thumb = fav.get("thumb")
        if thumb:
            cleaned_thumb = path_utils.sanitize_embedded_paths(thumb)
            if cleaned_thumb != thumb:
                fav.set("thumb", cleaned_thumb)
                changed = True
        if fav.text:
            cleaned_text = path_utils.sanitize_embedded_paths(fav.text)
            if cleaned_text != fav.text:
                fav.text = cleaned_text
                changed = True

    if not changed:
        return

    new_bytes = (
        b'<?xml version="1.0" encoding="utf-8" standalone="yes" ?>\n'
        + ET.tostring(root, encoding="utf-8")
    )
    f = xbmcvfs.File(path, "w")
    try:
        f.write(new_bytes)
    finally:
        f.close()


def sanitize_all_submenu_paths():
    """Rewrites any embedded drive-letter path in every occupied submenu
    slot's action/target strings through path_utils.sanitize_embedded_paths().
    Submenus have no database backing (see reset_all_submenus above) - they
    live purely as Skin.String values - so they're outside cpath_maker's
    database-driven remake_all_cpaths() sweep entirely and need this
    separate pass. Only writes a slot back if something actually changed.
    """
    for menu_id in ALL_SUBMENU_IDS:
        for slot in _occupied_submenu_slots(menu_id):
            data = _read_submenu_slot(menu_id, slot)
            cleaned_action = path_utils.sanitize_embedded_paths(data.get("action", ""))
            cleaned_target = path_utils.sanitize_embedded_paths(data.get("target", ""))
            if cleaned_action != data.get("action", "") or cleaned_target != data.get("target", ""):
                data["action"] = cleaned_action
                data["target"] = cleaned_target
                _write_submenu_slot(menu_id, slot, data)


def reset_all_submenus():
    """
    Clears every submenu slot for every menu that supports submenus.
    No defaults are re-seeded - every menu is simply left empty after
    clearing.
    """
    for menu_id in ALL_SUBMENU_IDS:
        _clear_all_submenu_items(menu_id)


def _input_label(default_text):
    kb = xbmc.Keyboard(default_text or "", "Set submenu label")
    kb.doModal()
    if not kb.isConfirmed():
        return None
    t = kb.getText().strip()
    return t if t else None


def _files_get_directory(directory, properties=None):
    properties = properties or ["title", "file", "thumbnail"]
    command = {
        "jsonrpc": "2.0",
        "id": "script.nimbus.helper",
        "method": "Files.GetDirectory",
        "params": {"directory": directory, "media": "files", "properties": properties},
    }
    response = xbmc.executeJSONRPC(json.dumps(command))
    result = json.loads(response).get("result", {})
    files = result.get("files", [])
    # This was originally written for addons:// browsing, where every
    # real entry is a plugin:// path - fine there, but it silently
    # filtered out EVERYTHING when browsing the Video/Music Library
    # (videodb:// / musicdb://), since those entries never start with
    # plugin://. That left the picker with zero items, which returned
    # {} with no dialog shown at all, so creating a submenu item from
    # Video/Music Library silently did nothing.
    browsable_schemes = ("plugin://", "videodb://", "musicdb://")
    return [i for i in files if i.get("file", "").startswith(browsable_schemes) and i.get("filetype") == "directory"]


def _strip_formatting(label):
    if not label:
        return ""
    s = label.replace("[B]", "").replace("[/B]", "")
    while "[COLOR" in s:
        start = s.find("[COLOR")
        end = s.find("]", start) + 1
        s = s[:start] + s[end:]
    return s.replace("[/COLOR]", "")


def _choose_window_target():
    options = (
        [i[0] for i in WINDOW_TARGETS]
        + ["Kodi Commands"]
        + [i[0] for i in LIBRARY_TARGETS]
        + ["Live TV / PVR"]
    )
    idx = dialog.select("Choose target type", options)
    if idx == -1:
        return None

    if idx < len(WINDOW_TARGETS):
        return WINDOW_TARGETS[idx][1]
    idx -= len(WINDOW_TARGETS)

    if idx == 0:
        return "__KODI_COMMANDS__"
    idx -= 1

    if idx < len(LIBRARY_TARGETS):
        return f"__LIBRARY__{idx}"

    return "__LIVE_TV__"


def _submenu_path_browser(label="", file=DEFAULT_PATH, thumbnail="", window_target="Videos", start_root=None, parent_history=None):
    if parent_history is None:
        parent_history = []
    file = resolve_addon_root(file)
    root = start_root or DEFAULT_PATH
    label_clean = _strip_formatting(label)
    results = _files_get_directory(file)
    items = []

    # ".. (Back)" - only once we're at least one level deep, matching a
    # normal file browser: Cancel at the very top still just cancels the
    # whole flow (nowhere within this recursion to go up to), but Cancel
    # at any deeper level used to cancel EVERYTHING too - this gives an
    # actual way to step back up one directory instead of losing the
    # whole browse.
    if parent_history:
        back_li = Listitem("[B].. (Back)[/B]", "Go up one directory", offscreen=True)
        back_li.setProperty("go_up", "true")
        items.append(back_li)

    if file != root:
        use_li = Listitem(
            f"Use [B]{label_clean}[/B] as menu item target",
            f"Set as target ({window_target})",
            offscreen=True
        )
        use_li.setArt({"icon": thumbnail})
        use_li.setProperty("item", json.dumps({
            "label": label_clean,
            "file": file,
            "thumbnail": thumbnail,
            "window_target": window_target,
            "is_final": True
        }))
        items.append(use_li)

    for i in results:
        stripped_label = _strip_formatting(i.get("label", ""))
        li = Listitem(f"{stripped_label} »", "Browse path...", offscreen=True)
        li.setArt({"icon": i.get("thumbnail", "")})
        li.setProperty("item", json.dumps({
            "label": i.get("label", ""),
            "file": i.get("file", ""),
            "thumbnail": i.get("thumbnail", ""),
            "window_target": window_target,
            "is_final": False
        }))
        items.append(li)

    if not items or (len(items) == 1 and parent_history):
        # Not a bug - this genuinely happens when the chosen source
        # (most commonly Video/Music Library) has nothing scanned
        # into it yet. Confirmed via diagnostic logging:
        # Files.GetDirectory("videodb://") returns a literal empty
        # file list on an empty library, not even the static
        # Movies/TV Shows category folders. Silently returning here
        # looked identical to a real failure, so tell the user why.
        dialog.ok("Nimbus", f"No items found in {window_target}. If you "
                             "picked Video or Music Library, make sure it "
                             "has content scanned into it first.")
        return {}

    choice = dialog.select("Choose path", items, useDetails=True)
    if choice == -1:
        return {}

    if items[choice].getProperty("go_up") == "true":
        previous = parent_history[-1]
        return _submenu_path_browser(
            label=previous["label"],
            file=previous["file"],
            thumbnail=previous["thumbnail"],
            window_target=window_target,
            start_root=root,
            parent_history=parent_history[:-1],
        )

    chosen = json.loads(items[choice].getProperty("item"))
    if chosen.get("is_final") or chosen["file"] == file:
        return chosen

    return _submenu_path_browser(
        label=chosen.get("label", ""),
        file=chosen.get("file", ""),
        thumbnail=chosen.get("thumbnail", ""),
        window_target=window_target,
        start_root=root,
        parent_history=parent_history + [
            {"label": label, "file": file, "thumbnail": thumbnail}
        ],
    )


def _build_submenu_action_from_path(path, window_target):
    p = _normalize_plugin_path(path)
    # Some third-party addons (confirmed: thechains, mp3streams) embed
    # their own local icon/fanart path as a query param inside the
    # plugin:// URL their own directory listing returns - not something
    # Nimbus put there, but once captured verbatim it's stored the same
    # way, and ships just as broken to another machine. Clean those up
    # here too, at the one place every submenu target action gets built,
    # rather than trying to catch it at every capture site.
    p = path_utils.sanitize_embedded_paths(p)
    # Quoted, matching exactly what Kodi itself writes into favourites.xml
    # for the same ActivateWindow call - confirmed by direct side-by-side
    # testing to behave differently on Back for at least one real addon
    # (madtitansports) versus the previously-unquoted path, even though
    # both parse to the same forward destination. Escaped in case a path
    # happens to contain a literal " itself.
    quoted_p = '"%s"' % p.replace('"', '\\"')
    return f"ActivateWindow({window_target},{quoted_p},return)"


def _set_or_edit_slot_from_kodi_command(menu_id, slot):
    idx = dialog.select("Choose a Kodi command", [c[0] for c in KODI_COMMANDS])
    if idx == -1:
        return

    command_label, action = KODI_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    # No real browsable path exists for these -> store the action itself
    # as the "target" so slot-occupied checks elsewhere still work.
    _set_submenu_target(menu_id, slot, "System", action)

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_live_tv(menu_id, slot):
    idx = dialog.select("Choose a Live TV / PVR destination", [c[0] for c in LIVE_TV_COMMANDS])
    if idx == -1:
        return

    command_label, action = LIVE_TV_COMMANDS[idx]
    label = _input_label(command_label)
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, "System", action)

    dialog.notification("Nimbus", f"Saved command in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_manual_entry(menu_id, slot):
    kb = xbmc.Keyboard("", "Enter the full action (e.g. PlayMedia(...) or ActivateWindow(...))")
    kb.doModal()
    if not kb.isConfirmed():
        return
    action = kb.getText().strip()
    if not action:
        return
    # A pasted Kodi favourite's action comes straight out of an XML file's
    # element text, where a literal & is written as &amp; (and < / >
    # likewise) - that escaping only ever made sense for the XML parser
    # that read it there. _set_submenu_item/_set_submenu_target below store
    # this value via a direct Skin.SetString() builtin call, never through
    # any XML parser, so &amp; would otherwise reach Kodi's plugin URL
    # parser completely literally - which splits query-string parameters
    # on a real &, not the four-character text "&amp;" - silently merging
    # every parameter after the first into one. Undo it here, once, before
    # anything else touches the string.
    action = xml_unescape(action)
    # Sanitized the same as any other captured path, in case a pasted
    # favourite action happens to embed a device-specific absolute path.
    action = path_utils.sanitize_embedded_paths(action)

    label = _input_label("New Item")
    if label is None:
        return

    _set_submenu_item(menu_id, slot, label, action)
    # No real browsable path exists for a raw manual action - store the
    # action itself as the "target", matching the Kodi Commands/Live TV
    # pattern, so slot-occupied checks elsewhere still work.
    _set_submenu_target(menu_id, slot, "System", action)

    dialog.notification("Nimbus", f"Saved submenu item in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def _set_or_edit_slot_from_browser(menu_id, slot):
    # A level above _choose_window_target's own list (which mixes Videos/
    # Music/etc, Kodi Commands, Library targets, and Live TV all together) -
    # "Browse for a target" leads into that exact, unchanged flow; "Enter
    # Manually" bypasses it entirely for a raw, user-supplied action.
    entry_choice = dialog.select("Set submenu target", ["Browse for a target", "Enter Manually"])
    if entry_choice == -1:
        return
    if entry_choice == 1:
        _set_or_edit_slot_from_manual_entry(menu_id, slot)
        return

    window_target = _choose_window_target()
    if not window_target:
        return

    if window_target == "__KODI_COMMANDS__":
        _set_or_edit_slot_from_kodi_command(menu_id, slot)
        return

    if window_target == "__LIVE_TV__":
        _set_or_edit_slot_from_live_tv(menu_id, slot)
        return

    if window_target.startswith("__LIBRARY__"):
        lib_idx = int(window_target.replace("__LIBRARY__", ""))
        _, real_window_target, start_path = LIBRARY_TARGETS[lib_idx]
        window_target = real_window_target
    else:
        start_path = _default_path_for_window(window_target)

    result = _submenu_path_browser(file=start_path, window_target=window_target, start_root=start_path)
    if not result:
        return

    target_path = _normalize_plugin_path(result.get("file"))
    if not target_path:
        return
    # .action and .target are two SEPARATE stored skin strings for the same
    # path (see _write_submenu_slot). Sanitizing target_path here, before
    # either one is derived/stored, is what keeps them in sync - previously
    # only _build_submenu_action_from_path's own copy got cleaned, so a
    # brand new item came out with a clean .action but a still-dirty
    # .target, only fixed later by the next sanitize_all_submenu_paths()
    # sweep rather than at creation time.
    target_path = path_utils.sanitize_embedded_paths(target_path)

    default_label = _strip_formatting(result.get("label", "")) or "New Item"
    label = _input_label(default_label)
    if label is None:
        return

    action = _build_submenu_action_from_path(target_path, window_target)
    _set_submenu_item(menu_id, slot, label, action)
    _set_submenu_target(menu_id, slot, window_target, target_path)

    dialog.notification("Nimbus", f"Saved submenu item in slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)


def manage_submenu_items(menu_id, max_items=50):
    """
    Submenu manager UX: shows the list of slots first (each labelled with
    its current content, or [Empty]). Picking an empty slot goes straight
    into browse+label; picking a filled slot offers change/rename/remove
    for that one slot. Loops back to the slot list after every action,
    so repeat edits don't require re-opening the manager. A trailing
    "Clear all" entry handles the one action that isn't slot-specific.

    Storage/generation is unchanged from before - this only replaces the
    old "what do you want to do first" menu.
    """
    if not menu_id:
        dialog.ok("Nimbus", "Missing menu id")
        return

    while True:
        items = []
        for i in range(1, max_items + 1):
            label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.label)")
            target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{i}.target)")
            text = f"{i}. {label}" if target else f"{i}. [Empty]"
            items.append(xbmcgui.ListItem(text, target if target else ""))
        clear_all_item = xbmcgui.ListItem("Clear all submenu items", "")
        items.append(clear_all_item)

        # A pause before showing the list, not just after an action changes
        # it: DialogSelect appears to sometimes redraw a row with its
        # previous content for a moment when re-shown immediately within
        # the same script session (confirmed on a real device - the
        # underlying Skin.String data was already correct at that point,
        # since backing all the way out and back in showed it correctly;
        # only the just-redisplayed dialog's own rows were stale). Applied
        # here rather than after each individual action, so it covers every
        # action uniformly instead of chasing this one at a time.
        #
        # 100ms wasn't reliably enough on a real device - still intermittent.
        # Bumped to 250ms as a middle ground: still noticeably lower than
        # human reaction time between actions (so it shouldn't read as
        # sluggish), but this remains a best-effort mitigation for a Kodi
        # dialog-redraw timing behavior outside direct control, not a
        # guaranteed fix - it may still show up occasionally.
        xbmc.sleep(250)
        idx = dialog.select(f"Submenu Items ({menu_id})", items, useDetails=True)
        if idx == -1:
            return

        if idx == max_items:
            if dialog.yesno("Nimbus", f"Clear all submenu items for '{menu_id}'?"):
                _clear_all_submenu_items(menu_id)
                xbmc.sleep(100)
                dialog.notification("Nimbus", f"Cleared all submenu items for {menu_id}", xbmcgui.NOTIFICATION_INFO, 2500)
            continue

        slot = idx + 1
        current_target = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.target)")

        if not current_target:
            # Empty slot: go straight into browsing + labeling.
            _set_or_edit_slot_from_browser(menu_id, slot)
            xbmc.sleep(100)
            continue

        # Filled slot: offer per-slot actions.
        slot_actions = [
            ("Move up", "move_up"),
            ("Move down", "move_down"),
            ("Change target (browse)", "change"),
            ("Change target (manual)", "change_manual"),
            ("Rename", "rename"),
            ("Remove", "remove"),
        ]
        current_label = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.label)")
        slot_choice = dialog.select(
            current_label or f"Slot {slot}",
            [i[0] for i in slot_actions],
        )
        if slot_choice == -1:
            continue
        slot_action = slot_actions[slot_choice][1]

        if slot_action in ("move_up", "move_down"):
            _move_submenu_item(
                menu_id, slot, "up" if slot_action == "move_up" else "down", max_items
            )

        elif slot_action == "change":
            _set_or_edit_slot_from_browser(menu_id, slot)
            xbmc.sleep(100)

        elif slot_action == "change_manual":
            _set_or_edit_slot_from_manual_entry(menu_id, slot)
            xbmc.sleep(100)

        elif slot_action == "rename":
            new_label = _input_label(current_label)
            if new_label is None:
                continue
            current_action = xbmc.getInfoLabel(f"Skin.String(Submenu.{menu_id}.{slot}.action)")
            _set_submenu_item(menu_id, slot, new_label, current_action)
            xbmc.sleep(100)
            dialog.notification("Nimbus", f"Renamed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

        elif slot_action == "remove":
            if dialog.yesno("Nimbus", f"Remove submenu item in slot {slot}?"):
                _clear_submenu_item(menu_id, slot)
                # _clear_submenu_item fires 4 Skin.Reset() builtins, queued
                # onto Kodi's message thread rather than applied inline (see
                # _clear_all_submenu_items' docstring). Without this pause,
                # _compact_submenu_slots' own occupied-slots check can run
                # before that reset has actually taken effect, still see
                # this slot as occupied, and conclude there's nothing to
                # compact - the gap this was supposed to close stays empty.
                xbmc.sleep(100)
                _compact_submenu_slots(menu_id)
                dialog.notification("Nimbus", f"Removed slot {slot}", xbmcgui.NOTIFICATION_INFO, 2000)

def apply_splash_setting():
    """
    Reads the skin's disable.splashscreen toggle and adds/removes the
    <splash>false</splash> line in special://userdata/advancedsettings.xml
    accordingly, preserving any other existing advancedsettings content.
    Requires a full Kodi restart to actually take effect, since the
    splash screen shows before the skin/Python ever run.
    """
    import xbmcvfs
    import xml.etree.ElementTree as ET

    disable_splash = xbmc.getCondVisibility("Skin.HasSetting(disable.splashscreen)")
    path = xbmcvfs.translatePath("special://userdata/advancedsettings.xml")

    if xbmcvfs.exists(path):
        try:
            tree = ET.parse(path)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element("advancedsettings")
            tree = ET.ElementTree(root)
    else:
        root = ET.Element("advancedsettings")
        tree = ET.ElementTree(root)

    splash_el = root.find("splash")

    if disable_splash:
        if splash_el is None:
            splash_el = ET.SubElement(root, "splash")
        splash_el.text = "false"
    else:
        if splash_el is not None:
            root.remove(splash_el)

    tree.write(path, encoding="UTF-8", xml_declaration=True)

    dialog.notification(
        "Nimbus",
        "Splash screen disabled - restart Kodi to apply"
        if disable_splash
        else "Splash screen enabled - restart Kodi to apply",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )

def apply_disable_background_playback_setting():
    """
    Adds or removes a dedicated keymap file that makes Back (keyboard
    Backspace, id 61448) stop playback instead of leaving it running
    in the background, while fullscreen video is playing.
    """
    import xbmcvfs

    enabled = xbmc.getCondVisibility("Skin.HasSetting(disable.backgroundplayback)")
    keymap_dir = xbmcvfs.translatePath("special://userdata/keymaps/")
    keymap_path = keymap_dir + "nimbus_back_stops_playback.xml"

    if enabled:
        if not xbmcvfs.exists(keymap_dir):
            xbmcvfs.mkdirs(keymap_dir)
        with xbmcvfs.File(keymap_path, "w") as f:
            f.write(
                '<keymap><fullscreenvideo><keyboard><key id="61448">stop</key>'
                "</keyboard></fullscreenvideo></keymap>"
            )
    else:
        if xbmcvfs.exists(keymap_path):
            xbmcvfs.delete(keymap_path)

    xbmc.executebuiltin("Action(reloadkeymaps)")

    dialog.notification(
        "Nimbus",
        "Background playback disabled" if enabled else "Background playback re-enabled",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )