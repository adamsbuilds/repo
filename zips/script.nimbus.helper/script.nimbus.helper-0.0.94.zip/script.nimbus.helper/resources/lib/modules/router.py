# -*- coding: utf-8 -*-
import sys
from urllib.parse import parse_qsl

# from modules.logger import logger


def routing():
    # RunScript(addon,arg) hands us everything after the addon id as a
    # single logical string, but on this build it sometimes lands split
    # across sys.argv[1:] instead of staying in sys.argv[1] alone once a
    # call has more than one "&"-joined key=value pair (confirmed via log:
    # a single "&" - e.g. mode=x&skin_id=y - stays in argv[1], but three
    # "&"s - mode=pick_skin_color&setting=...&default=...&header=... -
    # split across argv[1..4], silently dropping every param after the
    # first from a parse_qsl(sys.argv[1])-only read). Rejoining the whole
    # argv tail before parsing is a no-op when it was already one piece,
    # and reconstructs it correctly when it wasn't.
    params = dict(parse_qsl("&".join(sys.argv[1:]), keep_blank_values=True))
    _get = params.get
    mode = _get("mode", "check_for_update")

    if mode == "fix_initial_home_focus":
        from modules.custom_actions import fix_initial_home_focus
        return fix_initial_home_focus()

    if mode == "load_menu_listing_include":
        from modules.custom_actions import load_menu_listing_include
        return load_menu_listing_include()

    if mode == "manage_menu_listing_include":
        from modules.custom_actions import manage_menu_listing_include
        return manage_menu_listing_include()

    if mode == "reset_stored_views":
        from modules.custom_actions import reset_stored_views
        return reset_stored_views()
    
    if "actions" in mode:
        from modules import actions

        return exec("actions.%s(params)" % mode.split(".")[1])

    if mode == "check_for_update":
        from modules.version_monitor import check_for_update

        return check_for_update(_get("skin_id"))

    if mode == "check_for_profile_change":
        from modules.version_monitor import check_for_profile_change

        return check_for_profile_change(_get("skin_id"))

    if mode == "manage_widgets":
        from modules.cpath_maker import CPaths

        return CPaths(_get("cpath_setting")).manage_widgets()

    if mode == "manage_main_menu_path":
        from modules.cpath_maker import CPaths

        return CPaths(_get("cpath_setting")).manage_main_menu_path()

    # ADDED: submenu manager route
    if mode == "manage_submenu_items":
        from modules.custom_actions import manage_submenu_items

        return manage_submenu_items(_get("menu"))

    if mode == "manage_main_menu_order":
        from modules.cpath_maker import manage_main_menu_order

        return manage_main_menu_order()

    if mode == "remake_all_cpaths":
        from modules.cpath_maker import remake_all_cpaths

        return remake_all_cpaths()

    if mode == "refresh_search_history":
        from modules.search_utils import SPaths

        return SPaths().refresh_search_history()

    if mode == "search_input":
        from modules.search_utils import SPaths

        return SPaths().search_input()

    if mode == "remove_all_spaths":
        from modules.search_utils import SPaths

        return SPaths().remove_all_spaths()

    if mode == "re_search":
        from modules.search_utils import SPaths

        return SPaths().re_search()

    if mode == "open_search_window":
        from modules.search_utils import SPaths

        return SPaths().open_search_window()
    
    if mode == "toggle_search_provider":
        from modules.search_utils import SPaths

        return SPaths().toggle_search_provider()

    if mode == "set_api_key":
        from modules.custom_actions import set_api_key

        return set_api_key()

    if mode == "delete_all_ratings":
        from modules.databases.ratings import RatingsDatabase

        return RatingsDatabase().delete_all_ratings()

    if mode == "set_image":
        from modules.custom_actions import set_image
        
        return set_image(params)

    if mode == "capture_user_key":
        from modules.custom_actions import capture_user_key

        return capture_user_key()

    if mode == "modify_keymap":
        from modules.custom_actions import modify_keymap

        return modify_keymap()

    if mode == "play_trailer":
        from modules.custom_actions import play_trailer

        return play_trailer()

    if mode == "fix_black_screen":
        from modules.custom_actions import fix_black_screen

        return fix_black_screen()

    if mode == "set_blurradius":
        from modules.custom_actions import set_blurradius

        return set_blurradius()

    if mode == "set_blursaturation":
        from modules.custom_actions import set_blursaturation

        return set_blursaturation()

    if mode == "set_autoendplaybackdelay":
        from modules.custom_actions import set_autoendplaybackdelay

        return set_autoendplaybackdelay()

    if mode == "clear_image_cache":
        from modules.helper import clear_image_cache

        return clear_image_cache()

    if mode == "clean_settings_file":
        from modules.custom_actions import clean_settings_file

        return clean_settings_file()

    if mode == "calculate_cache_size":
        from modules.helper import calculate_cache_size

        return calculate_cache_size()

    if mode == "recover_widget_focus":
        from modules.custom_actions import recover_widget_focus

        return recover_widget_focus()

    if mode == "reset_widget_position":
        from modules.custom_actions import reset_widget_position

        return reset_widget_position()

    if mode == "set_widget_count":
        from modules.custom_actions import set_widget_count

        return set_widget_count()

    if mode == "show_changelog":
        from modules.custom_actions import show_changelog

        return show_changelog()

    if mode == "check_api_key_on_load":
        from modules.custom_actions import check_api_key_on_load

        return check_api_key_on_load()

    if mode == "reset_all_to_defaults":
        from modules.cpath_maker import reset_all_to_defaults
        return reset_all_to_defaults(
            silent=_get("silent") == "true",
            welcome=_get("welcome") == "true",
        )

    if mode == "apply_splash_setting":
        from modules.custom_actions import apply_splash_setting
        return apply_splash_setting()

    if mode == "apply_disable_background_playback_setting":
        from modules.custom_actions import apply_disable_background_playback_setting
        return apply_disable_background_playback_setting()

    if mode == "apply_touch_submenu_gesture_setting":
        from modules.custom_actions import apply_touch_submenu_gesture_setting
        return apply_touch_submenu_gesture_setting()

    if mode == "touch_home_submenu_swipe":
        from modules.custom_actions import touch_home_submenu_swipe
        return touch_home_submenu_swipe()

    if mode == "touch_home_submenu_longpress":
        from modules.custom_actions import touch_home_submenu_longpress
        return touch_home_submenu_longpress()

    if mode == "pick_skin_color":
        from modules.custom_actions import pick_skin_color
        return pick_skin_color(params)