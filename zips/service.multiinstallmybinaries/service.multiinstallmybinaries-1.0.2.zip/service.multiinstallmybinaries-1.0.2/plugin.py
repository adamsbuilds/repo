import xbmc
import xbmcvfs
import xbmcaddon
import os
import json
import time
    
class Installer:
    
    addon_data = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    get_setting = xbmcaddon.Addon().getSetting
    set_setting = xbmcaddon.Addon().setSetting
    addon_json = xbmcvfs.translatePath('special://home/addons/service.multiinstallmybinaries/resources/addons.json')
    
    def create_folder(self, folder_path):
        if not xbmcvfs.exists(folder_path):
            return xbmcvfs.mkdir(folder_path)
        
    def installer(self):
        xbmc.log('INSTALLER STARTED', xbmc.LOGINFO)
        xbmc.sleep(5000)
        
        try:
            xbmc.log(f'Reading addon_json from: {self.addon_json}', xbmc.LOGINFO)
            with open(self.addon_json, 'r', encoding='utf-8', errors='ignore') as f:
                addon_list = json.loads(f.read())
            xbmc.log(f'Addon list loaded successfully: {addon_list}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'ERROR reading addon_json: {str(e)}', xbmc.LOGERROR)
            self.set_setting('activate_installer', 'true')
            return
        
        failed = []
        for addon in addon_list.keys():
            try:
                name = addon_list[addon]
                plugin_id = addon_list[addon]['plugin_id']
                xbmc.log(f'Installing addon: {plugin_id}', xbmc.LOGINFO)
                install = self.install_addon(plugin_id)
                if install is not True:
                    xbmc.log(f'Failed to install: {plugin_id}', xbmc.LOGERROR)
                    failed.append([name, plugin_id])
                else:
                    xbmc.log(f'Successfully installed: {plugin_id}', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f'ERROR processing addon {addon}: {str(e)}', xbmc.LOGERROR)
                failed.append([addon, str(e)])
        
        if len(failed) == 0:
            xbmc.log('All addons installed successfully', xbmc.LOGINFO)
            self.set_setting('activate_installer', 'false')
        else:
            xbmc.log(f'Failed addons: {failed}', xbmc.LOGERROR)
            self.set_setting('activate_installer', 'true')
    
    def install_addon(self, plugin_id):
        try:
            # Double check using direct storage system validation before initiating network paths
            if self.isinstalled(plugin_id):
                xbmc.log(f'Addon already installed structurally on storage: {plugin_id}', xbmc.LOGINFO)
                return True
            
            # =========================================================================
            # FORCE REREPOSITORY REFRESH FOR FIRST BOOT ENVIRONMENT
            # =========================================================================
            xbmc.log(f'[Service] Preparing repo index cache before installing {plugin_id}...', xbmc.LOGINFO)
            
            # Force the official repositories to aggressively check for server-side updates
            xbmc.executebuiltin('UpdateRemoteKB()')    # Sync fallback mirror linkages
            xbmc.executebuiltin('UpdateAddonRepos()')   # Force repo structure layout rebuilds
            
            # Give Kodi's background network worker threads 4 seconds to parse listings
            xbmc.sleep(4000)
            
            # Double-check if the package is visible to the system package manager API yet
            query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"%s"},"id":1}' % plugin_id
            addonDetails = xbmc.executeJSONRPC(query)
            details_result = json.loads(addonDetails)
            
            # If the index is still blind to it, run a local fallback check
            if 'error' in details_result:
                xbmc.log(f'[Service] Repo index failed to resolve {plugin_id}. Forcing local sync fallback...', xbmc.LOGWARN)
                xbmc.executebuiltin('UpdateLocalAddons()')
                xbmc.sleep(2000)
            # =========================================================================
            
            xbmc.log(f'Executing InstallAddon for: {plugin_id}', xbmc.LOGINFO)
            xbmc.executebuiltin(f'InstallAddon({plugin_id})')
            clicked = False
            start = time.time()
            timeout = 60
            
            while not self.isinstalled(plugin_id):
                elapsed = time.time() - start
                if elapsed >= timeout:
                    xbmc.log(f'Installation timeout for {plugin_id} after {timeout} seconds', xbmc.LOGERROR)
                    return False
                
                xbmc.sleep(500)
                
                if xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)') and not clicked:
                    xbmc.log(f'Dialog detected, auto-clicking for {plugin_id}', xbmc.LOGINFO)
                    xbmc.executebuiltin('SendClick(yesnodialog, 11)')
                    clicked = True
            
            # Force activation of the module via JSON-RPC to overwrite old database flags
            xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":true},"id":1}' % plugin_id
            )
            
            xbmc.log(f'Installation completed and forced enabled: {plugin_id}', xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f'ERROR installing {plugin_id}: {str(e)}', xbmc.LOGERROR)
            return False

    def isinstalled(self, addonid):
        """
        Double-verifies addon initialization status by checking both JSON-RPC database flags
        AND physical folder structures to avoid database restoration collision false-positives.
        """
        try:
            # 1. Structural storage system physical directory check
            addon_folder = xbmcvfs.translatePath(f'special://home/addons/{addonid}')
            if not xbmcvfs.exists(addon_folder):
                xbmc.log(f'Physical directory missing on storage for: {addonid}', xbmc.LOGDEBUG)
                return False
                
            # 2. Database registry table check
            query = '{ "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails", "params": { "addonid": "%s", "properties" : ["enabled", "installed"] } }' % addonid
            addonDetails = xbmc.executeJSONRPC(query)
            details_result = json.loads(addonDetails)
            
            if "error" in details_result:
                xbmc.log(f'Error querying addon {addonid}: {details_result["error"]}', xbmc.LOGDEBUG)
                return False
                
            if details_result['result']['addon']['installed'] == True:
                xbmc.log(f'Addon database state confirms registration: {addonid}', xbmc.LOGDEBUG)
                return True
                
            return False
        except Exception as e:
            xbmc.log(f'ERROR checking if {addonid} is installed: {str(e)}', xbmc.LOGERROR)
            return False
