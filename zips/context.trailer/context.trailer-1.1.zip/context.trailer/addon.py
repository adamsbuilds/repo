# -*- coding: utf-8 -*-
#
# Copyright (C) 2016 BigNoid
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import xbmc
import xbmcaddon
import xbmcgui
import sys

ADDON = xbmcaddon.Addon()

IMDB_TRAILERS_ADDON_ID = "plugin.video.imdb.trailers"

# Values for the "source" setting (see resources/settings.xml)
SOURCE_IMDB_FIRST = "0"
SOURCE_LIBRARY_FIRST = "1"
SOURCE_IMDB_ONLY = "2"
SOURCE_LIBRARY_ONLY = "3"

# Fallback default if the "fallback_timeout" setting is missing/invalid.
DEFAULT_PLAYBACK_TIMEOUT = 7


class TrailerPlayer(xbmc.Player):
    """Watches playback of a single attempt so we can tell whether it
    actually started or failed (e.g. the "no trailer found" case)."""

    def __init__(self):
        super(TrailerPlayer, self).__init__()
        self.reset()

    def reset(self):
        self.started = False
        self.failed = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.failed = True

    def onPlayBackStopped(self):
        if not self.started:
            self.failed = True

    def onPlayBackEnded(self):
        if not self.started:
            self.failed = True


def imdb_trailers_available():
    """True if the IMDb Trailers addon is installed/enabled."""
    try:
        xbmcaddon.Addon(IMDB_TRAILERS_ADDON_ID)
        return True
    except RuntimeError:
        return False


def build_imdb_url(imdb_id):
    return "plugin://%s/?action=play_id&imdb=%s" % (IMDB_TRAILERS_ADDON_ID, imdb_id)


def get_candidates(info):
    """Ordered, de-duplicated list of trailer URLs to try, per the
    "source" setting."""
    library_trailer = info.getTrailer()
    imdb_id = info.getIMDBNumber()

    imdb_url = None
    if imdb_id and imdb_trailers_available():
        imdb_url = build_imdb_url(imdb_id)

    source = ADDON.getSetting("source") or SOURCE_IMDB_FIRST

    if source == SOURCE_IMDB_ONLY:
        ordered = [imdb_url]
    elif source == SOURCE_LIBRARY_ONLY:
        ordered = [library_trailer]
    elif source == SOURCE_LIBRARY_FIRST:
        ordered = [library_trailer, imdb_url]
    else:
        ordered = [imdb_url, library_trailer]

    seen = set()
    candidates = []
    for url in ordered:
        if url and url not in seen:
            seen.add(url)
            candidates.append(url)
    return candidates


def get_playback_timeout():
    try:
        timeout = int(ADDON.getSetting("fallback_timeout"))
    except (ValueError, TypeError):
        timeout = DEFAULT_PLAYBACK_TIMEOUT
    return timeout if timeout > 0 else DEFAULT_PLAYBACK_TIMEOUT


def attempt(url, windowed, player, monitor, timeout):
    """Trigger playback of a single candidate URL and wait to see whether
    it starts or fails, up to `timeout` seconds. Returns True if playback
    started (or Kodi is shutting down), False if it failed or timed out."""
    player.reset()
    play(url, windowed)

    waited = 0.0
    step = 0.2
    while waited < timeout:
        if monitor.waitForAbort(step):
            return True  # Kodi is shutting down, don't chase a fallback
        # Trust the callback flags first, but also poll player state
        # directly - some failure paths (e.g. a plugin that never calls
        # setResolvedUrl at all, or crashes before it can) never trigger
        # onPlayBackError/onPlayBackStopped, so the callbacks alone can
        # hang until timeout.
        if player.started or player.isPlayingVideo():
            return True
        if player.failed:
            return False
        waited += step

    # Never started and never explicitly errored - don't hang forever,
    # treat it as a failure so we still get a shot at the next source.
    return False


def play(url, windowed):
    if windowed:
        xbmc.executebuiltin("PlayMedia(%s)" % (url))
    else:
        xbmc.executebuiltin("PlayMedia(%s,1)" % (url))


def main():
    windowed = ADDON.getSetting("windowed") == "false"
    info = sys.listitem.getVideoInfoTag()
    candidates = get_candidates(info)

    if not candidates:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo("name"),
            ADDON.getLocalizedString(32003),
            xbmcgui.NOTIFICATION_INFO,
        )
        return

    player = TrailerPlayer()
    monitor = xbmc.Monitor()
    timeout = get_playback_timeout()
    last_index = len(candidates) - 1

    for i, url in enumerate(candidates):
        if i == last_index:
            # Nothing left to fall back to - just play it, no race against
            # a timeout that could cut off a legitimately-slow-but-working
            # stream (e.g. YouTube taking a moment to buffer). If this one
            # also fails, Kodi/the target addon will report that on their
            # own - nothing further for us to catch or retry.
            play(url, windowed)
            return
        if attempt(url, windowed, player, monitor, timeout):
            return
        if player.isPlaying():
            player.stop()


if __name__ == '__main__':
    main()
