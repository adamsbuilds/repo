# -*- coding: utf-8 -*-
#
# Copyright (C) 2016 BigNoid
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import xbmc
import xbmcaddon
import xbmcgui
import sys

ADDON = xbmcaddon.Addon()
HOME = xbmcgui.Window(10000)

IMDB_TRAILERS_ADDON_ID = "plugin.video.imdb.trailers"

# Home window property set while one of our trailers is playing (and for a
# short grace period after it stops). Skins / other addons can check it to
# skip widget reloads or "playback stopped" handling for trailers.
PLAYING_PROP = "context.trailer.playing"
STOP_GRACE_SECONDS = 3

# Values for the "source" setting (see resources/settings.xml)
SOURCE_IMDB_FIRST = "0"
SOURCE_LIBRARY_FIRST = "1"
SOURCE_IMDB_ONLY = "2"
SOURCE_LIBRARY_ONLY = "3"

# Fallback default if the "fallback_timeout" setting is missing/invalid.
DEFAULT_PLAYBACK_TIMEOUT = 7

# How long to wait for the final source to start before giving up on
# managing the playing flag (no fallback is attempted for the last source).
FINAL_SOURCE_MAX_WAIT = 60


class TrailerPlayer(xbmc.Player):
    """Watches playback of a single attempt so we can tell whether it
    actually started or failed (e.g. the "no trailer found" case)."""

    def __init__(self):
        super(TrailerPlayer, self).__init__()
        self.reset()

    def reset(self):
        self.started = False
        self.failed = False
        self.finished = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.failed = True
        self.finished = True

    def onPlayBackStopped(self):
        if not self.started:
            self.failed = True
        self.finished = True

    def onPlayBackEnded(self):
        if not self.started:
            self.failed = True
        self.finished = True


def imdb_trailers_available():
    """True if the IMDb Trailers addon is installed/enabled."""
    try:
        xbmcaddon.Addon(IMDB_TRAILERS_ADDON_ID)
        return True
    except RuntimeError:
        return False


def build_imdb_url(imdb_id):
    return "plugin://%s/?action=play_id&imdb=%s" % (IMDB_TRAILERS_ADDON_ID, imdb_id)


def get_candidates(info):
    """Ordered, de-duplicated list of trailer URLs to try, per the
    "source" setting."""
    library_trailer = info.getTrailer()
    imdb_id = info.getIMDBNumber()

    imdb_url = None
    if imdb_id and imdb_trailers_available():
        imdb_url = build_imdb_url(imdb_id)

    source = ADDON.getSetting("source") or SOURCE_IMDB_FIRST

    if source == SOURCE_IMDB_ONLY:
        ordered = [imdb_url]
    elif source == SOURCE_LIBRARY_ONLY:
        ordered = [library_trailer]
    elif source == SOURCE_LIBRARY_FIRST:
        ordered = [library_trailer, imdb_url]
    else:
        ordered = [imdb_url, library_trailer]

    seen = set()
    candidates = []
    for url in ordered:
        if url and url not in seen:
            seen.add(url)
            candidates.append(url)
    return candidates


def get_playback_timeout():
    try:
        timeout = int(ADDON.getSetting("fallback_timeout"))
    except (ValueError, TypeError):
        timeout = DEFAULT_PLAYBACK_TIMEOUT
    return timeout if timeout > 0 else DEFAULT_PLAYBACK_TIMEOUT


def play(url, windowed, player, title):
    """Play with a clean, minimal ListItem via the Player API instead of
    the PlayMedia() builtin. The trailer then carries nothing over from
    the focused item the context menu was opened on (e.g. a Red Light
    widget item) - no dbid/mediatype/plugin properties for Kodi or that
    addon to act on when playback stops."""
    li = xbmcgui.ListItem(label=title or "Trailer", path=url, offscreen=True)
    li.setProperty("IsPlayable", "true")
    if title:
        li.getVideoInfoTag().setTitle(title)
    player.play(url, li, windowed)


def attempt(url, windowed, player, monitor, timeout, title):
    """Trigger playback of a single candidate URL and wait to see whether
    it starts or fails, up to `timeout` seconds. Returns True if playback
    started (or Kodi is shutting down), False if it failed or timed out."""
    player.reset()
    play(url, windowed, player, title)

    waited = 0.0
    step = 0.2
    while waited < timeout:
        if monitor.waitForAbort(step):
            return True  # Kodi is shutting down, don't chase a fallback
        # Trust the callback flags first, but also poll player state
        # directly - some failure paths (e.g. a plugin that never calls
        # setResolvedUrl at all, or crashes before it can) never trigger
        # onPlayBackError/onPlayBackStopped, so the callbacks alone can
        # hang until timeout.
        if player.started or player.isPlayingVideo():
            return True
        if player.failed:
            return False
        waited += step

    # Never started and never explicitly errored - don't hang forever,
    # treat it as a failure so we still get a shot at the next source.
    return False


def wait_for_start(player, monitor):
    """Final source: no fallback, so no cutoff race - just wait (bounded)
    to learn whether it started, so we know whether to watch it."""
    waited = 0.0
    step = 0.2
    while waited < FINAL_SOURCE_MAX_WAIT:
        if monitor.waitForAbort(step):
            return False
        if player.started or player.isPlayingVideo():
            return True
        if player.failed:
            return False
        waited += step
    return False


def watch_until_done(player, monitor):
    """Stay alive (cheaply) until the trailer stops or ends."""
    while not monitor.abortRequested():
        if player.finished or not player.isPlaying():
            break
        if monitor.waitForAbort(0.5):
            return
    # Keep the flag up briefly after stop - that's exactly the moment
    # widget reloads / stop handlers fire.
    monitor.waitForAbort(STOP_GRACE_SECONDS)


def main():
    # Setting "windowed" true -> play windowed, otherwise fullscreen.
    windowed = ADDON.getSetting("windowed") == "true"
    info = sys.listitem.getVideoInfoTag()
    title = info.getTitle()
    candidates = get_candidates(info)

    if not candidates:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo("name"),
            ADDON.getLocalizedString(32003),
            xbmcgui.NOTIFICATION_INFO,
        )
        return

    player = TrailerPlayer()
    monitor = xbmc.Monitor()
    timeout = get_playback_timeout()
    last_index = len(candidates) - 1

    HOME.setProperty(PLAYING_PROP, "true")
    try:
        for i, url in enumerate(candidates):
            if i == last_index:
                player.reset()
                play(url, windowed, player, title)
                if wait_for_start(player, monitor):
                    watch_until_done(player, monitor)
                return
            if attempt(url, windowed, player, monitor, timeout, title):
                watch_until_done(player, monitor)
                return
            if player.isPlaying():
                player.stop()
    finally:
        HOME.clearProperty(PLAYING_PROP)


if __name__ == '__main__':
    main()