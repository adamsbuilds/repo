import os
import re
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import xbmc
import xbmcgui

from resources.lib import kodi


class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        m = re.match(r'^/mpd/([A-Za-z0-9_-]{11})\.mpd$', self.path.split('?')[0])
        path = os.path.join(kodi.profile_dir(), 'mpd', '%s.mpd' % m.group(1)) if m else None
        if not path or not os.path.exists(path):
            self.send_error(404)
            return
        with open(path, 'rb') as f:
            body = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class Monitor(xbmc.Monitor):
    def __init__(self):
        super(Monitor, self).__init__()
        self.library_pending = False

    def onSettingsChanged(self):
        set_context_flag()
        if kodi.setting_bool('library_fill'):
            self.library_pending = True

    def onNotification(self, sender, method, data):
        if method == 'VideoLibrary.OnScanFinished' and kodi.setting_bool('library_fill'):
            self.library_pending = True


def set_context_flag():
    xbmcgui.Window(10000).setProperty('tubelite.context', '1' if kodi.setting_bool('context_menu') else '')


def start_server():
    port = kodi.setting_int('server_port', 50152) or 50152
    try:
        server = Server(('127.0.0.1', port), Handler)
    except Exception as e:
        kodi.log('could not start manifest server on port %d: %s' % (port, e), xbmc.LOGERROR)
        return None
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    kodi.log('manifest server listening on 127.0.0.1:%d' % port)
    return server


def background_jobs(monitor):
    """Client refresh and library trailer fill, kept off the startup path."""
    if monitor.waitForAbort(20):
        return
    try:
        from resources.lib import takeover
        takeover.sync()
    except Exception as e:
        kodi.log('stand-in sync failed: %s' % e, xbmc.LOGWARNING)
    library_done = False
    while not monitor.abortRequested():
        if kodi.setting_bool('auto_clients'):
            try:
                from resources.lib import clientupdate
                from resources.lib.innertube import InnerTube
                clientupdate.refresh(InnerTube(), reason='daily')
            except Exception as e:
                kodi.log('client refresh failed: %s' % e, xbmc.LOGWARNING)
        if kodi.setting_bool('library_fill') and (not library_done or monitor.library_pending):
            monitor.library_pending = False
            try:
                from resources.lib import library
                library.fill(monitor)
                library_done = True
            except Exception as e:
                kodi.log('library fill failed: %s' % e, xbmc.LOGWARNING)
        # Wake every minute for library scans; the client refresh only re-runs once a day.
        if monitor.waitForAbort(60):
            break


def run():
    monitor = Monitor()
    set_context_flag()
    server = start_server()
    jobs = threading.Thread(target=background_jobs, args=(monitor,))
    jobs.daemon = True
    jobs.start()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    if server:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    run()
