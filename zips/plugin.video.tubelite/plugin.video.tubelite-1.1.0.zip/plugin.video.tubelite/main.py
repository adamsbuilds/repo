import json
import os
import sys
from urllib.parse import parse_qsl, urlparse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import kodi, storage, streams, trailers
from resources.lib.innertube import InnerTube, YTError
from resources.lib.parser import channel_title, parse, related_section

HANDLE = kodi.handle()
PATH = urlparse(sys.argv[0]).path.strip('/')
ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

_yt = None


def yt():
    global _yt
    if _yt is None:
        _yt = InnerTube()
    return _yt


def shorts():
    return not kodi.setting_bool('hide_shorts')


# ---------------------------------------------------------------- list helpers

def folder(label, path, thumb='', plot='', context=None, **params):
    li = xbmcgui.ListItem(label, offscreen=True)
    art = thumb if thumb.startswith('http') else (kodi.icon(thumb) if thumb else os.path.join(kodi.ADDON_PATH, 'icon.png'))
    li.setArt({'icon': art, 'thumb': art, 'poster': art,
               'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    if plot:
        tag = li.getVideoInfoTag()
        tag.setPlot(plot)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, True)


def video_item(v, extra_context=None):
    li = xbmcgui.ListItem(v.get('title') or v['id'], offscreen=True)
    li.setArt({'thumb': v.get('thumb'), 'icon': v.get('thumb'), 'poster': v.get('thumb'),
               'fanart': v.get('thumb')})
    tag = li.getVideoInfoTag()
    tag.setTitle(v.get('title', ''))
    tag.setMediaType('video')
    if v.get('duration'):
        tag.setDuration(int(v['duration']))
    if v.get('channel'):
        tag.setStudios([v['channel']])
    meta = ' · '.join(x for x in (v.get('channel'), v.get('views'), v.get('published')) if x)
    if v.get('live'):
        meta = '[LIVE] ' + meta
    tag.setPlot('[B]%s[/B]\n%s' % (meta, v.get('description', '')) if meta else v.get('description', ''))
    li.setProperty('IsPlayable', 'true')
    ctx = [('Related videos', 'Container.Update(%s)' % kodi.url('related', id=v['id']))]
    if v.get('channel_id'):
        ctx.append(('Go to channel', 'Container.Update(%s)' % kodi.url('channel', id=v['channel_id'],
                                                                         title=v.get('channel'))))
        ctx.append(('Add channel to My Channels', 'RunPlugin(%s)' % kodi.url(
            'channel/add', id=v['channel_id'], title=v.get('channel'))))
    ctx += extra_context or []
    li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url('play', video_id=v['id']), li, False)


def render(items, next_path=None, next_params=None):
    for it in items:
        if it['type'] == 'video':
            video_item(it)
        elif it['type'] == 'playlist':
            label = it['title'] + ('  [COLOR grey](%s)[/COLOR]' % it['count'] if it.get('count') else '')
            folder(label, 'playlist', it.get('thumb', ''), it.get('channel', ''), id=it['id'])
        elif it['type'] == 'channel':
            folder('[B]%s[/B]' % it['title'], 'channel', it.get('thumb', ''),
                   '%s\n%s' % (it.get('subs', ''), it.get('description', '')),
                   context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url(
                       'channel/add', id=it['id'], title=it['title'], thumb=it.get('thumb')))],
                   id=it['id'], title=it['title'])
    if next_path and next_params and next_params.get('cont'):
        folder('[COLOR yellow]Next page >>[/COLOR]', next_path, 'next.png', **next_params)


def finish(content='videos', cache=False):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def fail(e):
    kodi.log('error: %s' % e, xbmc.LOGERROR)
    kodi.notify(str(e) or 'Something went wrong')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# ---------------------------------------------------------------- menus

def setup():
    """One-time questions about hooking TubeLite into the rest of Kodi."""
    from resources.lib import takeover
    kodi.set_setting('setup_done', 'true')
    dialog = xbmcgui.Dialog()
    existing = takeover.status()
    if existing != 'shim':
        msg = ('Play YouTube links from the rest of Kodi through TubeLite?[CR][CR]'
               'Library trailers, the Trailer button on info screens, context menus and other add-ons '
               'all point at the YouTube add-on. TubeLite can stand in for it so they just work.')
        if existing == 'other':
            msg += '[CR][CR]Your current YouTube add-on will be backed up and can be restored in settings.'
        if dialog.yesno(kodi.ADDON_NAME, msg):
            takeover_install(quiet=True)
    if not kodi.setting_bool('library_fill') and dialog.yesno(
            kodi.ADDON_NAME, 'Add a trailer to library movies and TV shows that don\'t have one?[CR][CR]'
                             'Nothing is downloaded until you press Play Trailer. You can undo this in settings.'):
        kodi.set_setting('library_fill', 'true')
        library_fill()


def takeover_install(quiet=False):
    from resources.lib import takeover
    try:
        takeover.install()
        kodi.notify('Kodi\'s YouTube links now play through TubeLite')
    except Exception as e:
        kodi.log('stand-in install failed: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Could not set up YouTube links: %s' % e)


def takeover_remove():
    from resources.lib import takeover
    if takeover.status() != 'shim' and not takeover.has_backup():
        kodi.notify('TubeLite isn\'t handling YouTube links')
        return
    restored = takeover.remove()
    kodi.notify('Previous YouTube add-on restored' if restored else 'YouTube links no longer use TubeLite')


def library_fill():
    from resources.lib import library
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Adding trailers to your library')
    try:
        done = library.fill()
    finally:
        progress.close()
    parts = []
    for key, label in (('movies', 'movies'), ('tvshows', 'TV shows')):
        if done.get(key) is None and key in done:
            parts.append('%s: not supported by this Kodi' % label)
        elif done.get(key) is not None:
            parts.append('%d %s' % (done[key], label))
    kodi.notify('Trailers added: ' + ', '.join(parts) if parts else 'Library trailers are up to date')


def library_clear():
    from resources.lib import library
    if xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Remove the trailer links TubeLite added to your library?[CR]'
                                               'Scraped trailers are left alone.'):
        kodi.set_setting('library_fill', 'false')
        kodi.notify('Removed %d trailer links' % library.clear())


def clients_refresh():
    from resources.lib import clientupdate
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Testing YouTube player clients')
    meta = clientupdate.load_meta()
    meta['attempt'] = 0
    with open(os.path.join(kodi.profile_dir(), 'clients_meta.json'), 'w') as f:
        json.dump(meta, f)
    try:
        ok = clientupdate.refresh(yt(), force=True, reason='manual')
    finally:
        progress.close()
    meta = clientupdate.load_meta()
    working = ', '.join(meta.get('working') or []) or 'none'
    xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Source: %s[CR]Working clients: %s[CR]%s' % (
        meta.get('source', '?'), working,
        'Playback will use these, best first.' if ok else 'Kept the previous list. Check your connection.'))


def root():
    if not kodi.setting_bool('setup_done') and HANDLE >= 0:
        setup()
    folder('TV & Movie Trailers', 'trailers', 'trailers.png', 'Find trailers for any show or movie, plus the newest ones.')
    folder('Search', 'search', 'search.png', 'Search YouTube without signing in.')
    folder('My Channels', 'channels', 'channels.png', 'Channels you\'ve saved. Stored on this device, no account needed.')
    folder('Watch History', 'history', 'history.png', 'Videos you\'ve played here.')
    finish('files', cache=True)


def trailers_menu():
    folder('Find a Show\'s Trailer', 'trailers/search', 'search.png', 'Type a show or movie name.', kind='tv')
    folder('New TV Trailers This Week', 'trailers/new', 'trailers.png', what='tv', period='week')
    folder('New Movie Trailers This Week', 'trailers/new', 'trailers.png', what='movie', period='week')
    folder('New TV Trailers This Month', 'trailers/new', 'trailers.png', what='tv', period='month')
    folder('New Movie Trailers This Month', 'trailers/new', 'trailers.png', what='movie', period='month')
    folder('Studio & Network Channels', 'trailers/studios', 'channels.png')
    finish('files', cache=True)


def trailers_search():
    q = ARGS.get('q')
    if not q:
        q = kodi.keyboard('Show or movie name')
        if q:
            xbmc.executebuiltin('Container.Update(%s)' % kodi.url('trailers/search', q=q, kind=ARGS.get('kind', 'tv')))
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    try:
        items = trailers.find(yt(), q, ARGS.get('year', ''), ARGS.get('kind', 'tv'), ARGS.get('season', ''))
    except Exception as e:
        return fail(e)
    render(items)
    finish()


NEW_QUERIES = {
    'tv': 'official series trailer',
    'movie': 'official movie trailer',
}


def trailers_new():
    sp = trailers.NEW_THIS_MONTH if ARGS.get('period') == 'month' else trailers.NEW_THIS_WEEK
    try:
        data = yt().search(None, continuation=ARGS['cont']) if ARGS.get('cont') else \
            yt().search(NEW_QUERIES.get(ARGS.get('what'), 'official trailer'), sp)
        items, token = parse(data, shorts())
    except Exception as e:
        return fail(e)
    items = [i for i in items if i['type'] == 'video' and 'trailer' in i.get('title', '').lower()
             and trailers.score(i, '') > 0]
    render(items, 'trailers/new', dict(ARGS, cont=token))
    finish()


def trailers_studios():
    with open(os.path.join(kodi.ADDON_PATH, 'resources', 'data', 'trailer_channels.json')) as f:
        studios = json.load(f)
    for s in studios:
        folder(s['title'], 'channel', 'channels.png',
               context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url('channel/add', id=s['id'], title=s['title']))],
               id=s['id'], title=s['title'])
    finish('files', cache=True)


def search_menu():
    folder('[B]New search[/B]', 'search/results', 'search.png', new='1')
    folder('[B]Search channels[/B]', 'search/results', 'channels.png', new='1', kind='channels')
    folder('[B]Search playlists[/B]', 'search/results', 'search.png', new='1', kind='playlists')
    for s in storage.load('searches'):
        kind = s.get('kind', 'all')
        label = s['q'] + ('  [COLOR grey](%s)[/COLOR]' % kind if kind != 'all' else '')
        folder(label, 'search/results', 'search.png',
               context=[('Remove from search history', 'RunPlugin(%s)' % kodi.url('search/remove', q=s['q'])),
                        ('Clear search history', 'RunPlugin(%s)' % kodi.url('clear', what='searches'))],
               q=s['q'], kind=kind)
    finish('files')


SEARCH_PARAMS = {'all': None, 'videos': 'EgIQAQ==', 'channels': 'EgIQAg==', 'playlists': 'EgIQAw=='}


def search_results():
    kind = ARGS.get('kind', 'all')
    q = ARGS.get('q')
    if ARGS.get('new'):
        q = kodi.keyboard('Search YouTube')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        storage.add_search(q, kind)
        xbmc.executebuiltin('Container.Update(%s,replace)' % kodi.url('search/results', q=q, kind=kind))
        return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    try:
        if ARGS.get('cont'):
            data = yt().search(None, continuation=ARGS['cont'])
        else:
            data = yt().search(q, SEARCH_PARAMS.get(kind))
        items, token = parse(data, shorts())
    except Exception as e:
        return fail(e)
    render(items, 'search/results', {'q': q, 'kind': kind, 'cont': token})
    finish()


def channels_menu():
    chans = storage.channels()
    if not chans:
        folder('[I]No saved channels yet. Use "Add channel to My Channels" on any video.[/I]', 'trailers/studios', 'channels.png')
    for c in chans:
        folder(c['title'], 'channel', c.get('thumb', ''),
               context=[('Remove from My Channels', 'RunPlugin(%s)' % kodi.url('channel/remove', id=c['id']))],
               id=c['id'], title=c['title'])
    finish('files')


def channel():
    cid, title = ARGS['id'], ARGS.get('title', '')
    folder('Videos', 'channel/tab', 'trailers.png', id=cid, tab='videos', title=title)
    folder('Live', 'channel/tab', 'trailers.png', id=cid, tab='streams', title=title)
    folder('Playlists', 'channel/tab', 'channels.png', id=cid, tab='playlists', title=title)
    if not kodi.setting_bool('hide_shorts'):
        folder('Shorts', 'channel/tab', 'trailers.png', id=cid, tab='shorts', title=title)
    folder('Add to My Channels', 'channel/add', 'channels.png', id=cid, title=title)
    finish('files', cache=True)


def channel_tab():
    tab = ARGS.get('tab', 'videos')
    try:
        data = yt().channel_tab(ARGS['id'], tab, ARGS.get('cont'))
        items, token = parse(data, tab == 'shorts' or shorts())
    except Exception as e:
        return fail(e)
    render(items, 'channel/tab', dict(ARGS, cont=token))
    finish()


def channel_add():
    cid, title, thumb = ARGS['id'], ARGS.get('title', ''), ARGS.get('thumb', '')
    if cid.startswith('@') or not title or not thumb:
        try:
            data = yt().channel_tab(cid, 'videos')
            name, avatar = channel_title(data)
            title, thumb = title or name, thumb or avatar
            browse_id = ((data.get('metadata') or {}).get('channelMetadataRenderer') or {}).get('externalId')
            if browse_id:
                cid = browse_id
        except Exception as e:
            kodi.log('channel lookup failed: %s' % e)
    storage.add_channel(cid, title or cid, thumb)
    kodi.notify('Added %s to My Channels' % (title or cid))
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def channel_remove():
    storage.remove('channels', 'id', ARGS['id'])
    xbmc.executebuiltin('Container.Refresh')


def playlist():
    try:
        if ARGS.get('cont'):
            data = yt().browse(continuation=ARGS['cont'])
        else:
            pid = ARGS['id']
            data = yt().browse(pid if pid.startswith('VL') else 'VL' + pid)
        items, token = parse(data, True)
    except Exception as e:
        return fail(e)
    render(items, 'playlist', dict(ARGS, cont=token))
    finish()


def related():
    try:
        data = yt().next(continuation=ARGS['cont']) if ARGS.get('cont') else yt().next(ARGS['id'])
        items, token = parse(related_section(data), shorts())
    except Exception as e:
        return fail(e)
    render(items, 'related', dict(ARGS, cont=token))
    finish()


def history():
    items = storage.load('history')
    for v in items:
        v = dict(v, type='video')
        video_item(v, [('Remove from history', 'RunPlugin(%s)' % kodi.url('history/remove', id=v['id'])),
                       ('Clear watch history', 'RunPlugin(%s)' % kodi.url('clear', what='history'))])
    finish()


def clear():
    what = ARGS.get('what')
    names = {'history': 'watch history', 'searches': 'search history', 'channels': 'My Channels'}
    if what in names and xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Clear %s?' % names[what]):
        storage.clear(what)
        kodi.notify('Cleared %s' % names[what])
        xbmc.executebuiltin('Container.Refresh')


def reset_session():
    yt().reset_state()
    for name in ('clients.json', 'clients_meta.json'):
        try:
            os.remove(os.path.join(kodi.profile_dir(), name))
        except Exception:
            pass
    kodi.notify('Session reset')


# ---------------------------------------------------------------- playback

def _resolved(info):
    li = streams.listitem_for(info)
    li.setArt({'thumb': info['thumb'], 'icon': info['thumb'], 'fanart': info['thumb']})
    tag = li.getVideoInfoTag()
    tag.setTitle(info.get('title', ''))
    tag.setPlot(info.get('description', ''))
    tag.setMediaType('video')
    if info.get('channel'):
        tag.setStudios([info['channel']])
    if info.get('duration'):
        tag.setDuration(info['duration'])
    return li


def play_video(video_id):
    try:
        info = streams.resolve(yt(), video_id)
    except Exception as e:
        kodi.log('playback failed for %s: %s' % (video_id, e), xbmc.LOGERROR)
        kodi.notify('Can\'t play: %s' % e)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    kodi.log('%s playing via %s (%s)' % (video_id, info['client'], info['kind']))
    storage.add_history(dict(info, id=video_id))
    li = _resolved(info)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)


def play():
    vid = ARGS.get('video_id') or ARGS.get('videoid') or ARGS.get('v')
    if not vid and ARGS.get('url'):
        q = dict(parse_qsl(urlparse(ARGS['url']).query))
        vid = q.get('v') or urlparse(ARGS['url']).path.rstrip('/').split('/')[-1]
    if not vid:
        kodi.notify('No video id given')
        return
    play_video(vid)


def trailer():
    """External entry: plugin://plugin.video.tubelite/trailer/?title=Severance&year=2022&type=tv&season=2"""
    title = ARGS.get('title') or ARGS.get('tvshowtitle')
    if not title:
        kodi.notify('No title given')
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    try:
        best = trailers.find(yt(), title, ARGS.get('year', ''), ARGS.get('type', 'tv'), ARGS.get('season', ''))[0]
    except Exception as e:
        kodi.notify(str(e))
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    kodi.log('trailer for "%s": %s (%s)' % (title, best['title'], best['id']))
    play_video(best['id'])


ROUTES = {
    '': root,
    'trailers': trailers_menu,
    'trailers/search': trailers_search,
    'trailers/new': trailers_new,
    'trailers/studios': trailers_studios,
    'trailer': trailer,
    'search': search_menu,
    'search/results': search_results,
    'search/remove': lambda: (storage.remove('searches', 'q', ARGS.get('q')), xbmc.executebuiltin('Container.Refresh')),
    'channels': channels_menu,
    'channel': channel,
    'channel/tab': channel_tab,
    'channel/add': channel_add,
    'channel/remove': channel_remove,
    'playlist': playlist,
    'related': related,
    'history': history,
    'history/remove': lambda: (storage.remove('history', 'id', ARGS.get('id')), xbmc.executebuiltin('Container.Refresh')),
    'clear': clear,
    'reset_session': reset_session,
    'play': play,
    'setup': setup,
    'takeover/install': takeover_install,
    'takeover/remove': takeover_remove,
    'library/fill': library_fill,
    'library/clear': library_clear,
    'clients/refresh': clients_refresh,
}


def run():
    if PATH == '' and ARGS.get('action') in ('play_video', 'play'):
        return play()
    if PATH == '' and (ARGS.get('video_id') or ARGS.get('videoid')):
        return play()
    route = ROUTES.get(PATH)
    if not route:
        kodi.log('unknown route: %s' % PATH, xbmc.LOGWARNING)
        return root()
    try:
        route()
    except YTError as e:
        fail(e)


if __name__ == '__main__':
    run()
