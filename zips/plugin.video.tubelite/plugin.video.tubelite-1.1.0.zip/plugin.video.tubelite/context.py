import sys
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmc

YOUTUBE_PREFIXES = ('plugin://plugin.video.youtube', 'plugin://plugin.video.tubelite')


def youtube_id(trailer):
    """Video id from any YouTube-style trailer link, or None."""
    if not trailer:
        return None
    u = urlparse(trailer)
    q = dict(parse_qsl(u.query))
    if trailer.startswith(YOUTUBE_PREFIXES):
        return q.get('video_id') or q.get('videoid')
    if 'youtube.com' in u.netloc:
        return q.get('v')
    if 'youtu.be' in u.netloc:
        return u.path.strip('/') or None
    return None


def target_for(li):
    trailer = li.getProperty('trailer') or xbmc.getInfoLabel('ListItem.Trailer')
    if trailer.startswith('plugin://plugin.video.tubelite/trailer/'):
        return trailer
    vid = youtube_id(trailer)
    if vid:
        return 'plugin://plugin.video.tubelite/play/?video_id=%s' % vid
    if trailer and not trailer.startswith('plugin://'):
        return trailer
    dbtype = xbmc.getInfoLabel('ListItem.DBType')
    show = xbmc.getInfoLabel('ListItem.TVShowTitle')
    params = {'title': show or xbmc.getInfoLabel('ListItem.Title'),
              'type': 'tv' if show or dbtype in ('tvshow', 'season', 'episode') else 'movie'}
    if dbtype in ('season', 'episode'):
        params['season'] = xbmc.getInfoLabel('ListItem.Season')
    elif not show:
        params['year'] = xbmc.getInfoLabel('ListItem.Year')
    params = dict((k, v) for k, v in params.items() if v)
    if not params.get('title'):
        return None
    return 'plugin://plugin.video.tubelite/trailer/?' + urlencode(params)


if __name__ == '__main__':
    target = target_for(sys.listitem)
    if target:
        xbmc.executebuiltin('PlayMedia(%s)' % target)
