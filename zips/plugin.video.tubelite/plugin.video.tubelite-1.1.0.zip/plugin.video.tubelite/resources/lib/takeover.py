"""Installs (and removes) a stand-in plugin.video.youtube that forwards everything to TubeLite.

Kodi library trailers, skin info screens, context menus and many add-ons hard-code
plugin://plugin.video.youtube/... links. Putting a tiny add-on under that id is the
only way to catch all of them. Any existing YouTube add-on is moved into TubeLite's
profile folder first so it can be put back exactly as it was.
"""

import os
import re
import shutil
import time

import xbmc
import xbmcvfs

from . import kodi

YT_ID = 'plugin.video.youtube'


def _paths():
    addons = xbmcvfs.translatePath('special://home/addons/')
    return (os.path.join(addons, YT_ID),
            os.path.join(kodi.profile_dir(), 'youtube_backup', YT_ID),
            os.path.join(kodi.ADDON_PATH, 'resources', 'shim'))


def _shim_version(folder):
    try:
        with open(os.path.join(folder, 'default.py'), 'r') as f:
            m = re.match(r'TUBELITE_SHIM = (\d+)', f.read(200))
        return int(m.group(1)) if m else None
    except Exception:
        return None


def status():
    """'shim' if our stand-in is installed, 'other' if a different YouTube add-on is, else None."""
    target, _, _ = _paths()
    if not os.path.isdir(target):
        return None
    return 'shim' if _shim_version(target) is not None else 'other'


def has_backup():
    return os.path.isdir(_paths()[1])


def _register_and_enable(expect_version=None):
    xbmc.executebuiltin('UpdateLocalAddons')
    for _ in range(30):
        res = kodi.jsonrpc('Addons.GetAddonDetails', addonid=YT_ID, properties=['version'])
        version = ((res.get('result') or {}).get('addon') or {}).get('version')
        if version and (expect_version is None or version == expect_version):
            break
        time.sleep(0.5)
    kodi.jsonrpc('Addons.SetAddonEnabled', addonid=YT_ID, enabled=True)


def _copy_shim(src, target):
    if os.path.isdir(target):
        shutil.rmtree(target)
    shutil.copytree(src, target)
    shutil.copy(os.path.join(kodi.ADDON_PATH, 'icon.png'), os.path.join(target, 'icon.png'))
    for junk in ('__pycache__',):
        shutil.rmtree(os.path.join(target, junk), ignore_errors=True)


def install():
    target, backup, src = _paths()
    current = status()
    if current == 'other':
        if os.path.isdir(backup):
            shutil.rmtree(backup)
        os.makedirs(os.path.dirname(backup), exist_ok=True)
        kodi.jsonrpc('Addons.SetAddonEnabled', addonid=YT_ID, enabled=False)
        shutil.move(target, backup)
        kodi.log('moved existing YouTube add-on to %s' % backup)
    _copy_shim(src, target)
    _register_and_enable('100.0.0')
    kodi.set_setting('takeover', 'true')
    kodi.log('YouTube stand-in installed')


def remove():
    target, backup, _ = _paths()
    if status() == 'shim':
        kodi.jsonrpc('Addons.SetAddonEnabled', addonid=YT_ID, enabled=False)
        shutil.rmtree(target, ignore_errors=True)
    restored = False
    if os.path.isdir(backup) and not os.path.isdir(target):
        shutil.move(backup, target)
        restored = True
    if restored:
        _register_and_enable()
    else:
        xbmc.executebuiltin('UpdateLocalAddons')
    kodi.set_setting('takeover', 'false')
    kodi.log('YouTube stand-in removed (previous add-on restored: %s)' % restored)
    return restored


def sync():
    """Refreshes the installed stand-in after TubeLite updates ship a newer one."""
    target, _, src = _paths()
    if status() == 'shim' and _shim_version(target) != _shim_version(src):
        _copy_shim(src, target)
        _register_and_enable('100.0.0')
        kodi.log('YouTube stand-in updated')
