import re

from .innertube import YTError
from .parser import parse

VIDEOS_ONLY = 'EgIQAQ=='
NEW_THIS_WEEK = 'CAISBAgDEAE='
NEW_THIS_MONTH = 'CAISBAgEEAE='

BAD_WORDS = ('reaction', 'review', 'fan made', 'fanmade', 'concept', 'recap', 'explained', 'breakdown',
             'ending', 'theory', 'theories', 'parody', 'edit', 'amv', 'easter egg', 'behind the scenes',
             'interview', 'clip', 'scene', 'cast', 'blooper', 'ai trailer', 'what to know')


def norm(s):
    return re.sub(r'[^a-z0-9 ]+', ' ', (s or '').lower()).split()


def build_query(title, year='', kind='tv', season=''):
    parts = [title]
    if season and str(season) not in ('0', '1'):
        parts.append('season %s' % season)
    elif year:
        parts.append(str(year))
    parts.append('official trailer')
    return ' '.join(parts)


def score(item, title, year='', season=''):
    vt = ' '.join(norm(item.get('title')))
    want = norm(title)
    s = 0
    if want and all(w in vt.split() for w in want):
        s += 4
    elif want and ' '.join(want) in vt:
        s += 3
    if 'trailer' in vt:
        s += 3
    if 'official' in vt:
        s += 2
    if 'teaser' in vt:
        s += 1
    if season and str(season) not in ('0', '1'):
        if re.search(r'\bseason %s\b' % season, vt) or re.search(r'\bs%s\b' % season, vt):
            s += 3
        elif 'season' in vt:
            s -= 2
    if year and str(year) in vt:
        s += 1
    wanted = ' '.join(want)
    for w in BAD_WORDS:
        if re.search(r'\b%s\b' % re.escape(w), vt) and not re.search(r'\b%s\b' % re.escape(w), wanted):
            s -= 4
    d = item.get('duration') or 0
    if 30 <= d <= 330:
        s += 2
    elif d > 600:
        s -= 4
    if item.get('live'):
        s -= 10
    return s


def find(yt, title, year='', kind='tv', season=''):
    data = yt.search(build_query(title, year, kind, season), VIDEOS_ONLY)
    items = [i for i in parse(data)[0] if i['type'] == 'video']
    if not items:
        raise YTError('No trailers found for %s' % title)
    ranked = sorted(enumerate(items), key=lambda p: (-score(p[1], title, year, season), p[0]))
    return [i for _, i in ranked]
