import json
import os
import sys
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# Explicit id so the YouTube stand-in add-on can import this code and still use TubeLite's settings and data.
ADDON = xbmcaddon.Addon('plugin.video.tubelite')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))


def setting(key):
    return ADDON.getSetting(key)


def setting_bool(key):
    return ADDON.getSetting(key) == 'true'


def setting_int(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except (TypeError, ValueError):
        return default


def set_setting(key, value):
    ADDON.setSetting(key, value)


def profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, title=None, ms=4000):
    xbmcgui.Dialog().notification(title or ADDON_NAME, msg, os.path.join(ADDON_PATH, 'icon.png'), ms)


def keyboard(heading, default=''):
    kb = xbmc.Keyboard(default, heading)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText().strip()
    return ''


def url(path, **params):
    params = dict((k, v) for k, v in params.items() if v not in (None, ''))
    base = 'plugin://%s/%s/' % (ADDON_ID, path.strip('/')) if path else 'plugin://%s/' % ADDON_ID
    return base + ('?' + urlencode(params) if params else '')


def icon(name):
    return os.path.join(ADDON_PATH, 'resources', 'media', name)


def handle():
    return int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1


def jsonrpc(method, **params):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
