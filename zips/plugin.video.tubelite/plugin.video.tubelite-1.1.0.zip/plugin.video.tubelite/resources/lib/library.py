"""Gives library movies and TV shows a working trailer when the scraper left it blank.

The trailer link is a lazy TubeLite search (title + year), so nothing is looked up
until someone presses Play Trailer. Kodi's own info screen trailer button then
works for these items like any scraped trailer.
"""

from urllib.parse import urlencode

import xbmc

from . import kodi

PREFIX = 'plugin://plugin.video.tubelite/trailer/'

KINDS = (
    # (get method, set method, result key, id key, trailer type)
    ('VideoLibrary.GetMovies', 'VideoLibrary.SetMovieDetails', 'movies', 'movieid', 'movie'),
    ('VideoLibrary.GetTVShows', 'VideoLibrary.SetTVShowDetails', 'tvshows', 'tvshowid', 'tv'),
)


def trailer_url(title, year, kind):
    return PREFIX + '?' + urlencode(dict((k, v) for k, v in
                                         (('title', title), ('year', year or ''), ('type', kind)) if v))


def _items(get_method, key):
    res = kodi.jsonrpc(get_method, properties=['title', 'year', 'trailer'])
    if 'error' in res:
        return None
    return (res.get('result') or {}).get(key) or []


def fill(monitor=None):
    """Adds lazy trailer links to items with none. Returns {kind: count} (None if the kind is unsupported)."""
    done = {}
    for get_m, set_m, key, id_key, kind in KINDS:
        items = _items(get_m, key)
        if items is None:
            kodi.log('library: %s has no trailer field on this Kodi version, skipping' % key)
            done[key] = None
            continue
        count = 0
        for it in items:
            if monitor and monitor.abortRequested():
                return done
            if it.get('trailer') or not it.get('title'):
                continue
            res = kodi.jsonrpc(set_m, **{id_key: it[id_key], 'trailer': trailer_url(it['title'], it.get('year'), kind)})
            if 'error' in res:
                kodi.log('library: %s rejected trailer field: %s' % (set_m, res['error']))
                break
            count += 1
            if count % 50 == 0:
                xbmc.sleep(200)
        done[key] = count
        if count:
            kodi.log('library: added trailer links to %d %s' % (count, key))
    return done


def clear():
    """Removes only the links TubeLite added; scraped trailers are left alone."""
    removed = 0
    for get_m, set_m, key, id_key, kind in KINDS:
        for it in _items(get_m, key) or []:
            if (it.get('trailer') or '').startswith(PREFIX):
                kodi.jsonrpc(set_m, **{id_key: it[id_key], 'trailer': ''})
                removed += 1
    kodi.log('library: removed %d TubeLite trailer links' % removed)
    return removed
