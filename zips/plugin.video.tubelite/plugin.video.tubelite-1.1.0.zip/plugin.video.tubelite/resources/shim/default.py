TUBELITE_SHIM = 2

import sys
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmcvfs

TUBELITE = xbmcvfs.translatePath('special://home/addons/plugin.video.tubelite')
TABS = {'playlists': 'playlists', 'live': 'streams', 'streams': 'streams', 'shorts': 'shorts', 'videos': 'videos'}


def video_from(value):
    if not value:
        return None
    if len(value) == 11 and '/' not in value:
        return value
    u = urlparse(value)
    q = dict(parse_qsl(u.query))
    if q.get('v'):
        return q['v']
    last = u.path.rstrip('/').split('/')[-1]
    return last if len(last) == 11 else None


def translate(path, args):
    """Maps plugin.video.youtube URL styles onto TubeLite routes."""
    parts = [p for p in path.strip('/').split('/') if p]
    head = parts[0] if parts else ''
    vid = args.get('video_id') or args.get('videoid') or args.get('v')

    if head == 'uri2addon':
        vid = video_from(args.get('uri'))
    if vid and head in ('', 'play', 'uri2addon'):
        return 'play', {'video_id': vid}
    if head == 'play' and args.get('playlist_id'):
        return 'playlist', {'id': args['playlist_id']}
    if head == 'channel' and len(parts) > 1:
        tab = TABS.get(parts[2]) if len(parts) > 2 else None
        if tab:
            return 'channel/tab', {'id': parts[1], 'tab': tab}
        return 'channel', {'id': parts[1]}
    if head in ('user', 'handle', 'c') and len(parts) > 1:
        handle = parts[1] if parts[1].startswith('@') else '@' + parts[1]
        return 'channel', {'id': handle}
    if head == 'playlist' and len(parts) > 1:
        return 'playlist', {'id': parts[1]}
    if head == 'search' or parts[:2] == ['kodion', 'search']:
        q = args.get('q') or args.get('query')
        return ('search/results', {'q': q, 'kind': 'all'}) if q else ('search', {})
    return '', {}


def run():
    path = urlparse(sys.argv[0]).path
    args = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    route, params = translate(path, args)
    target = 'plugin://plugin.video.tubelite/%s/' % route if route else 'plugin://plugin.video.tubelite/'
    sys.argv = [target, sys.argv[1] if len(sys.argv) > 1 else '-1', ('?' + urlencode(params)) if params else '']
    sys.path.insert(0, TUBELITE)
    import main as tubelite
    tubelite.run()


if __name__ == '__main__':
    run()
