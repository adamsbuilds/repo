TUBELITE_SHIM = 3

import os
import sys
import xml.etree.ElementTree as ET
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmcvfs

ADDON_ROOTS = (xbmcvfs.translatePath('special://home/addons'), xbmcvfs.translatePath('special://xbmc/addons'))
TUBELITE = os.path.join(ADDON_ROOTS[0], 'plugin.video.tubelite')
TABS = {'playlists': 'playlists', 'live': 'streams', 'streams': 'streams', 'shorts': 'shorts', 'videos': 'videos'}


def video_from(value):
    if not value:
        return None
    if len(value) == 11 and '/' not in value:
        return value
    u = urlparse(value)
    q = dict(parse_qsl(u.query))
    if q.get('v'):
        return q['v']
    last = u.path.rstrip('/').split('/')[-1]
    return last if len(last) == 11 else None


def translate(path, args):
    """Maps plugin.video.youtube URL styles onto TubeLite routes."""
    parts = [p for p in path.strip('/').split('/') if p]
    head = parts[0] if parts else ''
    vid = args.get('video_id') or args.get('videoid') or args.get('v')

    if head == 'uri2addon':
        vid = video_from(args.get('uri'))
    if vid and head in ('', 'play', 'uri2addon'):
        return 'play', {'video_id': vid}
    if head == 'play' and args.get('playlist_id'):
        return 'playlist', {'id': args['playlist_id']}
    if head == 'channel' and len(parts) > 1:
        tab = TABS.get(parts[2]) if len(parts) > 2 else None
        if tab:
            return 'channel/tab', {'id': parts[1], 'tab': tab}
        return 'channel', {'id': parts[1]}
    if head in ('user', 'handle', 'c') and len(parts) > 1:
        handle = parts[1] if parts[1].startswith('@') else '@' + parts[1]
        return 'channel', {'id': handle}
    if head == 'playlist' and len(parts) > 1:
        return 'playlist', {'id': parts[1]}
    if head == 'search' or parts[:2] == ['kodion', 'search']:
        q = args.get('q') or args.get('query')
        return ('search/results', {'q': q, 'kind': 'all'}) if q else ('search', {})
    return '', {}


def add_module_paths(addon_id, seen=None):
    """Puts every Python module TubeLite depends on onto sys.path.

    Kodi only hands an add-on the modules it declares itself (and their own
    dependencies), not the dependencies of another plugin it imports, so the
    stand-in walks TubeLite's requirements and adds them the way Kodi would.
    """
    seen = seen if seen is not None else set()
    for root in ADDON_ROOTS:
        folder = os.path.join(root, addon_id)
        if os.path.exists(os.path.join(folder, 'addon.xml')):
            break
    else:
        return
    try:
        tree = ET.parse(os.path.join(folder, 'addon.xml')).getroot()
    except Exception:
        return
    for ext in tree.findall('extension'):
        if ext.get('point') == 'xbmc.python.module':
            path = os.path.join(folder, ext.get('library') or 'lib')
            if path not in sys.path:
                sys.path.append(path)
    for imp in tree.findall('requires/import'):
        dep = imp.get('addon') or ''
        if dep and dep not in seen and not dep.startswith('xbmc.') and not dep.startswith('kodi.'):
            seen.add(dep)
            add_module_paths(dep, seen)


def run():
    path = urlparse(sys.argv[0]).path
    args = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    route, params = translate(path, args)
    target = 'plugin://plugin.video.tubelite/%s/' % route if route else 'plugin://plugin.video.tubelite/'
    sys.argv = [target, sys.argv[1] if len(sys.argv) > 1 else '-1', ('?' + urlencode(params)) if params else '']
    add_module_paths('plugin.video.tubelite')
    sys.path.insert(0, TUBELITE)
    import main as tubelite
    tubelite.run()


if __name__ == '__main__':
    run()
