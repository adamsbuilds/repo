import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import xbmc
import xbmcgui

from resources.lib import kodi


class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        m = re.match(r'^/mpd/([A-Za-z0-9_-]{11})\.mpd$', self.path.split('?')[0])
        path = os.path.join(kodi.profile_dir(), 'mpd', '%s.mpd' % m.group(1)) if m else None
        if not path or not os.path.exists(path):
            self.send_error(404)
            return
        with open(path, 'rb') as f:
            body = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class Monitor(xbmc.Monitor):
    def __init__(self):
        super(Monitor, self).__init__()
        self.library_pending = False

    def onSettingsChanged(self):
        set_context_flag()
        if kodi.setting_bool('library_fill'):
            self.library_pending = True

    def onNotification(self, sender, method, data):
        if method == 'VideoLibrary.OnScanFinished' and kodi.setting_bool('library_fill'):
            self.library_pending = True


class Player(xbmc.Player):
    """Watches playback that TubeLite started: SponsorBlock skipping and YouTube watch history."""

    def __init__(self, monitor):
        super(Player, self).__init__()
        self.monitor = monitor
        self.session_id = 0

    def onAVStarted(self):
        win = xbmcgui.Window(10000)
        vid = win.getProperty('tubelite.playing')
        try:
            ts = int(win.getProperty('tubelite.playing_ts') or 0)
        except ValueError:
            ts = 0
        win.clearProperty('tubelite.playing')
        win.clearProperty('tubelite.playing_ts')
        self.session_id += 1
        if not vid or time.time() - ts > 120:
            return
        sid = self.session_id
        if kodi.setting_bool('sb_enabled'):
            t = threading.Thread(target=self.skip_loop, args=(vid, sid))
            t.daemon = True
            t.start()
        if kodi.setting_bool('report_history'):
            t = threading.Thread(target=self.report, args=(vid,))
            t.daemon = True
            t.start()

    def onPlayBackStopped(self):
        self.session_id += 1

    def onPlayBackEnded(self):
        self.session_id += 1

    def report(self, vid):
        from resources.lib import auth
        from resources.lib.innertube import InnerTube
        if not auth.signed_in():
            return
        try:
            ok = InnerTube().report_watched(vid)
            kodi.log('YouTube history %s for %s' % ('updated' if ok else 'not updated', vid))
        except Exception as e:
            kodi.log('YouTube history report failed: %s' % e, xbmc.LOGWARNING)

    def skip_loop(self, vid, sid):
        from resources.lib import sponsorblock
        from resources.lib.innertube import InnerTube
        try:
            segs = sponsorblock.segments(InnerTube().session, vid)
        except Exception as e:
            kodi.log('SponsorBlock lookup failed: %s' % e, xbmc.LOGWARNING)
            return
        if not segs:
            return
        kodi.log('SponsorBlock: %d segment(s) for %s' % (len(segs), vid))
        skipped = set()
        while sid == self.session_id and not self.monitor.abortRequested():
            try:
                if not self.isPlayingVideo():
                    break
                hit = sponsorblock.due(segs, self.getTime(), skipped)
            except Exception:
                break
            if hit:
                i, end, cat = hit
                skipped.add(i)
                try:
                    total = self.getTotalTime()
                    self.seekTime(min(end, total - 1) if total else end)
                except Exception:
                    continue
                if kodi.setting_bool('sb_notify'):
                    kodi.notify('Skipped %s' % sponsorblock.LABELS.get(cat, cat), 'SponsorBlock', 2000)
            if len(skipped) == len(segs) or self.monitor.waitForAbort(0.5):
                break


def set_context_flag():
    xbmcgui.Window(10000).setProperty('tubelite.context', '1' if kodi.setting_bool('context_menu') else '')


def start_server():
    port = kodi.setting_int('server_port', 50152) or 50152
    try:
        server = Server(('127.0.0.1', port), Handler)
    except Exception as e:
        kodi.log('could not start manifest server on port %d: %s' % (port, e), xbmc.LOGERROR)
        return None
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    kodi.log('manifest server listening on 127.0.0.1:%d' % port)
    return server


def background_jobs(monitor):
    """Client refresh and library trailer fill, kept off the startup path."""
    if monitor.waitForAbort(20):
        return
    library_done = False
    while not monitor.abortRequested():
        if kodi.setting_bool('auto_clients'):
            try:
                from resources.lib import clientupdate
                from resources.lib.innertube import InnerTube
                clientupdate.refresh(InnerTube(), reason='daily')
            except Exception as e:
                kodi.log('client refresh failed: %s' % e, xbmc.LOGWARNING)
        if kodi.setting_bool('library_fill') and (not library_done or monitor.library_pending):
            monitor.library_pending = False
            try:
                from resources.lib import library
                library.fill(monitor)
                library_done = True
            except Exception as e:
                kodi.log('library fill failed: %s' % e, xbmc.LOGWARNING)
        # Wake every minute for library scans; the client refresh only re-runs once a day.
        if monitor.waitForAbort(60):
            break


def run():
    monitor = Monitor()
    kodi.migrate_from_tubelite()
    set_context_flag()
    server = start_server()
    player = Player(monitor)
    jobs = threading.Thread(target=background_jobs, args=(monitor,))
    jobs.daemon = True
    jobs.start()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    del player
    if server:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    run()
