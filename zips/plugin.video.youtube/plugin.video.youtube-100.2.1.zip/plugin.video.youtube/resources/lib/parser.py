"""Turns InnerTube page JSON into plain item dicts.

Walks the whole response and picks out every renderer it recognises, in page
order, so it keeps working when YouTube shuffles the surrounding layout.
"""

import re

SKIP_KEYS = {
    'adSlotRenderer', 'promotedSparklesWebRenderer', 'searchPyvRenderer', 'promotedVideoRenderer',
    'responseContext', 'topbar', 'frameworkUpdates', 'microformat', 'header', 'sidebar',
    'engagementPanels', 'overlay', 'playerOverlays', 'compactPromotedVideoRenderer',
    'menu', 'thumbnailOverlays',
}

SHORTS_KEYS = {'reelItemRenderer', 'shortsLockupViewModel', 'reelShelfRenderer'}


def text(obj):
    if not obj:
        return ''
    if isinstance(obj, str):
        return obj
    if 'simpleText' in obj:
        return obj['simpleText']
    if 'runs' in obj:
        return ''.join(r.get('text', '') for r in obj['runs'])
    if 'content' in obj:
        return obj['content']
    return ''


def duration_seconds(value):
    if not value:
        return 0
    value = value.strip()
    if not re.match(r'^\d+(:\d+){0,2}$', value):
        return 0
    total = 0
    for part in value.split(':'):
        total = total * 60 + int(part)
    return total


def best_thumb(thumbs):
    if isinstance(thumbs, dict):
        thumbs = thumbs.get('thumbnails') or thumbs.get('sources') or []
    if not thumbs:
        return ''
    url = sorted(thumbs, key=lambda t: t.get('width', 0) or 0)[-1].get('url', '')
    if url.startswith('//'):
        url = 'https:' + url
    return url


def video_thumb(video_id):
    return 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % video_id


def _channel_from_runs(obj):
    for run in (obj or {}).get('runs', []):
        ep = (run.get('navigationEndpoint') or {}).get('browseEndpoint') or {}
        if ep.get('browseId'):
            return run.get('text', ''), ep['browseId']
    return text(obj), ''


def _video(r):
    vid = r.get('videoId')
    if not vid:
        return None
    channel, channel_id = _channel_from_runs(r.get('ownerText') or r.get('longBylineText') or r.get('shortBylineText'))
    length = text(r.get('lengthText'))
    if not length:
        for ov in r.get('thumbnailOverlays', []):
            st = ov.get('thumbnailOverlayTimeStatusRenderer')
            if st:
                length = text(st.get('text'))
                if st.get('style') == 'LIVE':
                    length = 'LIVE'
    desc = ''
    for snip in r.get('detailedMetadataSnippets', []):
        desc = text(snip.get('snippetText'))
        break
    if not desc:
        desc = text(r.get('descriptionSnippet'))
    return {
        'type': 'video',
        'id': vid,
        'title': text(r.get('title')) or text(r.get('headline')),
        'channel': channel,
        'channel_id': channel_id,
        'duration': duration_seconds(length),
        'live': length == 'LIVE' or bool(r.get('badges') and any(
            'LIVE' in str(b) for b in r.get('badges', []))),
        'views': text(r.get('shortViewCountText')) or text(r.get('viewCountText')),
        'published': text(r.get('publishedTimeText')),
        'description': desc,
        'thumb': video_thumb(vid),
    }


def _lockup(vm):
    cid = vm.get('contentId')
    ctype = vm.get('contentType', '')
    if not cid:
        return None
    meta = (vm.get('metadata') or {}).get('lockupMetadataViewModel') or {}
    title = text(meta.get('title'))
    rows = (((meta.get('metadata') or {}).get('contentMetadataViewModel') or {}).get('metadataRows')) or []
    channel, channel_id, parts = '', '', []
    for row in rows:
        for part in row.get('metadataParts') or []:
            t = part.get('text') or {}
            content = t.get('content', '')
            for cr in t.get('commandRuns') or []:
                be = (((cr.get('onTap') or {}).get('innertubeCommand') or {}).get('browseEndpoint')) or {}
                if be.get('browseId', '').startswith('UC'):
                    channel, channel_id = content, be['browseId']
            if content and content != channel:
                parts.append(content)
    image = vm.get('contentImage') or {}
    badges = []

    def collect_badges(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == 'thumbnailBadgeViewModel':
                    badges.append(v.get('text', ''))
                else:
                    collect_badges(v)
        elif isinstance(o, list):
            for v in o:
                collect_badges(v)

    collect_badges(image)
    if ctype == 'LOCKUP_CONTENT_TYPE_VIDEO':
        dur = 0
        live = False
        for b in badges:
            if duration_seconds(b):
                dur = duration_seconds(b)
            elif b.upper() == 'LIVE':
                live = True
        return {
            'type': 'video', 'id': cid, 'title': title, 'channel': channel, 'channel_id': channel_id,
            'duration': dur, 'live': live,
            'views': parts[0] if parts else '', 'published': parts[1] if len(parts) > 1 else '',
            'description': '', 'thumb': video_thumb(cid),
        }
    if ctype in ('LOCKUP_CONTENT_TYPE_PLAYLIST', 'LOCKUP_CONTENT_TYPE_PODCAST'):
        thumb_src = (((image.get('collectionThumbnailViewModel') or {}).get('primaryThumbnail') or {})
                     .get('thumbnailViewModel') or {}).get('image') or {}
        count = next((b for b in badges if re.search(r'\d', b) and re.search(r'[a-zA-Z]', b)),
                     next((b for b in badges if re.search(r'\d', b)), ''))
        return {
            'type': 'playlist', 'id': cid, 'title': title, 'channel': channel, 'channel_id': channel_id,
            'count': count, 'thumb': best_thumb(thumb_src),
        }
    return None


def _short(r):
    vid = r.get('videoId')
    title = text(r.get('headline'))
    if not vid:
        cmd = ((r.get('onTap') or {}).get('innertubeCommand') or {}).get('reelWatchEndpoint') or {}
        vid = cmd.get('videoId')
        title = text(((r.get('overlayMetadata') or {}).get('primaryText')))
    if not vid:
        return None
    return {'type': 'video', 'id': vid, 'title': title, 'channel': '', 'channel_id': '', 'duration': 0,
            'live': False, 'views': text(r.get('viewCountText')), 'published': '', 'description': '',
            'thumb': video_thumb(vid), 'short': True}


def _channel(r):
    cid = r.get('channelId')
    if not cid:
        return None
    return {
        'type': 'channel', 'id': cid, 'title': text(r.get('title')),
        'subs': text(r.get('videoCountText')) or text(r.get('subscriberCountText')),
        'description': text(r.get('descriptionSnippet')),
        'thumb': best_thumb(r.get('thumbnail')),
    }


def _playlist(r):
    pid = r.get('playlistId')
    if not pid:
        return None
    thumbs = r.get('thumbnails') or []
    thumb = best_thumb(thumbs[0]) if thumbs else best_thumb(r.get('thumbnail'))
    channel, channel_id = _channel_from_runs(r.get('longBylineText') or r.get('shortBylineText'))
    return {
        'type': 'playlist', 'id': pid, 'title': text(r.get('title')), 'channel': channel,
        'channel_id': channel_id, 'count': text(r.get('videoCountText')) or str(r.get('videoCount', '')),
        'thumb': thumb,
    }


def _tile(r):
    """YouTube TV app tile (what signed-in pages are built from)."""
    meta = ((r.get('metadata') or {}).get('tileMetadataRenderer')) or {}
    head = ((r.get('header') or {}).get('tileHeaderRenderer')) or {}
    lines = []
    for line in meta.get('lines') or []:
        parts = [text((i.get('lineItemRenderer') or {}).get('text'))
                 for i in ((line or {}).get('lineRenderer') or {}).get('items') or []]
        parts = [p for p in parts if p and p.strip() not in ('•', '·')]
        if parts:
            lines.append(parts)
    length, live, short = '', False, False
    for ov in head.get('thumbnailOverlays') or []:
        st = ov.get('thumbnailOverlayTimeStatusRenderer')
        if st:
            length = text(st.get('text'))
            live = live or st.get('style') == 'LIVE'
            short = short or st.get('style') == 'SHORTS'
    short = short or 'SHORTS' in (r.get('style') or '')
    sel = r.get('onSelectCommand') or {}
    watch = sel.get('watchEndpoint') or (sel.get('reelWatchEndpoint') or {})
    browse = sel.get('browseEndpoint') or {}
    ctype = r.get('contentType') or ''
    title = text(meta.get('title'))
    thumb = best_thumb(head.get('thumbnail'))
    if ctype == 'TILE_CONTENT_TYPE_PLAYLIST' or (watch.get('playlistId') and not watch.get('videoId')):
        pid = r.get('contentId') or watch.get('playlistId') or (browse.get('browseId') or '')[2:]
        if not pid:
            return None
        return {'type': 'playlist', 'id': pid, 'title': title, 'channel': (lines[0][0] if lines else ''),
                'channel_id': '', 'count': length, 'thumb': thumb}
    if ctype == 'TILE_CONTENT_TYPE_CHANNEL' or (browse.get('browseId', '').startswith('UC') and not watch):
        cid = browse.get('browseId') or r.get('contentId')
        if not cid:
            return None
        return {'type': 'channel', 'id': cid, 'title': title,
                'subs': ' · '.join(lines[0]) if lines else '', 'description': '', 'thumb': thumb}
    vid = watch.get('videoId') or (r.get('contentId') if ctype == 'TILE_CONTENT_TYPE_VIDEO' else None)
    if not vid:
        return None
    info = lines[1] if len(lines) > 1 else (lines[0][1:] if lines and len(lines[0]) > 1 else [])
    return {
        'type': 'video', 'id': vid, 'title': title, 'channel': lines[0][0] if lines else '', 'channel_id': '',
        'duration': duration_seconds(length), 'live': live,
        'views': info[0] if info else '', 'published': info[1] if len(info) > 1 else '',
        'description': '', 'thumb': video_thumb(vid), 'short': short,
    }


HANDLERS = {
    'tileRenderer': _tile,
    'videoRenderer': _video,
    'compactVideoRenderer': _video,
    'gridVideoRenderer': _video,
    'playlistVideoRenderer': _video,
    'videoWithContextRenderer': _video,
    'lockupViewModel': _lockup,
    'reelItemRenderer': _short,
    'shortsLockupViewModel': _short,
    'channelRenderer': _channel,
    'gridChannelRenderer': _channel,
    'playlistRenderer': _playlist,
    'gridPlaylistRenderer': _playlist,
}


def _continuation_token(r):
    cmd = ((r.get('continuationEndpoint') or {}).get('continuationCommand')) or {}
    if cmd.get('token'):
        return cmd['token']
    btn = ((r.get('button') or {}).get('buttonRenderer') or {}).get('command') or {}
    return (btn.get('continuationCommand') or {}).get('token')


def parse(data, include_shorts=False):
    """Returns (items, continuation_token)."""
    items, seen, token = [], set(), [None]

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k in SKIP_KEYS:
                    continue
                if not include_shorts and k in SHORTS_KEYS:
                    continue
                if k == 'continuationItemRenderer' and isinstance(v, dict):
                    t = _continuation_token(v)
                    if t:
                        token[0] = t
                    continue
                if k == 'horizontalListRenderer' and isinstance(v, dict):
                    # A row on a TV page: take its items but not its own "more of this row" token.
                    walk(v.get('items'))
                    continue
                if k == 'nextContinuationData' and isinstance(v, dict):
                    if v.get('continuation'):
                        token[0] = v['continuation']
                    continue
                handler = HANDLERS.get(k)
                if handler and isinstance(v, dict):
                    item = handler(v)
                    if item and not item.get('title'):
                        item['_renderer'] = k
                    if item and (item['type'], item['id']) not in seen:
                        if include_shorts or not item.get('short'):
                            seen.add((item['type'], item['id']))
                            items.append(item)
                    continue
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    walk(data)
    return items, token[0]


def related_section(data):
    """Narrows a /next response to the related-videos column so comment tokens aren't picked up."""
    try:
        return data['contents']['twoColumnWatchNextResults']['secondaryResults']
    except (KeyError, TypeError):
        pass
    actions = data.get('onResponseReceivedEndpoints') or []
    return [a for a in actions if 'comment' not in str((a.get('appendContinuationItemsAction') or {})
                                                         .get('targetId', '')).lower()]


def channel_title(data):
    md = (data.get('metadata') or {}).get('channelMetadataRenderer') or {}
    return md.get('title', ''), best_thumb(md.get('avatar'))


def video_details(data):
    """Pulls title/description/channel out of a /next response's primary column."""
    out = {}
    try:
        contents = data['contents']['twoColumnWatchNextResults']['results']['results']['contents']
    except (KeyError, TypeError):
        return out
    for c in contents:
        p = c.get('videoPrimaryInfoRenderer')
        if p:
            out['title'] = text(p.get('title'))
        s = c.get('videoSecondaryInfoRenderer')
        if s:
            owner = (s.get('owner') or {}).get('videoOwnerRenderer') or {}
            out['channel'], out['channel_id'] = _channel_from_runs(owner.get('title'))
            out['description'] = text(s.get('attributedDescription')) or text(s.get('description'))
    return out
