import json
import os
import re
import time

import requests

from . import kodi

BASE = 'https://www.youtube.com'
API = BASE + '/youtubei/v1/'

WEB_FALLBACK_VERSION = '2.20260708.00.00'
WEB_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
          '(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36')

# Player clients that return plain stream URLs without needing YouTube's
# player JavaScript. These are the built-in backup; clientupdate.py keeps an
# auto-updated, live-tested list in clients.json that takes priority.
PLAYER_CLIENTS = {
    'visionos': {
        'id': 101,
        'context': {
            'clientName': 'VISIONOS',
            'clientVersion': '1.02',
            'deviceMake': 'Apple',
            'deviceModel': 'RealityDevice17,1',
            'userAgent': ('Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 '
                          '(KHTML, like Gecko) Version/26.0 Safari/605.1.15'),
            'osName': 'visionOS',
            'osVersion': '26.5.23O471',
        },
    },
    'android_vr': {
        'id': 28,
        'context': {
            'clientName': 'ANDROID_VR',
            'clientVersion': '1.65.10',
            'deviceMake': 'Oculus',
            'deviceModel': 'Quest 3',
            'androidSdkVersion': 32,
            'userAgent': ('com.google.android.apps.youtube.vr.oculus/1.65.10 '
                          '(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip'),
            'osName': 'Android',
            'osVersion': '12L',
        },
    },
    'ios': {
        'id': 5,
        'context': {
            'clientName': 'IOS',
            'clientVersion': '21.26.4',
            'deviceMake': 'Apple',
            'deviceModel': 'iPhone16,2',
            'userAgent': 'com.google.ios.youtube/21.26.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)',
            'osName': 'iPhone',
            'osVersion': '18.3.2.22D82',
        },
    },
}


# Explore page (YouTube folded the old Trending page into it).
TRENDING_PARAMS = '6gQJRkVleHBsb3Jl'

# Signed-in requests use YouTube's TV app client; clientupdate.py keeps its version current.
TV_CLIENT = {
    'clientName': 'TVHTML5',
    'clientVersion': '7.20260901.15.00',
    'userAgent': ('Mozilla/5.0 (ChromiumStylePlatform) Cobalt/25.lts.30.1034943-gold (unlike Gecko), '
                  'Unknown_TV_Unknown_0/Unknown (Unknown, Unknown)'),
}


class YTError(Exception):
    pass


class InnerTube(object):
    """Talks to YouTube the same way the website does for a signed-out visitor."""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': WEB_UA, 'Accept-Language': 'en-US,en;q=0.9'})
        self.session.cookies.set('SOCS', 'CAI', domain='.youtube.com')
        self.session.cookies.set('CONSENT', 'YES+', domain='.youtube.com')
        self.hl = kodi.setting('hl') or 'en'
        self.gl = (kodi.setting('gl') or 'US').upper()
        self._state = None
        self._clients = None

    # ---- session state (web client version + visitor id), cached for 12h ----

    def _state_path(self):
        return os.path.join(kodi.profile_dir(), 'session.json')

    def state(self):
        if self._state:
            return self._state
        path = self._state_path()
        try:
            with open(path, 'r') as f:
                st = json.load(f)
            if time.time() - st.get('ts', 0) < 12 * 3600 and st.get('visitor'):
                self._state = st
                return st
        except Exception:
            pass
        st = {'ts': time.time(), 'version': WEB_FALLBACK_VERSION, 'visitor': ''}
        try:
            html = self.session.get(BASE + '/', timeout=15).text
            m = re.search(r'"INNERTUBE_CLIENT_VERSION":"([^"]+)"', html)
            if m:
                st['version'] = m.group(1)
            m = re.search(r'"VISITOR_DATA":"([^"]+)"', html)
            if m:
                st['visitor'] = m.group(1)
        except Exception as e:
            kodi.log('homepage bootstrap failed: %s' % e)
        self._state = st
        try:
            with open(path, 'w') as f:
                json.dump(st, f)
        except Exception:
            pass
        return st

    def reset_state(self):
        self._state = None
        try:
            os.remove(self._state_path())
        except Exception:
            pass

    # ---- web client calls (search / browse / next / resolve_url) ----

    def _web_context(self):
        st = self.state()
        client = {
            'clientName': 'WEB',
            'clientVersion': st['version'],
            'hl': self.hl,
            'gl': self.gl,
            'userAgent': WEB_UA,
        }
        if st.get('visitor'):
            client['visitorData'] = st['visitor']
        return {'client': client}

    def call(self, endpoint, payload):
        st = self.state()
        body = {'context': self._web_context()}
        body.update(payload)
        headers = {
            'Content-Type': 'application/json',
            'Origin': BASE,
            'Referer': BASE + '/',
            'X-YouTube-Client-Name': '1',
            'X-YouTube-Client-Version': st['version'],
        }
        if st.get('visitor'):
            headers['X-Goog-Visitor-Id'] = st['visitor']
        r = self.session.post(API + endpoint, params={'prettyPrint': 'false'},
                              data=json.dumps(body), headers=headers, timeout=20)
        if r.status_code != 200:
            raise YTError('YouTube returned HTTP %s for %s' % (r.status_code, endpoint))
        data = r.json()
        visitor = (data.get('responseContext') or {}).get('visitorData')
        if visitor and not st.get('visitor'):
            st['visitor'] = visitor
        return data

    def search(self, query, params=None, continuation=None):
        if continuation:
            return self.call('search', {'continuation': continuation})
        payload = {'query': query}
        if params:
            payload['params'] = params
        return self.call('search', payload)

    def browse(self, browse_id=None, params=None, continuation=None):
        if continuation:
            return self.call('browse', {'continuation': continuation})
        payload = {'browseId': browse_id}
        if params:
            payload['params'] = params
        return self.call('browse', payload)

    def next(self, video_id=None, continuation=None):
        if continuation:
            return self.call('next', {'continuation': continuation})
        return self.call('next', {'videoId': video_id, 'contentCheckOk': True, 'racyCheckOk': True})

    def resolve_url(self, url):
        data = self.call('navigation/resolve_url', {'url': url})
        ep = (data.get('endpoint') or {}).get('browseEndpoint')
        if not ep:
            raise YTError('Could not resolve %s' % url)
        return ep

    def channel_tab(self, channel, tab='videos', continuation=None):
        """channel is a UC... id or an @handle."""
        if continuation:
            return self.browse(continuation=continuation)
        if channel.startswith('@'):
            url = '%s/%s/%s' % (BASE, channel, tab)
        else:
            url = '%s/channel/%s/%s' % (BASE, channel, tab)
        ep = self.resolve_url(url)
        return self.browse(ep.get('browseId'), ep.get('params'))

    # ---- signed-in calls, made as YouTube's TV app (the only client YouTube's TV sign-in works with) ----

    def tv_client(self):
        """TVHTML5 context; the version comes from the auto-updated client list when available."""
        ctx = dict(TV_CLIENT)
        try:
            with open(os.path.join(kodi.profile_dir(), 'clients_meta.json')) as f:
                tv = (json.load(f).get('tv_client') or {})
            if tv.get('clientVersion'):
                ctx.update(clientVersion=tv['clientVersion'], userAgent=tv.get('userAgent') or ctx['userAgent'])
        except Exception:
            pass
        return ctx

    def tv_call(self, endpoint, payload, browse=False, require_auth=True):
        """A request as YouTube's TV app. Signed in when possible; Home and the topic sections
        also work signed out, like SmartTube."""
        from . import auth
        token = auth.access_token(self.session)
        if not token and require_auth:
            raise YTError('Sign in to YouTube first (TubeLite settings → Account)')
        st = self.state()
        client = self.tv_client()
        client.update(hl=self.hl, gl=self.gl, clientScreen='WATCH')
        if st.get('visitor'):
            client['visitorData'] = st['visitor']
        body = {'context': {'client': client, 'user': {'enableSafetyMode': False}},
                'racyCheckOk': True, 'contentCheckOk': True}
        if browse:
            body['tvAppInfo'] = {'appQuality': 'TV_APP_QUALITY_FULL_ANIMATION', 'zylonLeftNav': True}
        body.update(payload)
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': client['userAgent'],
            'Origin': BASE,
            'Referer': BASE + '/tv',
            'X-YouTube-Client-Name': '7',
            'X-YouTube-Client-Version': client['clientVersion'],
        }
        if token:
            headers['Authorization'] = 'Bearer %s' % token
        if st.get('visitor'):
            headers['X-Goog-Visitor-Id'] = st['visitor']
        r = self.session.post(API + endpoint, params={'prettyPrint': 'false'}, data=json.dumps(body),
                              headers=headers, timeout=20)
        if r.status_code == 401:
            raise YTError('YouTube rejected the sign-in. Try signing in again.')
        if r.status_code != 200:
            raise YTError('YouTube returned HTTP %s for %s' % (r.status_code, endpoint))
        return r.json()

    def account_browse(self, browse_id=None, continuation=None, require_auth=True):
        if continuation:
            return self.tv_call('browse', {'continuation': continuation}, browse=True, require_auth=require_auth)
        return self.tv_call('browse', {'browseId': browse_id}, browse=True, require_auth=require_auth)

    def trending(self, continuation=None, explore=True):
        if continuation:
            return self.browse(continuation=continuation)
        return self.browse('FEtrending', TRENDING_PARAMS if explore else None)

    def shorts(self, continuation=None):
        """Shorts feed as (video ids, next token), using the same calls as YouTube's Shorts player."""
        ids = []
        if not continuation:
            first = self.call('reel/reel_item_watch', {'disablePlayerResponse': True,
                                                       'inputType': 'REEL_WATCH_INPUT_TYPE_SEEDLESS',
                                                       'params': 'CA8%3D'})
            vid = ((first.get('replacementEndpoint') or {}).get('reelWatchEndpoint') or {}).get('videoId')
            if vid:
                ids.append(vid)
            continuation = first.get('sequenceContinuation') or (
                ((first.get('continuationEndpoint') or {}).get('continuationCommand') or {}).get('token'))
            if not continuation:
                return ids, None
        seq = self.call('reel/reel_watch_sequence', {'sequenceParams': continuation})
        for entry in seq.get('entries') or []:
            vid = (((entry.get('command') or {}).get('reelWatchEndpoint')) or {}).get('videoId')
            if vid and vid not in ids:
                ids.append(vid)
        token = seq.get('continuation') or (
            ((seq.get('continuationEndpoint') or {}).get('continuationCommand') or {}).get('token'))
        return ids, token

    def oembed(self, video_id):
        r = self.session.get(BASE + '/oembed', params={'url': BASE + '/shorts/' + video_id, 'format': 'json'},
                             timeout=10)
        if r.status_code != 200:
            return {}
        return r.json()

    def account_name(self):
        data = self.tv_call('account/accounts_list', {'accountReadMask': {
            'returnOwner': True, 'returnBrandAccounts': True, 'returnPersonaAccounts': False}})
        found = []

        def walk(o):
            if isinstance(o, dict):
                if 'accountName' in o and not found:
                    n = o['accountName']
                    found.append(n.get('simpleText') or ''.join(r.get('text', '') for r in n.get('runs', []))
                                 if isinstance(n, dict) else str(n))
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
        walk(data)
        return found[0] if found else ''

    def like(self, video_id, remove=False):
        return self.tv_call('like/removelike' if remove else 'like/like', {'target': {'videoId': video_id}})

    def subscribe(self, channel_id, remove=False):
        return self.tv_call('subscription/unsubscribe' if remove else 'subscription/subscribe',
                            {'channelIds': [channel_id]})

    def watch_later(self, video_id, remove=False):
        action = {'action': 'ACTION_REMOVE_VIDEO_BY_VIDEO_ID', 'removedVideoId': video_id} if remove else \
            {'action': 'ACTION_ADD_VIDEO', 'addedVideoId': video_id}
        return self.tv_call('browse/edit_playlist', {'playlistId': 'WL', 'actions': [action]})

    def history_url(self, video_id):
        """Watch-history ping URL from a signed-in TV player response (no stream URLs needed)."""
        data = self.tv_call('player', {'videoId': video_id, 'playbackContext': {
            'contentPlaybackContext': {'html5Preference': 'HTML5_PREF_WANTS'}}})
        return (((data.get('playbackTracking') or {}).get('videostatsPlaybackUrl') or {}).get('baseUrl'))

    def report_watched(self, video_id):
        import random
        url = self.history_url(video_id)
        if not url:
            return False
        from . import auth
        alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
        cpn = ''.join(random.choice(alphabet) for _ in range(16))
        sep = '&' if '?' in url else '?'
        client = self.tv_client()
        r = self.session.get(url + sep + 'ver=2&fs=0&cpn=' + cpn, timeout=10, headers={
            'User-Agent': client['userAgent'],
            'Authorization': 'Bearer %s' % auth.access_token(self.session)})
        return r.status_code in (200, 204)

    # ---- player (stream URLs) ----

    def reset_clients(self):
        self._clients = None

    def player_clients(self):
        """Ordered (name, definition) list: auto-updated clients.json first, built-ins as backup."""
        if getattr(self, '_clients', None):
            return self._clients
        clients = dict(PLAYER_CLIENTS)
        order = None
        try:
            with open(os.path.join(kodi.profile_dir(), 'clients.json'), 'r') as f:
                saved = json.load(f)
            order = saved.pop('_order', None)
            clients.update(dict((k, v) for k, v in saved.items() if isinstance(v, dict) and v.get('context')))
        except Exception:
            pass
        manual = [c.strip() for c in (kodi.setting('clients_override') or '').split(',') if c.strip()]
        order = manual or order or ['visionos', 'android_vr', 'ios']
        order += [n for n in PLAYER_CLIENTS if n not in order]
        self._clients = [(name, clients[name]) for name in order if name in clients]
        return self._clients

    def player(self, video_id, name, client):
        st = self.state()
        ctx = dict(client['context'])
        ctx.setdefault('hl', self.hl)
        ctx.setdefault('gl', self.gl)
        if st.get('visitor'):
            ctx['visitorData'] = st['visitor']
        body = {
            'context': {'client': ctx},
            'videoId': video_id,
            'playbackContext': {'contentPlaybackContext': {'html5Preference': 'HTML5_PREF_WANTS'}},
            'contentCheckOk': True,
            'racyCheckOk': True,
        }
        if client.get('params'):
            body['params'] = client['params']
        headers = {
            'Content-Type': 'application/json',
            'Origin': BASE,
            'User-Agent': ctx.get('userAgent', WEB_UA),
            'X-YouTube-Client-Name': str(client['id']),
            'X-YouTube-Client-Version': ctx['clientVersion'],
        }
        if st.get('visitor'):
            headers['X-Goog-Visitor-Id'] = st['visitor']
        r = self.session.post(API + 'player', params={'prettyPrint': 'false'},
                              data=json.dumps(body), headers=headers, timeout=20)
        if r.status_code != 200:
            raise YTError('%s player HTTP %s' % (name, r.status_code))
        return r.json()

    def probe(self, url, user_agent):
        """Fetch the first byte of a stream to confirm YouTube will actually serve it."""
        try:
            r = self.session.get(url, headers={'Range': 'bytes=0-0', 'User-Agent': user_agent},
                                 timeout=10, stream=True)
            ok = r.status_code in (200, 206)
            r.close()
            return ok
        except Exception:
            return False
