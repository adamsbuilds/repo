"""YouTube sign-in without an API key, the way YouTube's own TV app (and SmartTube) does it.

Kodi shows a code, the user enters it at youtube.com/activate, and YouTube hands
back a refresh token. The TV app's client id and secret are read from YouTube's
own TV web page each time they're needed, so nothing is tied to a Google Cloud
project and a rotation on YouTube's side is picked up automatically.
"""

import json
import os
import re
import time
import uuid

from . import kodi

TV_PAGE = 'https://www.youtube.com/tv'
DEVICE_CODE_URL = 'https://www.youtube.com/o/oauth2/device/code'
TOKEN_URL = 'https://www.youtube.com/o/oauth2/token'
SCOPE = 'http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content'
GRANT_DEVICE = 'http://oauth.net/grant_type/device/1.0'
MODEL_NAME = 'ytlr::'
PAGE_UA = ('Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0) Cobalt/22.lts.3.306369-gold (unlike Gecko) '
           'v8/8.8.278.8-jit gles Starboard/13, Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless) '
           'com.amazon.firetv.youtube/22.3.r2.v66.0')
BASE_JS_PATTERNS = (
    r'id="base-js" src="(.*?)"',
    r"\.src = '(.*?m=base)'",
    r"\.src = '(.*?)'; .\.id = 'base-js'",
)
# First match is the Android TV client; later matches in the same file are other devices with the wrong id.
CLIENT_PATTERN = r'clientId:"([-\w]+\.apps\.googleusercontent\.com)",\n?[$\w]+:"(\w+)"'


class AuthError(Exception):
    pass


def _path():
    return os.path.join(kodi.profile_dir(), 'auth.json')


def load():
    try:
        with open(_path()) as f:
            return json.load(f)
    except Exception:
        return {}


def save(data):
    tmp = _path() + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(data, f)
    os.replace(tmp, _path())


def signed_in():
    return bool(load().get('refresh_token'))


def show_in_settings(text):
    """Mirrors the account into settings, which can only show stored values."""
    try:
        kodi.set_setting('signed_in_as', text)
    except Exception:
        pass


def sync_settings():
    """Keeps the 'Signed in as' line in settings matching the stored sign-in."""
    want = (load().get('account') or 'Signed in') if signed_in() else ''
    if kodi.setting('signed_in_as') != want:
        show_in_settings(want)


def sign_out():
    try:
        os.remove(_path())
    except Exception:
        pass
    show_in_settings('')


def client_data(session):
    """Reads the TV app's OAuth client id and secret out of YouTube's TV page script."""
    page = session.get(TV_PAGE, headers={'User-Agent': PAGE_UA}, timeout=20).text
    src = None
    for pat in BASE_JS_PATTERNS:
        m = re.search(pat, page)
        if m:
            src = m.group(1).replace('\\/', '/')
            break
    if not src:
        raise AuthError('Could not find YouTube TV\'s script')
    if src.startswith('//'):
        src = 'https:' + src
    elif src.startswith('/'):
        src = 'https://www.youtube.com' + src
    script = session.get(src, headers={'User-Agent': PAGE_UA}, timeout=30).text
    m = re.search(CLIENT_PATTERN, script)
    if not m:
        raise AuthError('Could not read YouTube TV\'s sign-in details')
    return m.group(1), m.group(2)


def _post(session, url, body):
    r = session.post(url, data=json.dumps(body), headers={'Content-Type': 'application/json', 'User-Agent': PAGE_UA},
                     timeout=20)
    try:
        data = r.json()
    except Exception:
        raise AuthError('YouTube sign-in returned HTTP %s' % r.status_code)
    return data


def start(session):
    """Begins sign-in. Returns the pending state including the code to show the user."""
    client_id, client_secret = client_data(session)
    device_id = load().get('device_id') or str(uuid.uuid4())
    data = _post(session, DEVICE_CODE_URL, {'client_id': client_id, 'device_id': device_id,
                                             'model_name': MODEL_NAME, 'scope': SCOPE})
    if not data.get('user_code') or not data.get('device_code'):
        raise AuthError(data.get('error_description') or data.get('error') or 'No sign-in code returned')
    return {
        'client_id': client_id, 'client_secret': client_secret, 'device_id': device_id,
        'device_code': data['device_code'], 'user_code': data['user_code'],
        'url': data.get('verification_url') or 'https://www.youtube.com/activate',
        'interval': int(data.get('interval') or 5), 'expires': time.time() + int(data.get('expires_in') or 1800),
    }


def poll(session, pending):
    """One check for approval. Returns 'pending', 'slow_down' or 'done'; raises on denial or expiry."""
    data = _post(session, TOKEN_URL, {'code': pending['device_code'], 'client_id': pending['client_id'],
                                       'client_secret': pending['client_secret'], 'grant_type': GRANT_DEVICE})
    err = data.get('error')
    if err == 'authorization_pending':
        return 'pending'
    if err == 'slow_down':
        pending['interval'] += 5
        return 'slow_down'
    if err == 'expired_token':
        raise AuthError('The code expired. Try signing in again.')
    if err == 'access_denied':
        raise AuthError('Sign-in was declined.')
    if err or not data.get('refresh_token'):
        raise AuthError(data.get('error_description') or err or 'Sign-in failed')
    save({
        'client_id': pending['client_id'], 'client_secret': pending['client_secret'],
        'device_id': pending['device_id'], 'refresh_token': data['refresh_token'],
        'access_token': data.get('access_token'),
        'expires_at': time.time() + int(data.get('expires_in') or 3600),
    })
    show_in_settings('Signed in')
    return 'done'


def access_token(session):
    """A valid access token, refreshed when needed. None when signed out or the sign-in was revoked."""
    st = load()
    if not st.get('refresh_token'):
        return None
    if st.get('access_token') and time.time() < st.get('expires_at', 0) - 60:
        return st['access_token']
    data = _post(session, TOKEN_URL, {'refresh_token': st['refresh_token'], 'client_id': st['client_id'],
                                       'client_secret': st['client_secret'], 'grant_type': 'refresh_token'})
    if data.get('error') in ('invalid_grant', 'unauthorized_client', 'invalid_client'):
        kodi.log('sign-in no longer valid (%s); signing out' % data.get('error'))
        sign_out()
        return None
    if not data.get('access_token'):
        raise AuthError(data.get('error_description') or data.get('error') or 'Could not refresh sign-in')
    st.update(access_token=data['access_token'], expires_at=time.time() + int(data.get('expires_in') or 3600))
    save(st)
    return st['access_token']


def set_account_name(name):
    st = load()
    if st:
        st['account'] = name
        save(st)
    show_in_settings(name or 'Signed in')


def account_name():
    return load().get('account') or ''
