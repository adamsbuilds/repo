import json
import os
import sys
import time
from urllib.parse import parse_qsl, urlparse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import auth, kodi, storage, streams, trailers
from resources.lib.innertube import InnerTube, YTError
from resources.lib.parser import channel_title, parse, related_section, video_details

HANDLE = kodi.handle()
PATH = urlparse(sys.argv[0]).path.strip('/')
ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

TABS = {'playlists': 'playlists', 'live': 'streams', 'streams': 'streams', 'shorts': 'shorts', 'videos': 'videos'}


def video_from(value):
    if not value:
        return None
    if len(value) == 11 and '/' not in value:
        return value
    u = urlparse(value)
    q = dict(parse_qsl(u.query))
    if q.get('v'):
        return q['v']
    last = u.path.rstrip('/').split('/')[-1]
    return last if len(last) == 11 else None


def official_route(path, args):
    """Maps the official YouTube add-on's URL styles (used by Kodi's library, skins and other
    add-ons) onto TubeLite's routes. Returns (path, args), or None when it's already a TubeLite URL."""
    parts = [p for p in path.split('/') if p]
    head = parts[0] if parts else ''
    vid = args.get('video_id') or args.get('videoid') or args.get('v')
    if head == 'uri2addon':
        vid = video_from(args.get('uri'))
    if vid and head in ('', 'uri2addon'):
        return 'play', {'video_id': vid}
    if head == 'channel' and len(parts) > 1:
        if len(parts) > 3 and parts[2] == 'playlist':
            return 'playlist', {'id': parts[3]}
        tab = TABS.get(parts[2]) if len(parts) > 2 else None
        return ('channel/tab', {'id': parts[1], 'tab': tab}) if tab else ('channel', {'id': parts[1]})
    if head in ('user', 'handle', 'c') and len(parts) > 1:
        return 'channel', {'id': parts[1] if parts[1].startswith('@') else '@' + parts[1]}
    if head == 'playlist' and len(parts) > 1:
        return 'playlist', {'id': parts[1]}
    if head == 'search' and len(parts) == 1 and (args.get('q') or args.get('query')):
        return 'search/results', {'q': args.get('q') or args.get('query'), 'kind': 'all'}
    if parts[:2] == ['kodion', 'search']:
        q = args.get('q') or args.get('query')
        return ('search/results', {'q': q, 'kind': 'all'}) if q else ('search', {})
    return None

_yt = None


def yt():
    global _yt
    if _yt is None:
        _yt = InnerTube()
    return _yt


def shorts():
    return not kodi.setting_bool('hide_shorts')


# ---------------------------------------------------------------- list helpers

def folder(label, path, thumb='', plot='', context=None, **params):
    li = xbmcgui.ListItem(label, offscreen=True)
    art = thumb if thumb.startswith('http') else (kodi.icon(thumb) if thumb else os.path.join(kodi.ADDON_PATH, 'icon.png'))
    li.setArt({'icon': art, 'thumb': art, 'poster': art,
               'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    if plot:
        tag = li.getVideoInfoTag()
        tag.setPlot(plot)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, True)


def action_item(label, path, thumb='', plot='', **params):
    """An entry that runs something (sign in, settings) instead of opening a list.
    Kodi runs these like RunPlugin, outside the folder-loading screen."""
    li = xbmcgui.ListItem(label, offscreen=True)
    art = kodi.icon(thumb) if thumb else os.path.join(kodi.ADDON_PATH, 'icon.png')
    li.setArt({'icon': art, 'thumb': art, 'poster': art, 'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, False)


def fill_missing_titles(items):
    """Some YouTube rows come back without titles; look those up so they don't show as video ids."""
    missing = [it for it in items if it['type'] == 'video' and not it.get('title')]
    if not missing:
        return
    from concurrent.futures import ThreadPoolExecutor
    kodi.log('looking up %d missing title(s) (renderers: %s)' % (
        len(missing), ', '.join(sorted(set(it.get('_renderer', '?') for it in missing)))))

    def look(it):
        try:
            return it, yt().oembed(it['id'])
        except Exception:
            return it, {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        for it, d in pool.map(look, missing):
            it['title'] = d.get('title') or 'YouTube video'
            if not it.get('channel'):
                it['channel'] = d.get('author_name', '')
            if not it.get('channel_id'):
                handle = (d.get('author_url') or '').rstrip('/').split('/')[-1]
                it['channel_id'] = handle if handle.startswith('@') else ''


def trailer_item(it):
    """A movie or show title from YouTube's Movies & TV section: plays its trailer."""
    li = xbmcgui.ListItem(it['title'], offscreen=True)
    thumb = it.get('thumb') or kodi.icon('trailers.png')
    li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
    tag = li.getVideoInfoTag()
    tag.setTitle(it['title'])
    tag.setMediaType('video')
    tag.setPlot('[B]Plays the trailer[/B]')
    li.setProperty('IsPlayable', 'true')
    li.addContextMenuItems([('Find more trailers', 'Container.Update(%s)' % kodi.url(
        'trailers/search', q=it['title'], kind='tv'))])
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url('trailer', title=it['title']), li, False)


def video_item(v, extra_context=None):
    li = xbmcgui.ListItem(v.get('title') or v['id'], offscreen=True)
    li.setArt({'thumb': v.get('thumb'), 'icon': v.get('thumb'), 'poster': v.get('thumb'),
               'fanart': v.get('thumb')})
    tag = li.getVideoInfoTag()
    tag.setTitle(v.get('title', ''))
    tag.setMediaType('video')
    if v.get('duration'):
        tag.setDuration(int(v['duration']))
    if v.get('channel'):
        tag.setStudios([v['channel']])
    meta = ' · '.join(x for x in (v.get('channel'), v.get('views'), v.get('published')) if x)
    if v.get('live'):
        meta = '[LIVE] ' + meta
    tag.setPlot('[B]%s[/B]\n%s' % (meta, v.get('description', '')) if meta else v.get('description', ''))
    li.setProperty('IsPlayable', 'true')
    ctx = [('Related videos', 'Container.Update(%s)' % kodi.url('related', id=v['id']))]
    if v.get('channel_id'):
        ctx.append(('Go to channel', 'Container.Update(%s)' % kodi.url('channel', id=v['channel_id'],
                                                                         title=v.get('channel'))))
        ctx.append(('Add channel to My Channels', 'RunPlugin(%s)' % kodi.url(
            'channel/add', id=v['channel_id'], title=v.get('channel'))))
    if auth.signed_in():
        ctx.append(('Add to Watch Later', 'RunPlugin(%s)' % kodi.url('account/action', do='watchlater', id=v['id'])))
        ctx.append(('Like', 'RunPlugin(%s)' % kodi.url('account/action', do='like', id=v['id'])))
        if v.get('channel_id'):
            ctx.append(('Subscribe to %s' % (v.get('channel') or 'channel'), 'RunPlugin(%s)' % kodi.url(
                'account/action', do='subscribe', id=v['channel_id'], name=v.get('channel'))))
    ctx += extra_context or []
    li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url('play', video_id=v['id']), li, False)


def render(items, next_path=None, next_params=None):
    fill_missing_titles(items)
    for it in items:
        if it['type'] == 'video':
            video_item(it)
        elif it['type'] == 'trailer':
            trailer_item(it)
        elif it['type'] == 'playlist':
            label = it['title'] + ('  [COLOR grey](%s)[/COLOR]' % it['count'] if it.get('count') else '')
            folder(label, 'playlist', it.get('thumb', ''), it.get('channel', ''), id=it['id'])
        elif it['type'] == 'channel':
            folder('[B]%s[/B]' % it['title'], 'channel', it.get('thumb', ''),
                   '%s\n%s' % (it.get('subs', ''), it.get('description', '')),
                   context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url(
                       'channel/add', id=it['id'], title=it['title'], thumb=it.get('thumb')))] + ([
                       ('Subscribe', 'RunPlugin(%s)' % kodi.url('account/action', do='subscribe', id=it['id'],
                                                                name=it['title']))] if auth.signed_in() else []),
                   id=it['id'], title=it['title'])
    if next_path and next_params and next_params.get('cont'):
        folder('[COLOR yellow]Next page >>[/COLOR]', next_path, 'next.png', **next_params)


def finish(content='videos', cache=False):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def fail(e):
    kodi.log('error: %s' % e, xbmc.LOGERROR)
    kodi.notify(str(e) or 'Something went wrong')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# ---------------------------------------------------------------- menus

# ---------------------------------------------------------------- account

def signin():
    from resources.lib import signin_dialog
    try:
        done = signin_dialog.run(yt().session)
    except Exception as e:
        kodi.log('sign-in failed: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Could not start sign-in: %s' % e)
        return
    if not done:
        return
    name = ''
    try:
        name = yt().account_name()
        auth.set_account_name(name)
    except Exception as e:
        kodi.log('account name lookup failed: %s' % e)
    kodi.notify('Signed in%s' % (' as %s' % name if name else ''))
    xbmc.executebuiltin('Container.Refresh')


def signout():
    if xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Sign out of YouTube on this device?'):
        auth.sign_out()
        kodi.notify('Signed out')
        xbmc.executebuiltin('Container.Refresh')


# Sections, the way YouTube's own apps lay them out. Values: (label, icon, needs sign-in).
FEEDS = {
    'default': ('Home', 'home.png', False),
    'FEsubscriptions': ('Subscriptions', 'subscriptions.png', True),
    'FEhistory': ('History', 'history.png', True),
    'FEplaylist_aggregation': ('Playlists', 'playlists.png', True),
    'FEmy_youtube': ('Library', 'playlists.png', True),
    'VLWL': ('Watch later', 'watchlater.png', True),
    'VLLL': ('Liked videos', 'liked.png', True),
    'FEtopics_music': ('Music', 'music.png', False),
    'FEtopics_movies': ('Movies & TV', 'movies.png', False),
    'FEtopics_live': ('Live', 'live.png', False),
    'FEtopics_gaming': ('Gaming', 'gaming.png', False),
    'FEtopics_news': ('News', 'news.png', False),
    'FEtopics_sports': ('Sports', 'sports.png', False),
}


def account_feed():
    """Any TV-app section: Home, Subscriptions, Music, Gaming and the rest."""
    fid = ARGS.get('id', 'FEsubscriptions')
    needs_auth = FEEDS.get(fid, ('', '', True))[2]
    try:
        if ARGS.get('cont'):
            data = yt().account_browse(continuation=ARGS['cont'], require_auth=needs_auth)
        else:
            data = yt().account_browse(fid, require_auth=needs_auth)
        items, token = parse(data, shorts())
    except Exception as e:
        return fail(e)
    if fid == 'FEtopics_movies':
        # YouTube's Movies & TV rows are mostly titles to rent or buy; make each one play its trailer.
        items = [dict(it, type='trailer') if it['type'] in ('channel', 'playlist') and it.get('title') else it
                 for it in items]
    if not items and not ARGS.get('cont'):
        if fid == 'default' and not auth.signed_in():
            folder('[I]YouTube shows little here until you sign in. Try Explore or Search.[/I]', 'explore', 'home.png')
        else:
            kodi.notify('Nothing here yet')
    render(items, 'account/feed', dict(ARGS, cont=token))
    finish()


def feed_folder(fid, plot=''):
    label, icon, _ = FEEDS[fid]
    folder(label, 'account/feed', icon, plot, id=fid)


def account_action():
    do, item = ARGS.get('do'), ARGS.get('id')
    labels = {'like': 'Liked', 'watchlater': 'Added to Watch Later',
              'subscribe': 'Subscribed to %s' % (ARGS.get('name') or 'channel')}
    try:
        if do == 'like':
            yt().like(item)
        elif do == 'watchlater':
            yt().watch_later(item)
        elif do == 'subscribe':
            yt().subscribe(item)
        else:
            return
        kodi.notify(labels[do])
    except Exception as e:
        kodi.log('%s failed: %s' % (do, e), xbmc.LOGERROR)
        kodi.notify('Couldn\'t do that: %s' % e)


def library_fill():
    from resources.lib import library
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Adding trailers to your library')
    try:
        done = library.fill()
    finally:
        progress.close()
    parts = []
    for key, label in (('movies', 'movies'), ('tvshows', 'TV shows')):
        if done.get(key) is None and key in done:
            parts.append('%s: not supported by this Kodi' % label)
        elif done.get(key) is not None:
            parts.append('%d %s' % (done[key], label))
    kodi.notify('Trailers added: ' + ', '.join(parts) if parts else 'Library trailers are up to date')


def library_clear():
    from resources.lib import library
    if xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Remove the trailer links TubeLite added to your library?[CR]'
                                               'Scraped trailers are left alone.'):
        kodi.set_setting('library_fill', 'false')
        kodi.notify('Removed %d trailer links' % library.clear())


def clients_refresh():
    from resources.lib import clientupdate
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Testing YouTube player clients')
    meta = clientupdate.load_meta()
    meta['attempt'] = 0
    with open(os.path.join(kodi.profile_dir(), 'clients_meta.json'), 'w') as f:
        json.dump(meta, f)
    try:
        ok = clientupdate.refresh(yt(), force=True, reason='manual')
    finally:
        progress.close()
    meta = clientupdate.load_meta()
    working = ', '.join(meta.get('working') or []) or 'none'
    xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Source: %s[CR]Working clients: %s[CR]%s' % (
        meta.get('source', '?'), working,
        'Playback will use these, best first.' if ok else 'Kept the previous list. Check your connection.'))


def root():
    """Main screen, laid out like YouTube's: Home, Shorts, Subscriptions, You, Explore, Search."""
    signed = auth.signed_in()
    auth.sync_settings()
    feed_folder('default', 'Recommended for you.' if signed else 'What\'s popular right now.')
    folder('Shorts', 'shorts', 'shorts.png', 'Short vertical videos.')
    if signed:
        feed_folder('FEsubscriptions', 'New videos from channels you subscribe to.')
    else:
        folder('Subscriptions', 'channels', 'subscriptions.png',
               'Channels you\'ve saved on this device. Sign in to see your YouTube subscriptions.')
    folder('You', 'you', 'you.png', 'History, playlists, Watch later and liked videos.')
    folder('Explore', 'explore', 'explore.png', 'Trending, Music, Movies & TV, Live, Gaming, News, Sports and trailers.')
    folder('Search', 'search', 'search.png', 'Search YouTube.')
    if not signed:
        action_item('[B]Sign in[/B]', 'account/signin', 'signin.png',
                    'Scan a QR code or enter a code at youtube.com/activate. No API key needed.')
    finish('files')


def you_menu():
    signed = auth.signed_in()
    if signed:
        name = auth.account_name()
        for fid in ('FEhistory', 'FEplaylist_aggregation', 'VLWL', 'VLLL'):
            feed_folder(fid)
        folder('Watched on this device', 'history', 'history.png', 'Everything played through TubeLite here.')
        folder('Saved channels', 'channels', 'subscriptions.png', 'Channels saved on this device.')
        action_item('[COLOR grey]Signed in%s · Sign out[/COLOR]' % (' as %s' % name if name else ''),
                     'account/signout', 'signin.png')
    else:
        folder('History', 'history', 'history.png', 'Videos played on this device.')
        folder('Saved channels', 'channels', 'subscriptions.png', 'Channels saved on this device.')
        action_item('[B]Sign in[/B]', 'account/signin', 'signin.png',
                    'Sign in to see your YouTube history, playlists, Watch later and liked videos.')
    action_item('Settings', 'settings', 'settings.png')
    finish('files')


def explore_menu():
    folder('Trending', 'trending', 'trending.png', 'What\'s popular on YouTube.')
    for fid in ('FEtopics_music', 'FEtopics_movies', 'FEtopics_live', 'FEtopics_gaming', 'FEtopics_news',
                'FEtopics_sports'):
        feed_folder(fid)
    folder('Trailers', 'trailers', 'trailers.png', 'Find a trailer for any show or movie, plus the newest ones.')
    finish('files', cache=True)


def trending():
    """YouTube retired its Trending page in 2025, so try what still exists and fall back to Home."""
    items, token = [], None
    sources = [('web', None)] if ARGS.get('cont') else [('web', 'explore'), ('web', None), ('tv', None),
                                                         ('home', None)]
    if ARGS.get('src'):
        sources = [(ARGS['src'], ARGS.get('p') or None)]
    for src, variant in sources:
        try:
            if src == 'home':
                data = yt().account_browse(continuation=ARGS.get('cont'), require_auth=False) if ARGS.get('cont') \
                    else yt().account_browse('default', require_auth=False)
            elif src == 'tv':
                data = yt().account_browse(continuation=ARGS.get('cont'), require_auth=False) if ARGS.get('cont') \
                    else yt().account_browse('FEtrending', require_auth=False)
            else:
                data = yt().trending(ARGS.get('cont'), explore=(variant == 'explore'))
            items, token = parse(data, shorts())
        except Exception as e:
            kodi.log('trending via %s/%s failed: %s' % (src, variant, e))
            continue
        if items:
            kodi.log('trending served by %s/%s' % (src, variant))
            render(items, 'trending', {'cont': token, 'src': src, 'p': variant or ''})
            return finish()
    if ARGS.get('cont'):
        return finish()
    fail(YTError('Trending isn\'t available right now'))


def shorts_feed():
    from concurrent.futures import ThreadPoolExecutor
    try:
        ids, token = yt().shorts(ARGS.get('cont'))
    except Exception as e:
        return fail(e)

    def info(vid):
        try:
            return vid, yt().oembed(vid)
        except Exception:
            return vid, {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        details = dict(pool.map(info, ids))
    items = []
    for vid in ids:
        d = details.get(vid) or {}
        handle = (d.get('author_url') or '').rstrip('/').split('/')[-1]
        items.append({'type': 'video', 'id': vid, 'title': d.get('title') or 'Short', 'channel': d.get('author_name', ''),
                      'channel_id': handle if handle.startswith('@') else '', 'duration': 0, 'live': False,
                      'views': '', 'published': '', 'description': '', 'short': True,
                      'thumb': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % vid})
    if not items:
        kodi.notify('No Shorts right now')
    render(items, 'shorts', dict(ARGS, cont=token))
    finish()


def open_settings():
    kodi.ADDON.openSettings()


def trailers_menu():
    folder('Find a Show\'s Trailer', 'trailers/search', 'search.png', 'Type a show or movie name.', kind='tv')
    folder('New TV Trailers This Week', 'trailers/new', 'trailers.png', what='tv', period='week')
    folder('New Movie Trailers This Week', 'trailers/new', 'trailers.png', what='movie', period='week')
    folder('New TV Trailers This Month', 'trailers/new', 'trailers.png', what='tv', period='month')
    folder('New Movie Trailers This Month', 'trailers/new', 'trailers.png', what='movie', period='month')
    folder('Studio & Network Channels', 'trailers/studios', 'channels.png')
    finish('files', cache=True)


def trailers_search():
    q = ARGS.get('q')
    typed = not q
    if typed:
        q = kodi.keyboard('Show or movie name')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    try:
        items = trailers.find(yt(), q, ARGS.get('year', ''), ARGS.get('kind', 'tv'), ARGS.get('season', ''))
    except Exception as e:
        return fail(e)
    render(items)
    finish(cache=typed)


NEW_QUERIES = {
    'tv': 'official series trailer',
    'movie': 'official movie trailer',
}


def trailers_new():
    sp = trailers.NEW_THIS_MONTH if ARGS.get('period') == 'month' else trailers.NEW_THIS_WEEK
    try:
        data = yt().search(None, continuation=ARGS['cont']) if ARGS.get('cont') else \
            yt().search(NEW_QUERIES.get(ARGS.get('what'), 'official trailer'), sp)
        items, token = parse(data, shorts())
    except Exception as e:
        return fail(e)
    items = [i for i in items if i['type'] == 'video' and 'trailer' in i.get('title', '').lower()
             and trailers.score(i, '') > 0]
    render(items, 'trailers/new', dict(ARGS, cont=token))
    finish()


def trailers_studios():
    with open(os.path.join(kodi.ADDON_PATH, 'resources', 'data', 'trailer_channels.json')) as f:
        studios = json.load(f)
    for s in studios:
        folder(s['title'], 'channel', 'channels.png',
               context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url('channel/add', id=s['id'], title=s['title']))],
               id=s['id'], title=s['title'])
    finish('files', cache=True)


def search_menu():
    folder('[B]New search[/B]', 'search/results', 'search.png', new='1')
    folder('[B]Search channels[/B]', 'search/results', 'channels.png', new='1', kind='channels')
    folder('[B]Search playlists[/B]', 'search/results', 'search.png', new='1', kind='playlists')
    for s in storage.load('searches'):
        kind = s.get('kind', 'all')
        label = s['q'] + ('  [COLOR grey](%s)[/COLOR]' % kind if kind != 'all' else '')
        folder(label, 'search/results', 'search.png',
               context=[('Remove from search history', 'RunPlugin(%s)' % kodi.url('search/remove', q=s['q'])),
                        ('Clear search history', 'RunPlugin(%s)' % kodi.url('clear', what='searches'))],
               q=s['q'], kind=kind)
    finish('files')


SEARCH_PARAMS = {'all': None, 'videos': 'EgIQAQ==', 'channels': 'EgIQAg==', 'playlists': 'EgIQAw=='}


def search_results():
    kind = ARGS.get('kind', 'all')
    q = ARGS.get('q')
    new_search = bool(ARGS.get('new'))
    if new_search:
        q = kodi.keyboard('Search YouTube')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        storage.add_search(q, kind)
    try:
        if ARGS.get('cont'):
            data = yt().search(None, continuation=ARGS['cont'])
        else:
            data = yt().search(q, SEARCH_PARAMS.get(kind))
        items, token = parse(data, shorts())
    except Exception as e:
        return fail(e)
    render(items, 'search/results', {'q': q, 'kind': kind, 'cont': token})
    # Cached so coming back to these results doesn't open the keyboard again.
    finish(cache=new_search)


def channels_menu():
    chans = storage.channels()
    if not chans:
        folder('[I]No saved channels yet. Use "Add channel to My Channels" on any video.[/I]', 'trailers/studios', 'channels.png')
    for c in chans:
        folder(c['title'], 'channel', c.get('thumb', ''),
               context=[('Remove from My Channels', 'RunPlugin(%s)' % kodi.url('channel/remove', id=c['id']))],
               id=c['id'], title=c['title'])
    finish('files')


def channel():
    cid, title = ARGS['id'], ARGS.get('title', '')
    folder('Videos', 'channel/tab', 'trailers.png', id=cid, tab='videos', title=title)
    folder('Live', 'channel/tab', 'trailers.png', id=cid, tab='streams', title=title)
    folder('Playlists', 'channel/tab', 'channels.png', id=cid, tab='playlists', title=title)
    if not kodi.setting_bool('hide_shorts'):
        folder('Shorts', 'channel/tab', 'trailers.png', id=cid, tab='shorts', title=title)
    folder('Add to My Channels', 'channel/add', 'channels.png', id=cid, title=title)
    finish('files', cache=True)


def channel_tab():
    tab = ARGS.get('tab', 'videos')
    try:
        data = yt().channel_tab(ARGS['id'], tab, ARGS.get('cont'))
        items, token = parse(data, tab == 'shorts' or shorts())
    except Exception as e:
        return fail(e)
    render(items, 'channel/tab', dict(ARGS, cont=token))
    finish()


def channel_add():
    cid, title, thumb = ARGS['id'], ARGS.get('title', ''), ARGS.get('thumb', '')
    if cid.startswith('@') or not title or not thumb:
        try:
            data = yt().channel_tab(cid, 'videos')
            name, avatar = channel_title(data)
            title, thumb = title or name, thumb or avatar
            browse_id = ((data.get('metadata') or {}).get('channelMetadataRenderer') or {}).get('externalId')
            if browse_id:
                cid = browse_id
        except Exception as e:
            kodi.log('channel lookup failed: %s' % e)
    storage.add_channel(cid, title or cid, thumb)
    kodi.notify('Added %s to My Channels' % (title or cid))
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def channel_remove():
    storage.remove('channels', 'id', ARGS['id'])
    xbmc.executebuiltin('Container.Refresh')


def playlist():
    try:
        if ARGS.get('cont'):
            data = yt().browse(continuation=ARGS['cont'])
        else:
            pid = ARGS['id']
            data = yt().browse(pid if pid.startswith('VL') else 'VL' + pid)
        items, token = parse(data, True)
    except Exception as e:
        return fail(e)
    render(items, 'playlist', dict(ARGS, cont=token))
    finish()


def related():
    try:
        data = yt().next(continuation=ARGS['cont']) if ARGS.get('cont') else yt().next(ARGS['id'])
        items, token = parse(related_section(data), shorts())
    except Exception as e:
        return fail(e)
    render(items, 'related', dict(ARGS, cont=token))
    finish()


def history():
    items = storage.load('history')
    for v in items:
        v = dict(v, type='video')
        video_item(v, [('Remove from history', 'RunPlugin(%s)' % kodi.url('history/remove', id=v['id'])),
                       ('Clear watch history', 'RunPlugin(%s)' % kodi.url('clear', what='history'))])
    finish()


def clear():
    what = ARGS.get('what')
    names = {'history': 'watch history', 'searches': 'search history', 'channels': 'My Channels'}
    if what in names and xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Clear %s?' % names[what]):
        storage.clear(what)
        kodi.notify('Cleared %s' % names[what])
        xbmc.executebuiltin('Container.Refresh')


def reset_session():
    yt().reset_state()
    for name in ('clients.json', 'clients_meta.json'):
        try:
            os.remove(os.path.join(kodi.profile_dir(), name))
        except Exception:
            pass
    kodi.notify('Session reset')


# ---------------------------------------------------------------- playback

def _resolved(info):
    li = streams.listitem_for(info)
    li.setArt({'thumb': info['thumb'], 'icon': info['thumb'], 'fanart': info['thumb']})
    tag = li.getVideoInfoTag()
    tag.setTitle(info.get('title', ''))
    tag.setPlot(info.get('description', ''))
    tag.setMediaType('video')
    if info.get('channel'):
        tag.setStudios([info['channel']])
    if info.get('duration'):
        tag.setDuration(info['duration'])
    return li


def resolve_with_fallback(video_id):
    """Resolves a video; if it's an age-restricted trailer, plays the standard cut instead."""
    try:
        return streams.resolve(yt(), video_id), video_id
    except YTError as e:
        if 'your age' not in str(e).lower() or not kodi.setting_bool('age_fallback'):
            raise
        original = e
    title = ''
    try:
        title = video_details(yt().next(video_id)).get('title', '')
    except Exception as e:
        kodi.log('title lookup for age fallback failed: %s' % e)
    if not trailers.is_trailer(title):
        raise original
    for alt in trailers.alternatives(yt(), title, video_id):
        try:
            info = streams.resolve(yt(), alt['id'])
        except YTError as e:
            kodi.log('age fallback candidate %s failed: %s' % (alt['id'], e))
            continue
        kodi.notify('Age-restricted. Playing the standard version instead.')
        kodi.log('age fallback: %s -> %s (%s)' % (video_id, alt['id'], alt['title']))
        return info, alt['id']
    raise original


def handoff(video_id):
    """Tells the background service which video is starting, for SponsorBlock and YouTube history."""
    win = xbmcgui.Window(10000)
    win.setProperty('tubelite.playing', video_id)
    win.setProperty('tubelite.playing_ts', str(int(time.time())))


def play_video(video_id):
    try:
        info, played_id = resolve_with_fallback(video_id)
    except Exception as e:
        kodi.log('playback failed for %s: %s' % (video_id, e), xbmc.LOGERROR)
        kodi.notify('Can\'t play: %s' % e)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return False
    kodi.log('%s playing via %s (%s)' % (played_id, info['client'], info['kind']))
    storage.add_history(dict(info, id=played_id))
    handoff(played_id)
    li = _resolved(info)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)
    return True


def play():
    vid = ARGS.get('video_id') or ARGS.get('videoid') or ARGS.get('v')
    if not vid and ARGS.get('url'):
        q = dict(parse_qsl(urlparse(ARGS['url']).query))
        vid = q.get('v') or urlparse(ARGS['url']).path.rstrip('/').split('/')[-1]
    if not vid and ARGS.get('playlist_id'):
        xbmc.executebuiltin('Container.Update(%s)' % kodi.url('playlist', id=ARGS['playlist_id']))
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    if not vid:
        kodi.notify('No video id given')
        return
    play_video(vid)


def trailer():
    """External entry: plugin://plugin.video.youtube/trailer/?title=Severance&year=2022&type=tv&season=2"""
    title = ARGS.get('title') or ARGS.get('tvshowtitle')
    if not title:
        kodi.notify('No title given')
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    try:
        ranked = trailers.find(yt(), title, ARGS.get('year', ''), ARGS.get('type', 'tv'), ARGS.get('season', ''))
    except Exception as e:
        kodi.notify(str(e))
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    # Try the next-best match when one is restricted or blocked, rather than failing outright.
    for best in ranked[:4]:
        try:
            info = streams.resolve(yt(), best['id'])
        except YTError as e:
            kodi.log('trailer candidate %s skipped: %s' % (best['id'], e))
            continue
        kodi.log('trailer for "%s": %s (%s)' % (title, best['title'], best['id']))
        storage.add_history(dict(info, id=best['id']))
        handoff(best['id'])
        li = _resolved(info)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            xbmc.Player().play(li.getPath(), li)
        return
    kodi.notify('No playable trailer found for %s' % title)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))


ROUTES = {
    '': root,
    'trailers': trailers_menu,
    'trailers/search': trailers_search,
    'trailers/new': trailers_new,
    'trailers/studios': trailers_studios,
    'trailer': trailer,
    'search': search_menu,
    'search/results': search_results,
    'search/remove': lambda: (storage.remove('searches', 'q', ARGS.get('q')), xbmc.executebuiltin('Container.Refresh')),
    'channels': channels_menu,
    'channel': channel,
    'channel/tab': channel_tab,
    'channel/add': channel_add,
    'channel/remove': channel_remove,
    'playlist': playlist,
    'related': related,
    'history': history,
    'history/remove': lambda: (storage.remove('history', 'id', ARGS.get('id')), xbmc.executebuiltin('Container.Refresh')),
    'clear': clear,
    'reset_session': reset_session,
    'play': play,
    'account/signin': lambda: (signin(), HANDLE >= 0 and xbmcplugin.endOfDirectory(HANDLE, succeeded=False)),
    'account/signout': lambda: (signout(), HANDLE >= 0 and xbmcplugin.endOfDirectory(HANDLE, succeeded=False)),
    'account/feed': account_feed,
    'you': you_menu,
    'explore': explore_menu,
    'trending': trending,
    'shorts': shorts_feed,
    'settings': open_settings,
    'account/action': account_action,
    'library/fill': library_fill,
    'library/clear': library_clear,
    'clients/refresh': clients_refresh,
}


def run():
    global PATH, ARGS
    kodi.migrate_from_tubelite()
    if PATH == '' and ARGS.get('action') in ('play_video', 'play'):
        return play()
    if PATH not in ROUTES or PATH in ('', 'search') or PATH.startswith('kodion'):
        mapped = official_route(PATH, ARGS)
        if mapped:
            PATH, ARGS = mapped
    route = ROUTES.get(PATH)
    if not route:
        kodi.log('unknown route: %s' % PATH, xbmc.LOGWARNING)
        return root()
    try:
        route()
    except YTError as e:
        fail(e)


if __name__ == '__main__':
    run()
