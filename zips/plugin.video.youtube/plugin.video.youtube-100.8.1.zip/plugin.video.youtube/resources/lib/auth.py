"""YouTube sign-in without an API key, the way YouTube's own TV app (and SmartTube) does it.

Kodi shows a code, the user enters it at youtube.com/activate, and YouTube hands
back a refresh token. The TV app's client id and secret are read from YouTube's
own TV web page each time they're needed, so nothing is tied to a Google Cloud
project and a rotation on YouTube's side is picked up automatically.
"""

import json
import os
import re
import time
import uuid

from . import kodi

TV_PAGE = 'https://www.youtube.com/tv'
DEVICE_CODE_URL = 'https://www.youtube.com/o/oauth2/device/code'
TOKEN_URL = 'https://www.youtube.com/o/oauth2/token'
SCOPE = 'http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content'
GRANT_DEVICE = 'http://oauth.net/grant_type/device/1.0'
MODEL_NAME = 'ytlr::'
PAGE_UA = ('Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0) Cobalt/22.lts.3.306369-gold (unlike Gecko) '
           'v8/8.8.278.8-jit gles Starboard/13, Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless) '
           'com.amazon.firetv.youtube/22.3.r2.v66.0')
BASE_JS_PATTERNS = (
    r'id="base-js" src="(.*?)"',
    r"\.src = '(.*?m=base)'",
    r"\.src = '(.*?)'; .\.id = 'base-js'",
)
# First match is the Android TV client; later matches in the same file are other devices with the wrong id.
CLIENT_PATTERN = r'clientId:"([-\w]+\.apps\.googleusercontent\.com)",\n?[$\w]+:"(\w+)"'


class AuthError(Exception):
    pass


# ---------------------------------------------------------------- accounts
# Each linked account has its own folder under accounts/ holding its sign-in (auth.json) and its own local
# data on this device (watch history, searches, saved channels). accounts.json lists them in the order they
# were added and says which one is active. With no active account, local data lives in the profile folder.

TOKEN_KEYS = ('client_id', 'client_secret', 'device_id', 'refresh_token', 'access_token', 'expires_at')
PERSONAL = ('history', 'searches', 'channels')


def _accounts_dir():
    return os.path.join(kodi.profile_dir(), 'accounts')


def _index_path():
    return os.path.join(kodi.profile_dir(), 'accounts.json')


def _read_json(path, default):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def _write_json(path, data):
    folder_ = os.path.dirname(path)
    if not os.path.isdir(folder_):
        os.makedirs(folder_)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f)
    os.replace(tmp, path)


_migrated = False


def _index():
    global _migrated
    if not _migrated:
        _migrated = True
        _migrate()
    ix = _read_json(_index_path(), {})
    order = [k for k in ix.get('order') or [] if os.path.isdir(_slot_dir(k))]
    active = ix.get('active') if ix.get('active') in order else ''
    return {'order': order, 'active': active}


def _save_index(ix):
    _write_json(_index_path(), ix)


def _migrate():
    """Before 100.8.0 there was one sign-in (auth.json) next to the local data. It becomes the first account,
    taking a copy of the local data so nothing is lost signed in or out."""
    import shutil
    old = os.path.join(kodi.profile_dir(), 'auth.json')
    if not os.path.exists(old) or os.path.exists(_index_path()):
        return
    key = _new_key()
    os.makedirs(_slot_dir(key))
    shutil.move(old, os.path.join(_slot_dir(key), 'auth.json'))
    for name in PERSONAL:
        src = os.path.join(kodi.profile_dir(), name + '.json')
        if os.path.exists(src):
            shutil.copy(src, os.path.join(_slot_dir(key), name + '.json'))
    _save_index({'order': [key], 'active': key})


def _new_key():
    return uuid.uuid4().hex[:10]


def _slot_dir(key):
    return os.path.join(_accounts_dir(), key)


def _path(key=None):
    key = key or _index()['active']
    return os.path.join(_slot_dir(key), 'auth.json') if key else None


def active_key():
    return _index()['active']


def data_dir():
    """Where the active account's local data lives (the profile folder when no account is active)."""
    key = active_key()
    return _slot_dir(key) if key else kodi.profile_dir()


def load(key=None):
    path = _path(key)
    return _read_json(path, {}) if path else {}


def save(data, key=None):
    path = _path(key)
    if path:
        _write_json(path, data)


def signed_in():
    return bool(load().get('refresh_token'))


def accounts():
    """Every linked account: [{'key', 'name', 'signed_in'}], in the order they were added."""
    out = []
    for key in _index()['order']:
        st = load(key)
        out.append({'key': key, 'name': _name(st) or 'Account', 'signed_in': bool(st.get('refresh_token'))})
    return out


def activate(key):
    ix = _index()
    if key in ix['order'] and ix['active'] != key:
        ix['active'] = key
        _save_index(ix)
    sync_settings()


def remove(key=None):
    """Takes an account off this device, with its local data. The next account (if any) becomes active."""
    import shutil
    ix = _index()
    key = key or ix['active']
    if key not in ix['order']:
        return
    shutil.rmtree(_slot_dir(key), ignore_errors=True)
    ix['order'].remove(key)
    if ix['active'] == key:
        ix['active'] = ix['order'][0] if ix['order'] else ''
    _save_index(ix)
    sync_settings()


def _main_identity(st):
    ids = st.get('identities') or []
    main = next((i for i in ids if not i.get('page_id')), ids[0] if ids else None)
    if not main:
        return None
    return (main.get('handle') or '').lower() or (main.get('name') or '').lower() or None


def merge_duplicate():
    """When the account just signed in was already linked here (signed in again, or added twice), its new
    sign-in goes back into the existing account, which keeps its history and Browse-as choice. Returns True
    when that happened."""
    import shutil
    ix = _index()
    new = ix['active']
    st = load(new)
    ident = _main_identity(st)
    if not new or not ident:
        return False
    for key in ix['order']:
        if key == new:
            continue
        old = load(key)
        if _main_identity(old) != ident:
            continue
        old.update((k, st[k]) for k in TOKEN_KEYS + ('identities', 'account') if k in st)
        if old.get('page_id') and not any(i.get('page_id') == old['page_id'] for i in old.get('identities') or []):
            old.pop('page_id', None)
            old.pop('browse_name', None)
        save(old, key)
        shutil.rmtree(_slot_dir(new), ignore_errors=True)
        ix['order'].remove(new)
        ix['active'] = key
        _save_index(ix)
        sync_settings()
        return True
    return False


def show_in_settings(text):
    """Mirrors the account into settings, which can only show stored values."""
    try:
        kodi.set_setting('signed_in_as', text)
    except Exception:
        pass


def _name(st):
    name = st.get('account') or ''
    if name and st.get('page_id') and st.get('browse_name'):
        name = '%s · as %s' % (name, st['browse_name'])
    return name


def display_name():
    """'Main name', or 'Main name · as Channel' when browsing as one of your channels."""
    return _name(load()) or 'Signed in'


def sync_settings():
    """Keeps the 'Signed in as' line in settings matching the stored sign-in."""
    want = display_name() if signed_in() else ''
    if kodi.setting('signed_in_as') != want:
        show_in_settings(want)


def sign_out():
    """YouTube no longer accepts this account's sign-in: its tokens go, but the account and its local data
    stay, so signing in again picks up where it left off."""
    st = load()
    if st:
        for k in TOKEN_KEYS:
            st.pop(k, None)
        save(st)
    show_in_settings('')


def client_data(session):
    """Reads the TV app's OAuth client id and secret out of YouTube's TV page script."""
    page = session.get(TV_PAGE, headers={'User-Agent': PAGE_UA}, timeout=20).text
    src = None
    for pat in BASE_JS_PATTERNS:
        m = re.search(pat, page)
        if m:
            src = m.group(1).replace('\\/', '/')
            break
    if not src:
        raise AuthError('Could not find YouTube TV\'s script')
    if src.startswith('//'):
        src = 'https:' + src
    elif src.startswith('/'):
        src = 'https://www.youtube.com' + src
    script = session.get(src, headers={'User-Agent': PAGE_UA}, timeout=30).text
    m = re.search(CLIENT_PATTERN, script)
    if not m:
        raise AuthError('Could not read YouTube TV\'s sign-in details')
    return m.group(1), m.group(2)


def _post(session, url, body):
    r = session.post(url, data=json.dumps(body), headers={'Content-Type': 'application/json', 'User-Agent': PAGE_UA},
                     timeout=20)
    try:
        data = r.json()
    except Exception:
        raise AuthError('YouTube sign-in returned HTTP %s' % r.status_code)
    return data


def start(session):
    """Begins sign-in. Returns the pending state including the code to show the user."""
    client_id, client_secret = client_data(session)
    device_id = str(uuid.uuid4())
    data = _post(session, DEVICE_CODE_URL, {'client_id': client_id, 'device_id': device_id,
                                             'model_name': MODEL_NAME, 'scope': SCOPE})
    if not data.get('user_code') or not data.get('device_code'):
        raise AuthError(data.get('error_description') or data.get('error') or 'No sign-in code returned')
    return {
        'client_id': client_id, 'client_secret': client_secret, 'device_id': device_id,
        'device_code': data['device_code'], 'user_code': data['user_code'],
        'url': data.get('verification_url') or 'https://www.youtube.com/activate',
        'interval': int(data.get('interval') or 5), 'expires': time.time() + int(data.get('expires_in') or 1800),
        'slot': _new_key(),
    }


def poll(session, pending):
    """One check for approval. Returns 'pending', 'slow_down' or 'done'; raises on denial or expiry."""
    data = _post(session, TOKEN_URL, {'code': pending['device_code'], 'client_id': pending['client_id'],
                                       'client_secret': pending['client_secret'], 'grant_type': GRANT_DEVICE})
    err = data.get('error')
    if err == 'authorization_pending':
        return 'pending'
    if err == 'slow_down':
        pending['interval'] += 5
        return 'slow_down'
    if err == 'expired_token':
        raise AuthError('The code expired. Try signing in again.')
    if err == 'access_denied':
        raise AuthError('Sign-in was declined.')
    if err or not data.get('refresh_token'):
        raise AuthError(data.get('error_description') or err or 'Sign-in failed')
    # A new account goes into its own folder and becomes the active one; merge_duplicate() folds it back into
    # an existing account once YouTube says who it is.
    key = pending['slot']
    save({
        'client_id': pending['client_id'], 'client_secret': pending['client_secret'],
        'device_id': pending['device_id'], 'refresh_token': data['refresh_token'],
        'access_token': data.get('access_token'),
        'expires_at': time.time() + int(data.get('expires_in') or 3600),
    }, key)
    ix = _index()
    ix['order'].append(key)
    ix['active'] = key
    _save_index(ix)
    show_in_settings('Signed in')
    return 'done'


def access_token(session):
    """A valid access token, refreshed when needed. None when signed out or the sign-in was revoked."""
    st = load()
    if not st.get('refresh_token'):
        return None
    if st.get('access_token') and time.time() < st.get('expires_at', 0) - 60:
        return st['access_token']
    data = _post(session, TOKEN_URL, {'refresh_token': st['refresh_token'], 'client_id': st['client_id'],
                                       'client_secret': st['client_secret'], 'grant_type': 'refresh_token'})
    if data.get('error') in ('invalid_grant', 'unauthorized_client', 'invalid_client'):
        kodi.log('sign-in no longer valid (%s); signing out' % data.get('error'))
        sign_out()
        return None
    if not data.get('access_token'):
        raise AuthError(data.get('error_description') or data.get('error') or 'Could not refresh sign-in')
    st.update(access_token=data['access_token'], expires_at=time.time() + int(data.get('expires_in') or 3600))
    save(st)
    return st['access_token']


def set_account_name(name):
    st = load()
    if st:
        st['account'] = name
        save(st)
    show_in_settings(display_name())


def set_identities(accounts):
    """Remembers your main account and channels, keeping the chosen channel if it's still there."""
    st = load()
    if not st:
        return
    st['identities'] = [{'name': a['name'], 'handle': a.get('handle', ''), 'page_id': a.get('page_id')}
                        for a in accounts]
    if accounts:
        st['account'] = accounts[0]['name']
    if st.get('page_id') and not any(a.get('page_id') == st['page_id'] for a in accounts):
        st.pop('page_id', None)
        st.pop('browse_name', None)
    save(st)
    show_in_settings(display_name())


def identities():
    return load().get('identities') or []


def page_id():
    return load().get('page_id')


def select_identity(page_id_value, name):
    st = load()
    if not st:
        return
    if page_id_value:
        st['page_id'] = page_id_value
        st['browse_name'] = name
    else:
        st.pop('page_id', None)
        st.pop('browse_name', None)
    save(st)
    show_in_settings(display_name())


def account_name():
    return load().get('account') or ''
