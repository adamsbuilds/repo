import json
import os
import sys
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.youtube')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))


def setting(key):
    return ADDON.getSetting(key)


def setting_bool(key):
    return ADDON.getSetting(key) == 'true'


def setting_int(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except (TypeError, ValueError):
        return default


def set_setting(key, value):
    ADDON.setSetting(key, value)


def profile_dir():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


# Data files carried over from the earlier stand-alone TubeLite add-on (plugin.video.tubelite).
MIGRATE_FILES = ('channels.json', 'history.json', 'searches.json', 'clients.json', 'clients_meta.json')


def migrate_from_tubelite():
    dest = profile_dir()
    marker = os.path.join(dest, '.migrated')
    if os.path.exists(marker):
        return
    old = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.tubelite/')
    for name in MIGRATE_FILES:
        src = os.path.join(old, name)
        if os.path.exists(src) and not os.path.exists(os.path.join(dest, name)):
            try:
                with open(src, 'rb') as f, open(os.path.join(dest, name), 'wb') as g:
                    g.write(f.read())
            except Exception:
                pass
    with open(marker, 'w') as f:
        f.write('1')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), level)


def notify(msg, title=None, ms=4000):
    xbmcgui.Dialog().notification(title or ADDON_NAME, msg, os.path.join(ADDON_PATH, 'icon.png'), ms)


def keyboard(heading, default=''):
    kb = xbmc.Keyboard(default, heading)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText().strip()
    return ''


def url(path, **params):
    params = dict((k, v) for k, v in params.items() if v not in (None, ''))
    base = 'plugin://%s/%s/' % (ADDON_ID, path.strip('/')) if path else 'plugin://%s/' % ADDON_ID
    return base + ('?' + urlencode(params) if params else '')


def icon(name):
    return os.path.join(ADDON_PATH, 'resources', 'media', name)


def handle():
    return int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1


def jsonrpc(method, **params):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))


def error_path():
    return os.path.join(profile_dir(), 'last_error.txt')


def record_error(where, exc):
    """Saves the full details of the last error so they can be shown on screen and shared."""
    import time
    import traceback
    detail = getattr(exc, 'detail', '')
    text = '%s\nWhere: %s\nError: %s\n%s\n%s' % (
        time.strftime('%Y-%m-%d %H:%M'), where, exc,
        ('YouTube replied: %s\n' % detail) if detail else '',
        ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    try:
        with open(error_path(), 'w', encoding='utf-8') as f:
            f.write(text)
    except Exception:
        pass
    log('error in %s: %s %s' % (where, exc, detail), xbmc.LOGERROR)
