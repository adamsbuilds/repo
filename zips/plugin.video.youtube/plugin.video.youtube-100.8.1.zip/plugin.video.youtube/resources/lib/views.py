"""Set views, the way Fen Light does it: open a sample list of a kind, pick a view from the skin's side
menu, then select an item to save that view. Saved per skin, since view numbers mean nothing in another
skin, and applied whenever TubeLite opens that kind of list."""

import json
import os
import sys
import time
from urllib.parse import parse_qsl, unquote

import xbmc
import xbmcgui
import xbmcplugin

from . import kodi

# (target, label, Kodi content type the target's lists use)
TARGETS = (
    ('menus', 'Menus, moods and genres', 'files'),
    ('rows', 'Home and music rows', 'files'),
    ('videos', 'Videos and songs', 'videos'),
    ('channels', 'Channels and artists', 'files'),
    ('playlists', 'Playlists, albums and mixes', 'files'),
    ('movies', 'Free movies', 'movies'),
    ('episodes', 'TV episodes', 'episodes'),
)
CONTENT = dict((t, c) for t, _, c in TARGETS)
LABELS = dict((t, l) for t, l, _ in TARGETS)


def for_content(content):
    return {'files': 'menus', 'videos': 'videos', 'movies': 'movies', 'episodes': 'episodes'}.get(content)


def _path():
    return os.path.join(kodi.profile_dir(), 'views.json')


def _load():
    try:
        with open(_path(), encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _store(data):
    with open(_path(), 'w', encoding='utf-8') as f:
        json.dump(data, f)


def saved(target):
    return _load().get(xbmc.getSkinDir(), {}).get(target)


def _args():
    return dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}


def _here():
    return unquote(sys.argv[0] + (sys.argv[2] if len(sys.argv) > 2 else '')).rstrip('/')


def apply(target):
    """Switches the open list to the saved view once Kodi shows it. Lists loaded as skin widgets never
    become the open folder, so they're left alone."""
    view = saved(target) if target else None
    if not view or kodi.handle() < 0 or xbmcgui.getCurrentWindowId() == 10000:
        return
    here = _here()
    for _ in range(40):
        if unquote(xbmc.getInfoLabel('Container.FolderPath')).rstrip('/') == here:
            xbmc.executebuiltin('Container.SetViewMode(%s)' % view)
            return
        xbmc.sleep(50)


# ---------------------------------------------------------------- the Set views folder

def menu():
    handle = kodi.handle()
    for target, label, _ in TARGETS:
        view = saved(target)
        li = xbmcgui.ListItem('%s  [COLOR grey]%s[/COLOR]' % (label, ('view %s' % view) if view else 'skin default'),
                              offscreen=True)
        art = kodi.icon('settings.png')
        li.setArt({'icon': art, 'thumb': art, 'poster': art, 'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
        li.getVideoInfoTag().setPlot('Opens a sample %s list. Pick a view from the skin\'s side menu, then select '
                                     'any item in the list to save it.' % label.lower())
        li.addContextMenuItems([('Use the skin\'s default for %s' % label,
                                 'RunPlugin(%s)' % kodi.url('views/clear', target=target))])
        xbmcplugin.addDirectoryItem(handle, kodi.url('views/sample', target=target), li, True)
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def sample():
    """A stand-in list of the chosen kind. Every item saves the current view when selected."""
    handle = kodi.handle()
    target = _args().get('target', 'videos')
    label = LABELS.get(target, target)
    content = CONTENT.get(target, 'videos')
    thumb = kodi.icon('next_wide.png')
    for n in range(1, 9):
        li = xbmcgui.ListItem('[B]Select to save this view for %s[/B]' % label if n == 1 else
                              '%s example %d' % (label, n - 1), offscreen=True)
        art = os.path.join(kodi.ADDON_PATH, 'icon.png')
        li.setArt({'icon': art, 'thumb': art, 'poster': art, 'landscape': thumb,
                   'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
        tag = li.getVideoInfoTag()
        tag.setTitle(li.getLabel())
        tag.setPlot('1. Open the skin\'s side menu and choose a view.\n2. Select any item here to save that view '
                    'for %s.' % label.lower())
        if content != 'files':
            tag.setMediaType({'movies': 'movie', 'episodes': 'episode'}.get(content, 'video'))
        xbmcplugin.addDirectoryItem(handle, kodi.url('views/save', target=target), li, False)
    xbmcplugin.setContent(handle, content)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    view = saved(target)
    if view:
        apply(target)


def save():
    target = _args().get('target')
    view = xbmc.getInfoLabel('System.CurrentControlId')
    if kodi.handle() >= 0:
        xbmcplugin.endOfDirectory(kodi.handle(), succeeded=False)
    if target not in LABELS or not view.isdigit():
        kodi.notify('Couldn\'t read the view. Select an item inside the list.')
        return
    data = _load()
    data.setdefault(xbmc.getSkinDir(), {})[target] = view
    _store(data)
    kodi.notify('%s will use this view (%s)' % (LABELS[target], view))
    time.sleep(0.2)
    xbmc.executebuiltin('Action(Back)')


def clear():
    target = _args().get('target')
    data = _load()
    if data.get(xbmc.getSkinDir(), {}).pop(target, None) is not None:
        _store(data)
        kodi.notify('%s will use the skin\'s default view' % LABELS.get(target, target))
    xbmc.executebuiltin('Container.Refresh')
