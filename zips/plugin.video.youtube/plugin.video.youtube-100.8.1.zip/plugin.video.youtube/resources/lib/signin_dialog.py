"""Full-screen sign-in prompt: QR code, the URL, the code and a countdown.

Built from code (no skin XML), so it looks the same on every skin. Coordinates
are in a 1280x720 space, which Kodi scales to the screen.
"""

import os
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui

from . import auth, kodi, qr

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_STOP = 13

WHITE = kodi.icon('white.png')
RED = '0xFFFF3347'
GREY = '0xFFB0B0B0'


def qr_target(pending):
    """Where the QR code sends the phone. The code is added as user_code in case the page fills it in;
    it's shown on screen either way."""
    base = pending['url'] if pending['url'].startswith('http') else 'https://' + pending['url']
    return base + ('&' if '?' in base else '?') + urlencode({'user_code': pending['user_code']})


class SignInDialog(xbmcgui.WindowDialog):
    def __init__(self, pending, qr_path):
        super(SignInDialog, self).__init__()
        self.cancelled = False
        self.pending = pending
        url = pending['url'].replace('https://', '').replace('http://', '').rstrip('/')
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, WHITE, colorDiffuse='0xF0000000'))
        self.addControl(xbmcgui.ControlImage(170, 100, 940, 520, WHITE, colorDiffuse='0xFF212121'))
        self.addControl(xbmcgui.ControlImage(170, 100, 940, 6, WHITE, colorDiffuse=RED))
        self.addControl(xbmcgui.ControlLabel(220, 130, 840, 50, '[B]Sign in to YouTube[/B]', font='font30',
                                             textColor='0xFFFFFFFF'))
        self.addControl(xbmcgui.ControlImage(220, 200, 360, 360, qr_path, aspectRatio=2))
        x, w = 620, 450
        self.addControl(xbmcgui.ControlLabel(x, 210, w, 30, 'Scan the code with your phone', font='font13',
                                             textColor='0xFFFFFFFF'))
        self.addControl(xbmcgui.ControlLabel(x, 245, w, 30, 'or open this on any device:', font='font13',
                                             textColor=GREY))
        self.addControl(xbmcgui.ControlLabel(x, 280, w, 45, '[B]%s[/B]' % url, font='font30', textColor='0xFFFFFFFF'))
        self.addControl(xbmcgui.ControlLabel(x, 350, w, 30, 'Then enter this code:', font='font13', textColor=GREY))
        self.addControl(xbmcgui.ControlImage(x, 388, 330, 70, WHITE, colorDiffuse='0xFF303030'))
        self.addControl(xbmcgui.ControlLabel(x, 400, 330, 50, '[B]%s[/B]' % pending['user_code'], font='font30',
                                             textColor='0xFFFFFFFF', alignment=0x00000002))
        self.status = xbmcgui.ControlLabel(x, 490, w, 30, '', font='font13', textColor=GREY)
        self.addControl(self.status)
        self.addControl(xbmcgui.ControlLabel(x, 525, w, 30, 'Pick your main account, not a channel. You can browse '
                                             'as a channel afterwards.', font='font12', textColor='0xFF808080'))
        self.addControl(xbmcgui.ControlLabel(x, 560, w, 30, 'Press Back to cancel', font='font12',
                                             textColor='0xFF808080'))

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_STOP):
            self.cancelled = True

    def set_status(self, text):
        self.status.setLabel(text)


def run(session):
    """Shows the sign-in screen until approved, cancelled or expired. Returns True when signed in."""
    pending = auth.start(session)
    qr_path = os.path.join(kodi.profile_dir(), 'signin_qr_%d.png' % int(time.time()))
    qr.write(qr_target(pending), qr_path)
    dialog = SignInDialog(pending, qr_path)
    dialog.show()
    result = None
    error = None
    try:
        next_poll = time.time() + pending['interval']
        while not dialog.cancelled:
            left = int(pending['expires'] - time.time())
            if left <= 0:
                error = 'The code expired. Try signing in again.'
                break
            dialog.set_status('Waiting for you to approve…  (%d:%02d)' % (left // 60, left % 60))
            if time.time() >= next_poll:
                result = auth.poll(session, pending)
                if result == 'done':
                    dialog.set_status('[COLOR FF4CAF50]Signed in![/COLOR]')
                    xbmc.sleep(800)
                    break
                next_poll = time.time() + pending['interval']
            xbmc.sleep(250)
    except auth.AuthError as e:
        error = str(e)
    finally:
        dialog.close()
        del dialog
        try:
            os.remove(qr_path)
        except Exception:
            pass
    if error:
        xbmcgui.Dialog().ok(kodi.ADDON_NAME, error)
    return result == 'done'
