from . import lexer
from .lexer import NAME, NUM, STR, REGEX, PUNC, TMPL, EOF


class ParseError(Exception):
    pass


ASSIGN_OPS = frozenset(('=', '+=', '-=', '*=', '/=', '%=', '<<=', '>>=', '>>>=', '&=', '|=', '^=', '**=', '&&=', '||=', '??='))
BIN_PREC = {
    '??': 1, '||': 2, '&&': 3, '|': 4, '^': 5, '&': 6,
    '==': 7, '!=': 7, '===': 7, '!==': 7,
    '<': 8, '>': 8, '<=': 8, '>=': 8, 'instanceof': 8, 'in': 8,
    '<<': 9, '>>': 9, '>>>': 9,
    '+': 10, '-': 10, '*': 11, '/': 11, '%': 11, '**': 12,
}
LOGICAL = frozenset(('||', '&&', '??'))
UNARY = frozenset(('!', '~', '+', '-', 'typeof', 'void', 'delete', 'await'))
RESERVED = frozenset((
    'break', 'case', 'catch', 'continue', 'debugger', 'default', 'delete', 'do', 'else',
    'finally', 'for', 'function', 'if', 'in', 'instanceof', 'new', 'return', 'switch',
    'this', 'throw', 'try', 'typeof', 'var', 'void', 'while', 'with', 'class', 'const',
    'enum', 'export', 'extends', 'import', 'super', 'null', 'true', 'false'))

_ESC = {'n': '\n', 't': '\t', 'r': '\r', 'b': '\b', 'f': '\f', 'v': '\v', '0': '\0'}


def decode_string(body):
    if '\\' not in body:
        return body
    out = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c != '\\':
            out.append(c)
            i += 1
            continue
        i += 1
        c = body[i]
        if c == 'x':
            out.append(chr(int(body[i + 1:i + 3], 16)))
            i += 3
        elif c == 'u':
            if body[i + 1] == '{':
                j = body.index('}', i)
                out.append(chr(int(body[i + 2:j], 16)))
                i = j + 1
            else:
                code = int(body[i + 1:i + 5], 16)
                i += 5
                if 0xD800 <= code < 0xDC00 and body.startswith('\\u', i):
                    low = int(body[i + 2:i + 6], 16)
                    if 0xDC00 <= low < 0xE000:
                        code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        i += 6
                out.append(chr(code))
        elif c == '0' and i + 1 < n and body[i + 1].isdigit():
            j = i
            while j < n and j < i + 3 and body[j] in '01234567':
                j += 1
            out.append(chr(int(body[i:j], 8)))
            i = j
        elif c in _ESC:
            out.append(_ESC[c])
            i += 1
        elif c == '\r':
            i += 2 if body.startswith('\r\n', i) else 1
        elif c in '\n  ':
            i += 1
        elif c in '1234567':
            j = i
            while j < n and j < i + 3 and body[j] in '01234567':
                j += 1
            out.append(chr(int(body[i:j], 8)))
            i = j
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def parse_number(t):
    t = t.replace('_', '')
    if t.endswith('n'):
        return int(t[:-1], 0)
    low = t[:2].lower()
    if low == '0x':
        return int(t[2:], 16)
    if low == '0b':
        return int(t[2:], 2)
    if low == '0o':
        return int(t[2:], 8)
    if len(t) > 1 and t[0] == '0' and t.isdigit():
        if all(c in '01234567' for c in t):
            return int(t, 8)
        return int(t, 10)
    if t.isdigit():
        return int(t)
    v = float(t)
    if v.is_integer() and abs(v) < 2 ** 53:
        return int(v)
    return v


class Func(object):
    __slots__ = ('name', 'params', 'body', 'arrow', 'expr', 'range', 'tokens', 'compiled', 'is_decl', 'src')

    def __init__(self, name, params, body, arrow=False, expr=False, rng=None, tokens=None):
        self.name = name
        self.params = params
        self.body = body
        self.arrow = arrow
        self.expr = expr
        self.range = rng
        self.tokens = tokens
        self.compiled = None
        self.is_decl = False
        self.src = None


class Parser(object):
    def __init__(self, tokens, i=0, stop=None, lazy=True):
        self.tk = tokens
        if tokens.match is None:
            lexer.match_brackets(tokens)
        self.ty = tokens.type
        self.tx = tokens.text
        self.nl = tokens.nl
        self.match = tokens.match
        self.i = i
        self.stop = len(tokens.type) - 1 if stop is None else stop
        self.lazy = lazy

    def error(self, msg):
        i = min(self.i, len(self.tx) - 1)
        pos = self.tk.pos[i]
        raise ParseError('%s at %d near %r' % (msg, pos, self.tk.src[max(0, pos - 40):pos + 40]))

    def at_end(self):
        return self.i >= self.stop

    def peek(self, k=0):
        j = self.i + k
        if j >= self.stop:
            return ''
        return self.tx[j]

    def ptype(self, k=0):
        j = self.i + k
        if j >= self.stop:
            return EOF
        return self.ty[j]

    def eat(self, t):
        if self.i < self.stop and self.tx[self.i] == t and self.ty[self.i] in (PUNC, NAME):
            self.i += 1
            return True
        return False

    def expect(self, t):
        if self.i < self.stop and self.tx[self.i] == t:
            self.i += 1
            return
        self.error('expected %r' % t)

    def semicolon(self):
        if self.i >= self.stop:
            return
        t = self.tx[self.i]
        if t == ';' and self.ty[self.i] == PUNC:
            self.i += 1
            return
        if t == '}' or self.nl[self.i]:
            return
        self.error('expected ;')

    def ident(self):
        if self.ptype() != NAME:
            self.error('expected identifier')
        t = self.tx[self.i]
        self.i += 1
        return t

    def program(self):
        out = []
        while not self.at_end():
            out.append(self.statement())
        return out

    def statement(self):
        ty = self.ptype()
        t = self.peek()
        if ty == PUNC:
            if t == '{':
                return self.block()
            if t == ';':
                self.i += 1
                return ('empty',)
        elif ty == NAME:
            if t == 'var' or ((t == 'let' or t == 'const') and (self.ptype(1) == NAME or self.peek(1) in ('[', '{'))):
                self.i += 1
                d = self.var_decls(t)
                self.semicolon()
                return d
            if t == 'function':
                f = self.function(decl=True)
                return ('fundecl', f.name, f)
            if t == 'if':
                self.i += 1
                self.expect('(')
                test = self.expression()
                self.expect(')')
                cons = self.statement()
                alt = None
                if self.eat('else'):
                    alt = self.statement()
                return ('if', test, cons, alt)
            if t == 'for':
                return self.for_statement()
            if t == 'while':
                self.i += 1
                self.expect('(')
                test = self.expression()
                self.expect(')')
                return ('while', test, self.statement(), None)
            if t == 'do':
                self.i += 1
                body = self.statement()
                self.expect('while')
                self.expect('(')
                test = self.expression()
                self.expect(')')
                self.eat(';')
                return ('dowhile', test, body, None)
            if t == 'return':
                self.i += 1
                arg = None
                if not self.at_end() and self.peek() not in (';', '}') and not self.nl[self.i]:
                    arg = self.expression()
                self.semicolon()
                return ('return', arg)
            if t == 'break' or t == 'continue':
                self.i += 1
                label = None
                if self.ptype() == NAME and not self.nl[self.i] and self.peek() not in RESERVED:
                    label = self.ident()
                self.semicolon()
                return (t, label)
            if t == 'throw':
                self.i += 1
                arg = self.expression()
                self.semicolon()
                return ('throw', arg)
            if t == 'try':
                return self.try_statement()
            if t == 'switch':
                return self.switch_statement()
            if t == 'debugger':
                self.i += 1
                self.semicolon()
                return ('empty',)
            if t == 'class':
                return self.class_decl()
            if self.peek(1) == ':' and t not in RESERVED:
                self.i += 2
                body = self.statement()
                return ('label', t, body)
            if t == 'async' and self.peek(1) == 'function' and not self.nl[self.i + 1]:
                self.error('async functions are not supported')
        e = self.expression()
        self.semicolon()
        return ('expr', e)

    def block(self):
        self.expect('{')
        out = []
        while self.peek() != '}':
            if self.at_end():
                self.error('unterminated block')
            out.append(self.statement())
        self.i += 1
        return ('block', out)

    def var_decls(self, kind, no_in=False):
        decls = []
        while True:
            if self.peek() in ('[', '{'):
                target = self.binding_pattern()
            else:
                target = ('id', self.ident())
            init = None
            if self.eat('='):
                init = self.assign(no_in)
            decls.append((target, init))
            if not self.eat(','):
                break
        return ('var', kind, decls)

    def binding_pattern(self):
        e = self.primary()
        return self.to_pattern(e)

    def for_statement(self):
        self.i += 1
        self.expect('(')
        init = None
        if self.peek() == ';':
            pass
        elif self.peek() in ('var', 'let', 'const') and self.ptype() == NAME and (self.peek() == 'var' or self.ptype(1) == NAME or self.peek(1) in ('[', '{')):
            kind = self.peek()
            self.i += 1
            init = self.var_decls(kind, no_in=True)
        else:
            init = ('expr', self.expression(no_in=True))
        if self.peek() in ('in', 'of') and self.ptype() == NAME:
            kind = self.tx[self.i]
            self.i += 1
            obj = self.expression() if kind == 'in' else self.assign()
            self.expect(')')
            body = self.statement()
            if init[0] == 'var':
                target = ('decl', init[1], init[2][0][0])
            else:
                target = self.to_pattern(init[1])
            return ('forin' if kind == 'in' else 'forof', target, obj, body, None)
        self.expect(';')
        test = None if self.peek() == ';' else self.expression()
        self.expect(';')
        update = None if self.peek() == ')' else self.expression()
        self.expect(')')
        body = self.statement()
        return ('for', init, test, update, body, None)

    def try_statement(self):
        self.i += 1
        block = self.block()
        param = None
        handler = None
        final = None
        if self.eat('catch'):
            if self.eat('('):
                if self.peek() in ('[', '{'):
                    param = self.binding_pattern()
                else:
                    param = ('id', self.ident())
                self.expect(')')
            handler = self.block()
        if self.eat('finally'):
            final = self.block()
        return ('try', block, param, handler, final)

    def switch_statement(self):
        self.i += 1
        self.expect('(')
        disc = self.expression()
        self.expect(')')
        self.expect('{')
        cases = []
        while not self.eat('}'):
            if self.eat('default'):
                test = None
            else:
                self.expect('case')
                test = self.expression()
            self.expect(':')
            body = []
            while self.peek() not in ('case', 'default', '}') or self.ptype() == STR:
                if self.at_end():
                    self.error('unterminated switch')
                body.append(self.statement())
            cases.append((test, body))
        return ('switch', disc, cases, None)

    def class_decl(self):
        c = self.class_expr()
        return ('var', 'let', [(('id', c[1]), c)])

    def class_expr(self):
        self.expect('class')
        name = None
        if self.ptype() == NAME and self.peek() != 'extends' and self.peek() != '{':
            name = self.ident()
        parent = None
        if self.eat('extends'):
            parent = self.call_member()
        self.expect('{')
        members = []
        while not self.eat('}'):
            if self.eat(';'):
                continue
            static = False
            if self.peek() == 'static' and self.peek(1) not in ('(', '='):
                self.i += 1
                static = True
            kind = 'method'
            if self.peek() in ('get', 'set') and self.peek(1) not in ('(', '=', ';', '}'):
                kind = self.tx[self.i]
                self.i += 1
            key, computed = self.prop_key()
            if self.peek() == '(':
                f = self.function_rest(key if not computed else None, method=True)
                members.append((kind, static, key, computed, f))
            else:
                val = None
                if self.eat('='):
                    val = self.assign()
                self.semicolon()
                members.append(('field', static, key, computed, val))
        return ('class', name, parent, members)

    def prop_key(self):
        ty = self.ptype()
        t = self.peek()
        if t == '[' and ty == PUNC:
            self.i += 1
            k = self.assign()
            self.expect(']')
            return k, True
        self.i += 1
        if ty == STR:
            return decode_string(t[1:-1]), False
        if ty == NUM:
            from .runtime import num_to_str
            return num_to_str(parse_number(t)), False
        if ty == NAME:
            return t, False
        if t == '#':
            return '#' + self.ident(), False
        self.i -= 1
        self.error('bad property key')

    def function(self, decl=False):
        self.expect('function')
        if self.peek() == '*':
            self.error('generators are not supported')
        name = None
        if self.ptype() == NAME and self.peek() != '(':
            name = self.ident()
        f = self.function_rest(name)
        f.is_decl = decl
        return f

    def params(self):
        self.expect('(')
        out = []
        while not self.eat(')'):
            if self.eat('...'):
                out.append(('rest', self.binding_target()))
            else:
                target = self.binding_target()
                if self.eat('='):
                    target = ('default', target, self.assign())
                out.append(target)
            if not self.eat(','):
                self.expect(')')
                break
        return out

    def binding_target(self):
        if self.peek() in ('[', '{'):
            return self.binding_pattern()
        return ('id', self.ident())

    def function_rest(self, name, method=False):
        params = self.params()
        if self.peek() != '{':
            self.error('expected function body')
        start = self.i
        end = self.match[start]
        if self.lazy:
            self.i = end + 1
            return Func(name, params, None, rng=(start + 1, end), tokens=self.tk)
        body = self.block()[1]
        return Func(name, params, body)

    def body_of(self, f):
        if f.body is None:
            p = Parser(f.tokens, f.range[0], f.range[1], lazy=self.lazy)
            f.body = p.program()
        return f.body

    def expression(self, no_in=False):
        e = self.assign(no_in)
        if self.peek() == ',' and self.ptype() == PUNC:
            items = [e]
            while self.eat(','):
                items.append(self.assign(no_in))
            return ('seq', items)
        return e

    def arrow_ahead(self):
        i = self.i
        if i >= self.stop:
            return False
        t = self.tx[i]
        ty = self.ty[i]
        if ty == NAME and t not in RESERVED:
            j = i + 1
            if t == 'async' and self.ty[j] == NAME and self.tx[j + 1] == '=>':
                return True
            return self.tx[j] == '=>' and self.ty[j] == PUNC and not self.nl[j]
        if t == '(' and ty == PUNC:
            j = self.match[i] + 1
            return j < len(self.tx) and self.tx[j] == '=>' and self.ty[j] == PUNC
        return False

    def arrow(self):
        if self.peek() == 'async':
            self.error('async functions are not supported')
        if self.ptype() == NAME:
            params = [('id', self.ident())]
        else:
            params = self.params()
        self.expect('=>')
        if self.peek() == '{':
            start = self.i
            end = self.match[start]
            if self.lazy:
                self.i = end + 1
                return ('func', Func(None, params, None, arrow=True, rng=(start + 1, end), tokens=self.tk))
            body = self.block()[1]
            return ('func', Func(None, params, body, arrow=True))
        e = self.assign()
        return ('func', Func(None, params, [('return', e)], arrow=True, expr=True))

    def assign(self, no_in=False):
        if self.arrow_ahead():
            return self.arrow()
        left = self.conditional(no_in)
        if self.i < self.stop and self.ty[self.i] == PUNC:
            op = self.tx[self.i]
            if op in ASSIGN_OPS:
                self.i += 1
                if op == '=':
                    left = self.to_pattern(left)
                elif left[0] not in ('id', 'member', 'index'):
                    self.error('bad assignment target')
                right = self.assign(no_in)
                return ('assign', op, left, right)
        return left

    def to_pattern(self, e):
        k = e[0]
        if k in ('id', 'member', 'index', 'pattern_arr', 'pattern_obj', 'default'):
            return e
        if k == 'arr':
            items = []
            for it in e[1]:
                if it is None:
                    items.append(None)
                elif it[0] == 'spread':
                    items.append(('rest', self.to_pattern(it[1])))
                else:
                    items.append(self.to_pattern(it))
            return ('pattern_arr', items)
        if k == 'obj':
            props = []
            for p in e[1]:
                kind = p[0]
                if kind == 'spread':
                    props.append(('rest', None, False, self.to_pattern(p[1])))
                elif kind == 'init':
                    props.append(('prop', p[1], p[2], self.to_pattern(p[3])))
                else:
                    self.error('bad pattern')
            return ('pattern_obj', props)
        if k == 'assign' and e[1] == '=':
            return ('default', self.to_pattern(e[2]), e[3])
        self.error('bad assignment target')

    def conditional(self, no_in=False):
        test = self.binary(0, no_in)
        if self.peek() == '?' and self.ptype() == PUNC:
            self.i += 1
            cons = self.assign()
            self.expect(':')
            alt = self.assign(no_in)
            return ('cond', test, cons, alt)
        return test

    def binary(self, min_prec, no_in=False):
        left = self.unary()
        tx, ty = self.tx, self.ty
        while self.i < self.stop:
            op = tx[self.i]
            t = ty[self.i]
            if t == PUNC or (t == NAME and (op == 'instanceof' or (op == 'in' and not no_in))):
                prec = BIN_PREC.get(op)
            else:
                prec = None
            if prec is None or prec <= min_prec:
                break
            self.i += 1
            if op == '**':
                right = self.binary(prec - 1, no_in)
            else:
                right = self.binary(prec, no_in)
            if op in LOGICAL:
                left = ('logic', op, left, right)
            else:
                left = ('bin', op, left, right)
        return left

    def unary(self):
        t = self.peek()
        ty = self.ptype()
        if (ty == PUNC and t in ('!', '~', '+', '-')) or (ty == NAME and t in ('typeof', 'void', 'delete')):
            self.i += 1
            arg = self.unary()
            if t == '-' and arg[0] == 'num':
                v = arg[1]
                return ('num', -v if v != 0 else -0.0)
            return ('unary', t, arg)
        if ty == PUNC and t in ('++', '--'):
            self.i += 1
            arg = self.unary()
            return ('update', t, True, arg)
        return self.postfix()

    def postfix(self):
        e = self.call_member()
        if self.i < self.stop and self.ty[self.i] == PUNC and self.tx[self.i] in ('++', '--') and not self.nl[self.i]:
            op = self.tx[self.i]
            self.i += 1
            return ('update', op, False, e)
        return e

    def arguments(self):
        self.expect('(')
        args = []
        while not self.eat(')'):
            if self.eat('...'):
                args.append(('spread', self.assign()))
            else:
                args.append(self.assign())
            if not self.eat(','):
                self.expect(')')
                break
        return args

    def call_member(self):
        tx, ty = self.tx, self.ty
        if self.peek() == 'new' and self.ptype() == NAME:
            self.i += 1
            if self.peek() == '.':
                self.i += 1
                self.ident()
                e = ('newtarget',)
            else:
                callee = self.member_only()
                args = self.arguments() if self.peek() == '(' else []
                e = ('new', callee, args)
        else:
            e = self.primary()
        chain = False
        while self.i < self.stop:
            t = tx[self.i]
            if ty[self.i] == PUNC:
                if t == '.':
                    self.i += 1
                    if self.peek() == '#':
                        self.i += 1
                        e = ('member', e, '#' + self.ident())
                    else:
                        e = ('member', e, self.name_token())
                    continue
                if t == '?.':
                    self.i += 1
                    chain = True
                    if self.peek() == '(':
                        e = ('call', ('optional', e), self.arguments())
                    elif self.peek() == '[':
                        self.i += 1
                        k = self.expression()
                        self.expect(']')
                        e = ('index', ('optional', e), k)
                    else:
                        e = ('member', ('optional', e), self.name_token())
                    continue
                if t == '[':
                    self.i += 1
                    k = self.expression()
                    self.expect(']')
                    e = ('index', e, k)
                    continue
                if t == '(':
                    e = ('call', e, self.arguments())
                    continue
            elif ty[self.i] == TMPL:
                self.error('tagged templates are not supported')
            break
        if chain:
            e = ('chain', e)
        return e

    def member_only(self):
        if self.peek() == 'new' and self.ptype() == NAME:
            self.i += 1
            callee = self.member_only()
            args = self.arguments() if self.peek() == '(' else []
            e = ('new', callee, args)
        else:
            e = self.primary()
        while self.i < self.stop and self.ty[self.i] == PUNC:
            t = self.tx[self.i]
            if t == '.':
                self.i += 1
                e = ('member', e, self.name_token())
            elif t == '[':
                self.i += 1
                k = self.expression()
                self.expect(']')
                e = ('index', e, k)
            else:
                break
        return e

    def name_token(self):
        if self.ptype() != NAME:
            self.error('expected property name')
        t = self.tx[self.i]
        self.i += 1
        return t

    def primary(self):
        if self.i >= self.stop:
            self.error('unexpected end')
        ty = self.ty[self.i]
        t = self.tx[self.i]
        if ty == NAME:
            if t == 'function':
                return ('func', self.function())
            if t == 'class':
                return self.class_expr()
            self.i += 1
            if t == 'this':
                return ('this',)
            if t == 'null':
                return ('lit', None)
            if t == 'true':
                return ('lit', True)
            if t == 'false':
                return ('lit', False)
            if t == 'super':
                return ('super',)
            if t in RESERVED:
                self.i -= 1
                self.error('unexpected %r' % t)
            return ('id', t)
        if ty == NUM:
            self.i += 1
            return ('num', parse_number(t))
        if ty == STR:
            self.i += 1
            return ('str', decode_string(t[1:-1]))
        if ty == TMPL:
            self.i += 1
            return self.template(t)
        if ty == REGEX:
            self.i += 1
            j = t.rindex('/')
            return ('regex', t[1:j], t[j + 1:])
        if t == '(':
            self.i += 1
            e = self.expression()
            self.expect(')')
            return e
        if t == '[':
            return self.array()
        if t == '{':
            return self.object()
        self.error('unexpected token %r' % t)

    def array(self):
        self.expect('[')
        items = []
        while not self.eat(']'):
            if self.peek() == ',':
                self.i += 1
                items.append(None)
                continue
            if self.eat('...'):
                items.append(('spread', self.assign()))
            else:
                items.append(self.assign())
            if not self.eat(','):
                self.expect(']')
                break
        return ('arr', items)

    def object(self):
        self.expect('{')
        props = []
        while not self.eat('}'):
            if self.eat('...'):
                props.append(('spread', self.assign()))
            else:
                t = self.peek()
                ty = self.ptype()
                if ty == NAME and t in ('get', 'set') and self.peek(1) not in (',', ':', '(', '}'):
                    self.i += 1
                    key, computed = self.prop_key()
                    f = self.function_rest(None, method=True)
                    props.append((t, key, computed, f))
                elif ty == NAME and t == 'async' and self.peek(1) not in (',', ':', '(', '}'):
                    self.error('async methods are not supported')
                else:
                    key, computed = self.prop_key()
                    if self.eat(':'):
                        props.append(('init', key, computed, self.assign()))
                    elif self.peek() == '(':
                        f = self.function_rest(None, method=True)
                        props.append(('init', key, computed, ('func', f)))
                    elif self.peek() == '=' and ty == NAME:
                        self.i += 1
                        props.append(('init', key, False, ('assign', '=', ('id', key), self.assign())))
                    elif ty == NAME:
                        props.append(('init', key, False, ('id', key)))
                    else:
                        self.error('bad object literal')
            if not self.eat(','):
                self.expect('}')
                break
        return ('obj', props)

    def template(self, raw):
        body = raw[1:-1]
        parts = []
        exprs = []
        buf = []
        i = 0
        n = len(body)
        while i < n:
            c = body[i]
            if c == '\\':
                buf.append(body[i:i + 2])
                i += 2
            elif c == '$' and body.startswith('${', i):
                parts.append(decode_string(''.join(buf)))
                buf = []
                sub = lexer.Tokens(body)
                end = lexer._lex(body, i + 2, sub, brace_stop=True)
                sub.type.append(EOF)
                sub.text.append('')
                sub.pos.append(end)
                sub.nl.append(True)
                p = Parser(sub, 0, len(sub.type) - 1, lazy=False)
                exprs.append(p.expression())
                i = end
            else:
                buf.append(c)
                i += 1
        parts.append(decode_string(''.join(buf)))
        return ('tmpl', parts, exprs)


def parse(src, lazy=True):
    tk = lexer.tokenize(src)
    lexer.match_brackets(tk)
    return Parser(tk, lazy=lazy).program()


def parse_range(tokens, a, b, lazy=True):
    return Parser(tokens, a, b, lazy=lazy).program()
