from . import builtins
from . import parser as P
from .interp import Compiler, Ctx, Closure, Scope, TopLevel, _collect_vars
from .runtime import (UNDEF, REALM, JSObject, JSThrow, throw_error, _MISSING)

_ROOT_CTX = Ctx(frozenset(), None, is_func=False)
_GLOBAL = None


def global_object():
    global _GLOBAL
    if _GLOBAL is None:
        _GLOBAL = builtins.build_globals()
    return _GLOBAL


class Env(object):
    def __init__(self):
        self.G = global_object().props
        self.vars = {}
        self.top = TopLevel(self)
        self.compiler = Compiler(self.top, self._parse_body)
        self.scope = Scope(None, UNDEF)
        self.scope.vars = self.vars

    def _parse_body(self, f):
        if f.body is None:
            f.body = P.Parser(f.tokens, f.range[0], f.range[1]).program()
        return f.body

    def ensure(self, name):
        pass

    def lookup(self, name):
        v = self.vars.get(name, _MISSING)
        if v is not _MISSING:
            return v
        self.ensure(name)
        v = self.vars.get(name, _MISSING)
        if v is not _MISSING:
            return v
        v = self.G.get(name, _MISSING)
        if v is not _MISSING:
            return v
        raise throw_error('ReferenceError', '%s is not defined' % name)

    def defined(self, name):
        if name in self.vars:
            return True
        self.ensure(name)
        return name in self.vars or name in self.G

    def assign(self, name, value):
        if name not in self.vars:
            self.ensure(name)
            if name not in self.vars and name in self.G and not self.owns(name):
                self.G[name] = value
                return
        self.vars[name] = value

    def owns(self, name):
        return False

    def exec_statements(self, stmts):
        comp = self.compiler
        names = set()
        funcs = []
        _collect_vars(stmts, names, funcs)
        for n in names:
            if n not in self.vars:
                self.vars[n] = UNDEF
        for f in funcs:
            self.vars[f.name] = Closure(f, self.scope, comp, _ROOT_CTX)
        result = UNDEF
        for s in stmts:
            if s[0] == 'expr':
                result = comp.expr(s[1], _ROOT_CTX)(self.scope)
                continue
            fn = comp.stmt(s, _ROOT_CTX)
            if fn is not None:
                r = fn(self.scope)
                if r is not None and r[0] == 'r':
                    return r[1]
        return result

    def run(self, src):
        return self.exec_statements(P.parse(src))

    def eval_expr(self, src):
        tk = P.lexer.tokenize(src)
        P.lexer.match_brackets(tk)
        e = P.Parser(tk).expression()
        return self.compiler.expr(e, _ROOT_CTX)(self.scope)

    def call(self, fn, args, this=UNDEF):
        return fn.call(this, list(args))


class Namespace(JSObject):
    __slots__ = ('env', 'prefix')

    def __init__(self, env, prefix):
        JSObject.__init__(self, REALM.ObjectProto, 'Object')
        self.env = env
        self.prefix = prefix

    def get_own(self, key):
        if key.__class__ is int:
            key = str(key)
        v = self.props.get(key, _MISSING)
        if v is _MISSING and key.__class__ is str:
            self.env.ensure(self.prefix + key)
            v = self.props.get(key, _MISSING)
        return v

    def put(self, key, value, this=None):
        if key.__class__ is int:
            key = str(key)
        if key not in self.props and key.__class__ is str:
            self.env.ensure(self.prefix + key)
        self.props[key] = value


class PlayerEnv(Env):
    def __init__(self, program):
        Env.__init__(self)
        from . import slicer
        self.prog = program
        self.units = slicer.units(program, reads=False)
        self.writers = slicer.writer_index(self.units)
        self.aliases = set(k for u in self.units if u.alias_of for k in u.writes)
        self.done_units = set()
        self.state = {}
        self.order = []
        ns = program.namespace
        self.ns_name = ns
        self.ns_prefix = ns + '.'
        self.namespace = Namespace(self, self.ns_prefix)
        self.vars[ns] = self.namespace
        self.vars['window'] = global_object()
        self.vars['_yt_player'] = self.namespace
        self.failures = []

    def owns(self, name):
        return name in self.writers

    def ensure(self, key):
        st = self.state.get(key)
        if st is not None:
            return
        if key in self.aliases:
            self.state[key] = 2
            return
        us = self.writers.get(key)
        if not us:
            self.state[key] = 2
            return
        self.state[key] = 1
        for u in us:
            self.run_unit(u)
        self.state[key] = 2

    def run_unit(self, u):
        if u.index in self.done_units:
            return
        self.done_units.add(u.index)
        for d in u.deps:
            self._exec_unit(d, again=True)
        self._exec_unit(u)
        self.order.append(u.index)

    def _exec_unit(self, u, again=False):
        tk = self.prog.tk
        try:
            if u.decl is not None:
                p = P.Parser(tk, u.a, u.b)
                e = p.assign()
                if e[0] == 'id':
                    if e[1] not in self.vars:
                        self.vars[e[1]] = UNDEF
                    return
                self.compiler.expr(e, _ROOT_CTX)(self.scope)
                return
            stmts = P.Parser(tk, u.a, u.b).program()
            self.exec_statements(stmts)
        except JSThrow as e:
            self.failures.append((u.index, str(e)))
        except P.ParseError as e:
            self.failures.append((u.index, 'parse: %s' % e))
        except RecursionError:
            self.failures.append((u.index, 'recursion'))

    def unit_text(self, u):
        return self.prog.text(u.a, u.b)

    def slice_source(self):
        idx = sorted(self.order)
        parts = []
        seen = set()
        for i in idx:
            u = self.units[i]
            for d in u.deps:
                parts.append(self._unit_source(d))
            if i not in seen:
                seen.add(i)
                parts.append(self._unit_source(u))
        return '\n'.join(parts)

    def _unit_source(self, u):
        txt = self.prog.text(u.a, u.b)
        if u.decl is not None:
            if txt.endswith(','):
                txt = txt[:-1]
            return 'var ' + txt + ';'
        if not txt.endswith(';') and not txt.endswith('}'):
            txt += ';'
        return txt
