from . import lexer
from .lexer import NAME, STR, PUNC
import re

from .env import Env, PlayerEnv, global_object
from .runtime import UNDEF, REALM, JSObject, JSFunction, JSThrow, get_prop, to_str, call
from . import slicer
from . import parser as P

ENGINE = 1
_STS_RX = re.compile(r'(?:signatureTimestamp|sts)\s*:\s*(\d{5})')

_SKIP_KEYS = ('constructor', 'set', 'get', 'clone')


class SolverError(Exception):
    pass


def _url_builders(prog, us):
    tk = prog.tk
    texts, types = tk.text, tk.type
    hits = []
    for i in range(prog.body[0], prog.body[1] - 6):
        if (texts[i] == 'set' and texts[i - 1] == '.' and texts[i + 1] == '(' and types[i + 2] == STR
                and texts[i + 2][1:-1] == 'alr' and texts[i + 3] == ',' and types[i + 4] == STR
                and texts[i + 4][1:-1] == 'yes' and texts[i + 5] == ')'):
            hits.append(i)
    names = []
    for i in hits:
        for u in us:
            if u.a <= i < u.b:
                keys = sorted(u.writes) or sorted(u.mutates)
                for k in keys:
                    if k not in names:
                        names.append(k)
                break
    return names


def signature_timestamp(src):
    m = _STS_RX.search(src)
    return int(m.group(1)) if m else None


class BaseSolver(object):
    env = None
    ns_prefix = 'g.'
    namespace = None
    candidates = ()
    working = None

    def _builder(self, name):
        if name.startswith(self.ns_prefix):
            return get_prop(self.namespace, name[len(self.ns_prefix):])
        return self.env.lookup(name)

    def _run(self, name, n, sig):
        enc = self.env.G['encodeURIComponent']
        dec = self.env.G['decodeURIComponent']
        f = self._builder(name)
        if not isinstance(f, JSFunction):
            raise SolverError('%s is not a function' % name)
        s_arg = enc.call(UNDEF, [sig]) if sig else UNDEF
        url = f.call(UNDEF, ['https://youtube.com/watch?v=yt-dlp-wins', 's', s_arg])
        call(get_prop(url, 'set'), url, ['n', UNDEF if n is None else n])
        proto = url.proto if isinstance(url, JSObject) else None
        if proto is None:
            raise SolverError('URL object has no prototype')
        keys = proto.own_keys() + proto.own_keys(True)
        for key in keys:
            if key not in _SKIP_KEYS:
                call(get_prop(url, key), url, [])
                break
        s = call(get_prop(url, 'get'), url, ['s'])
        nv = call(get_prop(url, 'get'), url, ['n'])
        out_sig = dec.call(UNDEF, [s]) if s not in (UNDEF, None, '') else None
        out_n = None if nv in (UNDEF, None) else to_str(nv)
        return out_n, out_sig

    def solve(self, n=None, sig=None):
        names = [self.working] if self.working else self.candidates
        results = []
        errors = []
        for name in names:
            try:
                results.append(self._run(name, n, sig))
                if self.working is None:
                    self.working = name
                break
            except (JSThrow, SolverError, RecursionError, TypeError, AttributeError, KeyError) as e:
                errors.append('%s: %s' % (name, e))
        if not results:
            raise SolverError('; '.join(errors) or 'no solution')
        return results[0]

    def n(self, value):
        out = self.solve(n=value)[0]
        if not out or out == value or out.endswith(value):
            raise SolverError('n function rejected %r' % value)
        return out

    def sig(self, value):
        out = self.solve(sig=value)[1]
        if not out:
            raise SolverError('signature function returned nothing')
        return out


class Solver(BaseSolver):
    def __init__(self, src):
        self.sts = signature_timestamp(src)
        self.prog = slicer.Program(src)
        self.env = PlayerEnv(self.prog)
        self.ns_prefix = self.env.ns_prefix
        self.namespace = self.env.namespace
        self.candidates = _url_builders(self.prog, self.env.units)
        if not self.candidates:
            raise SolverError('URL builder not found in player')
        self.working = None

    def export(self):
        if not self.working:
            raise SolverError('solve once before exporting')
        return {'engine': ENGINE, 'sts': self.sts, 'builder': self.working,
                'ns': self.env.ns_name, 'slice': self.env.slice_source()}


class SliceSolver(BaseSolver):
    def __init__(self, data):
        if data.get('engine') != ENGINE:
            raise SolverError('saved solver is from another engine version')
        self.sts = data.get('sts')
        self.env = Env()
        ns = data.get('ns') or 'g'
        self.ns_prefix = ns + '.'
        self.namespace = JSObject(REALM.ObjectProto)
        self.env.vars[ns] = self.namespace
        self.env.vars['window'] = global_object()
        self.env.vars['_yt_player'] = self.namespace
        try:
            self.env.run(data['slice'])
        except (JSThrow, P.ParseError) as e:
            raise SolverError('saved solver failed to load: %s' % e)
        self.candidates = [data['builder']]
        self.working = data['builder']
