import re
from array import array

NAME, NUM, STR, REGEX, PUNC, TMPL, EOF = 1, 2, 3, 4, 5, 6, 7

_RX = re.compile(r'''
 (?P<ws>(?:[ \t\r\n\v\f ﻿  ]+|//[^\n]*|/\*.*?\*/)+)
|(?P<name>(?:[^\W\d]|\$)[\w$‌‍]*)
|(?P<num>0[xX][0-9a-fA-F_]+n?|0[bB][01_]+n?|0[oO][0-7_]+n?|(?:\d[\d_]*\.?[\d_]*(?:[eE][+-]?\d+)?|\.\d[\d_]*(?:[eE][+-]?\d+)?)n?)
|(?P<str>"(?:[^"\\\n]|\\.|\\\n)*"|'(?:[^'\\\n]|\\.|\\\n)*')
|(?P<punc>>>>=|\.\.\.|===|!==|\*\*=|<<=|>>=|>>>|\?\?=|&&=|\|\|=|=>|==|!=|<=|>=|&&|\|\||\?\?|\?\.(?!\d)|\+\+|--|\+=|-=|\*=|/=|%=|&=|\|=|\^=|\*\*|<<|>>|[{}()\[\];,<>+\-*/%&|^!~?:=.@#])
|(?P<tmpl>`)
''', re.S | re.X)

_REGEX_BODY = re.compile(r'(?:[^\\/\[\n]|\\.|\[(?:[^\]\\\n]|\\.)*\])+/[\w$]*')

_BEFORE_REGEX_WORDS = frozenset((
    'return', 'typeof', 'case', 'do', 'else', 'in', 'instanceof', 'new',
    'delete', 'void', 'throw', 'yield', 'await', 'of'))
_NOT_BEFORE_REGEX = frozenset((')', ']', '}'))


class LexError(Exception):
    pass


class Tokens(object):
    __slots__ = ('src', 'type', 'text', 'pos', 'nl', 'match')

    def __init__(self, src):
        self.src = src
        self.type = bytearray()
        self.text = []
        self.pos = array('i')
        self.nl = bytearray()
        self.match = None

    def __len__(self):
        return len(self.type)


def _scan_template(src, i):
    n = len(src)
    while i < n:
        c = src[i]
        if c == '\\':
            i += 2
        elif c == '`':
            return i + 1
        elif c == '$' and src.startswith('${', i):
            sub = Tokens(src)
            i = _lex(src, i + 2, sub, brace_stop=True)
        else:
            i += 1
    raise LexError('unterminated template')


def _lex(src, i, out, brace_stop=False):
    rx_match = _RX.match
    regex_body = _REGEX_BODY.match
    types, texts, poss, nls = out.type, out.text, out.pos, out.nl
    shared = {}
    n = len(src)
    nl = False
    depth = 0
    last_type = None
    last_text = None
    while i < n:
        m = rx_match(src, i)
        if m is None:
            raise LexError('bad character %r at %d' % (src[i], i))
        kind = m.lastgroup
        end = m.end()
        if kind == 'ws':
            if not nl:
                t = m.group()
                if '\n' in t or ' ' in t or ' ' in t:
                    nl = True
            i = end
            continue
        if kind == 'name':
            types.append(NAME)
            t = m.group()
            texts.append(shared.setdefault(t, t))
            poss.append(i)
            nls.append(nl)
            nl = False
            last_type, last_text = NAME, t
            i = end
            continue
        elif kind == 'punc':
            t = m.group()
            t = shared.setdefault(t, t)
            if t == '/' or t == '/=':
                if (last_type is None or (last_type == PUNC and last_text not in _NOT_BEFORE_REGEX)
                        or (last_type == NAME and last_text in _BEFORE_REGEX_WORDS)):
                    r = regex_body(src, i + 1)
                    if r is None:
                        raise LexError('bad regex at %d' % i)
                    end = r.end()
                    types.append(REGEX)
                    texts.append(src[i:end])
                    poss.append(i)
                    nls.append(nl)
                    nl = False
                    last_type, last_text = REGEX, None
                    i = end
                    continue
            elif brace_stop:
                if t == '{':
                    depth += 1
                elif t == '}':
                    if depth == 0:
                        return end
                    depth -= 1
            types.append(PUNC)
            texts.append(t)
            poss.append(i)
            nls.append(nl)
            nl = False
            last_type, last_text = PUNC, t
            i = end
            continue
        elif kind == 'num':
            types.append(NUM)
        elif kind == 'str':
            types.append(STR)
        else:
            end = _scan_template(src, end)
            types.append(TMPL)
        t = src[i:end]
        texts.append(t)
        poss.append(i)
        nls.append(nl)
        nl = False
        last_type, last_text = types[-1], t
        i = end
    if brace_stop:
        raise LexError('unterminated template expression')
    return i


def tokenize(src):
    out = Tokens(src)
    _lex(src, 0, out)
    out.type.append(EOF)
    out.text.append('')
    out.pos.append(len(src))
    out.nl.append(True)
    return out


def match_brackets(tokens):
    pairs = {'(': ')', '[': ']', '{': '}'}
    closers = {')', ']', '}'}
    match = array('i', [-1]) * len(tokens.type)
    stack = []
    push = stack.append
    pop = stack.pop
    types, texts = tokens.type, tokens.text
    for idx in range(len(types)):
        if types[idx] != PUNC:
            continue
        t = texts[idx]
        if t in pairs:
            push(idx)
        elif t in closers:
            if not stack:
                raise LexError('unbalanced %s at %d' % (t, tokens.pos[idx]))
            j = pop()
            if pairs[texts[j]] != t:
                raise LexError('mismatched %s at %d' % (t, tokens.pos[idx]))
            match[j] = idx
            match[idx] = j
    if stack:
        raise LexError('unclosed bracket at %d' % tokens.pos[stack[-1]])
    tokens.match = match
    return match
