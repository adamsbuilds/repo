import math
import re


class Undefined(object):
    __slots__ = ()

    def __repr__(self):
        return 'undefined'

    def __bool__(self):
        return False


UNDEF = Undefined()
NAN = float('nan')
INF = float('inf')


class JSThrow(Exception):
    def __init__(self, value):
        Exception.__init__(self)
        self.value = value

    def __str__(self):
        v = self.value
        if isinstance(v, JSObject):
            try:
                return '%s: %s' % (to_str(v.get('name')), to_str(v.get('message')))
            except Exception:
                pass
        try:
            return to_str(v)
        except Exception:
            return repr(v)


class Accessor(object):
    __slots__ = ('get', 'set')

    def __init__(self, get=None, set=None):
        self.get = get
        self.set = set


class JSObject(object):
    __slots__ = ('props', 'proto', 'cls', 'hidden', 'frozen', 'prim', '__weakref__')

    def __init__(self, proto=None, cls='Object'):
        self.props = {}
        self.proto = proto
        self.cls = cls
        self.hidden = None
        self.frozen = False
        self.prim = None

    def __repr__(self):
        return '<JS %s>' % self.cls

    def get_own(self, key):
        if key.__class__ is int:
            key = str(key)
        return self.props.get(key, _MISSING)

    def get(self, key, this=None):
        o = self
        while o is not None:
            v = o.get_own(key)
            if v is not _MISSING:
                if v.__class__ is Accessor:
                    if v.get is None:
                        return UNDEF
                    return v.get.call(self if this is None else this, [])
                return v
            o = o.proto
        return UNDEF

    def find(self, key):
        o = self
        while o is not None:
            v = o.get_own(key)
            if v is not _MISSING:
                return o, v
            o = o.proto
        return None, _MISSING

    def put(self, key, value, this=None):
        if key.__class__ is int:
            key = str(key)
        props = self.props
        cur = props.get(key, _MISSING)
        if cur is not _MISSING and cur.__class__ is not Accessor:
            if not self.frozen:
                props[key] = value
            return
        owner, found = self.find(key) if cur is _MISSING else (self, cur)
        if found.__class__ is Accessor:
            if found.set is not None:
                found.set.call(self if this is None else this, [value])
            return
        if not self.frozen:
            self.set_own(key, value)

    def set_own(self, key, value):
        if key.__class__ is int:
            key = str(key)
        self.props[key] = value

    def has_own(self, key):
        if key.__class__ is int:
            key = str(key)
        return key in self.props

    def has(self, key):
        o = self
        while o is not None:
            if o.has_own(key):
                return True
            o = o.proto
        return False

    def delete(self, key):
        if self.frozen:
            return False
        if key.__class__ is int:
            key = str(key)
        self.props.pop(key, None)
        if self.hidden:
            self.hidden.discard(key)
        return True

    def own_keys(self, include_hidden=False):
        keys = list(self.props.keys())
        ints = [k for k in keys if _is_index(k)]
        if ints:
            others = [k for k in keys if not _is_index(k)]
            keys = sorted(ints, key=int) + others
        if include_hidden or not self.hidden:
            return keys
        h = self.hidden
        return [k for k in keys if k not in h]

    def hide(self, key):
        if self.hidden is None:
            self.hidden = set()
        self.hidden.add(key)

    def define_hidden(self, key, value):
        self.props[key] = value
        self.hide(key)


_MISSING = object()
_INDEX_RX = re.compile(r'(?:0|[1-9]\d*)\Z')


def _is_index(k):
    return k.__class__ is str and _INDEX_RX.match(k) is not None and len(k) < 16


class JSArray(JSObject):
    __slots__ = ('items',)

    def __init__(self, items=None, proto=None):
        JSObject.__init__(self, proto or REALM.ArrayProto, 'Array')
        self.items = items if items is not None else []

    def get_own(self, key):
        if key.__class__ is int:
            items = self.items
            if 0 <= key < len(items):
                return items[key]
            return _MISSING
        if key == 'length':
            return len(self.items)
        if key and key[0] in '0123456789' and _INDEX_RX.match(key):
            i = int(key)
            if i < len(self.items):
                return self.items[i]
            return _MISSING
        return self.props.get(key, _MISSING)

    def set_own(self, key, value):
        if key.__class__ is int:
            self._set_index(key, value)
            return
        if key == 'length':
            n = to_uint32(value)
            items = self.items
            if n < len(items):
                del items[n:]
            else:
                items.extend([UNDEF] * (n - len(items)))
            return
        if key and key[0] in '0123456789' and _INDEX_RX.match(key):
            self._set_index(int(key), value)
            return
        self.props[key] = value

    def _set_index(self, i, value):
        items = self.items
        n = len(items)
        if i < n:
            items[i] = value
        elif i == n:
            items.append(value)
        elif i < n + 10000000:
            items.extend([UNDEF] * (i - n))
            items.append(value)
        else:
            raise throw_error('RangeError', 'array too large')

    def put(self, key, value, this=None):
        if key.__class__ is int and not self.frozen:
            if key >= 0:
                self._set_index(key, value)
                return
            key = str(key)
        if key == 'length' or (key.__class__ is str and key[:1].isdigit()):
            if not self.frozen:
                self.set_own(key, value)
            return
        JSObject.put(self, key, value, this)

    def has_own(self, key):
        if key.__class__ is int:
            return 0 <= key < len(self.items)
        if key == 'length':
            return True
        if key and key[0] in '0123456789' and _INDEX_RX.match(key):
            return int(key) < len(self.items)
        return key in self.props

    def delete(self, key):
        if key.__class__ is str and _is_index(key):
            key = int(key)
        if key.__class__ is int:
            if 0 <= key < len(self.items):
                self.items[key] = UNDEF
            return True
        return JSObject.delete(self, key)

    def own_keys(self, include_hidden=False):
        keys = [str(i) for i in range(len(self.items))]
        keys.extend(JSObject.own_keys(self, include_hidden))
        if include_hidden:
            keys.append('length')
        return keys


class JSFunction(JSObject):
    __slots__ = ('name', 'nparams')

    def __init__(self, name='', nparams=0, proto=None):
        JSObject.__init__(self, proto or REALM.FunctionProto, 'Function')
        self.name = name
        self.nparams = nparams

    def get_own(self, key):
        v = self.props.get(key, _MISSING)
        if v is _MISSING:
            if key == 'prototype' and self.has_prototype():
                p = JSObject(REALM.ObjectProto)
                p.define_hidden('constructor', self)
                self.props['prototype'] = p
                self.hide('prototype')
                return p
            if key == 'name':
                return self.name or ''
            if key == 'length':
                return self.nparams
        return v

    def has_prototype(self):
        return False

    def call(self, this, args):
        raise NotImplementedError

    def construct(self, args, new_target=None):
        proto = (new_target or self).get('prototype')
        if not isinstance(proto, JSObject):
            proto = REALM.ObjectProto
        obj = JSObject(proto)
        r = self.call(obj, args)
        if isinstance(r, JSObject):
            return r
        return obj


class Native(JSFunction):
    __slots__ = ('fn', 'ctor')

    def __init__(self, fn, name='', nparams=0, ctor=None):
        JSFunction.__init__(self, name, nparams)
        self.fn = fn
        self.ctor = ctor

    def has_prototype(self):
        return self.ctor is not None

    def call(self, this, args):
        return self.fn(this, args)

    def construct(self, args, new_target=None):
        if self.ctor is None:
            raise throw_error('TypeError', '%s is not a constructor' % (self.name or 'function'))
        r = self.ctor(args, new_target or self)
        return r


class Bound(JSFunction):
    __slots__ = ('target', 'bthis', 'bargs')

    def __init__(self, target, bthis, bargs):
        JSFunction.__init__(self, 'bound ' + to_str(target.get('name')), max(0, target.nparams - len(bargs)))
        self.target = target
        self.bthis = bthis
        self.bargs = bargs

    def call(self, this, args):
        return self.target.call(self.bthis, self.bargs + list(args))

    def construct(self, args, new_target=None):
        return self.target.construct(self.bargs + list(args))


class Realm(object):
    pass


REALM = Realm()


def throw_error(kind, msg):
    ctor = REALM.globals.get(kind) if hasattr(REALM, 'globals') else None
    if isinstance(ctor, JSFunction):
        e = make_error(ctor, msg)
    else:
        e = msg
    return JSThrow(e)


def make_error(ctor, msg):
    proto = ctor.get('prototype')
    e = JSObject(proto if isinstance(proto, JSObject) else REALM.ObjectProto, 'Error')
    if msg is not UNDEF:
        e.define_hidden('message', to_str(msg))
    e.define_hidden('stack', '%s: %s' % (to_str(ctor.get('name')), '' if msg is UNDEF else to_str(msg)))
    return e


def typeof(v):
    if v is UNDEF:
        return 'undefined'
    if v is None:
        return 'object'
    c = v.__class__
    if c is str:
        return 'string'
    if c is bool:
        return 'boolean'
    if c is int or c is float:
        return 'number'
    if isinstance(v, JSFunction):
        return 'function'
    if c is Symbol:
        return 'symbol'
    return 'object'


class Symbol(object):
    __slots__ = ('desc',)

    def __init__(self, desc=''):
        self.desc = desc

    def __repr__(self):
        return 'Symbol(%s)' % self.desc


def num_to_str(v, radix=10):
    if v.__class__ is int:
        if radix == 10:
            return str(v)
        return _int_radix(v, radix)
    if v.__class__ is bool:
        return 'true' if v else 'false'
    if v != v:
        return 'NaN'
    if v == INF:
        return 'Infinity'
    if v == -INF:
        return '-Infinity'
    if v == 0:
        return '0'
    if radix != 10:
        if v.is_integer():
            return _int_radix(int(v), radix)
        return _float_radix(v, radix)
    if v.is_integer() and abs(v) < 1e21:
        return '%d' % v
    r = repr(v)
    if 'e' not in r:
        return r
    mant, exp = r.split('e')
    e = int(exp)
    neg = mant.startswith('-')
    if neg:
        mant = mant[1:]
    digits = mant.replace('.', '')
    point = mant.index('.') if '.' in mant else len(mant)
    digits = digits.rstrip('0') or '0'
    n = point + e
    k = len(digits)
    if k <= n <= 21:
        s = digits + '0' * (n - k)
    elif 0 < n <= 21:
        s = digits[:n] + '.' + digits[n:]
    elif -6 < n <= 0:
        s = '0.' + '0' * (-n) + digits
    else:
        e2 = n - 1
        s = digits[0] + ('.' + digits[1:] if k > 1 else '') + 'e' + ('+' if e2 >= 0 else '-') + str(abs(e2))
    return '-' + s if neg else s


_DIGITS = '0123456789abcdefghijklmnopqrstuvwxyz'


def _int_radix(n, radix):
    if n == 0:
        return '0'
    neg = n < 0
    n = abs(n)
    out = []
    while n:
        n, r = divmod(n, radix)
        out.append(_DIGITS[r])
    if neg:
        out.append('-')
    return ''.join(reversed(out))


def _float_radix(v, radix):
    neg = v < 0
    v = abs(v)
    ip = int(v)
    fp = v - ip
    s = _int_radix(ip, radix) + '.'
    for _ in range(52):
        fp *= radix
        d = int(fp)
        s += _DIGITS[d]
        fp -= d
        if fp == 0:
            break
    return ('-' if neg else '') + s


def to_str(v):
    c = v.__class__
    if c is str:
        return v
    if c is int:
        return str(v)
    if c is bool:
        return 'true' if v else 'false'
    if c is float:
        return num_to_str(v)
    if v is UNDEF:
        return 'undefined'
    if v is None:
        return 'null'
    if c is Symbol:
        raise throw_error('TypeError', 'Cannot convert a Symbol value to a string')
    return to_str(to_primitive(v, 'string'))


def to_key(v):
    c = v.__class__
    if c is str:
        return v
    if c is int:
        return v if v >= 0 else str(v)
    if c is float:
        if v.is_integer() and 0 <= v < 2 ** 53:
            return int(v)
        return num_to_str(v)
    if c is Symbol:
        return v
    return to_str(v)


def key_str(k):
    if k.__class__ is int:
        return str(k)
    return k


_NUM_RX = re.compile(r'\s*([+-]?(?:Infinity|\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?))\s*\Z')


def str_to_num(s):
    t = s.strip()
    if t == '':
        return 0
    low = t[:2].lower()
    try:
        if low == '0x':
            return int(t[2:], 16)
        if low == '0b':
            return int(t[2:], 2)
        if low == '0o':
            return int(t[2:], 8)
    except ValueError:
        return NAN
    m = _NUM_RX.match(t)
    if not m:
        return NAN
    t = m.group(1)
    if t.endswith('Infinity'):
        return -INF if t[0] == '-' else INF
    try:
        if t.lstrip('+-').isdigit():
            return int(t)
        return norm(float(t))
    except ValueError:
        return NAN


def to_num(v):
    c = v.__class__
    if c is int or c is float:
        return v
    if c is bool:
        return 1 if v else 0
    if c is str:
        return str_to_num(v)
    if v is UNDEF:
        return NAN
    if v is None:
        return 0
    if c is Symbol:
        raise throw_error('TypeError', 'Cannot convert a Symbol value to a number')
    return to_num(to_primitive(v, 'number'))


def to_bool(v):
    c = v.__class__
    if c is bool:
        return v
    if c is str:
        return len(v) > 0
    if c is int:
        return v != 0
    if c is float:
        return not (v == 0 or v != v)
    if v is UNDEF or v is None:
        return False
    return True


def to_primitive(v, hint='default'):
    if not isinstance(v, JSObject):
        return v
    order = ('toString', 'valueOf') if hint == 'string' else ('valueOf', 'toString')
    for name in order:
        f = v.get(name)
        if isinstance(f, JSFunction):
            r = f.call(v, [])
            if not isinstance(r, JSObject):
                return r
    raise throw_error('TypeError', 'Cannot convert object to primitive value')


def to_int(v):
    n = to_num(v)
    if n.__class__ is int:
        return n
    if n != n:
        return 0
    if n in (INF, -INF):
        return n
    return int(n)


def to_int32(v):
    n = v if v.__class__ is int else to_num(v)
    if n.__class__ is not int:
        if n != n or n in (INF, -INF):
            return 0
        n = int(n)
    n &= 0xFFFFFFFF
    if n & 0x80000000:
        n -= 0x100000000
    return n


def to_uint32(v):
    n = v if v.__class__ is int else to_num(v)
    if n.__class__ is not int:
        if n != n or n in (INF, -INF):
            return 0
        n = int(n)
    return n & 0xFFFFFFFF


def norm(v):
    if v.__class__ is float and v.is_integer() and -9007199254740992 <= v <= 9007199254740992:
        if v == 0 and math.copysign(1, v) < 0:
            return v
        return int(v)
    return v


def to_object(v):
    if isinstance(v, JSObject):
        return v
    if v is UNDEF or v is None:
        raise throw_error('TypeError', 'Cannot convert undefined or null to object')
    c = v.__class__
    if c is str:
        o = JSObject(REALM.StringProto, 'String')
    elif c is bool:
        o = JSObject(REALM.BooleanProto, 'Boolean')
    elif c is Symbol:
        o = JSObject(REALM.ObjectProto, 'Symbol')
    else:
        o = JSObject(REALM.NumberProto, 'Number')
    o.prim = v
    return o


def strict_eq(a, b):
    ca = a.__class__
    cb = b.__class__
    if ca is bool or cb is bool:
        return ca is cb and a == b
    if ca in (int, float) and cb in (int, float):
        return a == b
    if ca is str and cb is str:
        return a == b
    return a is b


def loose_eq(a, b):
    while True:
        ca = a.__class__
        cb = b.__class__
        if (a is None or a is UNDEF) and (b is None or b is UNDEF):
            return True
        if a is None or a is UNDEF or b is None or b is UNDEF:
            return False
        if ca is cb or (ca in (int, float) and cb in (int, float)):
            return strict_eq(a, b)
        if ca is bool:
            a = 1 if a else 0
            continue
        if cb is bool:
            b = 1 if b else 0
            continue
        if ca in (int, float) and cb is str:
            return a == str_to_num(b)
        if ca is str and cb in (int, float):
            return str_to_num(a) == b
        if isinstance(a, JSObject) and not isinstance(b, JSObject):
            a = to_primitive(a)
            continue
        if isinstance(b, JSObject) and not isinstance(a, JSObject):
            b = to_primitive(b)
            continue
        return False


def js_add(a, b):
    ca = a.__class__
    cb = b.__class__
    if ca is int and cb is int:
        r = a + b
        if -9007199254740992 <= r <= 9007199254740992:
            return r
        return float(r)
    if ca is str and cb is str:
        return a + b
    if isinstance(a, JSObject):
        a = to_primitive(a)
        ca = a.__class__
    if isinstance(b, JSObject):
        b = to_primitive(b)
        cb = b.__class__
    if ca is str or cb is str:
        return to_str(a) + to_str(b)
    return norm(to_num(a) + to_num(b))


def js_sub(a, b):
    if a.__class__ is int and b.__class__ is int:
        return a - b
    return norm(to_num(a) - to_num(b))


def js_mul(a, b):
    if a.__class__ is int and b.__class__ is int:
        r = a * b
        if -9007199254740992 <= r <= 9007199254740992 and not (r == 0 and (a < 0 or b < 0)):
            return r
        return float(a) * float(b)
    a = to_num(a)
    b = to_num(b)
    try:
        return norm(float(a) * float(b))
    except OverflowError:
        return INF


def js_div(a, b):
    a = to_num(a)
    b = to_num(b)
    if b == 0:
        if a != a or a == 0:
            return NAN
        neg = (a < 0) != (math.copysign(1, b) < 0)
        return -INF if neg else INF
    if a.__class__ is int and b.__class__ is int and a % b == 0:
        return a // b
    return norm(a / b)


def js_mod(a, b):
    if a.__class__ is int and b.__class__ is int and b != 0:
        r = abs(a) % abs(b)
        return -r if a < 0 else r
    a = to_num(a)
    b = to_num(b)
    if b == 0 or a != a or b != b or a in (INF, -INF):
        return NAN
    if b in (INF, -INF):
        return a
    return norm(math.fmod(a, b))


def js_pow(a, b):
    a = to_num(a)
    b = to_num(b)
    try:
        r = a ** b
        if isinstance(r, complex):
            return NAN
        return norm(r) if r.__class__ is float else r
    except (OverflowError, ZeroDivisionError):
        return INF


def js_less(a, b):
    a = to_primitive(a, 'number')
    b = to_primitive(b, 'number')
    if a.__class__ is str and b.__class__ is str:
        return a < b
    a = to_num(a)
    b = to_num(b)
    if a != a or b != b:
        return None
    return a < b


def lt(a, b):
    if a.__class__ is int and b.__class__ is int:
        return a < b
    r = js_less(a, b)
    return bool(r)


def gt(a, b):
    if a.__class__ is int and b.__class__ is int:
        return a > b
    r = js_less(b, a)
    return bool(r)


def le(a, b):
    if a.__class__ is int and b.__class__ is int:
        return a <= b
    r = js_less(b, a)
    return r is False


def ge(a, b):
    if a.__class__ is int and b.__class__ is int:
        return a >= b
    r = js_less(a, b)
    return r is False


def get_prop(v, key):
    c = v.__class__
    if c is JSArray:
        if key.__class__ is int:
            items = v.items
            if 0 <= key < len(items):
                return items[key]
        return v.get(key)
    if isinstance(v, JSObject):
        return v.get(key)
    if c is str:
        if key.__class__ is int:
            if 0 <= key < len(v):
                return v[key]
            return UNDEF
        if key == 'length':
            return len(v)
        return REALM.StringProto.get(key, v)
    if v is UNDEF or v is None:
        raise throw_error('TypeError', "Cannot read properties of %s (reading '%s')" % (to_str(v), key_str(key) if key.__class__ is not Symbol else 'symbol'))
    if c is bool:
        return REALM.BooleanProto.get(key, v)
    if c is Symbol:
        if key == 'description':
            return v.desc
        return REALM.ObjectProto.get(key, v)
    return REALM.NumberProto.get(key, v)


def set_prop(v, key, value):
    if isinstance(v, JSObject):
        v.put(key, value)
        return
    if v is UNDEF or v is None:
        raise throw_error('TypeError', "Cannot set properties of %s (setting '%s')" % (to_str(v), key_str(key)))


def call(f, this, args):
    if isinstance(f, JSFunction):
        return f.call(this, args)
    raise throw_error('TypeError', '%s is not a function' % typeof(f))


def construct(f, args):
    if isinstance(f, JSFunction):
        return f.construct(args)
    raise throw_error('TypeError', '%s is not a constructor' % typeof(f))


def instance_of(v, f):
    if not isinstance(f, JSFunction):
        raise throw_error('TypeError', "Right-hand side of 'instanceof' is not callable")
    if isinstance(f, Bound):
        f = f.target
    if not isinstance(v, JSObject):
        return False
    proto = f.get('prototype')
    o = v.proto
    while o is not None:
        if o is proto:
            return True
        o = o.proto
    return False


def has_property(obj, key):
    if not isinstance(obj, JSObject):
        raise throw_error('TypeError', "Cannot use 'in' operator to search for '%s' in %s" % (key_str(key), to_str(obj)))
    return obj.has(key)
