import json
import math
import random
import re
import time
from urllib.parse import quote, unquote

from .runtime import (
    UNDEF, NAN, INF, REALM, JSObject, JSArray, JSFunction, Native, Bound, Accessor, JSThrow, Symbol,
    throw_error, make_error, typeof, to_str, to_num, to_bool, to_key, key_str, to_int, to_int32,
    to_uint32, to_primitive, to_object, strict_eq, num_to_str, norm, str_to_num, _MISSING)


def arg(args, i):
    return args[i] if i < len(args) else UNDEF


def native(obj, name, fn, n=0, hidden=True):
    f = Native(fn, name, n)
    if hidden:
        obj.define_hidden(name, f)
    else:
        obj.props[name] = f
    return f


def _is_callable(f):
    return isinstance(f, JSFunction)


def _need_fn(f, what='callback'):
    if not isinstance(f, JSFunction):
        raise throw_error('TypeError', '%s is not a function' % typeof(f))
    return f


def _len(o):
    if o.__class__ is JSArray:
        return len(o.items)
    if o.__class__ is str:
        return len(o)
    return max(0, to_int(get(o, 'length')))


def get(o, k):
    from .runtime import get_prop
    return get_prop(o, k)


def _items(o):
    if o.__class__ is JSArray:
        return o.items
    if o.__class__ is str:
        return list(o)
    n = _len(o)
    return [get(o, i) for i in range(n)]


def _rel(i, n, default):
    if i is UNDEF:
        return default
    i = to_int(i)
    if i in (INF,):
        return n
    if i in (-INF,):
        return 0
    if i < 0:
        return max(0, n + i)
    return min(i, n)


class JSRegExp(JSObject):
    __slots__ = ('source', 'flags', 'rx', 'last')

    def __init__(self, source, flags):
        JSObject.__init__(self, REALM.RegExpProto, 'RegExp')
        self.source = source
        self.flags = flags
        self.rx = compile_regex(source, flags)
        self.props['lastIndex'] = 0
        self.hide('lastIndex')

    def get_own(self, key):
        if key == 'source':
            return self.source
        if key == 'flags':
            return ''.join(sorted(self.flags))
        if key == 'global':
            return 'g' in self.flags
        if key == 'ignoreCase':
            return 'i' in self.flags
        if key == 'multiline':
            return 'm' in self.flags
        if key == 'sticky':
            return 'y' in self.flags
        if key == 'unicode':
            return 'u' in self.flags
        return JSObject.get_own(self, key)


_rx_cache = {}


def compile_regex(source, flags):
    key = (source, flags)
    rx = _rx_cache.get(key)
    if rx is not None:
        return rx
    out = []
    i = 0
    n = len(source)
    in_class = False
    while i < n:
        c = source[i]
        if c == '\\' and i + 1 < n:
            d = source[i + 1]
            if d == 'd':
                out.append('[0-9]' if not in_class else '0-9')
            elif d == 'D':
                out.append('[^0-9]')
            elif d == 'w':
                out.append('[A-Za-z0-9_]' if not in_class else 'A-Za-z0-9_')
            elif d == 'W':
                out.append('[^A-Za-z0-9_]')
            elif d == 'u' and i + 2 < n and source[i + 2] == '{':
                j = source.index('}', i)
                out.append('\\U%08x' % int(source[i + 3:j], 16))
                i = j + 1
                continue
            elif d == 'c' and i + 2 < n:
                out.append('\\x%02x' % (ord(source[i + 2]) % 32))
                i += 3
                continue
            elif d == '/':
                out.append('/')
            elif d == 'k' and i + 2 < n and source[i + 2] == '<':
                j = source.index('>', i)
                out.append('(?P=' + source[i + 3:j] + ')')
                i = j + 1
                continue
            else:
                out.append(c + d)
            i += 2
            continue
        if in_class:
            if c == ']':
                in_class = False
            elif c == '[':
                out.append('\\[')
                i += 1
                continue
            out.append(c)
            i += 1
            continue
        if c == '[':
            if source.startswith('[^]', i):
                out.append('[\\s\\S]')
                i += 3
                continue
            if source.startswith('[]', i):
                out.append('(?!)')
                i += 2
                continue
            in_class = True
            out.append(c)
            if i + 1 < n and source[i + 1] == ']':
                out.append('\\]')
                i += 2
                continue
            i += 1
            continue
        if c == '(' and source.startswith('(?<', i) and i + 3 < n and source[i + 3] not in '=!':
            out.append('(?P<')
            i += 3
            continue
        if c == '$' and 'm' not in flags:
            out.append('(?!.|\\n)')
            i += 1
            continue
        out.append(c)
        i += 1
    pat = ''.join(out)
    f = 0
    if 'i' in flags:
        f |= re.I
    if 'm' in flags:
        f |= re.M
    if 's' in flags:
        f |= re.S
    try:
        rx = re.compile(pat, f)
    except re.error as e:
        raise throw_error('SyntaxError', 'Invalid regular expression: /%s/: %s' % (source, e))
    _rx_cache[key] = rx
    return rx


def make_regexp(source, flags):
    return JSRegExp(source, flags)


def _match_array(m, s):
    groups = [m.group(0)] + [UNDEF if g is None else g for g in m.groups()]
    a = JSArray(groups)
    a.props['index'] = m.start()
    a.props['input'] = s
    gd = m.groupdict()
    if gd:
        go = JSObject(REALM.ObjectProto)
        for k, v in gd.items():
            go.props[k] = UNDEF if v is None else v
        a.props['groups'] = go
    else:
        a.props['groups'] = UNDEF
    return a


def regexp_exec(rx, s):
    s = to_str(s)
    glob = 'g' in rx.flags or 'y' in rx.flags
    start = to_int(rx.get('lastIndex')) if glob else 0
    if start > len(s):
        rx.put('lastIndex', 0)
        return None
    if 'y' in rx.flags:
        m = rx.rx.match(s, start)
    else:
        m = rx.rx.search(s, start)
    if m is None:
        if glob:
            rx.put('lastIndex', 0)
        return None
    if glob:
        end = m.end()
        rx.put('lastIndex', end if end > m.start() else end)
    return _match_array(m, s)


def _expand_replacement(repl, m, s):
    out = []
    i = 0
    n = len(repl)
    groups = m.groups()
    while i < n:
        c = repl[i]
        if c == '$' and i + 1 < n:
            d = repl[i + 1]
            if d == '$':
                out.append('$')
                i += 2
                continue
            if d == '&':
                out.append(m.group(0))
                i += 2
                continue
            if d == '`':
                out.append(s[:m.start()])
                i += 2
                continue
            if d == "'":
                out.append(s[m.end():])
                i += 2
                continue
            if d.isdigit():
                j = i + 2
                if j < n and repl[j].isdigit() and int(repl[i + 1:j + 1]) <= len(groups):
                    j += 1
                num = int(repl[i + 1:j])
                if 1 <= num <= len(groups):
                    out.append(groups[num - 1] or '')
                    i = j
                    continue
            if d == '<':
                j = repl.find('>', i)
                if j > 0:
                    try:
                        out.append(m.group(repl[i + 2:j]) or '')
                    except (IndexError, re.error):
                        pass
                    i = j + 1
                    continue
        out.append(c)
        i += 1
    return ''.join(out)


def string_replace(s, pattern, replacement, all_=False):
    s = to_str(s)
    fn = replacement if _is_callable(replacement) else None
    rep = None if fn else to_str(replacement)
    if isinstance(pattern, JSRegExp):
        glob = 'g' in pattern.flags
        out = []
        pos = 0
        for m in pattern.rx.finditer(s):
            out.append(s[pos:m.start()])
            if fn:
                cargs = [m.group(0)] + [UNDEF if g is None else g for g in m.groups()] + [m.start(), s]
                out.append(to_str(fn.call(UNDEF, cargs)))
            else:
                out.append(_expand_replacement(rep, m, s))
            pos = m.end()
            if not glob:
                break
        out.append(s[pos:])
        if glob:
            pattern.put('lastIndex', 0)
        return ''.join(out)
    pat = to_str(pattern)
    out = []
    pos = 0
    while True:
        idx = s.find(pat, pos)
        if idx < 0:
            break
        out.append(s[pos:idx])
        if fn:
            out.append(to_str(fn.call(UNDEF, [pat, idx, s])))
        else:
            m = _LiteralMatch(s, idx, pat)
            out.append(_expand_replacement(rep, m, s))
        pos = idx + len(pat)
        if not all_:
            break
        if not pat:
            if pos < len(s):
                out.append(s[pos])
            pos += 1
            if pos > len(s):
                break
    out.append(s[pos:])
    return ''.join(out)


class _LiteralMatch(object):
    def __init__(self, s, idx, pat):
        self._s = s
        self._i = idx
        self._p = pat

    def group(self, i=0):
        return self._p

    def groups(self):
        return ()

    def start(self):
        return self._i

    def end(self):
        return self._i + len(self._p)


def iterate(o):
    if o.__class__ is JSArray:
        return list(o.items)
    if isinstance(o, JSMapLike):
        return o.iter_values()
    it_fn = o.get(REALM.sym_iterator) if REALM.sym_iterator is not None else UNDEF
    if isinstance(it_fn, JSFunction):
        it = it_fn.call(o, [])
        out = []
        nxt = get(it, 'next')
        for _ in range(10000000):
            r = nxt.call(it, [])
            if to_bool(get(r, 'done')):
                break
            out.append(get(r, 'value'))
        return out
    if o.cls == 'Arguments':
        return list(o.items)
    return None


class JSMapLike(JSObject):
    __slots__ = ('data', 'is_set')

    def __init__(self, proto, is_set):
        JSObject.__init__(self, proto, 'Set' if is_set else 'Map')
        self.data = {}
        self.is_set = is_set

    def get_own(self, key):
        if key == 'size':
            return len(self.data)
        return JSObject.get_own(self, key)

    @staticmethod
    def k(v):
        c = v.__class__
        if c is float and v.is_integer():
            return (int, int(v))
        if c in (int, str, bool, float):
            return (c, v)
        return ('id', id(v))

    def iter_values(self):
        if self.is_set:
            return [v for (_, v) in self.data.values()]
        return [JSArray([k, v]) for (k, v) in self.data.values()]


def build_globals():
    R = REALM
    R.make_regexp = make_regexp
    R.iterate = iterate
    ObjectProto = JSObject(None)
    FunctionProto = JSObject(ObjectProto, 'Function')
    R.ObjectProto = ObjectProto
    R.FunctionProto = FunctionProto
    fp = Native(lambda this, args: UNDEF, '', 0)
    fp.proto = ObjectProto
    R.FunctionProto = fp
    FunctionProto = fp
    R.ArrayProto = JSArray([], ObjectProto)
    ArrayProto = R.ArrayProto
    R.StringProto = JSObject(ObjectProto, 'String')
    R.StringProto.prim = ''
    R.NumberProto = JSObject(ObjectProto, 'Number')
    R.NumberProto.prim = 0
    R.BooleanProto = JSObject(ObjectProto, 'Boolean')
    R.BooleanProto.prim = False
    R.RegExpProto = JSObject(ObjectProto)
    R.sym_iterator = None
    G = JSObject(ObjectProto, 'global')
    R.globals = G.props
    R.global_object = G

    def ctor(name, call_fn, construct_fn, proto, n=1):
        f = Native(call_fn, name, n, construct_fn)
        f.props['prototype'] = proto
        f.hide('prototype')
        proto.define_hidden('constructor', f)
        G.define_hidden(name, f)
        return f

    def object_call(this, args):
        v = arg(args, 0)
        if v is UNDEF or v is None:
            return JSObject(ObjectProto)
        return to_object(v)

    def object_ctor(args, nt):
        v = arg(args, 0)
        if v is UNDEF or v is None:
            proto = nt.get('prototype') if nt is not None else ObjectProto
            return JSObject(proto if isinstance(proto, JSObject) else ObjectProto)
        return to_object(v)

    Object = ctor('Object', object_call, object_ctor, ObjectProto)

    def own_keys(o, hidden=False):
        o = to_object(o)
        return [k for k in o.own_keys(hidden) if k.__class__ is not Symbol]

    native(Object, 'keys', lambda t, a: JSArray([key_str(k) for k in own_keys(arg(a, 0))]), 1)
    native(Object, 'getOwnPropertyNames', lambda t, a: JSArray([key_str(k) for k in own_keys(arg(a, 0), True)]), 1)
    native(Object, 'values', lambda t, a: JSArray([to_object(arg(a, 0)).get(k) for k in own_keys(arg(a, 0))]), 1)
    native(Object, 'entries', lambda t, a: JSArray([JSArray([key_str(k), to_object(arg(a, 0)).get(k)]) for k in own_keys(arg(a, 0))]), 1)
    native(Object, 'getOwnPropertySymbols', lambda t, a: JSArray([k for k in to_object(arg(a, 0)).own_keys(True) if k.__class__ is Symbol]), 1)

    def get_proto(t, a):
        v = arg(a, 0)
        if isinstance(v, JSObject):
            return v.proto
        o = to_object(v)
        return o.proto
    native(Object, 'getPrototypeOf', get_proto, 1)

    def set_proto(t, a):
        o = arg(a, 0)
        p = arg(a, 1)
        if isinstance(o, JSObject) and (isinstance(p, JSObject) or p is None):
            o.proto = p
        return o
    native(Object, 'setPrototypeOf', set_proto, 2)

    def create(t, a):
        p = arg(a, 0)
        if not (isinstance(p, JSObject) or p is None):
            raise throw_error('TypeError', 'Object prototype may only be an Object or null')
        o = JSObject(p)
        props = arg(a, 1)
        if isinstance(props, JSObject):
            define_properties(o, props)
        return o
    native(Object, 'create', create, 2)

    def define_property(o, key, desc):
        if not isinstance(o, JSObject):
            raise throw_error('TypeError', 'Object.defineProperty called on non-object')
        if not isinstance(desc, JSObject):
            raise throw_error('TypeError', 'Property description must be an object')
        key = to_key(key)
        g = desc.get('get')
        s = desc.get('set')
        if key.__class__ is int:
            if o.__class__ is JSArray:
                o.set_own(key, desc.get('value'))
                return o
            key = str(key)
        if g is not UNDEF or s is not UNDEF:
            cur = o.props.get(key)
            acc = cur if cur.__class__ is Accessor else Accessor()
            if g is not UNDEF:
                acc.get = g if isinstance(g, JSFunction) else None
            if s is not UNDEF:
                acc.set = s if isinstance(s, JSFunction) else None
            o.props[key] = acc
        elif desc.has('value') or key not in o.props:
            if o.__class__ is JSArray and key == 'length':
                o.set_own(key, desc.get('value'))
            else:
                o.props[key] = desc.get('value')
        if not to_bool(desc.get('enumerable')):
            if not (key in o.props and desc.get('enumerable') is UNDEF and o.hidden is not None and key not in o.hidden and False):
                o.hide(key)
        elif o.hidden:
            o.hidden.discard(key)
        return o

    def define_properties(o, props):
        for k in props.own_keys():
            define_property(o, k, props.get(k))
        return o

    native(Object, 'defineProperty', lambda t, a: define_property(arg(a, 0), arg(a, 1), arg(a, 2)), 3)
    native(Object, 'defineProperties', lambda t, a: define_properties(arg(a, 0), arg(a, 1)), 2)

    def get_desc(t, a):
        o = arg(a, 0)
        if not isinstance(o, JSObject):
            return UNDEF
        k = to_key(arg(a, 1))
        if not o.has_own(k):
            return UNDEF
        v = o.get_own(k if o.__class__ is JSArray else key_str(k))
        d = JSObject(ObjectProto)
        if v.__class__ is Accessor:
            d.props['get'] = v.get or UNDEF
            d.props['set'] = v.set or UNDEF
        else:
            d.props['value'] = v
            d.props['writable'] = not o.frozen
        d.props['enumerable'] = not (o.hidden and key_str(k) in o.hidden)
        d.props['configurable'] = not o.frozen
        return d
    native(Object, 'getOwnPropertyDescriptor', get_desc, 2)

    def get_descs(t, a):
        o = arg(a, 0)
        out = JSObject(ObjectProto)
        if isinstance(o, JSObject):
            for k in o.own_keys(True):
                out.props[key_str(k)] = get_desc(t, [o, k])
        return out
    native(Object, 'getOwnPropertyDescriptors', get_descs, 1)

    def freeze(t, a):
        o = arg(a, 0)
        if isinstance(o, JSObject):
            o.frozen = True
        return o
    native(Object, 'freeze', freeze, 1)
    native(Object, 'seal', lambda t, a: arg(a, 0), 1)
    native(Object, 'preventExtensions', lambda t, a: arg(a, 0), 1)
    native(Object, 'isFrozen', lambda t, a: bool(isinstance(arg(a, 0), JSObject) and arg(a, 0).frozen) or not isinstance(arg(a, 0), JSObject), 1)
    native(Object, 'isSealed', lambda t, a: bool(isinstance(arg(a, 0), JSObject) and arg(a, 0).frozen), 1)
    native(Object, 'isExtensible', lambda t, a: isinstance(arg(a, 0), JSObject) and not arg(a, 0).frozen, 1)

    def assign(t, a):
        target = to_object(arg(a, 0))
        for src in a[1:]:
            if isinstance(src, JSObject):
                for k in src.own_keys():
                    target.put(k, src.get(k))
        return target
    native(Object, 'assign', assign, 2)

    def same_value(x, y):
        if x.__class__ in (int, float) and y.__class__ in (int, float):
            if x != x and y != y:
                return True
            if x == 0 and y == 0:
                return math.copysign(1, x) == math.copysign(1, y)
            return x == y
        return strict_eq(x, y)
    native(Object, 'is', lambda t, a: same_value(arg(a, 0), arg(a, 1)), 2)

    def from_entries(t, a):
        o = JSObject(ObjectProto)
        for e in iterate(arg(a, 0)) or []:
            o.put(to_key(get(e, 0)), get(e, 1))
        return o
    native(Object, 'fromEntries', from_entries, 1)

    def has_own(t, a):
        k = to_key(arg(a, 0))
        o = to_object(t)
        return o.has_own(k)
    native(ObjectProto, 'hasOwnProperty', has_own, 1)
    native(Object, 'hasOwn', lambda t, a: to_object(arg(a, 0)).has_own(to_key(arg(a, 1))), 2)

    def obj_to_string(t, a):
        if t is UNDEF:
            return '[object Undefined]'
        if t is None:
            return '[object Null]'
        if t.__class__ is str:
            return '[object String]'
        if t.__class__ is bool:
            return '[object Boolean]'
        if t.__class__ in (int, float):
            return '[object Number]'
        if isinstance(t, JSFunction):
            return '[object Function]'
        cls = t.cls if t.cls in ('Array', 'Error', 'RegExp', 'Date', 'Arguments', 'Boolean', 'Number', 'String') else 'Object'
        return '[object %s]' % cls
    native(ObjectProto, 'toString', obj_to_string)
    native(ObjectProto, 'toLocaleString', lambda t, a: to_str(t))

    def value_of(t, a):
        if isinstance(t, JSObject) and t.prim is not None and t is not ObjectProto:
            return t.prim
        return t
    native(ObjectProto, 'valueOf', value_of)

    def is_proto_of(t, a):
        v = arg(a, 0)
        if not isinstance(v, JSObject):
            return False
        o = v.proto
        while o is not None:
            if o is t:
                return True
            o = o.proto
        return False
    native(ObjectProto, 'isPrototypeOf', is_proto_of, 1)
    native(ObjectProto, 'propertyIsEnumerable', lambda t, a: isinstance(t, JSObject) and t.has_own(to_key(arg(a, 0))) and not (t.hidden and key_str(to_key(arg(a, 0))) in t.hidden), 1)
    ObjectProto.props['__proto__'] = Accessor(
        Native(lambda t, a: t.proto if isinstance(t, JSObject) else to_object(t).proto, 'get __proto__'),
        Native(lambda t, a: setattr(t, 'proto', arg(a, 0)) if isinstance(t, JSObject) and (isinstance(arg(a, 0), JSObject) or arg(a, 0) is None) else None, 'set __proto__'))
    ObjectProto.hide('__proto__')

    def function_call(this, args):
        raise throw_error('EvalError', 'Function constructor is not supported')
    Function = ctor('Function', function_call, lambda a, nt: function_call(None, a), FunctionProto)

    def f_call(t, a):
        return _need_fn(t).call(arg(a, 0), list(a[1:]))
    native(FunctionProto, 'call', f_call, 1)

    def f_apply(t, a):
        al = arg(a, 1)
        args = [] if al is UNDEF or al is None else list(_items(al))
        return _need_fn(t).call(arg(a, 0), args)
    native(FunctionProto, 'apply', f_apply, 2)
    native(FunctionProto, 'bind', lambda t, a: Bound(_need_fn(t), arg(a, 0), list(a[1:])), 1)

    def f_to_string(t, a):
        if hasattr(t, 'func') and getattr(t.func, 'tokens', None) is not None and t.func.range:
            return 'function %s() { [code] }' % (t.name or '')
        return 'function %s() { [native code] }' % (getattr(t, 'name', '') or '')
    native(FunctionProto, 'toString', f_to_string)

    def array_call(this, args):
        if len(args) == 1 and args[0].__class__ in (int, float):
            n = args[0]
            if n < 0 or n != int(n):
                raise throw_error('RangeError', 'Invalid array length')
            return JSArray([UNDEF] * int(n))
        return JSArray(list(args))
    Array = ctor('Array', array_call, lambda a, nt: array_call(None, a), ArrayProto)
    native(Array, 'isArray', lambda t, a: arg(a, 0).__class__ is JSArray, 1)

    def array_from(t, a):
        src = arg(a, 0)
        fn = arg(a, 1)
        if src is UNDEF or src is None:
            raise throw_error('TypeError', 'Array.from requires an array-like')
        if src.__class__ is str:
            items = list(src)
        elif isinstance(src, JSObject):
            items = iterate(src)
            if items is None:
                items = _items(src)
        else:
            items = []
        if _is_callable(fn):
            items = [fn.call(UNDEF, [v, i]) for i, v in enumerate(items)]
        return JSArray(list(items))
    native(Array, 'from', array_from, 1)
    native(Array, 'of', lambda t, a: JSArray(list(a)), 0)

    def this_items(t):
        if t.__class__ is JSArray:
            return t.items
        return None

    def a_push(t, a):
        items = this_items(t)
        if items is not None:
            items.extend(a)
            return len(items)
        n = _len(t)
        for v in a:
            t.put(n, v)
            n += 1
        t.put('length', n)
        return n
    native(ArrayProto, 'push', a_push, 1)

    def a_pop(t, a):
        items = this_items(t)
        if items is not None:
            return items.pop() if items else UNDEF
        n = _len(t)
        if n == 0:
            t.put('length', 0)
            return UNDEF
        v = get(t, n - 1)
        t.delete(n - 1)
        t.put('length', n - 1)
        return v
    native(ArrayProto, 'pop', a_pop)

    def a_shift(t, a):
        items = this_items(t)
        if items is not None:
            return items.pop(0) if items else UNDEF
        lst = _items(t)
        if not lst:
            return UNDEF
        v = lst.pop(0)
        _write_back(t, lst)
        return v
    native(ArrayProto, 'shift', a_shift)

    def _write_back(t, lst):
        n = _len(t)
        for i, v in enumerate(lst):
            t.put(i, v)
        for i in range(len(lst), n):
            t.delete(i)
        t.put('length', len(lst))

    def a_unshift(t, a):
        items = this_items(t)
        if items is not None:
            items[0:0] = a
            return len(items)
        lst = list(a) + _items(t)
        _write_back(t, lst)
        return len(lst)
    native(ArrayProto, 'unshift', a_unshift, 1)

    def a_splice(t, a):
        items = this_items(t)
        generic = items is None
        if generic:
            items = _items(t)
        n = len(items)
        start = _rel(arg(a, 0), n, 0)
        if len(a) == 0:
            count = 0
        elif len(a) == 1:
            count = n - start
        else:
            count = max(0, min(to_int(a[1]), n - start))
        removed = items[start:start + count]
        items[start:start + count] = list(a[2:])
        if generic:
            _write_back(t, items)
        return JSArray(removed)
    native(ArrayProto, 'splice', a_splice, 2)

    def a_slice(t, a):
        items = _items(t)
        n = len(items)
        s = _rel(arg(a, 0), n, 0)
        e = _rel(arg(a, 1), n, n)
        return JSArray(items[s:e])
    native(ArrayProto, 'slice', a_slice, 2)

    def a_concat(t, a):
        out = list(_items(t)) if t.__class__ is JSArray else [t]
        for v in a:
            if v.__class__ is JSArray:
                out.extend(v.items)
            else:
                out.append(v)
        return JSArray(out)
    native(ArrayProto, 'concat', a_concat, 1)

    def _join_item(v):
        if v is UNDEF or v is None:
            return ''
        return to_str(v)

    def a_join(t, a):
        sep = arg(a, 0)
        sep = ',' if sep is UNDEF else to_str(sep)
        return sep.join(_join_item(v) for v in _items(t))
    native(ArrayProto, 'join', a_join, 1)
    native(ArrayProto, 'toString', lambda t, a: a_join(t, []))
    native(ArrayProto, 'toLocaleString', lambda t, a: a_join(t, []))

    def a_reverse(t, a):
        items = this_items(t)
        if items is not None:
            items.reverse()
            return t
        lst = _items(t)
        lst.reverse()
        _write_back(t, lst)
        return t
    native(ArrayProto, 'reverse', a_reverse)

    def a_index_of(t, a):
        items = _items(t)
        v = arg(a, 0)
        start = _rel(arg(a, 1), len(items), 0)
        for i in range(start, len(items)):
            if strict_eq(items[i], v):
                return i
        return -1
    native(ArrayProto, 'indexOf', a_index_of, 1)

    def a_last_index_of(t, a):
        items = _items(t)
        v = arg(a, 0)
        start = len(items) - 1 if len(a) < 2 else to_int(a[1])
        if start < 0:
            start += len(items)
        for i in range(min(start, len(items) - 1), -1, -1):
            if strict_eq(items[i], v):
                return i
        return -1
    native(ArrayProto, 'lastIndexOf', a_last_index_of, 1)

    def a_includes(t, a):
        v = arg(a, 0)
        for x in _items(t):
            if strict_eq(x, v) or (x != x and v != v and x.__class__ is float and v.__class__ is float):
                return True
        return False
    native(ArrayProto, 'includes', a_includes, 1)

    def iter_fn(name, kind):
        def run(t, a):
            fn = _need_fn(arg(a, 0))
            this = arg(a, 1)
            items = _items(t)
            n = len(items)
            if kind == 'forEach':
                for i in range(n):
                    if i >= len(items):
                        break
                    fn.call(this, [items[i], i, t])
                return UNDEF
            if kind == 'map':
                return JSArray([fn.call(this, [items[i], i, t]) for i in range(n)])
            if kind == 'filter':
                return JSArray([items[i] for i in range(n) if to_bool(fn.call(this, [items[i], i, t]))])
            if kind == 'some':
                for i in range(n):
                    if to_bool(fn.call(this, [items[i], i, t])):
                        return True
                return False
            if kind == 'every':
                for i in range(n):
                    if not to_bool(fn.call(this, [items[i], i, t])):
                        return False
                return True
            if kind == 'find':
                for i in range(n):
                    if to_bool(fn.call(this, [items[i], i, t])):
                        return items[i]
                return UNDEF
            if kind == 'findIndex':
                for i in range(n):
                    if to_bool(fn.call(this, [items[i], i, t])):
                        return i
                return -1
            if kind == 'findLast':
                for i in range(n - 1, -1, -1):
                    if to_bool(fn.call(this, [items[i], i, t])):
                        return items[i]
                return UNDEF
            if kind == 'findLastIndex':
                for i in range(n - 1, -1, -1):
                    if to_bool(fn.call(this, [items[i], i, t])):
                        return i
                return -1
            if kind == 'flatMap':
                out = []
                for i in range(n):
                    r = fn.call(this, [items[i], i, t])
                    if r.__class__ is JSArray:
                        out.extend(r.items)
                    else:
                        out.append(r)
                return JSArray(out)
        native(ArrayProto, name, run, 1)
    for k in ('forEach', 'map', 'filter', 'some', 'every', 'find', 'findIndex', 'findLast', 'findLastIndex', 'flatMap'):
        iter_fn(k, k)

    def a_reduce(t, a, right=False):
        fn = _need_fn(arg(a, 0))
        items = _items(t)
        idx = list(range(len(items)))
        if right:
            idx.reverse()
        if len(a) > 1:
            acc = a[1]
        else:
            if not idx:
                raise throw_error('TypeError', 'Reduce of empty array with no initial value')
            acc = items[idx.pop(0)]
        for i in idx:
            acc = fn.call(UNDEF, [acc, items[i], i, t])
        return acc
    native(ArrayProto, 'reduce', a_reduce, 1)
    native(ArrayProto, 'reduceRight', lambda t, a: a_reduce(t, a, True), 1)

    def a_sort(t, a):
        fn = arg(a, 0)
        items = this_items(t)
        generic = items is None
        if generic:
            items = _items(t)
        undefs = [v for v in items if v is UNDEF]
        vals = [v for v in items if v is not UNDEF]
        import functools
        if _is_callable(fn):
            def cmp(x, y):
                r = to_num(fn.call(UNDEF, [x, y]))
                if r != r:
                    return 0
                return -1 if r < 0 else (1 if r > 0 else 0)
            vals.sort(key=functools.cmp_to_key(cmp))
        else:
            vals.sort(key=lambda v: _utf16_key(to_str(v)))
        items[:] = vals + undefs
        if generic:
            _write_back(t, items)
        return t
    native(ArrayProto, 'sort', a_sort, 1)

    def a_fill(t, a):
        items = this_items(t)
        if items is None:
            return t
        n = len(items)
        v = arg(a, 0)
        s = _rel(arg(a, 1), n, 0)
        e = _rel(arg(a, 2), n, n)
        for i in range(s, e):
            items[i] = v
        return t
    native(ArrayProto, 'fill', a_fill, 1)

    def a_flat(t, a):
        depth = 1 if arg(a, 0) is UNDEF else to_int(arg(a, 0))

        def flat(items, d):
            out = []
            for v in items:
                if v.__class__ is JSArray and d > 0:
                    out.extend(flat(v.items, d - 1))
                else:
                    out.append(v)
            return out
        return JSArray(flat(_items(t), depth))
    native(ArrayProto, 'flat', a_flat)

    def a_at(t, a):
        items = _items(t)
        i = to_int(arg(a, 0))
        if i < 0:
            i += len(items)
        return items[i] if 0 <= i < len(items) else UNDEF
    native(ArrayProto, 'at', a_at, 1)

    def a_copy_within(t, a):
        items = this_items(t)
        n = len(items)
        target = _rel(arg(a, 0), n, 0)
        s = _rel(arg(a, 1), n, 0)
        e = _rel(arg(a, 2), n, n)
        chunk = items[s:e]
        for i, v in enumerate(chunk):
            if target + i < n:
                items[target + i] = v
        return t
    native(ArrayProto, 'copyWithin', a_copy_within, 2)

    def make_iter(values):
        it = JSObject(ObjectProto)
        state = [0]

        def nxt(t, a):
            r = JSObject(ObjectProto)
            if state[0] < len(values):
                r.props['value'] = values[state[0]]
                r.props['done'] = False
                state[0] += 1
            else:
                r.props['value'] = UNDEF
                r.props['done'] = True
            return r
        native(it, 'next', nxt)
        if R.sym_iterator is not None:
            it.define_hidden(R.sym_iterator, Native(lambda t, a: t, '[Symbol.iterator]'))
        return it
    R.make_iter = make_iter
    native(ArrayProto, 'keys', lambda t, a: make_iter(list(range(len(_items(t))))))
    native(ArrayProto, 'values', lambda t, a: make_iter(list(_items(t))))
    native(ArrayProto, 'entries', lambda t, a: make_iter([JSArray([i, v]) for i, v in enumerate(_items(t))]))

    def string_call(this, args):
        if not args:
            return ''
        v = args[0]
        if v.__class__ is Symbol:
            return 'Symbol(%s)' % v.desc
        return to_str(v)

    def string_ctor(args, nt):
        o = JSObject(R.StringProto, 'String')
        o.prim = string_call(None, args)
        return o
    String = ctor('String', string_call, string_ctor, R.StringProto)
    SP = R.StringProto

    def this_str(t):
        if t.__class__ is str:
            return t
        if isinstance(t, JSObject) and t.prim.__class__ is str:
            return t.prim
        if t is UNDEF or t is None:
            raise throw_error('TypeError', 'String.prototype method called on null or undefined')
        return to_str(t)

    def from_char_code(t, a):
        out = []
        units = [to_uint32(v) & 0xFFFF for v in a]
        i = 0
        while i < len(units):
            u = units[i]
            if 0xD800 <= u < 0xDC00 and i + 1 < len(units) and 0xDC00 <= units[i + 1] < 0xE000:
                out.append(chr(0x10000 + ((u - 0xD800) << 10) + (units[i + 1] - 0xDC00)))
                i += 2
                continue
            out.append(chr(u))
            i += 1
        return ''.join(out)
    native(String, 'fromCharCode', from_char_code, 1)
    native(String, 'fromCodePoint', lambda t, a: ''.join(chr(to_int(v)) for v in a), 1)
    native(String, 'raw', lambda t, a: ''.join(_items(get(arg(a, 0), 'raw'))), 1)

    def s_char_at(t, a):
        s = this_str(t)
        i = to_int(arg(a, 0))
        return s[i] if 0 <= i < len(s) else ''
    native(SP, 'charAt', s_char_at, 1)

    def s_char_code_at(t, a):
        s = this_str(t)
        i = to_int(arg(a, 0))
        if 0 <= i < len(s):
            c = ord(s[i])
            if c > 0xFFFF:
                return 0xD800 + ((c - 0x10000) >> 10)
            return c
        return NAN
    native(SP, 'charCodeAt', s_char_code_at, 1)

    def s_code_point_at(t, a):
        s = this_str(t)
        i = to_int(arg(a, 0))
        if 0 <= i < len(s):
            return ord(s[i])
        return UNDEF
    native(SP, 'codePointAt', s_code_point_at, 1)

    def s_index_of(t, a):
        s = this_str(t)
        start = to_int(arg(a, 1)) if len(a) > 1 else 0
        return s.find(to_str(arg(a, 0)), max(0, min(start, len(s))))
    native(SP, 'indexOf', s_index_of, 1)

    def s_last_index_of(t, a):
        s = this_str(t)
        sub = to_str(arg(a, 0))
        if len(a) > 1 and arg(a, 1) is not UNDEF:
            pos = to_num(a[1])
            if pos == pos:
                return s.rfind(sub, 0, max(0, int(pos)) + len(sub))
        return s.rfind(sub)
    native(SP, 'lastIndexOf', s_last_index_of, 1)

    def s_includes(t, a):
        s = this_str(t)
        start = to_int(arg(a, 1)) if len(a) > 1 else 0
        return to_str(arg(a, 0)) in s[max(0, start):]
    native(SP, 'includes', s_includes, 1)

    def s_starts_with(t, a):
        s = this_str(t)
        pos = to_int(arg(a, 1)) if len(a) > 1 else 0
        return s.startswith(to_str(arg(a, 0)), max(0, pos))
    native(SP, 'startsWith', s_starts_with, 1)

    def s_ends_with(t, a):
        s = this_str(t)
        end = len(s) if arg(a, 1) is UNDEF else max(0, min(to_int(a[1]), len(s)))
        return s[:end].endswith(to_str(arg(a, 0)))
    native(SP, 'endsWith', s_ends_with, 1)

    def s_slice(t, a):
        s = this_str(t)
        n = len(s)
        return s[_rel(arg(a, 0), n, 0):_rel(arg(a, 1), n, n)]
    native(SP, 'slice', s_slice, 2)

    def s_substring(t, a):
        s = this_str(t)
        n = len(s)

        def clamp(v, d):
            if v is UNDEF:
                return d
            v = to_num(v)
            if v != v:
                return 0
            return int(max(0, min(v, n)))
        x = clamp(arg(a, 0), 0)
        y = clamp(arg(a, 1), n)
        if x > y:
            x, y = y, x
        return s[x:y]
    native(SP, 'substring', s_substring, 2)

    def s_substr(t, a):
        s = this_str(t)
        n = len(s)
        start = _rel(arg(a, 0), n, 0)
        ln = n - start if arg(a, 1) is UNDEF else max(0, to_int(a[1]))
        return s[start:start + ln]
    native(SP, 'substr', s_substr, 2)
    native(SP, 'toLowerCase', lambda t, a: this_str(t).lower())
    native(SP, 'toUpperCase', lambda t, a: this_str(t).upper())
    native(SP, 'toLocaleLowerCase', lambda t, a: this_str(t).lower())
    native(SP, 'toLocaleUpperCase', lambda t, a: this_str(t).upper())
    _ws = ' \t\n\r\v\f ﻿                　'
    native(SP, 'trim', lambda t, a: this_str(t).strip(_ws))
    native(SP, 'trimStart', lambda t, a: this_str(t).lstrip(_ws))
    native(SP, 'trimEnd', lambda t, a: this_str(t).rstrip(_ws))
    native(SP, 'trimLeft', lambda t, a: this_str(t).lstrip(_ws))
    native(SP, 'trimRight', lambda t, a: this_str(t).rstrip(_ws))

    def s_split(t, a):
        s = this_str(t)
        sep = arg(a, 0)
        limit = arg(a, 1)
        lim = None if limit is UNDEF else to_uint32(limit)
        if sep is UNDEF:
            out = [s]
        elif isinstance(sep, JSRegExp):
            if s == '':
                out = [] if sep.rx.match(s) else ['']
            else:
                out = []
                pos = 0
                for m in sep.rx.finditer(s):
                    if m.end() == m.start() and (m.start() == 0 or m.start() >= len(s)):
                        continue
                    if m.end() == m.start() and m.start() == pos and pos != 0 and False:
                        continue
                    out.append(s[pos:m.start()])
                    out.extend(UNDEF if g is None else g for g in m.groups())
                    pos = m.end()
                out.append(s[pos:])
        else:
            sep = to_str(sep)
            if sep == '':
                out = list(s)
            else:
                out = s.split(sep)
        if lim is not None:
            out = out[:lim]
        return JSArray(out)
    native(SP, 'split', s_split, 2)
    native(SP, 'replace', lambda t, a: string_replace(this_str(t), arg(a, 0), arg(a, 1)), 2)
    native(SP, 'replaceAll', lambda t, a: string_replace(this_str(t), arg(a, 0), arg(a, 1), True), 2)

    def s_match(t, a):
        s = this_str(t)
        rx = arg(a, 0)
        if not isinstance(rx, JSRegExp):
            rx = make_regexp('(?:)' if rx is UNDEF else _escape_literal(to_str(rx)), '')
        if 'g' in rx.flags:
            found = [m.group(0) for m in rx.rx.finditer(s)]
            rx.put('lastIndex', 0)
            return JSArray(found) if found else None
        return regexp_exec(rx, s)
    native(SP, 'match', s_match, 1)

    def s_match_all(t, a):
        s = this_str(t)
        rx = arg(a, 0)
        if not isinstance(rx, JSRegExp):
            rx = make_regexp(_escape_literal(to_str(rx)), 'g')
        return make_iter([_match_array(m, s) for m in rx.rx.finditer(s)])
    native(SP, 'matchAll', s_match_all, 1)

    def s_search(t, a):
        s = this_str(t)
        rx = arg(a, 0)
        if not isinstance(rx, JSRegExp):
            rx = make_regexp(_escape_literal(to_str(rx)), '')
        m = rx.rx.search(s)
        return m.start() if m else -1
    native(SP, 'search', s_search, 1)
    native(SP, 'concat', lambda t, a: this_str(t) + ''.join(to_str(v) for v in a), 1)
    native(SP, 'repeat', lambda t, a: this_str(t) * max(0, to_int(arg(a, 0))), 1)

    def pad(t, a, start):
        s = this_str(t)
        n = to_int(arg(a, 0))
        fill = ' ' if arg(a, 1) is UNDEF else to_str(a[1])
        if n <= len(s) or not fill:
            return s
        need = n - len(s)
        p = (fill * (need // len(fill) + 1))[:need]
        return p + s if start else s + p
    native(SP, 'padStart', lambda t, a: pad(t, a, True), 2)
    native(SP, 'padEnd', lambda t, a: pad(t, a, False), 2)
    native(SP, 'toString', lambda t, a: this_str(t))
    native(SP, 'valueOf', lambda t, a: this_str(t))
    native(SP, 'at', lambda t, a: (lambda s, i: s[i] if -len(s) <= i < len(s) else UNDEF)(this_str(t), to_int(arg(a, 0))), 1)

    def s_locale_compare(t, a):
        x = this_str(t)
        y = to_str(arg(a, 0))
        return -1 if x < y else (1 if x > y else 0)
    native(SP, 'localeCompare', s_locale_compare, 1)
    native(SP, 'normalize', lambda t, a: this_str(t))

    def number_call(this, args):
        if not args:
            return 0
        return to_num(args[0])

    def number_ctor(args, nt):
        o = JSObject(R.NumberProto, 'Number')
        o.prim = number_call(None, args)
        return o
    Number = ctor('Number', number_call, number_ctor, R.NumberProto)
    NP = R.NumberProto

    def this_num(t):
        if t.__class__ in (int, float) and t.__class__ is not bool:
            return t
        if isinstance(t, JSObject) and t.prim.__class__ in (int, float):
            return t.prim
        raise throw_error('TypeError', 'Number.prototype.valueOf requires that this be a Number')

    def n_to_string(t, a):
        radix = arg(a, 0)
        r = 10 if radix is UNDEF else to_int(radix)
        if r < 2 or r > 36:
            raise throw_error('RangeError', 'toString() radix must be between 2 and 36')
        return num_to_str(this_num(t), r)
    native(NP, 'toString', n_to_string, 1)
    native(NP, 'toLocaleString', lambda t, a: num_to_str(this_num(t)))
    native(NP, 'valueOf', lambda t, a: this_num(t))

    def n_to_fixed(t, a):
        v = this_num(t)
        d = to_int(arg(a, 0))
        if v != v:
            return 'NaN'
        if abs(v) >= 1e21:
            return num_to_str(v)
        from decimal import Decimal, ROUND_HALF_UP
        q = Decimal(v).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP)
        s = format(q, 'f')
        if s.startswith('-') and float(q) == 0:
            s = s[1:]
        return s
    native(NP, 'toFixed', n_to_fixed, 1)

    def n_to_precision(t, a):
        v = this_num(t)
        if arg(a, 0) is UNDEF:
            return num_to_str(v)
        p = to_int(a[0])
        s = '%.*g' % (p, v)
        if 'e' in s:
            m, e = s.split('e')
            if '.' not in m and p > 1:
                m = m + '.' + '0' * (p - 1)
            return m + 'e' + ('+' if int(e) >= 0 else '-') + str(abs(int(e)))
        digits = len(s.replace('-', '').replace('.', '').lstrip('0')) or 1
        if digits < p:
            if '.' not in s:
                s += '.'
            s += '0' * (p - digits)
        return s
    native(NP, 'toPrecision', n_to_precision, 1)
    native(NP, 'toExponential', lambda t, a: ('%.*e' % (to_int(arg(a, 0)) if arg(a, 0) is not UNDEF else 6, this_num(t))).replace('e+0', 'e+').replace('e-0', 'e-'), 1)
    Number.props['MAX_SAFE_INTEGER'] = 9007199254740991
    Number.props['MIN_SAFE_INTEGER'] = -9007199254740991
    Number.props['MAX_VALUE'] = 1.7976931348623157e308
    Number.props['MIN_VALUE'] = 5e-324
    Number.props['EPSILON'] = 2.220446049250313e-16
    Number.props['POSITIVE_INFINITY'] = INF
    Number.props['NEGATIVE_INFINITY'] = -INF
    Number.props['NaN'] = NAN
    for k in list(Number.props):
        if k.isupper() or k == 'NaN':
            Number.hide(k)

    def is_integer(v):
        return v.__class__ is int or (v.__class__ is float and v.is_integer())
    native(Number, 'isInteger', lambda t, a: is_integer(arg(a, 0)), 1)
    native(Number, 'isSafeInteger', lambda t, a: is_integer(arg(a, 0)) and abs(arg(a, 0)) <= 9007199254740991, 1)
    native(Number, 'isFinite', lambda t, a: arg(a, 0).__class__ in (int, float) and arg(a, 0).__class__ is not bool and not (arg(a, 0) != arg(a, 0) or arg(a, 0) in (INF, -INF)), 1)
    native(Number, 'isNaN', lambda t, a: arg(a, 0).__class__ is float and arg(a, 0) != arg(a, 0), 1)

    def parse_int(t, a):
        s = to_str(arg(a, 0)).strip(_ws)
        radix = to_int32(arg(a, 1))
        sign = 1
        if s[:1] in ('+', '-'):
            if s[0] == '-':
                sign = -1
            s = s[1:]
        if radix == 0:
            radix = 10
            if s[:2].lower() == '0x':
                radix = 16
                s = s[2:]
        elif radix == 16 and s[:2].lower() == '0x':
            s = s[2:]
        if radix < 2 or radix > 36:
            return NAN
        digits = _DIGITS36[:radix]
        j = 0
        low = s.lower()
        while j < len(low) and low[j] in digits:
            j += 1
        if j == 0:
            return NAN
        v = int(low[:j], radix) * sign
        if v == 0 and sign < 0:
            return -0.0
        return v if abs(v) <= 9007199254740992 else float(v)

    def parse_float(t, a):
        s = to_str(arg(a, 0)).strip(_ws)
        m = re.match(r'[+-]?(?:Infinity|\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?)', s)
        if not m:
            return NAN
        t2 = m.group(0)
        if 'Infinity' in t2:
            return -INF if t2[0] == '-' else INF
        return norm(float(t2))
    pi = native(G, 'parseInt', parse_int, 2)
    pf = native(G, 'parseFloat', parse_float, 1)
    Number.define_hidden('parseInt', pi)
    Number.define_hidden('parseFloat', pf)
    native(G, 'isNaN', lambda t, a: (lambda v: v.__class__ is float and v != v)(to_num(arg(a, 0))), 1)
    native(G, 'isFinite', lambda t, a: (lambda v: not (v != v or v in (INF, -INF)))(to_num(arg(a, 0))), 1)

    def boolean_ctor(args, nt):
        o = JSObject(R.BooleanProto, 'Boolean')
        o.prim = to_bool(arg(args, 0))
        return o
    ctor('Boolean', lambda t, a: to_bool(arg(a, 0)), boolean_ctor, R.BooleanProto)

    def this_bool(t):
        if t.__class__ is bool:
            return t
        if isinstance(t, JSObject) and t.prim.__class__ is bool:
            return t.prim
        raise throw_error('TypeError', 'not a boolean')
    native(R.BooleanProto, 'toString', lambda t, a: 'true' if this_bool(t) else 'false')
    native(R.BooleanProto, 'valueOf', lambda t, a: this_bool(t))

    def uri_encode(safe):
        def run(t, a):
            s = to_str(arg(a, 0))
            try:
                return quote(s.encode('utf-8', 'strict'), safe=safe)
            except UnicodeEncodeError:
                raise throw_error('URIError', 'URI malformed')
        return run
    native(G, 'encodeURIComponent', uri_encode("-_.!~*'()"), 1)
    native(G, 'encodeURI', uri_encode("-_.!~*'();/?:@&=+$,#"), 1)

    def uri_decode(reserved):
        def run(t, a):
            s = to_str(arg(a, 0))
            if '%' not in s:
                return s
            if not re.match(r'(?:[^%]|%[0-9a-fA-F]{2})*\Z', s):
                raise throw_error('URIError', 'URI malformed')
            if reserved:
                parts = re.split(r'(%(?:2[346BCFbcf]|3[ABDFabdf]|40))', s)
                out = []
                for i, p in enumerate(parts):
                    out.append(p if i % 2 else _strict_unquote(p))
                return ''.join(out)
            return _strict_unquote(s)
        return run
    native(G, 'decodeURIComponent', uri_decode(False), 1)
    native(G, 'decodeURI', uri_decode(True), 1)

    def escape(t, a):
        s = to_str(arg(a, 0))
        out = []
        for ch in s:
            c = ord(ch)
            if ch.isalnum() and c < 128 or ch in '@*_+-./':
                out.append(ch)
            elif c < 256:
                out.append('%%%02X' % c)
            else:
                out.append('%%u%04X' % c)
        return ''.join(out)
    native(G, 'escape', escape, 1)

    def unescape(t, a):
        s = to_str(arg(a, 0))
        s = re.sub(r'%u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), s)
        return re.sub(r'%([0-9a-fA-F]{2})', lambda m: chr(int(m.group(1), 16)), s)
    native(G, 'unescape', unescape, 1)

    M = JSObject(ObjectProto, 'Math')
    G.define_hidden('Math', M)
    for k, v in (('PI', math.pi), ('E', math.e), ('LN2', math.log(2)), ('LN10', math.log(10)),
                 ('LOG2E', 1 / math.log(2)), ('LOG10E', 1 / math.log(10)), ('SQRT2', math.sqrt(2)), ('SQRT1_2', math.sqrt(0.5))):
        M.define_hidden(k, v)

    def mfn(name, f, n=1):
        def run(t, a):
            try:
                return norm(f(*[float(to_num(v)) for v in a[:n]] + [NAN] * (n - len(a))))
            except (ValueError, OverflowError):
                return NAN
        native(M, name, run, n)

    def m_floor(t, a):
        v = to_num(arg(a, 0))
        if v.__class__ is int:
            return v
        if v != v or v in (INF, -INF):
            return v
        return math.floor(v)

    def m_ceil(t, a):
        v = to_num(arg(a, 0))
        if v.__class__ is int:
            return v
        if v != v or v in (INF, -INF):
            return v
        r = math.ceil(v)
        if r == 0 and v < 0:
            return -0.0
        return r

    def m_round(t, a):
        v = to_num(arg(a, 0))
        if v.__class__ is int:
            return v
        if v != v or v in (INF, -INF):
            return v
        r = math.floor(v + 0.5)
        if r == 0 and v < 0:
            return -0.0
        return r

    def m_trunc(t, a):
        v = to_num(arg(a, 0))
        if v.__class__ is int or v != v or v in (INF, -INF):
            return v
        return int(v)
    native(M, 'floor', m_floor, 1)
    native(M, 'ceil', m_ceil, 1)
    native(M, 'round', m_round, 1)
    native(M, 'trunc', m_trunc, 1)

    def m_abs(t, a):
        v = to_num(arg(a, 0))
        return abs(v)
    native(M, 'abs', m_abs, 1)

    def m_minmax(is_max):
        def run(t, a):
            vals = [to_num(v) for v in a]
            if not vals:
                return -INF if is_max else INF
            for v in vals:
                if v != v:
                    return NAN
            return max(vals) if is_max else min(vals)
        return run
    native(M, 'max', m_minmax(True), 2)
    native(M, 'min', m_minmax(False), 2)
    native(M, 'pow', lambda t, a: _pow(arg(a, 0), arg(a, 1)), 2)
    native(M, 'random', lambda t, a: random.random())

    def m_sign(t, a):
        v = to_num(arg(a, 0))
        if v != v:
            return NAN
        return 1 if v > 0 else (-1 if v < 0 else v)
    native(M, 'sign', m_sign, 1)
    mfn('sqrt', math.sqrt)
    mfn('cbrt', lambda x: math.copysign(abs(x) ** (1.0 / 3), x))
    mfn('log', lambda x: math.log(x) if x > 0 else (-INF if x == 0 else NAN))
    mfn('log2', lambda x: math.log2(x) if x > 0 else (-INF if x == 0 else NAN))
    mfn('log10', lambda x: math.log10(x) if x > 0 else (-INF if x == 0 else NAN))
    mfn('log1p', math.log1p)
    mfn('exp', math.exp)
    mfn('expm1', math.expm1)
    for k in ('sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh', 'asinh', 'acosh', 'atanh'):
        mfn(k, getattr(math, k))
    mfn('atan2', math.atan2, 2)
    mfn('hypot', math.hypot, 2)
    mfn('fround', lambda x: x)

    def m_imul(t, a):
        return to_int32(to_int32(arg(a, 0)) * to_int32(arg(a, 1)))
    native(M, 'imul', m_imul, 2)

    def m_clz32(t, a):
        v = to_uint32(arg(a, 0))
        return 32 - v.bit_length()
    native(M, 'clz32', m_clz32, 1)

    def error_ctor_factory(name, parent_proto):
        proto = JSObject(parent_proto, 'Error')
        proto.define_hidden('name', name)
        proto.define_hidden('message', '')

        def construct_err(args, nt):
            target = nt if nt is not None else f
            e = make_error(target, arg(args, 0))
            opts = arg(args, 1)
            if isinstance(opts, JSObject) and opts.has('cause'):
                e.define_hidden('cause', opts.get('cause'))
            return e
        f = ctor(name, lambda this, args: construct_err(args, None), construct_err, proto)
        return f, proto
    Error, ErrorProto = error_ctor_factory('Error', ObjectProto)

    def err_to_string(t, a):
        name = get(t, 'name')
        msg = get(t, 'message')
        name = 'Error' if name is UNDEF else to_str(name)
        msg = '' if msg is UNDEF else to_str(msg)
        if not msg:
            return name
        if not name:
            return msg
        return name + ': ' + msg
    native(ErrorProto, 'toString', err_to_string)
    native(Error, 'captureStackTrace', lambda t, a: UNDEF, 1)
    for nm in ('TypeError', 'RangeError', 'SyntaxError', 'ReferenceError', 'EvalError', 'URIError'):
        sub, _ = error_ctor_factory(nm, ErrorProto)
        sub.proto = Error

    def regexp_call(this, args):
        p = arg(args, 0)
        flags = arg(args, 1)
        if isinstance(p, JSRegExp):
            return make_regexp(p.source, p.flags if flags is UNDEF else to_str(flags))
        return make_regexp('(?:)' if p is UNDEF else to_str(p), '' if flags is UNDEF else to_str(flags))
    RegExp = ctor('RegExp', regexp_call, lambda a, nt: regexp_call(None, a), R.RegExpProto, 2)
    RP = R.RegExpProto

    def need_rx(t):
        if not isinstance(t, JSRegExp):
            raise throw_error('TypeError', 'not a RegExp')
        return t
    native(RP, 'exec', lambda t, a: regexp_exec(need_rx(t), arg(a, 0)), 1)
    native(RP, 'test', lambda t, a: regexp_exec(need_rx(t), arg(a, 0)) is not None, 1)
    native(RP, 'toString', lambda t, a: '/%s/%s' % (need_rx(t).source, need_rx(t).flags))

    def date_now(t, a):
        return int(time.time() * 1000)

    DateProto = JSObject(ObjectProto, 'Date')

    def date_ctor(args, nt):
        o = JSObject(DateProto, 'Date')
        if not args:
            o.prim = date_now(None, [])
        elif len(args) == 1:
            v = args[0]
            if isinstance(v, JSObject) and v.cls == 'Date':
                o.prim = v.prim
            else:
                v = to_primitive(v)
                if v.__class__ is str:
                    o.prim = parse_date(v)
                else:
                    o.prim = time_clip(to_num(v))
        else:
            o.prim = time_clip(_local_to_utc(_components(args)))
        return o
    Date = ctor('Date', lambda t, a: _date_string(date_now(None, [])), date_ctor, DateProto, 7)
    native(Date, 'now', date_now)
    native(Date, 'parse', lambda t, a: parse_date(to_str(arg(a, 0))), 1)
    native(Date, 'UTC', lambda t, a: time_clip(_components(a)), 7)

    def this_time(t):
        if isinstance(t, JSObject) and t.cls == 'Date':
            return t.prim
        raise throw_error('TypeError', 'this is not a Date object.')
    native(DateProto, 'getTime', lambda t, a: this_time(t))
    native(DateProto, 'valueOf', lambda t, a: this_time(t))

    def tm(t, utc):
        v = this_time(t)
        if v != v:
            return None
        return _breakdown(v, utc)

    def getter(name, field, utc):
        def run(t, a):
            b = tm(t, utc)
            return NAN if b is None else b[field]
        native(DateProto, name, run)
    for i, nm in enumerate(('FullYear', 'Month', 'Date', 'Hours', 'Minutes', 'Seconds', 'Milliseconds', 'Day')):
        getter('get' + nm, i, False)
        getter('getUTC' + nm, i, True)
    native(DateProto, 'getYear', lambda t, a: (lambda b: NAN if b is None else b[0] - 1900)(tm(t, False)))

    def tz_offset(t, a):
        v = this_time(t)
        if v != v:
            return NAN
        return -_tz_seconds(v / 1000.0) // 60
    native(DateProto, 'getTimezoneOffset', tz_offset)

    def iso(t, a):
        v = this_time(t)
        if v != v:
            raise throw_error('RangeError', 'Invalid time value')
        b = _breakdown(v, True)
        return '%04d-%02d-%02dT%02d:%02d:%02d.%03dZ' % (b[0], b[1] + 1, b[2], b[3], b[4], b[5], b[6])
    native(DateProto, 'toISOString', iso)
    native(DateProto, 'toJSON', lambda t, a: iso(t, a) if this_time(t) == this_time(t) else None)
    native(DateProto, 'toString', lambda t, a: _date_string(this_time(t)))
    native(DateProto, 'toUTCString', lambda t, a: _utc_string(this_time(t)))
    native(DateProto, 'toGMTString', lambda t, a: _utc_string(this_time(t)))

    def setter(name, fields, utc):
        def run(t, a):
            v = this_time(t)
            b = list(_breakdown(v, utc)) if v == v else [1970, 0, 1, 0, 0, 0, 0, 0]
            for i, f in enumerate(fields):
                if i < len(a):
                    b[f] = to_num(a[i])
            ms = _components(b[:7])
            if not utc:
                ms = _local_to_utc(ms)
            t.prim = time_clip(ms)
            return t.prim
        native(DateProto, name, run, len(fields))
    for utc in (False, True):
        pre = 'setUTC' if utc else 'set'
        setter(pre + 'FullYear', (0, 1, 2), utc)
        setter(pre + 'Month', (1, 2), utc)
        setter(pre + 'Date', (2,), utc)
        setter(pre + 'Hours', (3, 4, 5, 6), utc)
        setter(pre + 'Minutes', (4, 5, 6), utc)
        setter(pre + 'Seconds', (5, 6), utc)
        setter(pre + 'Milliseconds', (6,), utc)

    def set_time(t, a):
        this_time(t)
        t.prim = time_clip(to_num(arg(a, 0)))
        return t.prim
    native(DateProto, 'setTime', set_time, 1)

    J = JSObject(ObjectProto, 'JSON')
    G.define_hidden('JSON', J)

    def to_py(v, depth=0):
        if depth > 200:
            raise throw_error('TypeError', 'Converting circular structure to JSON')
        if v is UNDEF or isinstance(v, JSFunction):
            return _SKIP
        if v is None or v.__class__ in (bool, str, int):
            return v
        if v.__class__ is float:
            if v != v or v in (INF, -INF):
                return None
            return v
        if v.__class__ is JSArray:
            out = []
            for x in v.items:
                r = to_py(x, depth + 1)
                out.append(None if r is _SKIP else r)
            return out
        if isinstance(v, JSObject):
            tj = v.get('toJSON')
            if isinstance(tj, JSFunction):
                return to_py(tj.call(v, []), depth + 1)
            if v.prim is not None:
                return v.prim
            out = {}
            for k in v.own_keys():
                if k.__class__ is Symbol:
                    continue
                r = to_py(v.get(k), depth + 1)
                if r is not _SKIP:
                    out[key_str(k)] = r
            return out
        return None

    def stringify(t, a):
        v = to_py(arg(a, 0))
        if v is _SKIP:
            return UNDEF
        ind = arg(a, 2)
        indent = None
        if ind.__class__ in (int, float) and ind > 0:
            indent = int(ind)
        elif ind.__class__ is str and ind:
            indent = ind
        return json.dumps(v, ensure_ascii=False, separators=(',', ':') if indent is None else (',', ': '), indent=indent)
    native(J, 'stringify', stringify, 3)

    def from_py(v):
        if isinstance(v, dict):
            o = JSObject(ObjectProto)
            for k, x in v.items():
                o.put(to_key(k) if k.isdigit() else k, from_py(x))
            return o
        if isinstance(v, list):
            return JSArray([from_py(x) for x in v])
        if isinstance(v, float):
            return norm(v)
        return v

    def parse(t, a):
        try:
            return from_py(json.loads(to_str(arg(a, 0))))
        except ValueError as e:
            raise throw_error('SyntaxError', 'Unexpected token in JSON: %s' % e)
    native(J, 'parse', parse, 2)

    SymProto = JSObject(ObjectProto, 'Symbol')
    registry = {}

    def symbol_call(t, a):
        d = arg(a, 0)
        return Symbol('' if d is UNDEF else to_str(d))
    Sym = ctor('Symbol', symbol_call, None, SymProto, 0)
    Sym.ctor = None
    R.sym_iterator = Symbol('Symbol.iterator')
    for nm in ('iterator', 'asyncIterator', 'hasInstance', 'toPrimitive', 'toStringTag', 'species', 'isConcatSpreadable', 'match', 'replace', 'search', 'split', 'unscopables'):
        Sym.define_hidden(nm, R.sym_iterator if nm == 'iterator' else Symbol('Symbol.' + nm))

    def sym_for(t, a):
        k = to_str(arg(a, 0))
        if k not in registry:
            registry[k] = Symbol(k)
        return registry[k]
    native(Sym, 'for', sym_for, 1)
    native(SymProto, 'toString', lambda t, a: 'Symbol(%s)' % (t.desc if t.__class__ is Symbol else ''))
    ArrayProto.define_hidden(R.sym_iterator, ArrayProto.get('values'))
    SP.define_hidden(R.sym_iterator, Native(lambda t, a: make_iter(list(this_str(t))), '[Symbol.iterator]'))

    def map_like(name, is_set, weak=False):
        proto = JSObject(ObjectProto, name)

        def construct_m(args, nt):
            pr = nt.get('prototype') if nt is not None else proto
            o = JSMapLike(pr if isinstance(pr, JSObject) else proto, is_set)
            init = arg(args, 0)
            if init is not UNDEF and init is not None:
                for e in iterate(init) or []:
                    if is_set:
                        o.data[JSMapLike.k(e)] = (e, e)
                    else:
                        k = get(e, 0)
                        o.data[JSMapLike.k(k)] = (k, get(e, 1))
            return o
        F = ctor(name, lambda t, a: (_ for _ in ()).throw(throw_error('TypeError', "Constructor %s requires 'new'" % name)), construct_m, proto, 0)

        def need(t):
            if not isinstance(t, JSMapLike):
                raise throw_error('TypeError', 'incompatible receiver')
            return t
        native(proto, 'has', lambda t, a: JSMapLike.k(arg(a, 0)) in need(t).data, 1)

        def delete(t, a):
            return need(t).data.pop(JSMapLike.k(arg(a, 0)), None) is not None
        native(proto, 'delete', delete, 1)
        native(proto, 'clear', lambda t, a: need(t).data.clear())
        if is_set:
            def add(t, a):
                v = arg(a, 0)
                need(t).data[JSMapLike.k(v)] = (v, v)
                return t
            native(proto, 'add', add, 1)
        else:
            def m_get(t, a):
                r = need(t).data.get(JSMapLike.k(arg(a, 0)))
                return UNDEF if r is None else r[1]
            native(proto, 'get', m_get, 1)

            def m_set(t, a):
                k = arg(a, 0)
                need(t).data[JSMapLike.k(k)] = (k, arg(a, 1))
                return t
            native(proto, 'set', m_set, 2)
        if not weak:
            def for_each(t, a):
                fn = _need_fn(arg(a, 0))
                for k, v in list(need(t).data.values()):
                    fn.call(arg(a, 1), [v, k, t])
                return UNDEF
            native(proto, 'forEach', for_each, 1)
            native(proto, 'values', lambda t, a: make_iter([v for (_, v) in need(t).data.values()]))
            native(proto, 'keys', lambda t, a: make_iter([k for (k, _) in need(t).data.values()]))
            native(proto, 'entries', lambda t, a: make_iter([JSArray([k, v]) for (k, v) in need(t).data.values()]))
            proto.define_hidden(R.sym_iterator, proto.get('values' if is_set else 'entries'))
            proto.props['size'] = Accessor(Native(lambda t, a: len(need(t).data), 'size'))
            proto.hide('size')
    map_like('Map', False)
    map_like('Set', True)
    map_like('WeakMap', False, True)
    map_like('WeakSet', True, True)

    PromiseProto = JSObject(ObjectProto, 'Promise')

    def promise_ctor(args, nt):
        o = JSObject(PromiseProto, 'Promise')
        return o
    Promise = ctor('Promise', lambda t, a: UNDEF, promise_ctor, PromiseProto)
    for nm in ('then', 'catch', 'finally'):
        native(PromiseProto, nm, lambda t, a: t, 1)
    for nm in ('resolve', 'reject', 'all', 'race', 'allSettled', 'any'):
        native(Promise, nm, lambda t, a: promise_ctor([], None), 1)

    Reflect = JSObject(ObjectProto, 'Reflect')
    G.define_hidden('Reflect', Reflect)
    native(Reflect, 'apply', lambda t, a: _need_fn(arg(a, 0)).call(arg(a, 1), list(_items(arg(a, 2)))), 3)
    native(Reflect, 'construct', lambda t, a: _need_fn(arg(a, 0)).construct(list(_items(arg(a, 1))), arg(a, 2) if isinstance(arg(a, 2), JSFunction) else None), 2)
    native(Reflect, 'getPrototypeOf', get_proto, 1)
    native(Reflect, 'setPrototypeOf', lambda t, a: set_proto(t, a) is not None, 2)
    native(Reflect, 'ownKeys', lambda t, a: JSArray([key_str(k) for k in arg(a, 0).own_keys(True)]), 1)
    native(Reflect, 'has', lambda t, a: arg(a, 0).has(to_key(arg(a, 1))), 2)
    native(Reflect, 'get', lambda t, a: get(arg(a, 0), to_key(arg(a, 1))), 2)
    native(Reflect, 'defineProperty', lambda t, a: define_property(arg(a, 0), arg(a, 1), arg(a, 2)) is not None, 3)

    console = JSObject(ObjectProto, 'console')
    G.define_hidden('console', console)
    for nm in ('log', 'warn', 'error', 'info', 'debug', 'trace'):
        native(console, nm, lambda t, a: UNDEF)

    G.define_hidden('NaN', NAN)
    G.define_hidden('Infinity', INF)
    G.define_hidden('undefined', UNDEF)
    G.define_hidden('globalThis', G)
    G.define_hidden('window', G)
    G.define_hidden('self', G)

    location = JSObject(ObjectProto)
    for k, v in (('hash', ''), ('host', 'www.youtube.com'), ('hostname', 'www.youtube.com'),
                 ('href', 'https://www.youtube.com/watch?v=yt-dlp-wins'), ('origin', 'https://www.youtube.com'),
                 ('password', ''), ('pathname', '/watch'), ('port', ''), ('protocol', 'https:'),
                 ('search', '?v=yt-dlp-wins'), ('username', '')):
        location.props[k] = v
    G.define_hidden('location', location)
    G.define_hidden('document', JSObject(None))
    G.define_hidden('navigator', JSObject(None))
    xhr = Native(lambda t, a: UNDEF, 'XMLHttpRequest', 0, lambda a, nt: JSObject(ObjectProto))
    xhr.props['prototype'] = JSObject(ObjectProto)
    G.define_hidden('XMLHttpRequest', xhr)

    def typed(name, size):
        proto = JSObject(ArrayProto, name)

        def construct_t(args, nt):
            v = arg(args, 0)
            if v.__class__ in (int, float):
                items = [0] * int(v)
            elif isinstance(v, JSObject):
                items = [to_num(x) for x in (iterate(v) if v.__class__ is not JSArray else v.items)]
            else:
                items = []
            return JSArray(items, proto)
        ctor(name, lambda t, a: construct_t(a, None), construct_t, proto, 3)
    for nm in ('Uint8Array', 'Int8Array', 'Uint16Array', 'Int16Array', 'Uint32Array', 'Int32Array', 'Float32Array', 'Float64Array', 'Uint8ClampedArray'):
        typed(nm, 1)
    return G


_MONTHS = ('jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec')
_DAYS = ('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat')
_ISO_RX = re.compile(r'([+-]\d{6}|\d{4})(?:-(\d{2})(?:-(\d{2}))?)?'
                     r'(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:[.,](\d{1,9}))?)?)?\s*(Z|[+-]\d{2}(?::?\d{2})?)?\Z', re.I)
_TEXT_RX = re.compile(r'(?:[A-Za-z]{3,},?\s+)?(?:(\d{1,2})\s+([A-Za-z]{3,})|([A-Za-z]{3,})\s+(\d{1,2}),?)\s+(\d{4})'
                      r'(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*(?:(?:GMT|UTC|Z)?\s*([+-]\d{2}:?\d{2})?|(GMT|UTC|Z))?(?:\s*\(.*\))?\s*\Z', re.I)
_SLASH_RX = re.compile(r'(\d{1,2})/(\d{1,2})/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*\Z')


def _days_from_civil(y, m, d):
    y -= m <= 2
    era = (y if y >= 0 else y - 399) // 400
    yoe = y - era * 400
    mp = (m + 9) % 12
    doy = (153 * mp + 2) // 5 + d - 1
    doe = yoe * 365 + yoe // 4 - yoe // 100 + doy
    return era * 146097 + doe - 719468


def _civil_from_days(z):
    z += 719468
    era = (z if z >= 0 else z - 146096) // 146097
    doe = z - era * 146097
    yoe = (doe - doe // 1460 + doe // 36524 - doe // 146096) // 365
    y = yoe + era * 400
    doy = doe - (365 * yoe + yoe // 4 - yoe // 100)
    mp = (5 * doy + 2) // 153
    d = doy - (153 * mp + 2) // 5 + 1
    m = mp + 3 if mp < 10 else mp - 9
    return y + (m <= 2), m, d


def _components(a):
    vals = [to_num(v) for v in list(a)[:7]]
    for v in vals:
        if v != v or v in (INF, -INF):
            return NAN
    while len(vals) < 7:
        vals.append(1 if len(vals) == 2 else 0)
    y, mo, d, h, mi, s, ms = [int(v) for v in vals]
    if 0 <= y <= 99 and len(a) > 0 and a[0].__class__ is not list:
        y += 1900
    y += mo // 12
    mo %= 12
    days = _days_from_civil(y, mo + 1, 1) + d - 1
    return float(((days * 24 + h) * 60 + mi) * 60000 + s * 1000 + ms)


def time_clip(v):
    if v != v or abs(v) > 8.64e15:
        return NAN
    return int(v)


def _tz_seconds(epoch):
    try:
        lt = time.localtime(epoch)
        return lt.tm_gmtoff if lt.tm_gmtoff is not None else -time.timezone
    except (OverflowError, ValueError, OSError):
        return -time.timezone


def _local_to_utc(ms):
    if ms != ms:
        return ms
    off = _tz_seconds(ms / 1000.0)
    guess = ms - off * 1000
    off2 = _tz_seconds(guess / 1000.0)
    return ms - off2 * 1000


def _breakdown(v, utc):
    v = int(v)
    if not utc:
        v += _tz_seconds(v / 1000.0) * 1000
    days, rem = divmod(v, 86400000)
    y, m, d = _civil_from_days(days)
    h, rem = divmod(rem, 3600000)
    mi, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    wd = (days + 4) % 7
    return (y, m - 1, d, h, mi, s, ms, wd)


def parse_date(s):
    s = s.strip()
    m = _ISO_RX.match(s)
    if m:
        y, mo, d, h, mi, sec, frac, tz = m.groups()
        ms = _components([int(y), int(mo or 1) - 1, int(d or 1), int(h or 0), int(mi or 0), int(sec or 0),
                          int((frac or '0')[:3].ljust(3, '0'))])
        if ms != ms:
            return NAN
        if tz:
            if tz.upper() != 'Z':
                sign = -1 if tz[0] == '-' else 1
                digits = tz[1:].replace(':', '')
                off = int(digits[:2]) * 60 + int(digits[2:4] or 0)
                ms -= sign * off * 60000
        elif h is not None:
            ms = _local_to_utc(ms)
        return time_clip(ms)
    m = _TEXT_RX.match(s)
    if m:
        d1, mon1, mon2, d2, y, h, mi, sec, off, z = m.groups()
        mon = (mon1 or mon2)[:3].lower()
        if mon not in _MONTHS:
            return NAN
        ms = _components([int(y), _MONTHS.index(mon), int(d1 or d2), int(h or 0), int(mi or 0), int(sec or 0), 0])
        if off:
            sign = -1 if off[0] == '-' else 1
            digits = off[1:].replace(':', '')
            ms -= sign * (int(digits[:2]) * 60 + int(digits[2:])) * 60000
        elif not z and 'GMT' not in s.upper() and 'UTC' not in s.upper():
            ms = _local_to_utc(ms)
        return time_clip(ms)
    m = _SLASH_RX.match(s)
    if m:
        mo, d, y, h, mi, sec = m.groups()
        return time_clip(_local_to_utc(_components([int(y), int(mo) - 1, int(d), int(h or 0), int(mi or 0), int(sec or 0), 0])))
    return NAN


def _date_string(v):
    if v != v:
        return 'Invalid Date'
    b = _breakdown(v, False)
    off = _tz_seconds(v / 1000.0) // 60
    return '%s %s %02d %04d %02d:%02d:%02d GMT%s%02d%02d' % (
        _DAYS[b[7]], _MONTHS[b[1]].capitalize(), b[2], b[0], b[3], b[4], b[5],
        '+' if off >= 0 else '-', abs(off) // 60, abs(off) % 60)


def _utc_string(v):
    if v != v:
        return 'Invalid Date'
    b = _breakdown(v, True)
    return '%s, %02d %s %04d %02d:%02d:%02d GMT' % (_DAYS[b[7]], b[2], _MONTHS[b[1]].capitalize(), b[0], b[3], b[4], b[5])


def _pow(a, b):
    from .runtime import js_pow
    return js_pow(a, b)


def _strict_unquote(s):
    try:
        return unquote(s, errors='strict')
    except UnicodeDecodeError:
        raise throw_error('URIError', 'URI malformed')


def _escape_literal(s):
    return re.sub(r'([\\^$.|?*+()\[\]{}/])', r'\\\1', s)


def _utf16_key(s):
    if all(ord(c) < 0x10000 for c in s):
        return s
    return s.encode('utf-16-be')


_DIGITS36 = '0123456789abcdefghijklmnopqrstuvwxyz'
_SKIP = object()
