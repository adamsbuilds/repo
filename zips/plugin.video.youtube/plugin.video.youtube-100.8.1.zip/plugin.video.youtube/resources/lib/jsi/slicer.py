from . import lexer
from .lexer import NAME, NUM, STR, REGEX, PUNC, TMPL, EOF

_ENDS_EXPR = frozenset((NAME, NUM, STR, REGEX, TMPL))
_CONTINUE_WORDS = frozenset(('in', 'instanceof', 'of'))
_STMT_WORDS = frozenset(('var', 'let', 'const', 'if', 'for', 'while', 'do', 'try',
                         'function', 'return', 'throw', 'switch', 'break', 'continue'))
_NOT_VALUE_WORDS = frozenset((
    'var', 'let', 'const', 'if', 'else', 'for', 'while', 'do', 'try', 'catch', 'finally',
    'function', 'return', 'throw', 'switch', 'case', 'default', 'break', 'continue',
    'new', 'typeof', 'void', 'delete', 'in', 'instanceof', 'this', 'null', 'true', 'false',
    'undefined', 'prototype', 'arguments', 'debugger', 'with', 'of', 'class', 'extends',
    'super', 'yield', 'async', 'await', 'get', 'set', 'static'))


class SliceError(Exception):
    pass


class Program(object):
    def __init__(self, src):
        self.src = src
        self.tk = lexer.tokenize(src)
        lexer.match_brackets(self.tk)
        self.body = self._find_body()
        self.stmts = self._split(self.body[0] + 1, self.body[1])

    def _find_body(self):
        tk = self.tk
        types, texts, match = tk.type, tk.text, tk.match
        best = None
        for i in range(min(len(types) - 6, 400)):
            if texts[i] == 'function' and texts[i + 1] == '(' and types[i + 2] == NAME and texts[i + 3] == ')' and texts[i + 4] == '{':
                b = i + 4
                size = match[b] - b
                if best is None or size > best[1] - best[0]:
                    best = (b, match[b], texts[i + 2])
        if best is None:
            raise SliceError('player wrapper not found')
        self.namespace = best[2]
        return best[0], best[1]

    def _skip_group(self, i):
        m = self.tk.match[i]
        return m + 1

    def _stmt_end(self, i, stop):
        tk = self.tk
        texts, types = tk.text, tk.type
        t = texts[i]
        if types[i] == NAME:
            if t in ('if', 'for', 'while', 'with') and texts[i + 1] == '(':
                j = self._stmt_end(self._skip_group(i + 1), stop)
                if t == 'if' and j < stop and texts[j] == 'else':
                    j = self._stmt_end(j + 1, stop)
                return j
            if t == 'do':
                j = self._stmt_end(i + 1, stop)
                if texts[j] == 'while':
                    j = self._skip_group(j + 1)
                if j < stop and texts[j] == ';':
                    j += 1
                return j
            if t == 'try':
                j = self._skip_group(i + 1)
                if j < stop and texts[j] == 'catch':
                    j += 1
                    if texts[j] == '(':
                        j = self._skip_group(j)
                    j = self._skip_group(j)
                if j < stop and texts[j] == 'finally':
                    j = self._skip_group(j + 1)
                return j
            if t == 'function' and types[i + 1] == NAME:
                j = self._skip_group(i + 2)
                return self._skip_group(j)
            if t == 'switch':
                return self._skip_group(self._skip_group(i + 1))
            if texts[i + 1] == ':' and t not in _STMT_WORDS:
                return self._stmt_end(i + 2, stop)
        if t == '{':
            return self._skip_group(i)
        if t == ';':
            return i + 1
        j = i
        nl = tk.nl
        match = tk.match
        while j < stop:
            t = texts[j]
            ty = types[j]
            if ty == PUNC:
                if t == ';':
                    return j + 1
                if t in ('(', '[', '{'):
                    j = match[j] + 1
                    if j < stop and nl[j] and self._asi(j - 1, j):
                        return j
                    continue
            j += 1
            if j < stop and nl[j] and self._asi(j - 1, j):
                return j
        return stop

    def _asi(self, prev, nxt):
        tk = self.tk
        pt, ptext = tk.type[prev], tk.text[prev]
        if not (pt in _ENDS_EXPR or ptext in (')', ']', '}', '++', '--')):
            return False
        if pt == NAME and ptext in ('return', 'break', 'continue', 'throw'):
            return True
        nt, ntext = tk.type[nxt], tk.text[nxt]
        if nt == NAME:
            return ntext not in _CONTINUE_WORDS
        if nt in (NUM, STR, TMPL, REGEX):
            return True
        return ntext in ('{', '!', '~', '++', '--', ';')

    def _split(self, start, stop):
        out = []
        i = start
        while i < stop:
            j = self._stmt_end(i, stop)
            if j <= i:
                raise SliceError('no progress at %d' % self.tk.pos[i])
            out.append((i, j))
            i = j
        return out

    def text(self, a, b):
        tk = self.tk
        end = tk.pos[b - 1] + len(tk.text[b - 1])
        return self.src[tk.pos[a]:end]

    def depth0_commas(self, a, b):
        texts, types, match = self.tk.text, self.tk.type, self.tk.match
        parts = []
        s = a
        j = a
        while j < b:
            t = texts[j]
            if types[j] == PUNC:
                if t in ('(', '[', '{'):
                    j = match[j] + 1
                    continue
                if t == ',':
                    parts.append((s, j))
                    s = j + 1
                elif t == ';':
                    break
            elif t == 'function' and j + 1 < b and texts[j + 1] != '(':
                pass
            j += 1
        if s < j:
            parts.append((s, j))
        return parts


def _target_key(tk, a, b, ns):
    texts, types = tk.text, tk.type
    if types[a] != NAME:
        return None, None
    j = a + 1
    if texts[a] == ns and j < b and texts[j] == '.' and types[j + 1] == NAME:
        root = ns + '.' + texts[j + 1]
        j += 2
    else:
        root = texts[a]
    path = j
    while j < b and texts[j] in ('.', '['):
        if texts[j] == '.':
            j += 2
        else:
            j = tk.match[j] + 1
    if j < b and texts[j] == '=' :
        return root, path < j
    return None, None


def _hoisted(tk, a, b, out):
    texts, types, match = tk.text, tk.type, tk.match
    j = a
    while j < b:
        t = texts[j]
        if types[j] == NAME:
            if t == 'function':
                if types[j + 1] == NAME:
                    out.add(texts[j + 1])
                    j += 2
                p = j
                while texts[p] != '(':
                    p += 1
                body = match[p] + 1
                j = match[body] + 1
                continue
            if t in ('var', 'let', 'const') and types[j + 1] == NAME:
                k = j + 1
                out.add(texts[k])
                while k < b:
                    tt = texts[k]
                    if types[k] == PUNC:
                        if tt in ('(', '[', '{'):
                            k = match[k] + 1
                            continue
                        if tt in (';', ')', ']', '}'):
                            break
                        if tt == ',' and types[k + 1] == NAME:
                            out.add(texts[k + 1])
                    elif tt in ('in', 'of') and types[k] == NAME:
                        break
                    k += 1
                    if tk.nl[k] and k < b and types[k] == NAME and texts[k] in _STMT_WORDS:
                        break
                j += 1
                continue
            if t == 'catch' and texts[j + 1] == '(' and types[j + 2] == NAME:
                out.add(texts[j + 2])
        j += 1
    return out


def _params(tk, p, out):
    texts, types, match = tk.text, tk.type, tk.match
    for k in range(p + 1, match[p]):
        if types[k] == NAME and texts[k - 1] in ('(', ',', '...'):
            out.add(texts[k])
    return out


def _reads(tk, a, b, ns, out, scopes=()):
    texts, types, match = tk.text, tk.type, tk.match
    j = a
    while j < b:
        if types[j] == NAME:
            t = texts[j]
            if t == 'function':
                local = set(('arguments',))
                if types[j + 1] == NAME:
                    local.add(texts[j + 1])
                    j += 1
                p = j + 1
                while texts[p] != '(':
                    p += 1
                _params(tk, p, local)
                body = match[p] + 1
                bend = match[body]
                _hoisted(tk, body + 1, bend, local)
                _reads(tk, p + 1, match[p], ns, out, scopes + (local,))
                _reads(tk, body + 1, bend, ns, out, scopes + (local,))
                j = bend + 1
                continue
            if j > a and texts[j - 1] == '.' and types[j - 1] == PUNC:
                pass
            elif texts[j + 1] == ':' and texts[j - 1] in ('{', ','):
                pass
            elif t in _NOT_VALUE_WORDS:
                pass
            elif any(t in sc for sc in scopes):
                pass
            elif t == ns and texts[j + 1] == '.' and types[j + 2] == NAME:
                out.add(ns + '.' + texts[j + 2])
                j += 3
                continue
            else:
                out.add(t)
        j += 1
    return out


class _NoReads(frozenset):
    def add(self, k):
        pass

    def discard(self, k):
        pass


_NO_READS = _NoReads()


class _Unit(object):
    __slots__ = ('index', 'a', 'b', 'writes', 'mutates', 'reads', 'decl', 'alias_of', 'deps')

    def __init__(self, index, a, b):
        self.index = index
        self.a = a
        self.b = b
        self.writes = set()
        self.mutates = set()
        self.reads = _NO_READS
        self.decl = None
        self.alias_of = None
        self.deps = []


def units(prog, reads=True):
    def Unit(i, a, b):
        u = _Unit(i, a, b)
        if reads:
            u.reads = set()
        return u
    tk = prog.tk
    texts, types = tk.text, tk.type
    ns = prog.namespace
    out = []
    for (a, b) in prog.stmts:
        t = texts[a]
        if t in ('var', 'let', 'const') and types[a] == NAME:
            for (c, d) in prog.depth0_commas(a + 1, b):
                u = Unit(len(out), c, d)
                u.decl = t
                if types[c] == NAME:
                    u.writes.add(texts[c])
                reads and _reads(tk, c + 1, d, ns, u.reads)
                out.append(u)
            continue
        if t == 'function' and types[a] == NAME and types[a + 1] == NAME:
            u = Unit(len(out), a, b)
            u.writes.add(texts[a + 1])
            reads and _reads(tk, a + 2, b, ns, u.reads)
            out.append(u)
            continue
        parts = prog.depth0_commas(a, b) if types[a] == NAME else [(a, b)]
        simple = True
        keys = []
        for (c, d) in parts:
            root, member = _target_key(tk, c, d, ns)
            if root is None:
                simple = False
                break
            keys.append((c, d, root, member))
        if simple and len(parts) > 1:
            for (c, d, root, member) in keys:
                u = Unit(len(out), c, d)
                (u.mutates if member else u.writes).add(root)
                reads and _reads(tk, c, d, ns, u.reads)
                out.append(u)
            continue
        u = Unit(len(out), a, b)
        if simple:
            root, member = keys[0][2], keys[0][3]
            (u.mutates if member else u.writes).add(root)
            if not member:
                eq = a
                while texts[eq] != '=':
                    eq += 1
                rk, rm = _alias_source(tk, eq + 1, b, ns)
                if rk:
                    u.alias_of = rk
        elif t in ('if', 'try', 'for', 'while', 'do') or (types[a] == NAME and texts[a + 1] == ':'):
            _compound_writes(tk, a, b, ns, u.writes)
        reads and _reads(tk, a, b, ns, u.reads)
        out.append(u)
    return out


def _compound_writes(tk, a, b, ns, out):
    texts, types, match = tk.text, tk.type, tk.match
    j = a
    while j < b:
        if types[j] == NAME:
            t = texts[j]
            if t == 'function':
                p = j + 1
                while texts[p] != '(':
                    p += 1
                j = match[match[p] + 1] + 1
                continue
            if texts[j - 1] != '.':
                root, member = _target_key(tk, j, b, ns)
                if root is not None:
                    out.add(root)
        j += 1
    return out


def _alias_source(tk, a, b, ns):
    texts, types = tk.text, tk.type
    if b > a and texts[b - 1] == ';':
        b -= 1
    if types[a] != NAME:
        return None, None
    j = a + 1
    if texts[a] == ns and texts[j] == '.' and types[j + 1] == NAME:
        root = ns + '.' + texts[j + 1]
        j += 2
    else:
        root = texts[a]
    while j < b:
        if texts[j] == '.' and types[j + 1] == NAME:
            j += 2
        else:
            return None, None
    return root, True


def writer_index(us):
    writers = {}
    alias_unit = {}
    for u in us:
        for k in u.mutates:
            au = alias_unit.get(k)
            if au is not None:
                writers.setdefault(au.alias_of, []).append(u)
                u.reads.discard(k)
                u.deps = [au]
            else:
                writers.setdefault(k, []).append(u)
        for k in u.writes:
            writers.setdefault(k, []).append(u)
            if u.alias_of:
                alias_unit[k] = u
            else:
                alias_unit.pop(k, None)
    return writers


def closure(us, seeds):
    writers = {}
    alias_unit = {}
    for u in us:
        for k in u.mutates:
            au = alias_unit.get(k)
            if au is not None:
                writers.setdefault(au.alias_of, []).append(u)
                u.reads.discard(k)
                u.deps = [au]
            else:
                writers.setdefault(k, []).append(u)
        for k in u.writes:
            writers.setdefault(k, []).append(u)
            if u.alias_of:
                alias_unit[k] = u
            else:
                alias_unit.pop(k, None)
    need = set()
    chosen = set()
    todo_keys = list(seeds)
    todo_units = []
    while todo_keys or todo_units:
        if todo_units:
            u = todo_units.pop()
            if u.index in chosen:
                continue
            chosen.add(u.index)
            todo_keys.extend(r for r in u.reads if r not in need)
            todo_units.extend(u.deps)
            if u.alias_of and not u.mutates and u.alias_of not in need:
                todo_keys.append(u.alias_of)
            continue
        k = todo_keys.pop()
        if k in need:
            continue
        need.add(k)
        for u in writers.get(k, ()):
            if u.index not in chosen:
                todo_units.append(u)
    return sorted(chosen), need
