import glob
import json
import os
import re
import socket
from urllib.parse import parse_qs, quote, urlparse
from xml.sax.saxutils import escape, quoteattr

from . import jsc
from . import kodi
from .innertube import EMBEDDED_CLIENT, YTError

EMBEDDED_UA = EMBEDDED_CLIENT['userAgent']

MAX_RES = [2160, 1440, 1080, 720, 480, 360]


def codec_family(mime):
    m = re.search(r'codecs="([^"]+)"', mime or '')
    codec = (m.group(1) if m else '').lower()
    if codec.startswith('avc1'):
        return 'avc', codec
    if codec.startswith('vp9') or codec.startswith('vp09'):
        return 'vp9', codec
    if codec.startswith('av01'):
        return 'av1', codec
    if codec.startswith('mp4a'):
        return 'aac', codec
    if codec.startswith('opus'):
        return 'opus', codec
    if codec.startswith('ec-3') or codec.startswith('ac-3'):
        return 'dolby', codec
    return codec.split('.')[0], codec


def allowed_codecs():
    choice = kodi.setting_int('codecs', 1)
    if choice == 0:
        return {'avc'}
    if choice == 2:
        return {'avc', 'vp9', 'av1'}
    return {'avc', 'vp9'}


def max_height():
    return MAX_RES[min(max(kodi.setting_int('max_res', 2), 0), len(MAX_RES) - 1)]


def usable_url(fmt):
    """A format we can play: no DRM, and either no "n" challenge or one TubeLite has already solved."""
    url = fmt.get('url')
    if not url or fmt.get('drmFamilies'):
        return None
    if not fmt.get('_solved') and 'n' in parse_qs(urlparse(url).query):
        return None
    return url


def _rng(r):
    return '%s-%s' % (r['start'], r['end'])


def build_mpd(streaming_data, duration):
    allowed = allowed_codecs()
    limit = max_height()
    video, audio = {}, {}
    adaptive = streaming_data.get('adaptiveFormats') or []

    tracks = [f.get('audioTrack') for f in adaptive if f.get('audioTrack')]
    default_track = next((t.get('id') for t in tracks if t.get('audioIsDefault')), None)

    for f in adaptive:
        url = usable_url(f)
        if not url or not f.get('initRange') or not f.get('indexRange'):
            continue
        mime = f.get('mimeType', '')
        base = mime.split(';')[0]
        family, codec = codec_family(mime)
        if base.startswith('video/'):
            if family not in allowed:
                continue
            if (f.get('height') or 0) > limit or 'HDR' in (f.get('qualityLabel') or ''):
                continue
            video.setdefault((base, family), []).append((f, url, codec))
        elif base.startswith('audio/'):
            if f.get('isDrc') or family == 'dolby':
                continue
            track = f.get('audioTrack') or {}
            if default_track and track.get('id') not in (None, default_track):
                continue
            audio.setdefault((base, family), []).append((f, url, codec))

    if not video or not audio:
        return None, None

    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" '
           'type="static" minBufferTime="PT1.5S" mediaPresentationDuration="PT%sS">' % (duration or 0),
           '<Period>']
    set_id = 0
    first_video_url = None
    for (base, family), reps in sorted(video.items(), key=lambda kv: ['avc', 'vp9', 'av1'].index(kv[0][1])):
        reps.sort(key=lambda r: (r[0].get('height', 0), r[0].get('bitrate', 0)), reverse=True)
        first_video_url = first_video_url or reps[0][1]
        out.append('<AdaptationSet id="%d" mimeType="%s" contentType="video" subsegmentAlignment="true" '
                   'subsegmentStartsWithSAP="1">' % (set_id, base))
        set_id += 1
        for f, url, codec in reps:
            out.append('<Representation id="%s" codecs="%s" bandwidth="%s" width="%s" height="%s" frameRate="%s">'
                       % (f.get('itag'), codec, f.get('bitrate', 0), f.get('width', 0), f.get('height', 0),
                          f.get('fps', 30)))
            out.append('<BaseURL>%s</BaseURL>' % escape(url))
            out.append('<SegmentBase indexRange="%s"><Initialization range="%s"/></SegmentBase>'
                       % (_rng(f['indexRange']), _rng(f['initRange'])))
            out.append('</Representation>')
        out.append('</AdaptationSet>')
    for (base, family), reps in sorted(audio.items(), key=lambda kv: kv[0][1] != 'aac'):
        reps.sort(key=lambda r: r[0].get('bitrate', 0), reverse=True)
        lang = ((reps[0][0].get('audioTrack') or {}).get('id') or 'und').split('.')[0].split('-')[0]
        out.append('<AdaptationSet id="%d" mimeType="%s" contentType="audio" lang=%s subsegmentAlignment="true">'
                   % (set_id, base, quoteattr(lang)))
        set_id += 1
        for f, url, codec in reps:
            out.append('<Representation id="%s" codecs="%s" bandwidth="%s" audioSamplingRate="%s">'
                       % (f.get('itag'), codec, f.get('bitrate', 0), f.get('audioSampleRate', 44100)))
            out.append('<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" '
                       'value="%s"/>' % f.get('audioChannels', 2))
            out.append('<BaseURL>%s</BaseURL>' % escape(url))
            out.append('<SegmentBase indexRange="%s"><Initialization range="%s"/></SegmentBase>'
                       % (_rng(f['indexRange']), _rng(f['initRange'])))
            out.append('</Representation>')
        out.append('</AdaptationSet>')
    out.append('</Period></MPD>')
    return '\n'.join(out), first_video_url


def best_progressive(streaming_data):
    limit = max_height()
    best = None
    for f in streaming_data.get('formats') or []:
        url = usable_url(f)
        if not url or (f.get('height') or 0) > limit:
            continue
        if not best or (f.get('height') or 0) > (best[0].get('height') or 0):
            best = (f, url)
    return best


DEFAULT_PORT = 50152


def server_port():
    """The port TubeLite's background service is listening on: the one it picked (Automatic), or the one
    set in Settings → Advanced."""
    import xbmcgui
    picked = xbmcgui.Window(10000).getProperty('tubelite.port')
    if picked.isdigit():
        return int(picked)
    if not kodi.setting_bool('port_auto'):
        return kodi.setting_int('server_port', DEFAULT_PORT) or DEFAULT_PORT
    return DEFAULT_PORT


def server_alive():
    try:
        s = socket.create_connection(('127.0.0.1', server_port()), timeout=1)
        s.close()
        return True
    except Exception:
        return False


def write_mpd(video_id, mpd):
    folder = os.path.join(kodi.profile_dir(), 'mpd')
    if not os.path.isdir(folder):
        os.makedirs(folder)
    old = sorted(glob.glob(os.path.join(folder, '*.mpd')), key=os.path.getmtime)
    for path in old[:-10]:
        try:
            os.remove(path)
        except Exception:
            pass
    with open(os.path.join(folder, '%s.mpd' % video_id), 'w', encoding='utf-8') as f:
        f.write(mpd)
    return 'http://127.0.0.1:%d/mpd/%s.mpd' % (server_port(), video_id)


def isa_available():
    import xbmc
    return bool(xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'))


def check_client(yt, name, client, video_id):
    """True if this client gets a stream for the video that YouTube's servers will actually serve."""
    pr = yt.player(video_id, name, client)
    if (pr.get('playabilityStatus') or {}).get('status') != 'OK':
        return False
    sd = pr.get('streamingData') or {}
    ua = client['context'].get('userAgent', '')
    duration = int((pr.get('videoDetails') or {}).get('lengthSeconds') or 0)
    mpd, test_url = build_mpd(sd, duration)
    if mpd:
        return yt.probe(test_url, ua)
    hls = sd.get('hlsManifestUrl')
    if hls and '/n/' not in hls:
        return yt.probe(hls, ua)
    prog = best_progressive(sd)
    return bool(prog and yt.probe(prog[1], ua))


# Messages meaning the video itself is off-limits, where a client refresh won't help.
VIDEO_PROBLEMS = ('private', 'removed', 'unavailable', 'copyright', 'terminated', 'your age', 'members',
                  'own apps', 'inputstream adaptive', 'signed-in playback',
                  'not available in your country', 'premieres', 'live event will begin')


def resolve(yt, video_id):
    """Returns a dict describing how Kodi should play the video, refreshing clients once if all fail."""
    try:
        return _resolve(yt, video_id)
    except YTError as e:
        if not kodi.setting_bool('auto_clients') or any(p in str(e).lower() for p in VIDEO_PROBLEMS):
            raise
        from . import clientupdate
        kodi.log('all clients failed for %s (%s); refreshing client list' % (video_id, e))
        if clientupdate.refresh(yt, force=True, reason='playback failure'):
            return _resolve(yt, video_id)
        raise


def _details(video_id, pr, name, ua):
    details = pr.get('videoDetails') or {}
    return {
        'title': details.get('title', ''),
        'channel': details.get('author', ''),
        'channel_id': details.get('channelId', ''),
        'duration': int(details.get('lengthSeconds') or 0),
        'description': details.get('shortDescription', ''),
        'thumb': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % video_id,
        'client': name,
        'user_agent': ua,
    }


def _probe_note(yt):
    """YouTube's answer to the last refused stream, and what the link carried, for Check playback."""
    lp = getattr(yt, 'last_probe', None)
    if not lp:
        return ''
    q = parse_qs(urlparse(lp.get('url') or '').query)
    keys = ','.join(sorted(k for k in q if k in ('n', 'sig', 'signature', 'lsig', 'sp', 'pot', 'c', 'ratebypass')))
    return ' (HTTP %s %s | link has %s, c=%s, host %s)' % (
        lp.get('status'), (lp.get('body') or '')[:120], keys or 'none of n/sig/pot', (q.get('c') or ['?'])[0],
        urlparse(lp.get('url') or '').netloc.split('.')[0])


def _served_only(yt, sd, ua):
    """Tests every stream link in parallel and keeps the ones YouTube serves. Returns (streaming data with
    only those, how many were tested); (None, n) when no video and audio pair survives."""
    from concurrent.futures import ThreadPoolExecutor
    fmts = [f for f in sd.get('adaptiveFormats') or [] if usable_url(f)]
    if not fmts:
        return None, 0
    with ThreadPoolExecutor(max_workers=8) as pool:
        ok = list(pool.map(lambda f: yt.probe(usable_url(f), ua), fmts))
    kept = [f for f, good in zip(fmts, ok) if good]
    has_video = any((f.get('mimeType') or '').startswith('video/') for f in kept)
    has_audio = any((f.get('mimeType') or '').startswith('audio/') for f in kept)
    if not (has_video and has_audio):
        return None, len(fmts)
    return dict(sd, adaptiveFormats=kept), len(fmts)


def _pick(yt, video_id, name, ua, pr, modes, reasons):
    """Chooses DASH, HLS or a single MP4 from one player response, or returns None."""
    dash_ok, isa, mp4_only = modes
    sd = pr.get('streamingData') or {}
    info = _details(video_id, pr, name, ua)
    live = bool((pr.get('videoDetails') or {}).get('isLive'))
    hls = sd.get('hlsManifestUrl')
    if hls and '/n/' in hls and not sd.get('_solved'):
        hls = None

    if dash_ok and not live:
        mpd, test_url = build_mpd(sd, info['duration'])
        if mpd and yt.probe(test_url, ua):
            info.update(kind='dash', url=write_mpd(video_id, mpd), mime='application/dash+xml')
            return info
        if mpd:
            refused = _probe_note(yt)
            served, total = _served_only(yt, sd, ua)
            mpd = build_mpd(served, info['duration'])[0] if served else None
            if mpd:
                # YouTube can hold some qualities back on a route and serve the rest; play what it serves.
                info.update(kind='dash', url=write_mpd(video_id, mpd), mime='application/dash+xml',
                            note='%d of %d streams served' % (len(served['adaptiveFormats']), total))
                return info
            reasons.append('%s: DASH streams blocked%s' % (name, refused))

    if hls and (live or not mp4_only) and yt.probe(hls, ua):
        info.update(kind='hls', url=hls, mime='application/vnd.apple.mpegurl', use_isa=isa)
        return info

    prog = best_progressive(sd)
    if prog and yt.probe(prog[1], ua):
        info.update(kind='mp4', url=prog[1], mime=prog[0].get('mimeType', 'video/mp4').split(';')[0])
        return info
    reasons.append('%s: no playable streams' % name)
    kodi.log('%s: %s returned no playable streams' % (video_id, name))
    return None


def _resolve(yt, video_id):
    reasons = []
    mp4_only = kodi.setting_int('play_mode', 0) == 1
    isa = (not mp4_only) and isa_available()
    dash_ok = isa and server_alive()
    modes = (dash_ok, isa, mp4_only)
    protected = []

    for name, client in yt.player_clients():
        try:
            pr = yt.player(video_id, name, client)
        except Exception as e:
            reasons.append(str(e))
            continue
        status = pr.get('playabilityStatus') or {}
        if status.get('status') != 'OK':
            reasons.append(status.get('reason') or status.get('status') or '%s refused' % name)
            kodi.log('%s: %s -> %s' % (video_id, name, reasons[-1]))
            continue
        sd = pr.get('streamingData') or {}
        if sd.get('licenseInfos'):
            # A free (or rented) movie: encrypted, so only the Widevine route can play it.
            protected.append((name, client, pr))
            continue
        info = _pick(yt, video_id, name, client['context'].get('userAgent', ''), pr, modes, reasons)
        if info:
            return info

    if protected:
        from . import drm
        if not dash_ok:
            raise YTError('Install or enable InputStream Adaptive to play YouTube movies')
        info = drm.prepare(video_id, protected)
        details = protected[0][2].get('videoDetails') or {}
        info.update(title=details.get('title', ''), channel=details.get('author', ''),
                    channel_id=details.get('channelId', ''), duration=int(details.get('lengthSeconds') or 0),
                    description=details.get('shortDescription', ''),
                    thumb='https://i.ytimg.com/vi/%s/hqdefault.jpg' % video_id)
        return info

    # Age-restricted: signed in, the TV app with your account first; then YouTube's
    # embedded player, which needs no account but only plays videos whose uploaders allow embedding.
    from . import auth
    if auth.signed_in():
        info = resolve_signed_in(yt, video_id, modes, reasons)
        if info:
            return info
    if any(_age_gated(r) for r in reasons):
        info = resolve_embedded(yt, video_id, modes, reasons)
        if info:
            return info
        if not auth.signed_in():
            raise YTError('%s (sign in under You \u2192 Sign in to watch age-restricted videos)' % reasons[0],
                          '\n'.join(reasons + LAST_EMBED_ATTEMPT))
    raise YTError(reasons[0] if reasons else 'No playable stream found', '\n'.join(reasons))


def _age_gated(reason):
    r = (reason or '').lower()
    return 'your age' in r or 'age-restricted' in r or 'inappropriate' in r


LAST_EMBED_ATTEMPT = []


def resolve_embedded(yt, video_id, modes, reasons):
    """Age-restricted videos through YouTube's embedded player (as if embedded on another website), the
    route yt-dlp uses for them. No sign-in needed; works when the uploader allows embedding. Its stream
    links are scrambled like the TV app's, so TubeLite's own JavaScript engine unscrambles them."""
    del LAST_EMBED_ATTEMPT[:]
    try:
        ch = jsc.get(yt.session, allow_previous=True,
                     on_build=lambda: kodi.notify('Getting age-restricted playback ready (once per YouTube update)…',
                                                  ms=8000))
        pr = yt.embedded_player(video_id, ch.sts)
    except (jsc.ChallengeError, YTError) as e:
        LAST_EMBED_ATTEMPT.append('embedded player: %s' % e)
        return None
    status = pr.get('playabilityStatus') or {}
    if status.get('status') != 'OK':
        LAST_EMBED_ATTEMPT.append('embedded player (%s): %s %s' % (pr.get('_embed_setup', ''), status.get('status'),
                                                                   status.get('reason') or ''))
        return None
    sd = pr.get('streamingData') or {}
    if sd.get('licenseInfos'):
        LAST_EMBED_ATTEMPT.append('embedded player: encrypted, left to the signed-in route')
        return None
    try:
        solved = solve_streaming_data(ch, sd)
    except jsc.ChallengeError as e:
        LAST_EMBED_ATTEMPT.append('embedded player: %s' % e)
        return None
    tried = []
    info = _pick(yt, video_id, 'web_embedded', EMBEDDED_UA, pr, modes, tried)
    if info:
        LAST_EMBED_ATTEMPT.append('embedded player (player %s): OK, %d links unscrambled, playing %s%s' % (
            ch.pid, solved, info['kind'], ' (%s)' % info['note'] if info.get('note') else ''))
        return info
    LAST_EMBED_ATTEMPT.append('embedded player (player %s): OK, %d links unscrambled, but %s' % (
        ch.pid, solved, '; '.join(tried) or 'refused'))
    return None


def solve_streaming_data(ch, sd, include_drm=False):
    """Unscrambles the signature and "n" challenge on every stream link, in place."""
    solved = 0
    for f in (sd.get('adaptiveFormats') or []) + (sd.get('formats') or []):
        if f.get('drmFamilies') and not include_drm:
            continue
        url = f.get('url')
        sig = sp = None
        if not url and f.get('signatureCipher'):
            sc = parse_qs(f['signatureCipher'])
            url = (sc.get('url') or [None])[0]
            sig = (sc.get('s') or [None])[0]
            sp = (sc.get('sp') or ['signature'])[-1]
            if not url or not sig:
                continue
        if not url:
            continue
        f['url'] = jsc.solve_url(ch, url, sig, sp)
        f['_solved'] = True
        solved += 1
    for key in ('hlsManifestUrl', 'dashManifestUrl'):
        if sd.get(key) and '/n/' in sd[key]:
            sd[key] = jsc.solve_manifest(ch, sd[key])
    sd['_solved'] = True
    return solved


TV_VARIANTS = ('samsung', 'page', 'standard', 'plain', 'older')
# YouTube ties the generic TV app to a TV-only player script; a named Samsung Tizen TV gets the normal one
# (what yt-dlp's tv_samsung client sends).
SAMSUNG_TV = {
    'clientName': 'TVHTML5',
    'clientVersion': '5.20260707',
    'deviceMake': 'Samsung',
    'deviceModel': 'UKS9800',
    'userAgent': ('Mozilla/5.0 (SMART-TV; Linux; Tizen 2.4.0) AppleWebKit/538.1 (KHTML, like Gecko) '
                  'Version/2.4.0 TV Safari/538.1'),
    'osName': 'Tizen',
    'osVersion': '2.4.0',
}
LAST_TV_ATTEMPTS = []


def _variant_path():
    return os.path.join(kodi.profile_dir(), 'tv_variant.json')


def _variant_order():
    order = list(TV_VARIANTS)
    try:
        with open(_variant_path()) as f:
            best = json.load(f).get('name')
        if best in order:
            order.remove(best)
            order.insert(0, best)
    except Exception:
        pass
    return order


def _remember_variant(name):
    try:
        with open(_variant_path(), 'w') as f:
            json.dump({'name': name}, f)
    except Exception:
        pass


def _variant_args(yt, name):
    """How to ask YouTube's TV app: its own page's settings first, then simpler forms of the request."""
    base = yt.tv_client()
    if name == 'samsung':
        return {'client': dict(SAMSUNG_TV), 'screen': False}, None, None
    if name == 'page':
        cfg = yt.tv_page_config()
        client = dict(base)
        if cfg.get('version'):
            client['clientVersion'] = cfg['version']
        return {'client': client, 'visitor': cfg.get('visitor') or '', 'screen': False}, cfg.get('player'), cfg.get('sts')
    if name == 'plain':
        return {'visitor': '', 'screen': False}, None, None
    if name == 'older':
        client = dict(base, clientVersion='5.20260707', userAgent='Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version')
        return {'client': client, 'visitor': '', 'screen': False}, None, None
    return {}, None, None


def _worth_retrying(reason):
    r = reason.lower()
    return any(w in r for w in ('reload', 'refresh', 'error', 'try again', 'unavailable', 'blocked'))


def _signed_in_widevine(yt, video_id, name, args, ch, sts, pr, modes, tag):
    """An encrypted signed-in video (official TV episodes, movies): unscramble its links and play it through
    the Widevine route, licensed as the TV app with your account. Returns (info, failure reason)."""
    from . import drm
    if not modes[0]:
        LAST_TV_ATTEMPTS.append('%s: encrypted, needs InputStream Adaptive' % tag)
        return None, 'Install or enable InputStream Adaptive to play this video'
    sd = pr.get('streamingData') or {}
    try:
        solved = solve_streaming_data(ch, sd, include_drm=True)
    except jsc.ChallengeError as e:
        LAST_TV_ATTEMPTS.append('%s: encrypted, %s' % (tag, e))
        return None, str(e)
    ctx = dict(args.get('client') or yt.tv_client())
    try:
        info = drm.prepare_signed(video_id, name, ctx, pr, {
            'sts': sts, 'visitor': args.get('visitor'), 'screen': args.get('screen', True)})
    except YTError as e:
        LAST_TV_ATTEMPTS.append('%s: encrypted, %d links unscrambled, but %s' % (tag, solved, e))
        return None, str(e)
    info.update(_details(video_id, pr, 'tv', ctx.get('userAgent', '')), kind='widevine', client='tv')
    LAST_TV_ATTEMPTS.append('%s: encrypted, %d links unscrambled, playing with Widevine' % (tag, solved))
    return info, None


def resolve_signed_in(yt, video_id, modes, reasons):
    """Plays a video as YouTube's TV app with your account, which YouTube requires for age-restricted
    and members-only videos. TubeLite unscrambles the TV app's stream links itself, and remembers which
    form of the request YouTube accepted. A just-released YouTube player is stood in for by the last saved
    one; only if YouTube refuses that is the new one read on the spot."""
    del LAST_TV_ATTEMPTS[:]
    used_previous = []
    base = list(reasons)
    info = _signed_in_attempts(yt, video_id, modes, reasons, True, used_previous)
    if info is None and used_previous:
        LAST_TV_ATTEMPTS.append('retrying with YouTube\'s newest player')
        reasons[:] = base
        info = _signed_in_attempts(yt, video_id, modes, reasons, False, [])
    return info


def _signed_in_attempts(yt, video_id, modes, reasons, allow_previous, used_previous):
    notify = lambda: kodi.notify('Getting signed-in playback ready (once per YouTube update)…', ms=8000)
    last = None
    start = 0
    for name in _variant_order():
        try:
            args, pid, page_sts = _variant_args(yt, name)
            if pid and allow_previous and not jsc.has_saved(pid):
                pid = None
            ch = jsc.get(yt.session, on_build=notify, pid=pid, allow_previous=allow_previous)
            if ch.previous:
                used_previous.append(ch.pid)
                page_sts = None
            sts = page_sts or ch.sts
            pr = yt.tv_player(video_id, sts, **args)
        except (jsc.ChallengeError, YTError) as e:
            last = str(e)
            LAST_TV_ATTEMPTS.append('%s: %s' % (name, e))
            continue
        status = pr.get('playabilityStatus') or {}
        ua = (args.get('client') or yt.tv_client()).get('userAgent', '')
        tag = '%s (player %s, sts %s)' % (name, ch.pid, sts)
        if status.get('status') != 'OK':
            last = status.get('reason') or status.get('status') or 'refused'
            LAST_TV_ATTEMPTS.append('%s: %s %s' % (tag, status.get('status'), last))
            kodi.log('%s: tv %s -> %s' % (video_id, tag, last))
            if _worth_retrying(last):
                continue
            break
        sd = pr.get('streamingData') or {}
        if sd.get('licenseInfos'):
            info, last = _signed_in_widevine(yt, video_id, name, args, ch, sts, pr, modes, tag)
            if info:
                _remember_variant(name)
                return info
            continue
        try:
            solved = solve_streaming_data(ch, sd)
        except jsc.ChallengeError as e:
            last = str(e)
            LAST_TV_ATTEMPTS.append('%s: %s' % (tag, e))
            continue
        if not solved:
            last = 'YouTube sent no stream links'
            LAST_TV_ATTEMPTS.append('%s: OK but no stream links' % tag)
            continue
        tried = []
        info = _pick(yt, video_id, 'tv', ua, pr, modes, tried)
        if info:
            LAST_TV_ATTEMPTS.append('%s: OK, %d links unscrambled, playing %s%s' % (
                tag, solved, info['kind'], ' (%s)' % info['note'] if info.get('note') else ''))
            _remember_variant(name)
            return info
        last = 'YouTube refused the unscrambled streams'
        LAST_TV_ATTEMPTS.append('%s: OK, %d links unscrambled, but %s' % (tag, solved, '; '.join(tried) or 'refused'))
    if last and 'primary account' in last.lower():
        last = ('YouTube only lets your main Google account confirm your age, and TubeLite is signed in with a '
                'channel (brand account). Sign out, then sign in again and pick your main account at '
                'youtube.com/activate')
    if last:
        reasons.insert(0, 'Signed-in playback: %s' % last)
    reasons.extend('TV app %s' % a for a in LAST_TV_ATTEMPTS[start:])
    return None


def kodi_major():
    import xbmc
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except Exception:
        return 21


def listitem_for(info):
    import xbmcgui
    ua = quote(info.get('user_agent', ''))
    li = xbmcgui.ListItem(info.get('title', ''), offscreen=True)
    li.setContentLookup(False)
    li.setMimeType(info['mime'])
    if info['kind'] == 'widevine':
        from . import drm
        li.setPath(info['url'])
        drm.apply_props(li, info['video_id'], info.get('user_agent', ''), kodi_major())
        return li
    if info['kind'] == 'dash' or (info['kind'] == 'hls' and info.get('use_isa')):
        li.setPath(info['url'])
        li.setProperty('inputstream', 'inputstream.adaptive')
        if kodi_major() < 21:
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd' if info['kind'] == 'dash' else 'hls')
        if info['kind'] == 'hls':
            li.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent=%s' % ua)
        li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=%s' % ua)
    else:
        li.setPath('%s|User-Agent=%s' % (info['url'], ua))
    return li
