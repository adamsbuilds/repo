"""SponsorBlock: skips sponsor reads and other segments the community has marked.

Uses the hash-prefix endpoint, so only the first 4 characters of a SHA-256 of the
video id leave the device, not the video id itself.
"""

import hashlib
import json

from . import kodi

API = 'https://sponsor.ajay.app/api/skipSegments/'

CATEGORIES = (
    # (setting id, SponsorBlock category, label shown when skipped)
    ('sb_sponsor', 'sponsor', 'sponsor'),
    ('sb_selfpromo', 'selfpromo', 'self-promotion'),
    ('sb_interaction', 'interaction', 'subscribe reminder'),
    ('sb_intro', 'intro', 'intro'),
    ('sb_outro', 'outro', 'outro'),
    ('sb_preview', 'preview', 'preview'),
    ('sb_music_offtopic', 'music_offtopic', 'non-music section'),
    ('sb_filler', 'filler', 'filler'),
)
LABELS = dict((c, l) for _, c, l in CATEGORIES)


def enabled_categories():
    return [c for sid, c, _ in CATEGORIES if kodi.setting_bool(sid)]


def segments(session, video_id):
    """Sorted list of (start, end, category) to skip for this video."""
    cats = enabled_categories()
    if not cats:
        return []
    prefix = hashlib.sha256(video_id.encode('utf-8')).hexdigest()[:4]
    r = session.get(API + prefix, params={'categories': json.dumps(cats), 'actionTypes': json.dumps(['skip'])},
                    timeout=10)
    if r.status_code == 404:
        return []
    r.raise_for_status()
    out = []
    for entry in r.json():
        if entry.get('videoID') != video_id:
            continue
        for seg in entry.get('segments') or []:
            start, end = (seg.get('segment') or [0, 0])[:2]
            if seg.get('actionType', 'skip') == 'skip' and end - start >= 1:
                out.append((float(start), float(end), seg.get('category', 'sponsor')))
    return sorted(out)


def due(segs, position, skipped, tolerance=0.5):
    """The segment to skip at this playback position, if any (each segment is skipped once)."""
    for i, (start, end, cat) in enumerate(segs):
        if i in skipped:
            continue
        if start - tolerance <= position < end - 1:
            return i, end, cat
    return None
