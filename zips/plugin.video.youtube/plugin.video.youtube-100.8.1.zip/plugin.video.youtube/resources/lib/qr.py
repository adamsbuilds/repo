"""QR code to PNG with only the standard library, so it works on every Kodi box."""

import struct
import zlib

from .qrcodegen import QrCode


def _chunk(kind, data):
    body = kind + data
    return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)


def png(text, scale=10, border=4):
    """8-bit greyscale PNG bytes of a QR code for text: black modules on white, with a quiet zone."""
    qr = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
    n = qr.get_size() + border * 2
    rows = []
    for y in range(n):
        line = bytearray()
        for x in range(n):
            dark = qr.get_module(x - border, y - border)
            line += (b'\x00' if dark else b'\xff') * scale
        row = b'\x00' + bytes(line)
        rows.extend([row] * scale)
    size = n * scale
    header = struct.pack('>IIBBBBB', size, size, 8, 0, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + _chunk(b'IHDR', header) +
            _chunk(b'IDAT', zlib.compress(b''.join(rows), 9)) + _chunk(b'IEND', b''))


def write(text, path, scale=10):
    with open(path, 'wb') as f:
        f.write(png(text, scale))
    return path
