"""Keeps the player client list working when YouTube changes things.

yt-dlp's maintainers re-tune YouTube's app clients within days of every break,
and publish which clients work without JavaScript. This module reads their
current source straight from GitHub, pulls out the client definitions, tests
each candidate against a real video, and saves the ones that actually play,
best first, to clients.json in the profile folder.
"""

import ast
import json
import os
import time

from . import kodi

UPSTREAM = 'https://raw.githubusercontent.com/yt-dlp/yt-dlp/master/yt_dlp/extractor/'
BASE_PATHS = ('youtube/_base.py', 'youtube.py')
VIDEO_PATHS = ('youtube/_video.py', 'youtube.py')
TEST_VIDEOS = ('jNQXAC9IVRw', 'aqz-KE-bpKQ')
DAILY = 24 * 3600
RETRY_GAP = 30 * 60


def _clients_path():
    return os.path.join(kodi.profile_dir(), 'clients.json')


def _meta_path():
    return os.path.join(kodi.profile_dir(), 'clients_meta.json')


def load_meta():
    try:
        with open(_meta_path()) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_meta(meta):
    with open(_meta_path(), 'w') as f:
        json.dump(meta, f)


def _const(node):
    try:
        return ast.literal_eval(node)
    except Exception:
        return None


def _po_token_required(node):
    """True if any GvsPoTokenPolicy(required=True) is set for HTTPS or DASH streams."""
    if not isinstance(node, ast.Dict):
        return False
    for k, v in zip(node.keys, node.values):
        proto = getattr(k, 'attr', '')
        if proto not in ('HTTPS', 'DASH') or not isinstance(v, ast.Call):
            continue
        for kw in v.keywords:
            if kw.arg == 'required' and _const(kw.value) is True:
                return True
    return False


def parse_clients(source):
    """Pulls INNERTUBE_CLIENTS out of yt-dlp's source without running it."""
    tree = ast.parse(source)
    table = None
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(getattr(t, 'id', '') == 'INNERTUBE_CLIENTS' for t in node.targets):
            table = node.value
            break
    if not isinstance(table, ast.Dict):
        return {}
    out = {}
    for key, val in zip(table.keys, table.values):
        name = _const(key)
        if not isinstance(name, str) or not isinstance(val, ast.Dict):
            continue
        fields = dict((_const(k), v) for k, v in zip(val.keys, val.values))
        ctx = _const(fields.get('INNERTUBE_CONTEXT')) if 'INNERTUBE_CONTEXT' in fields else None
        client = (ctx or {}).get('client') if isinstance(ctx, dict) else None
        cid = _const(fields.get('INNERTUBE_CONTEXT_CLIENT_NAME')) if 'INNERTUBE_CONTEXT_CLIENT_NAME' in fields else None
        if not isinstance(client, dict) or not client.get('clientName') or not client.get('clientVersion') \
                or not isinstance(cid, int):
            continue
        entry = {
            'id': cid,
            'context': client,
            'js': _const(fields['REQUIRE_JS_PLAYER']) is not False if 'REQUIRE_JS_PLAYER' in fields else True,
            'auth': _const(fields.get('REQUIRE_AUTH')) is True if 'REQUIRE_AUTH' in fields else False,
            'host': _const(fields.get('INNERTUBE_HOST')) if 'INNERTUBE_HOST' in fields else 'www.youtube.com',
            'pot': _po_token_required(fields.get('GVS_PO_TOKEN_POLICY')),
        }
        if 'PLAYER_PARAMS' in fields and isinstance(_const(fields['PLAYER_PARAMS']), str):
            entry['params'] = _const(fields['PLAYER_PARAMS'])
        out[name] = entry
    return out


def parse_jsless_defaults(source):
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(getattr(t, 'id', '') == '_DEFAULT_JSLESS_CLIENTS' for t in node.targets):
            val = _const(node.value)
            if isinstance(val, (tuple, list)):
                return [v for v in val if isinstance(v, str)]
    return []


def candidates(clients, jsless):
    """Clients we can use (no JavaScript, no sign-in), yt-dlp's own picks first."""
    usable = dict((n, c) for n, c in clients.items()
                  if not c['js'] and not c['auth'] and c.get('host') in (None, 'www.youtube.com'))
    order = [n for n in jsless if n in usable]
    rest = sorted((n for n in usable if n not in order), key=lambda n: usable[n]['pot'])
    return [(n, usable[n]) for n in order + rest]


def _fetch(session, paths):
    for path in paths:
        try:
            r = session.get(UPSTREAM + path, timeout=20)
            if r.status_code == 200 and ('INNERTUBE_CLIENTS' in r.text or '_DEFAULT_JSLESS_CLIENTS' in r.text):
                return r.text
        except Exception as e:
            kodi.log('client update: fetch %s failed: %s' % (path, e))
    return None


def refresh(yt, force=False, reason='daily'):
    """Returns True if a working client list is in place after the run."""
    from .streams import check_client
    meta = load_meta()
    now = time.time()
    if not force and now - meta.get('checked', 0) < DAILY:
        return bool(meta.get('working'))
    if force:
        if now - meta.get('attempt', 0) < RETRY_GAP:
            kodi.log('client update: skipped, last forced refresh was under 30 minutes ago')
            return False
        meta['attempt'] = now
        _save_meta(meta)

    base_src = _fetch(yt.session, BASE_PATHS)
    video_src = _fetch(yt.session, VIDEO_PATHS)
    if not base_src:
        kodi.log('client update: could not reach yt-dlp upstream')
        return bool(meta.get('working'))
    try:
        clients = parse_clients(base_src)
        jsless = parse_jsless_defaults(video_src or '')
    except Exception as e:
        kodi.log('client update: parse failed: %s' % e)
        return bool(meta.get('working'))
    cands = candidates(clients, jsless)
    source = 'yt-dlp'
    tv = (clients.get('tv') or {}).get('context') or {}
    if tv.get('clientName') == 'TVHTML5' and tv.get('clientVersion'):
        meta['tv_client'] = {'clientVersion': tv['clientVersion'], 'userAgent': tv.get('userAgent', '')}
    from .innertube import PLAYER_CLIENTS
    seen = set(n for n, _ in cands)
    cands += [(n, c) for n, c in PLAYER_CLIENTS.items() if n not in seen]

    working = []
    for name, client in cands[:10]:
        ok = False
        for vid in TEST_VIDEOS:
            try:
                if check_client(yt, name, client, vid):
                    ok = True
                    break
            except Exception as e:
                kodi.log('client update: %s test error: %s' % (name, e))
        kodi.log('client update: %s %s' % (name, 'works' if ok else 'failed'))
        if ok:
            working.append(name)

    meta.update(checked=now, source=source, reason=reason, working=working,
                tested=[n for n, _ in cands[:10]])
    _save_meta(meta)
    if not working:
        kodi.log('client update: no client passed; keeping previous list')
        return False

    defs = dict((n, {'id': c['id'], 'context': c['context'], **({'params': c['params']} if c.get('params') else {})})
                for n, c in cands if n in working)
    # Untested fallbacks go after the proven ones in case the test videos themselves are blocked.
    order = working + [n for n, _ in cands[:10] if n not in working]
    for n, c in cands[:10]:
        defs.setdefault(n, {'id': c['id'], 'context': c['context']})
    defs['_order'] = order
    tmp = _clients_path() + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(defs, f)
    os.replace(tmp, _clients_path())
    yt.reset_clients()
    return True
