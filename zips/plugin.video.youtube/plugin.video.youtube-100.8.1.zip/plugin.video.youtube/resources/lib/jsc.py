"""YouTube's signature and "n" challenges, solved by TubeLite's own JavaScript engine (resources/lib/jsi).

Signed-in playback (age-restricted videos, members-only, your own private uploads) only works through
YouTube's TV app client, whose stream links are scrambled by YouTube's player script. The engine runs
just the part of that script that unscrambles them, so no outside JavaScript runtime is needed. The
part it used is saved per player version, so later starts skip downloading the 3 MB player again.
"""
import glob
import json
import os
import re
import threading
import time

from . import kodi

IFRAME_API = 'https://www.youtube.com/iframe_api'
PLAYER_JS = 'https://www.youtube.com/s/player/%s/player_ias.vflset/en_US/base.js'
PLAYER_ID_MAX_AGE = 6 * 3600
_TEST_N = 'TubeLiteTestN-0123'
_TEST_SIG = ('AOq0QJ8wRgIhAN7xN0BrP3cE4a7Ng1yQ9mF6Z2lK8sV3uT5wX1yZ0aBcAiEA9pQ2rS4tU6vW8xY0zA2bC4dE6fG8hI0jK2lM4nO6pQ8='
             'gwzz')
_lock = threading.Lock()
_solvers = {}


class ChallengeError(Exception):
    pass


def _dir():
    d = os.path.join(kodi.profile_dir(), 'jsc')
    if not os.path.isdir(d):
        os.makedirs(d)
    return d


def _read_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def _write_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f)
    os.replace(tmp, path)


def player_id(session, refresh=False):
    """The player version YouTube currently serves, checked at most every few hours."""
    path = os.path.join(_dir(), 'current.json')
    cur = _read_json(path) or {}
    if not refresh and cur.get('id') and time.time() - cur.get('ts', 0) < PLAYER_ID_MAX_AGE:
        return cur['id']
    try:
        r = session.get(IFRAME_API, timeout=15)
        m = re.search(r'player\\?/([0-9a-fA-F]{8})\\?/', r.text)
    except Exception as e:
        if cur.get('id'):
            kodi.log('player version check failed (%s); using %s' % (e, cur['id']))
            return cur['id']
        raise ChallengeError('Could not reach YouTube to check its player version: %s' % e)
    if not m:
        if cur.get('id'):
            return cur['id']
        raise ChallengeError('YouTube did not say which player version it uses')
    pid = m.group(1)
    _write_json(path, {'id': pid, 'ts': time.time()})
    return pid


def _cache_path(pid):
    return os.path.join(_dir(), '%s.json' % pid)


def _prune(keep):
    files = sorted(glob.glob(os.path.join(_dir(), '[0-9a-f]' * 8 + '.json')), key=os.path.getmtime, reverse=True)
    for path in files[keep:]:
        try:
            os.remove(path)
        except Exception:
            pass


def _check(solver):
    n = solver.n(_TEST_N)
    sig = solver.sig(_TEST_SIG)
    if not n or not sig or sig == _TEST_SIG:
        raise ChallengeError('the player script gave no usable answer')


def _from_cache(pid):
    from .jsi import ytplayer
    data = _read_json(_cache_path(pid))
    if not data or data.get('engine') != ytplayer.ENGINE or not data.get('sts'):
        return None
    try:
        s = ytplayer.SliceSolver(data)
        _check(s)
        return s
    except Exception as e:
        kodi.log('saved player %s needs rebuilding: %s' % (pid, e))
        return None


def _build(session, pid, keep_full=False):
    from .jsi import ytplayer
    started = time.time()
    try:
        r = session.get(PLAYER_JS % pid, timeout=40)
    except Exception as e:
        raise ChallengeError('Could not download YouTube\'s player script: %s' % e)
    if r.status_code != 200 or len(r.text) < 100000:
        raise ChallengeError('YouTube\'s player script download failed (HTTP %s)' % r.status_code)
    try:
        solver = ytplayer.Solver(r.text)
        if not solver.sts:
            raise ChallengeError('the player script has no signature timestamp')
        _check(solver)
        data = solver.export()
    except ChallengeError:
        raise
    except Exception as e:
        raise ChallengeError('TubeLite could not read player %s: %s' % (pid, e))
    data['player'] = pid
    data['created'] = int(time.time())
    try:
        _write_json(_cache_path(pid), data)
        _prune(3)
    except Exception as e:
        kodi.log('could not save player %s: %s' % (pid, e))
    kodi.log('player %s ready in %.1fs (signature timestamp %s, %d units, %d bytes kept)'
             % (pid, time.time() - started, data['sts'], len(solver.env.order), len(data['slice'])))
    if keep_full:
        return solver
    try:
        small = ytplayer.SliceSolver(data)
        _check(small)
        return small
    except Exception as e:
        kodi.log('keeping the full player %s in memory: %s' % (pid, e))
        return solver


def _resave(pid, solver):
    try:
        data = solver.export()
        data['player'] = pid
        data['created'] = int(time.time())
        _write_json(_cache_path(pid), data)
    except Exception as e:
        kodi.log('could not update saved player %s: %s' % (pid, e))


class Challenges(object):
    """Solves the challenges in one player response's stream links, rebuilding from the full player once
    if the saved slice can't handle an input."""

    def __init__(self, session, pid, solver, built=False):
        self.built = built
        self.previous = False
        self.session = session
        self.pid = pid
        self.solver = solver
        self.sts = solver.sts
        self.n_cache = {}
        self.rebuilt = False

    def _retry(self, fn, value):
        from .jsi import ytplayer
        try:
            return fn(self.solver, value)
        except Exception as first:
            if self.rebuilt or not isinstance(self.solver, ytplayer.SliceSolver):
                raise ChallengeError('Could not unscramble the stream link: %s' % first)
            kodi.log('saved player %s failed on an input (%s); rebuilding' % (self.pid, first))
            self.rebuilt = True
            with _lock:
                self.solver = _build(self.session, self.pid, keep_full=True)
                _solvers[self.pid] = self.solver
            try:
                out = fn(self.solver, value)
            except Exception as e:
                raise ChallengeError('Could not unscramble the stream link: %s' % e)
            _resave(self.pid, self.solver)
            return out

    def n(self, value):
        out = self.n_cache.get(value)
        if out is None:
            out = self._retry(lambda s, v: s.n(v), value)
            self.n_cache[value] = out
        return out

    def sig(self, value):
        return self._retry(lambda s, v: s.sig(v), value)


def _previous():
    """The newest saved player other than the current one: (id, solver) or (None, None)."""
    files = sorted(glob.glob(os.path.join(_dir(), '[0-9a-f]' * 8 + '.json')), key=os.path.getmtime, reverse=True)
    for path in files:
        pid = os.path.basename(path)[:8]
        solver = _from_cache(pid)
        if solver is not None:
            return pid, solver
    return None, None


def get(session, refresh_id=False, on_build=None, pid=None, allow_previous=False):
    """Challenge solver for the current player. With allow_previous, a newly released player that hasn't been
    read yet is stood in for by the last saved one (YouTube keeps accepting it for a while); the background
    service reads the new one when Kodi is idle."""
    pid = pid or player_id(session, refresh=refresh_id)
    built = False
    with _lock:
        solver = _solvers.get(pid)
        if solver is None:
            solver = _from_cache(pid)
            if solver is None and allow_previous:
                old_pid, old = _previous()
                if old is not None:
                    kodi.log('player %s not read yet; using saved player %s meanwhile' % (pid, old_pid))
                    ch = Challenges(session, old_pid, old)
                    ch.previous = True
                    return ch
            if solver is None:
                if on_build:
                    on_build()
                solver = _build(session, pid)
                built = True
            _solvers[pid] = solver
    return Challenges(session, pid, solver, built)


def has_saved(pid):
    return pid in _solvers or os.path.exists(_cache_path(pid))


def needs_build(session):
    """The current player version, and whether it still has to be read (a cheap check)."""
    pid = player_id(session, refresh=True)
    return pid, not _read_json(_cache_path(pid))


def prepare(session):
    """Background warm-up: makes sure the current player version is saved, so playback starts quickly."""
    pid, needed = needs_build(session)
    if not needed:
        return pid, False
    with _lock:
        if pid not in _solvers:
            _solvers[pid] = _build(session, pid)
    return pid, True


_N_RX = re.compile(r'([?&])n=([^&]+)')


def solve_url(ch, url, encrypted_sig=None, sp=None):
    if encrypted_sig:
        url = '%s&%s=%s' % (url, sp or 'signature', ch.sig(encrypted_sig))
    m = _N_RX.search(url)
    if m:
        new = ch.n(m.group(2))
        url = url[:m.start()] + m.group(1) + 'n=' + new + url[m.end():]
    return url


def solve_manifest(ch, url):
    m = re.search(r'/n/([^/]+)', url or '')
    if not m:
        return url
    return url.replace('/n/%s' % m.group(1), '/n/%s' % ch.n(m.group(1)), 1)
