"""YouTube Music: its pages (Home, Charts, New releases, Moods & genres, search, artists, albums) turned
into TubeLite items. YouTube Music is the same InnerTube service as YouTube, asked as its own web app
(WEB_REMIX at music.youtube.com), and its songs and music videos are ordinary YouTube videos.

A page is a list of shelves (rows of songs, cards of albums, playlists, artists, or mood buttons). Each
shelf may carry a "more" link (a browse or a filtered search showing the whole list) and a token for
more of the same shelf."""

import re

from .parser import SKIP_KEYS, best_thumb, clean, duration_seconds, is_mix, text, video_fanart, video_thumb

ARTIST, ALBUM, PLAYLIST = 'MUSIC_PAGE_TYPE_ARTIST', 'MUSIC_PAGE_TYPE_ALBUM', 'MUSIC_PAGE_TYPE_PLAYLIST'
MUSIC_SKIP = SKIP_KEYS | {'menu', 'header', 'musicImmersiveHeaderRenderer', 'musicVisualHeaderRenderer',
                          'musicDetailHeaderRenderer', 'musicEditablePlaylistDetailHeaderRenderer',
                          'musicResponsiveHeaderRenderer', 'chipCloudRenderer', 'sortFilterSubMenuRenderer',
                          'musicSideAlignedItemRenderer'}
DURATION_RX = re.compile(r'^\d{1,2}(:\d{2}){1,2}$')


def _page_type(endpoint):
    return (((endpoint.get('browseEndpointContextSupportedConfigs') or {})
             .get('browseEndpointContextMusicConfig') or {}).get('pageType') or '')


def _thumb(r):
    t = (r.get('thumbnail') or r.get('thumbnailRenderer') or {})
    t = t.get('musicThumbnailRenderer') or t.get('croppedSquareThumbnailRenderer') or t
    return best_thumb(t.get('thumbnail') or {})


def _browse_item(title, browse, thumb, subtitle):
    """An artist, album or playlist, from where its link points."""
    bid = browse.get('browseId') or ''
    ptype = _page_type(browse)
    if ptype == ARTIST or (not ptype and bid.startswith('UC')):
        kind = 'artist'
    elif ptype == ALBUM or bid.startswith('MPRE'):
        kind = 'album'
    elif ptype == PLAYLIST or bid.startswith('VL'):
        kind = 'mplaylist'
    else:
        kind = 'mpage'
    return {'type': kind, 'id': bid, 'params': browse.get('params') or '', 'title': title, 'thumb': thumb,
            'description': subtitle}


def _runs_text(obj):
    return [clean(r.get('text', '')) for r in (obj or {}).get('runs', []) if r.get('text', '').strip(' •·')]


def _artist(runs_obj):
    for r in (runs_obj or {}).get('runs', []):
        be = (r.get('navigationEndpoint') or {}).get('browseEndpoint') or {}
        if _page_type(be) == ARTIST or str(be.get('browseId', '')).startswith('UC'):
            return clean(r.get('text', '')), be.get('browseId', '')
    return '', ''


def _big(url, size=1200):
    """YouTube Music's album art comes sized by its URL (=w120-h120...); ask for a large copy."""
    if 'googleusercontent.com' in url:
        return re.sub(r'=w\d+-h\d+[^/]*$', '=w%d-h%d-l90-rj' % (size, size), url)
    return url


def _song(video_id, title, sub_runs, thumb, extra_duration=''):
    parts = _runs_text(sub_runs)
    artist, artist_id = _artist(sub_runs)
    duration = next((p for p in parts + [extra_duration] if DURATION_RX.match(p or '')), '')
    rest = [p for p in parts if p not in (artist, duration)]
    views = next((p for p in rest if re.search(r'\d.*\b(views?|plays?)\b', p, re.I)), '')
    return {'type': 'video', 'id': video_id, 'title': title, 'channel': artist or (parts[0] if parts else ''),
            'channel_id': artist_id, 'duration': duration_seconds(duration), 'live': False, 'views': views,
            'published': '', 'description': ' · '.join(rest), 'thumb': video_thumb(video_id) if not thumb or
            'i.ytimg.com' in thumb else _big(thumb, 544), 'fanart': video_fanart(video_id) if not thumb or
            'i.ytimg.com' in thumb else _big(thumb), 'music': True}


def _list_row(r):
    """musicResponsiveListItemRenderer: a song or video row, or an artist/album/playlist row in search."""
    cols = [((c.get('musicResponsiveListItemFlexColumnRenderer') or {}).get('text') or {})
            for c in r.get('flexColumns') or []]
    title = text(cols[0]) if cols else ''
    sub = {'runs': [run for c in cols[1:] for run in (c.get('runs') or []) + [{'text': ' • '}]]}
    fixed = [text((c.get('musicResponsiveListItemFixedColumnRenderer') or {}).get('text'))
             for c in r.get('fixedColumns') or []]
    vid = (r.get('playlistItemData') or {}).get('videoId')
    if not vid:
        play = (((((r.get('overlay') or {}).get('musicItemThumbnailOverlayRenderer') or {}).get('content') or {})
                 .get('musicPlayButtonRenderer') or {}).get('playNavigationEndpoint') or {})
        vid = (play.get('watchEndpoint') or {}).get('videoId')
    if not vid and cols:
        for run in cols[0].get('runs') or []:
            vid = vid or ((run.get('navigationEndpoint') or {}).get('watchEndpoint') or {}).get('videoId')
    if vid:
        item = _song(vid, title, sub, _thumb(r), fixed[0] if fixed else '')
        rank = text(((r.get('customIndexColumn') or {}).get('musicCustomIndexColumnRenderer') or {}).get('text'))
        if rank.isdigit():
            item['title'] = '%s. %s' % (rank, title)
        return item
    browse = (r.get('navigationEndpoint') or {}).get('browseEndpoint')
    if browse and title:
        return _browse_item(title, browse, _thumb(r), ' · '.join(_runs_text(sub)))
    return None


def _card(r):
    """musicTwoRowItemRenderer: an album, single, playlist, artist, mix or music video card."""
    title = text(r.get('title'))
    subtitle = r.get('subtitle') or {}
    nav = r.get('navigationEndpoint') or {}
    thumb = _thumb(r)
    watch = nav.get('watchEndpoint') or {}
    if watch.get('playlistId') and (is_mix(watch['playlistId']) or not watch.get('videoId')):
        return {'type': 'playlist', 'id': watch['playlistId'], 'title': title, 'channel': ' · '.join(
            _runs_text(subtitle)), 'channel_id': '', 'count': '', 'thumb': thumb, 'video': watch.get('videoId')}
    if watch.get('videoId'):
        return _song(watch['videoId'], title, subtitle, thumb)
    wpl = nav.get('watchPlaylistEndpoint') or {}
    if wpl.get('playlistId'):
        return {'type': 'playlist', 'id': wpl['playlistId'], 'title': title, 'channel': ' · '.join(
            _runs_text(subtitle)), 'channel_id': '', 'count': '', 'thumb': thumb, 'video': None}
    browse = nav.get('browseEndpoint')
    if browse and title:
        return _browse_item(title, browse, thumb, ' · '.join(_runs_text(subtitle)))
    return None


def _button(r):
    """musicNavigationButtonRenderer: a mood or genre."""
    browse = ((r.get('clickCommand') or {}).get('browseEndpoint')) or {}
    title = text(r.get('buttonText'))
    if not (browse.get('browseId') and title):
        return None
    return {'type': 'mpage', 'id': browse['browseId'], 'params': browse.get('params') or '', 'title': title,
            'thumb': '', 'description': ''}


def _multi_row(r):
    """musicMultiRowListItemRenderer: a podcast episode (an ordinary video)."""
    play = (((((r.get('overlay') or {}).get('musicItemThumbnailOverlayRenderer') or {}).get('content') or {})
             .get('musicPlayButtonRenderer') or {}).get('playNavigationEndpoint') or {})
    vid = ((play.get('watchEndpoint') or {}).get('videoId') or
           (((r.get('onTap') or {}).get('watchEndpoint')) or {}).get('videoId'))
    if not vid:
        return None
    item = _song(vid, text(r.get('title')), r.get('subtitle'), _thumb(r))
    item['description'] = text(r.get('description')) or item['description']
    if not item['channel_id']:
        item['channel'] = ''
    return item


def _top_card(r):
    """musicCardShelfRenderer (search's top result): the result itself, from its title link."""
    title = text(r.get('title'))
    for run in (r.get('title') or {}).get('runs') or []:
        nav = run.get('navigationEndpoint') or {}
        if (nav.get('watchEndpoint') or {}).get('videoId'):
            return _song(nav['watchEndpoint']['videoId'], title, r.get('subtitle'), _thumb(r))
        if nav.get('browseEndpoint'):
            return _browse_item(title, nav['browseEndpoint'], _thumb(r), ' · '.join(_runs_text(r.get('subtitle'))))
    return None


ITEMS = {
    'musicResponsiveListItemRenderer': _list_row,
    'musicTwoRowItemRenderer': _card,
    'musicNavigationButtonRenderer': _button,
    'musicMultiRowListItemRenderer': _multi_row,
}
SHELVES = ('musicCarouselShelfRenderer', 'musicShelfRenderer', 'musicPlaylistShelfRenderer', 'gridRenderer',
           'musicImmersiveCarouselShelfRenderer', 'musicCardShelfRenderer')


def _token(o):
    """A continuation token directly on a shelf or continuation (not inside its items)."""
    if not isinstance(o, dict):
        return None
    for c in o.get('continuations') or []:
        t = (c.get('nextContinuationData') or c.get('reloadContinuationData') or {}).get('continuation')
        if t:
            return t
    for item in (o.get('contents') or o.get('items') or [])[-1:]:
        cir = (item or {}).get('continuationItemRenderer') or {}
        t = (((cir.get('continuationEndpoint') or {}).get('continuationCommand')) or {}).get('token')
        if t:
            return t
    return None


def items(o, seen=None):
    """Every item in o, in page order."""
    out, seen = [], seen if seen is not None else set()

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in MUSIC_SKIP:
                    continue
                handler = ITEMS.get(k)
                if handler and isinstance(v, dict):
                    it = handler(v)
                    key = (it['type'], it['id'], it.get('params')) if it else None
                    if it and key not in seen:
                        seen.add(key)
                        out.append(it)
                    continue
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(o)
    return out


# "See all" pages YouTube Music only serves to a signed-in YouTube Music account, which TubeLite can't use;
# their rows open with the items they came with instead.
SIGNIN_ONLY = ('FEmusic_ucp_', 'FEmusic_library', 'FEmusic_liked', 'FEmusic_history', 'FEmusic_listening_review')


def _more(shelf):
    """Where a shelf's "See all" / "More" goes: ('browse', id, params) or ('search', query, params)."""
    header = shelf.get('header') or {}
    candidates = []
    for h in header.values():
        if isinstance(h, dict):
            btn = ((h.get('moreContentButton') or {}).get('buttonRenderer') or {}).get('navigationEndpoint') or {}
            candidates.append(btn)
            for run in (h.get('title') or {}).get('runs') or []:
                candidates.append(run.get('navigationEndpoint') or {})
    candidates.append(shelf.get('bottomEndpoint') or {})
    for run in (shelf.get('title') or {}).get('runs') or []:
        candidates.append(run.get('navigationEndpoint') or {})
    for ep in candidates:
        be = ep.get('browseEndpoint') or {}
        if be.get('browseId', '').startswith(SIGNIN_ONLY):
            return None
        if be.get('browseId'):
            return ['browse', be['browseId'], be.get('params') or '']
        se = ep.get('searchEndpoint') or {}
        if se.get('query'):
            return ['search', se['query'], se.get('params') or '']
    return None


def _shelf_title(shelf, key):
    header = shelf.get('header') or {}
    for h in header.values():
        if isinstance(h, dict) and text(h.get('title')):
            return text(h['title'])
    if text(shelf.get('title')):
        return text(shelf['title'])
    return 'Top result' if key == 'musicCardShelfRenderer' else ''


def page(data):
    """A YouTube Music reply as {'shelves': [{'title', 'items', 'more', 'cont'}], 'cont': more shelves}."""
    shelves, seen, top = [], set(), [None]

    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in SKIP_KEYS or k == 'menu':
                    continue
                if k in SHELVES and isinstance(v, dict):
                    found = items(v.get('contents') or v.get('items') or [], seen)
                    if k == 'musicCardShelfRenderer':
                        card = _top_card(v)
                        key = (card['type'], card['id'], card.get('params')) if card else None
                        if card and key not in seen:
                            seen.add(key)
                            found.insert(0, card)
                    if found:
                        title = _shelf_title(v, k)
                        # The page's own list (a playlist's or album's tracks, a podcast's episodes) has no
                        # heading; it's shown directly, with the page's other rows as folders after it.
                        main = k == 'musicPlaylistShelfRenderer' or (k == 'musicShelfRenderer' and not title)
                        shelves.append({'title': title, 'items': found, 'more': _more(v), 'cont': _token(v),
                                        'main': main})
                    continue
                if k in ('sectionListRenderer', 'sectionListContinuation') and isinstance(v, dict):
                    top[0] = _token(v) or top[0]
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(data)
    return {'shelves': shelves, 'cont': top[0]}


def continuation(data):
    """More of one shelf: (items, next token)."""
    cc = data.get('continuationContents') or {}
    for key in ('musicShelfContinuation', 'musicPlaylistShelfContinuation', 'gridContinuation',
                'musicCarouselShelfContinuation', 'sectionListContinuation'):
        if key in cc:
            return items(cc[key].get('contents') or cc[key].get('items') or []), _token(cc[key])
    for action in data.get('onResponseReceivedActions') or []:
        got = (action.get('appendContinuationItemsAction') or {}).get('continuationItems')
        if got:
            return items(got), _token({'contents': got})
    return [], None
