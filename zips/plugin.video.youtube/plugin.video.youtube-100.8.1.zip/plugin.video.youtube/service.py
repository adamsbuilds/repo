import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import xbmc
import xbmcgui

from resources.lib import kodi


class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        seg = re.match(r'^/seg/([A-Za-z0-9_-]{11})/(\d+)$', self.path.split('?')[0])
        if seg:
            return self.relay(seg.group(1), seg.group(2))
        m = re.match(r'^/mpd/([A-Za-z0-9_-]{11})\.mpd$', self.path.split('?')[0])
        path = os.path.join(kodi.profile_dir(), 'mpd', '%s.mpd' % m.group(1)) if m else None
        if not path or not os.path.exists(path):
            self.send_error(404)
            return
        with open(path, 'rb') as f:
            body = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def relay(self, video_id, itag):
        """Movie streams: passes Kodi's request to YouTube and streams the reply back."""
        from resources.lib import drm
        try:
            r = drm.open_stream(_relay_session(), video_id, itag, self.headers.get('Range'))
        except Exception as e:
            kodi.log('stream relay error: %s' % e, xbmc.LOGERROR)
            r = None
        if r is None:
            self.send_error(403)
            return
        try:
            self.send_response(r.status_code)
            for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                if r.headers.get(h):
                    self.send_header(h, r.headers[h])
            self.end_headers()
            first = (self.headers.get('Range') or '').startswith('bytes=0-')
            for chunk in r.iter_content(64 * 1024):
                if first:
                    # The stream's header: note which key it needs, to check the license against it.
                    drm.note_init(video_id, itag, chunk)
                    first = False
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass  # Kodi dropped the request, e.g. after a seek; normal.
        finally:
            r.close()

    def do_POST(self):
        """Widevine license requests from InputStream Adaptive for free movies."""
        m = re.match(r'^/license/([A-Za-z0-9_-]{11})$', self.path.split('?')[0])
        if not m:
            self.send_error(404)
            return
        length = int(self.headers.get('Content-Length') or 0)
        challenge = self.rfile.read(length) if length else b''
        try:
            from resources.lib import drm
            from resources.lib.innertube import InnerTube
            data = drm.license(InnerTube().session, m.group(1), challenge)
        except Exception as e:
            kodi.log('license proxy error: %s' % e, xbmc.LOGERROR)
            data = None
        if not data:
            self.send_error(403)
            return
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


_relay = []


def _relay_session():
    """One shared HTTP session for movie streams, so requests reuse connections to YouTube."""
    if not _relay:
        import requests
        from requests.adapters import HTTPAdapter
        session = requests.Session()
        session.mount('https://', HTTPAdapter(pool_connections=4, pool_maxsize=16))
        _relay.append(session)
    return _relay[0]


class Monitor(xbmc.Monitor):
    def __init__(self):
        super(Monitor, self).__init__()
        self.library_pending = False

    def onSettingsChanged(self):
        set_context_flag()
        if kodi.setting_bool('library_fill'):
            self.library_pending = True

    def onNotification(self, sender, method, data):
        if method == 'VideoLibrary.OnScanFinished' and kodi.setting_bool('library_fill'):
            self.library_pending = True


class Player(xbmc.Player):
    """Watches playback that TubeLite started: SponsorBlock skipping and YouTube watch history."""

    def __init__(self, monitor):
        super(Player, self).__init__()
        self.monitor = monitor
        self.session_id = 0

    def onAVStarted(self):
        win = xbmcgui.Window(10000)
        vid = win.getProperty('tubelite.playing')
        try:
            ts = int(win.getProperty('tubelite.playing_ts') or 0)
        except ValueError:
            ts = 0
        win.clearProperty('tubelite.playing')
        win.clearProperty('tubelite.playing_ts')
        self.session_id += 1
        if not vid or time.time() - ts > 120:
            return
        sid = self.session_id
        if kodi.setting_bool('sb_enabled'):
            t = threading.Thread(target=self.skip_loop, args=(vid, sid))
            t.daemon = True
            t.start()
        if kodi.setting_bool('report_history'):
            t = threading.Thread(target=self.report, args=(vid,))
            t.daemon = True
            t.start()

    def onPlayBackStopped(self):
        self.session_id += 1

    def onPlayBackEnded(self):
        self.session_id += 1

    def report(self, vid):
        from resources.lib import auth
        from resources.lib.innertube import InnerTube
        if not auth.signed_in():
            return
        try:
            ok, notes = InnerTube().report_watched(vid)
            kodi.log('YouTube history %s for %s (%s)' % ('updated' if ok else 'NOT updated', vid, '; '.join(notes)),
                     xbmc.LOGINFO if ok else xbmc.LOGWARNING)
        except Exception as e:
            kodi.log('YouTube history report failed: %s' % e, xbmc.LOGWARNING)

    def skip_loop(self, vid, sid):
        from resources.lib import sponsorblock
        from resources.lib.innertube import InnerTube
        try:
            segs = sponsorblock.segments(InnerTube().session, vid)
        except Exception as e:
            kodi.log('SponsorBlock lookup failed: %s' % e, xbmc.LOGWARNING)
            return
        if not segs:
            return
        kodi.log('SponsorBlock: %d segment(s) for %s' % (len(segs), vid))
        skipped = set()
        while sid == self.session_id and not self.monitor.abortRequested():
            try:
                if not self.isPlayingVideo():
                    break
                hit = sponsorblock.due(segs, self.getTime(), skipped)
            except Exception:
                break
            if hit:
                i, end, cat = hit
                skipped.add(i)
                try:
                    total = self.getTotalTime()
                    self.seekTime(min(end, total - 1) if total else end)
                except Exception:
                    continue
                if kodi.setting_bool('sb_notify'):
                    kodi.notify('Skipped %s' % sponsorblock.LABELS.get(cat, cat), 'SponsorBlock', 2000)
            if len(skipped) == len(segs) or self.monitor.waitForAbort(0.5):
                break


def set_context_flag():
    xbmcgui.Window(10000).setProperty('tubelite.context', '1' if kodi.setting_bool('context_menu') else '')


def start_server():
    """The local server Kodi's player talks to (manifests, movie streams, movie licenses). Automatic: port
    50152, or any free port if that's taken. Manual: the port set in Settings → Advanced. The port in use is
    published as the tubelite.port window property for the add-on to read."""
    from resources.lib.streams import DEFAULT_PORT
    win = xbmcgui.Window(10000)
    win.clearProperty('tubelite.port')
    choice = _port_choice()
    auto = choice[0] != 'false'
    manual = int(choice[1]) if choice[1].isdigit() else DEFAULT_PORT
    ports = [DEFAULT_PORT, 0] if auto else [manual]
    server = None
    for port in ports:
        try:
            server = Server(('127.0.0.1', port), Handler)
            break
        except Exception as e:
            kodi.log('could not start manifest server on port %d: %s' % (port, e),
                     xbmc.LOGWARNING if auto else xbmc.LOGERROR)
    if server is None:
        if not auto:
            kodi.notify('Port %s is in use. Pick another under Settings → Advanced, or set it to Automatic.'
                        % ports[0], ms=8000)
        return None
    port = server.server_address[1]
    win.setProperty('tubelite.port', str(port))
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    kodi.log('manifest server listening on 127.0.0.1:%d' % port)
    return server


def _port_choice():
    import xbmcaddon
    fresh = xbmcaddon.Addon(kodi.ADDON_ID)  # a new Addon object sees settings changed since startup
    return fresh.getSetting('port_auto'), fresh.getSetting('server_port')


def signed_in():
    try:
        from resources.lib import auth
        return auth.signed_in()
    except Exception:
        return False


def player_script_pending():
    """Signed in: whether YouTube's current player script still needs its one-time read."""
    try:
        from resources.lib import jsc
        from resources.lib.innertube import InnerTube
        return jsc.needs_build(InnerTube().session)[1]
    except Exception as e:
        kodi.log('player version check failed: %s' % e, xbmc.LOGWARNING)
        return False


def kodi_idle(seconds=60):
    try:
        return xbmc.getGlobalIdleTime() >= seconds and not xbmc.Player().isPlaying()
    except Exception:
        return False


def prepare_player_script():
    """The one-time read of YouTube's player script for signed-in playback. Heavy on slow boxes, so the
    service only runs it while nobody is using Kodi."""
    try:
        from resources.lib import jsc
        from resources.lib.innertube import InnerTube
        pid, built = jsc.prepare(InnerTube().session)
        if built:
            kodi.log('prepared YouTube player %s for signed-in playback' % pid)
    except Exception as e:
        kodi.log('player script preparation failed: %s' % e, xbmc.LOGWARNING)


def background_jobs(monitor):
    """Client refresh and library trailer fill, kept off the startup path."""
    if monitor.waitForAbort(20):
        return
    library_done = False
    player_checked = 0
    was_signed_in = False
    script_pending = False
    while not monitor.abortRequested():
        signed = signed_in()
        if signed and (not was_signed_in or time.time() - player_checked > 6 * 3600):
            player_checked = time.time()
            script_pending = player_script_pending()
        if signed and script_pending and kodi_idle():
            prepare_player_script()
            script_pending = False
        was_signed_in = signed
        if kodi.setting_bool('auto_clients'):
            try:
                from resources.lib import clientupdate
                from resources.lib.innertube import InnerTube
                clientupdate.refresh(InnerTube(), reason='daily')
            except Exception as e:
                kodi.log('client refresh failed: %s' % e, xbmc.LOGWARNING)
        if kodi.setting_bool('library_fill') and (not library_done or monitor.library_pending):
            monitor.library_pending = False
            try:
                from resources.lib import library
                library.fill(monitor)
                library_done = True
            except Exception as e:
                kodi.log('library fill failed: %s' % e, xbmc.LOGWARNING)
        # Wake every minute for library scans; the client refresh only re-runs once a day.
        if monitor.waitForAbort(60):
            break


def run():
    monitor = Monitor()
    kodi.migrate_from_tubelite()
    try:
        from resources.lib import auth
        auth.sync_settings()
    except Exception as e:
        kodi.log('account settings sync failed: %s' % e, xbmc.LOGWARNING)
    set_context_flag()
    port_choice = _port_choice()
    server = start_server()
    player = Player(monitor)
    jobs = threading.Thread(target=background_jobs, args=(monitor,))
    jobs.daemon = True
    jobs.start()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        if _port_choice() != port_choice:
            # Port setting changed: move the server without needing a Kodi restart.
            port_choice = _port_choice()
            if server:
                server.shutdown()
                server.server_close()
            server = start_server()
    del player
    if server:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    run()
