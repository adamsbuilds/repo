import json
import os
import re
import sys
import time
from urllib.parse import parse_qsl, urlparse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import auth, kodi, music, parser, storage, streams, trailers, views
from resources.lib.innertube import InnerTube, YTError
from resources.lib.parser import (channel_title, clean, find_key, is_mix, nav_channels, parse, related_section,
                                  renderer_census, shelves, video_details, video_fanart)

parser.KEEP_EMOJI = kodi.setting_bool('show_emoji')
HANDLE = kodi.handle()
PATH = urlparse(sys.argv[0]).path.strip('/')
ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

TABS = {'playlists': 'playlists', 'live': 'streams', 'streams': 'streams', 'shorts': 'shorts', 'videos': 'videos'}


def video_from(value):
    if not value:
        return None
    if len(value) == 11 and '/' not in value:
        return value
    u = urlparse(value)
    q = dict(parse_qsl(u.query))
    if q.get('v'):
        return q['v']
    last = u.path.rstrip('/').split('/')[-1]
    return last if len(last) == 11 else None


def official_route(path, args):
    """Maps the official YouTube add-on's URL styles (used by Kodi's library, skins and other
    add-ons) onto TubeLite's routes. Returns (path, args), or None when it's already a TubeLite URL."""
    parts = [p for p in path.split('/') if p]
    head = parts[0] if parts else ''
    vid = args.get('video_id') or args.get('videoid') or args.get('v')
    if head == 'uri2addon':
        vid = video_from(args.get('uri'))
    if vid and head in ('', 'uri2addon'):
        return 'play', {'video_id': vid}
    if head == 'channel' and len(parts) > 1:
        if len(parts) > 3 and parts[2] == 'playlist':
            return 'playlist', {'id': parts[3]}
        tab = TABS.get(parts[2]) if len(parts) > 2 else None
        return ('channel/tab', {'id': parts[1], 'tab': tab}) if tab else ('channel', {'id': parts[1]})
    if head in ('user', 'handle', 'c') and len(parts) > 1:
        return 'channel', {'id': parts[1] if parts[1].startswith('@') else '@' + parts[1]}
    if head == 'playlist' and len(parts) > 1:
        return 'playlist', {'id': parts[1]}
    if head == 'search' and len(parts) == 1 and (args.get('q') or args.get('query')):
        return 'search/results', {'q': args.get('q') or args.get('query'), 'kind': 'all'}
    if parts[:2] == ['kodion', 'search']:
        q = args.get('q') or args.get('query')
        return ('search/results', {'q': q, 'kind': 'all'}) if q else ('search', {})
    return None

_yt = None


def yt():
    global _yt
    if _yt is None:
        _yt = InnerTube()
    return _yt


def shorts():
    return not kodi.setting_bool('hide_shorts')


def page_size():
    return min(max(kodi.setting_int('page_size', 30), 5), 200)


MAX_FETCHES = 10


def paged(fetch):
    """One page of a list, filled to Settings → Browsing → Items per page. YouTube sends lists in batches
    of its own size (5 for a Home row, 20 for search, 100 for a playlist), so this asks for more batches
    until the page is full. fetch(token) returns (items, next token); token None is the first batch.
    Returns (items, args for the next page or None). A page that ends partway through a batch carries
    that batch's token and how many of its items were already shown (skip)."""
    want = page_size()
    cur = ARGS.get('cont') or None
    skip = int(ARGS.get('skip') or 0)
    out, seen = [], set()
    for _ in range(MAX_FETCHES):
        items, token = fetch(cur)
        batch = items[skip:]
        used = skip
        for it in batch:
            used += 1
            key = (it['type'], it['id'], it.get('params'))
            if key in seen:
                continue
            seen.add(key)
            out.append(it)
            if len(out) >= want:
                if used < len(items):
                    return out, {'cont': cur or '', 'skip': used}
                return out, ({'cont': token} if token else None)
        skip = 0
        if not token:
            return out, None
        cur = token
    return out, {'cont': cur}


def next_args(nxt, **base):
    """Arguments for the next page: this list's own (minus paging) plus where the next page starts."""
    if not nxt:
        return None
    args = dict((k, v) for k, v in (base or ARGS).items() if k not in ('cont', 'skip', 'new'))
    args.update(nxt)
    return args


# ---------------------------------------------------------------- list helpers

def folder(label, path, thumb='', plot='', context=None, **params):
    li = xbmcgui.ListItem(label, offscreen=True)
    art = thumb if thumb.startswith('http') else (kodi.icon(thumb) if thumb else os.path.join(kodi.ADDON_PATH, 'icon.png'))
    li.setArt({'icon': art, 'thumb': art, 'poster': art,
               'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    if plot:
        tag = li.getVideoInfoTag()
        tag.setPlot(plot)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, True)


def action_item(label, path, thumb='', plot='', **params):
    """An entry that runs something (sign in, settings) instead of opening a list.
    Kodi runs these like RunPlugin, outside the folder-loading screen."""
    li = xbmcgui.ListItem(label, offscreen=True)
    art = kodi.icon(thumb) if thumb else os.path.join(kodi.ADDON_PATH, 'icon.png')
    li.setArt({'icon': art, 'thumb': art, 'poster': art, 'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    if plot:
        li.getVideoInfoTag().setPlot(plot)
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, False)


def next_item(label, path, **params):
    """The "next page" entry, with art for every image slot a view might use (square and 16:9) and the
    SpecialSort property skins use to keep it at the bottom."""
    li = xbmcgui.ListItem('[COLOR yellow]%s >>[/COLOR]' % label, offscreen=True)
    square, wide = kodi.icon('next.png'), kodi.icon('next_wide.png')
    li.setArt({'icon': square, 'thumb': square, 'poster': square, 'landscape': wide, 'banner': wide,
               'fanart': os.path.join(kodi.ADDON_PATH, 'fanart.jpg')})
    li.setProperty('SpecialSort', 'bottom')
    li.getVideoInfoTag().setPlot('Next page')
    xbmcplugin.addDirectoryItem(HANDLE, kodi.url(path, **params), li, True)


def fill_missing_titles(items):
    """Some YouTube rows come back without titles; look those up so they don't show as video ids
    or blank playlists."""
    missing = [it for it in items if it['type'] in ('video', 'playlist') and not it.get('title')]
    if not missing:
        return
    from concurrent.futures import ThreadPoolExecutor
    kodi.log('looking up %d missing title(s) (renderers: %s)' % (
        len(missing), ', '.join(sorted(set(it.get('_renderer', '?') for it in missing)))))

    def look(it):
        try:
            if it['type'] == 'playlist':
                return it, {'title': yt().playlist_title(it['id'])}
            return it, yt().oembed(it['id'])
        except Exception:
            return it, {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        for it, d in pool.map(look, missing):
            it['title'] = clean(d.get('title') or '') or ('Playlist' if it['type'] == 'playlist' else 'YouTube video')
            if it['type'] == 'playlist':
                continue
            if not it.get('channel'):
                it['channel'] = d.get('author_name', '')
            if not it.get('channel_id'):
                handle = (d.get('author_url') or '').rstrip('/').split('/')[-1]
                it['channel_id'] = handle if handle.startswith('@') else ''


def video_item(v, extra_context=None, url=None, label=None):
    li = xbmcgui.ListItem(label or v.get('title') or v['id'], offscreen=True)
    fanart = v.get('thumb') if v.get('short') else (v.get('fanart') or video_fanart(v['id']))
    li.setArt({'thumb': v.get('thumb'), 'icon': v.get('thumb'), 'poster': v.get('thumb'), 'fanart': fanart,
               'landscape': v['thumb'] if 'hqdefault' not in (v.get('thumb') or '') else fanart})
    tag = li.getVideoInfoTag()
    tag.setTitle(v.get('title', ''))
    tag.setMediaType('video')
    if v.get('duration'):
        tag.setDuration(int(v['duration']))
    if v.get('channel'):
        tag.setStudios([v['channel']])
    meta = ' · '.join(x for x in (v.get('channel'), v.get('views'), v.get('published')) if x)
    if v.get('live'):
        meta = '[LIVE] ' + meta
    tag.setPlot('[B]%s[/B]\n%s' % (meta, v.get('description', '')) if meta else v.get('description', ''))
    li.setProperty('IsPlayable', 'true')
    ctx = [('Related videos', 'Container.Update(%s)' % kodi.url('related', id=v['id']))]
    if v.get('channel_id'):
        ctx.append(('Go to channel', 'Container.Update(%s)' % kodi.url('channel', id=v['channel_id'],
                                                                         title=v.get('channel'))))
        ctx.append(('Add channel to My Channels', 'RunPlugin(%s)' % kodi.url(
            'channel/add', id=v['channel_id'], title=v.get('channel'))))
    if auth.signed_in():
        ctx.append(('Add to Watch Later', 'RunPlugin(%s)' % kodi.url('account/action', do='watchlater', id=v['id'])))
        ctx.append(('Like', 'RunPlugin(%s)' % kodi.url('account/action', do='like', id=v['id'])))
        if v.get('channel_id'):
            ctx.append(('Subscribe to %s' % (v.get('channel') or 'channel'), 'RunPlugin(%s)' % kodi.url(
                'account/action', do='subscribe', id=v['channel_id'], name=v.get('channel'))))
    ctx.append(('Check playback', 'RunPlugin(%s)' % kodi.url('signedin/test', id=v['id'])))
    ctx += extra_context or []
    li.addContextMenuItems(ctx)
    xbmcplugin.addDirectoryItem(HANDLE, url or kodi.url('play', video_id=v['id']), li, False)


# What the last render() listed, by kind, so finish() can pick a list view rather than the video view when
# nothing in the list plays.
RENDERED = {}
KINDS = {'video': 'video', 'channel': 'channel', 'artist': 'channel', 'playlist': 'playlist',
         'mplaylist': 'playlist', 'album': 'playlist', 'show': 'playlist', 'mpage': 'menu'}


def render(items, next_path=None, next_params=None):
    # Paid movies and shows can't be bought through Kodi, so they're left out of every list.
    items = [it for it in items if not ((it.get('movie') and not it.get('free')) or it.get('paid'))]
    fill_missing_titles(items)
    for it in items:
        kind = KINDS.get(it['type'], 'menu')
        RENDERED[kind] = RENDERED.get(kind, 0) + 1
        if it['type'] == 'video':
            video_item(it, label=('%s  [COLOR grey]%s[/COLOR]' % (it['title'], it['channel']))
                       if it.get('music') and it.get('channel') else None)
        elif it['type'] == 'mplaylist':
            pid = it['id'][2:] if it['id'].startswith('VL') else it['id']
            folder(it['title'], 'playlist', it.get('thumb') or 'playlists.png', it.get('description', ''), id=pid)
        elif it['type'] in ('album', 'artist', 'mpage'):
            folder(it['title'], 'music/browse', it.get('thumb') or 'music.png', it.get('description', ''),
                   id=it['id'], params=it.get('params'))
        elif it['type'] == 'show':
            show_folder(it)
        elif it['type'] == 'playlist':
            label = it['title'] + ('  [COLOR grey](%s)[/COLOR]' % it['count'] if it.get('count') else '')
            folder(label, 'playlist', it.get('thumb', ''), it.get('channel', ''), id=it['id'], video=it.get('video'))
        elif it['type'] == 'channel':
            folder('[B]%s[/B]' % it['title'], 'channel', it.get('thumb', ''),
                   '%s\n%s' % (it.get('subs', ''), it.get('description', '')),
                   context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url(
                       'channel/add', id=it['id'], title=it['title'], thumb=it.get('thumb')))] + ([
                       ('Subscribe', 'RunPlugin(%s)' % kodi.url('account/action', do='subscribe', id=it['id'],
                                                                name=it['title']))] if auth.signed_in() else []),
                   id=it['id'], title=it['title'])
    if next_path and next_params and (next_params.get('cont') or next_params.get('skip')):
        next_item('Next page', next_path, **next_params)


def finish(content='videos', cache=False, view=None):
    """Ends the listing, then applies the view saved for it under Settings → Set views. A list with nothing
    that plays (channels, playlists, albums, moods) is shown as a plain list, not with the video view."""
    if content == 'videos' and RENDERED and not RENDERED.get('video'):
        content = 'files'
        if view not in ('channels', 'playlists', 'rows'):
            kinds = [k for k, n in RENDERED.items() if n]
            view = {'channel': 'channels', 'playlist': 'playlists'}.get(kinds[0]) if len(kinds) == 1 else 'menus'
    elif view in ('channels', 'playlists', 'rows'):
        content = 'files'
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)
    views.apply(view or views.for_content(content))


def fail(e):
    kodi.record_error(PATH or 'main menu', e)
    kodi.notify('%s  (details: You → Show last error)' % (str(e) or 'Something went wrong'), ms=6000)
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def show_error():
    try:
        with open(kodi.error_path(), encoding='utf-8') as f:
            text = f.read()
    except Exception:
        text = 'No errors recorded.'
    xbmcgui.Dialog().textviewer('Last TubeLite error', text)


# ---------------------------------------------------------------- menus

# ---------------------------------------------------------------- account

def account_changed():
    """After signing in or out: a fresh YouTube session (new visitor id) and no lists kept from before."""
    import shutil
    yt().reset_state()
    for name in ('home', 'lists'):
        shutil.rmtree(os.path.join(kodi.profile_dir(), name), ignore_errors=True)
    win = xbmcgui.Window(10000)
    for prop in ('tubelite.music_signed_out', 'tubelite.search', 'tubelite.free_search', 'tubelite.music_search'):
        win.clearProperty(prop)


def signin():
    from resources.lib import signin_dialog
    try:
        done = signin_dialog.run(yt().session)
    except Exception as e:
        kodi.log('sign-in failed: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Could not start sign-in: %s' % e)
        return
    if not done:
        return
    account_changed()
    name = ''
    accounts = []
    try:
        accounts = yt().accounts()
        auth.set_identities(accounts)
        name = accounts[0]['name'] if accounts else ''
    except Exception as e:
        kodi.log('account lookup failed: %s' % e)
    kodi.notify('Signed in%s' % (' as %s' % name if name else ''))
    if len(accounts) > 1:
        choose_identity(accounts)
    xbmc.executebuiltin('Container.Refresh')


def _identity_label(a):
    if not a.get('page_id'):
        return '%s  [COLOR grey](main account)[/COLOR]' % a['name']
    return '%s  [COLOR grey](channel%s)[/COLOR]' % (a['name'], ', ' + a['handle'] if a.get('handle') else '')


def choose_identity(accounts=None):
    """Browse as your main account or one of your channels. Age-restricted videos always play through the
    main account, which is the only one YouTube lets confirm your age."""
    if not auth.signed_in():
        return
    if accounts is None:
        try:
            accounts = yt().accounts()
            auth.set_identities(accounts)
        except Exception as e:
            kodi.log('account list failed: %s' % e)
            accounts = auth.identities()
    if not accounts:
        xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'YouTube didn\'t list any accounts for this sign-in.')
        return
    current = auth.page_id()
    preselect = next((i for i, a in enumerate(accounts) if a.get('page_id') == current), 0)
    pick = xbmcgui.Dialog().select('Browse YouTube as', [_identity_label(a) for a in accounts], preselect=preselect)
    if pick < 0:
        return
    chosen = accounts[pick]
    auth.select_identity(chosen.get('page_id'), chosen['name'])
    kodi.notify('Browsing as %s' % chosen['name'])
    xbmc.executebuiltin('Container.Refresh')


def signout():
    if xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Sign out of YouTube on this device?'):
        auth.sign_out()
        account_changed()
        kodi.notify('Signed out')
        xbmc.executebuiltin('Container.Refresh')


# Sections, the way YouTube's own apps lay them out. Values: (label, icon, needs sign-in).
FEEDS = {
    'default': ('Home', 'home.png', False),
    'FEsubscriptions': ('Subscriptions', 'subscriptions.png', True),
    'FEhistory': ('History', 'history.png', True),
    'FEplaylist_aggregation': ('Playlists', 'playlists.png', True),
    'FEmy_youtube': ('Library', 'playlists.png', True),
    'VLWL': ('Watch later', 'watchlater.png', True),
    'VLLL': ('Liked videos', 'liked.png', True),
    'VLLM': ('Liked music', 'liked.png', True),
    'FEtopics_music': ('Music', 'music.png', False),
    'FEtopics_live': ('Live', 'live.png', False),
    'FEtopics_gaming': ('Gaming', 'gaming.png', False),
    'FEtopics_news': ('News', 'news.png', False),
    'FEtopics_sports': ('Sports', 'sports.png', False),
}


def account_feed():
    """Any TV-app section: Home, Subscriptions, Music, Gaming and the rest."""
    fid = ARGS.get('id', 'FEsubscriptions')
    needs_auth = FEEDS.get(fid, ('', '', True))[2]
    def fetch(token):
        if token:
            return parse(yt().account_browse(continuation=token, require_auth=needs_auth), shorts())
        return parse(yt().account_browse(fid, require_auth=needs_auth), shorts())
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    if not items and not ARGS.get('cont'):
        if fid == 'default' and not auth.signed_in():
            folder('[I]YouTube shows little here until you sign in. Try Music, Gaming or Search.[/I]', '',
                   'home.png')
        else:
            kodi.notify('Nothing here yet')
    render(items, 'account/feed', next_args(nxt))
    finish(view='playlists' if fid == 'FEplaylist_aggregation' else None)


def feed_folder(fid, plot=''):
    label, icon, _ = FEEDS[fid]
    folder(label, 'account/feed', icon, plot, id=fid)


def account_action():
    do, item = ARGS.get('do'), ARGS.get('id')
    labels = {'like': 'Liked', 'watchlater': 'Added to Watch Later',
              'subscribe': 'Subscribed to %s' % (ARGS.get('name') or 'channel')}
    try:
        if do == 'like':
            yt().like(item)
        elif do == 'watchlater':
            yt().watch_later(item)
        elif do == 'subscribe':
            yt().subscribe(item)
        else:
            return
        kodi.notify(labels[do])
    except Exception as e:
        kodi.log('%s failed: %s' % (do, e), xbmc.LOGERROR)
        kodi.notify('Couldn\'t do that: %s' % e)


def library_fill():
    from resources.lib import library
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Adding trailers to your library')
    try:
        done = library.fill()
    finally:
        progress.close()
    parts = []
    for key, label in (('movies', 'movies'), ('tvshows', 'TV shows')):
        if done.get(key) is None and key in done:
            parts.append('%s: not supported by this Kodi' % label)
        elif done.get(key) is not None:
            parts.append('%d %s' % (done[key], label))
    kodi.notify('Trailers added: ' + ', '.join(parts) if parts else 'Library trailers are up to date')


def library_clear():
    from resources.lib import library
    if xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Remove the trailer links TubeLite added to your library?[CR]'
                                               'Scraped trailers are left alone.'):
        kodi.set_setting('library_fill', 'false')
        kodi.notify('Removed %d trailer links' % library.clear())


def clients_refresh():
    from resources.lib import clientupdate
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Testing YouTube player clients')
    meta = clientupdate.load_meta()
    meta['attempt'] = 0
    with open(os.path.join(kodi.profile_dir(), 'clients_meta.json'), 'w') as f:
        json.dump(meta, f)
    try:
        ok = clientupdate.refresh(yt(), force=True, reason='manual')
    finally:
        progress.close()
    meta = clientupdate.load_meta()
    working = ', '.join(meta.get('working') or []) or 'none'
    xbmcgui.Dialog().ok(kodi.ADDON_NAME, 'Source: %s[CR]Working clients: %s[CR]%s' % (
        meta.get('source', '?'), working,
        'Playback will use these, best first.' if ok else 'Kept the previous list. Check your connection.'))


def root():
    """Main screen: YouTube's sections, the way its own apps list them."""
    signed = auth.signed_in()
    auth.sync_settings()
    folder('Home', 'home', 'home.png', 'Recommended for you, row by row.' if signed else
           'What\'s popular right now, row by row.')
    if signed:
        feed_folder('FEsubscriptions', 'New videos from channels you subscribe to.')
        folder('Channels', 'account/channels', 'channels.png', 'The channels you subscribe to.')
    else:
        folder('Subscriptions', 'channels', 'subscriptions.png',
               'Channels you\'ve saved on this device. Sign in to see your YouTube subscriptions.')
    folder('Shorts', 'shorts', 'shorts.png', 'Short vertical videos.')
    folder('Music', 'music', 'music.png', 'YouTube Music: charts, new releases, moods and genres, mixes and '
                                          'music search.')
    for fid in ('FEtopics_live', 'FEtopics_gaming', 'FEtopics_news', 'FEtopics_sports'):
        feed_folder(fid)
    folder('Free Movies', 'movies/free', 'movies.png', 'Full movies YouTube offers free, checked to play on Kodi.')
    folder('Trailers', 'trailers', 'trailers.png', 'Find a trailer for any show or movie, plus the newest ones.')
    folder('You', 'you', 'you.png', 'History, playlists, Watch later and liked videos.')
    folder('Search', 'search', 'search.png', 'Search YouTube.')
    if not signed:
        action_item('[B]Sign in[/B]', 'account/signin', 'signin.png',
                    'Scan a QR code or enter a code at youtube.com/activate. No API key needed.')
    folder('Settings', 'tools', 'settings.png', 'Set views and add-on settings.')
    finish('files')


def you_menu():
    signed = auth.signed_in()
    if signed:
        name = auth.display_name()
        for fid in ('FEhistory', 'FEplaylist_aggregation', 'VLWL', 'VLLL'):
            feed_folder(fid)
        folder('Watched on this device', 'history', 'history.png', 'Everything played through TubeLite here.')
        folder('Saved channels', 'channels', 'subscriptions.png', 'Channels saved on this device.')
        if len(auth.identities()) > 1:
            action_item('Browse as…', 'account/identity', 'signin.png',
                        'Switch between your main account and your channels. Age-restricted videos always '
                        'play through your main account.')
        action_item('[COLOR grey]Signed in as %s · Sign out[/COLOR]' % name, 'account/signout', 'signin.png')
    else:
        folder('History', 'history', 'history.png', 'Videos played on this device.')
        folder('Saved channels', 'channels', 'subscriptions.png', 'Channels saved on this device.')
        action_item('[B]Sign in[/B]', 'account/signin', 'signin.png',
                    'Sign in to see your YouTube history, playlists, Watch later and liked videos.')
    if os.path.exists(kodi.error_path()):
        action_item('Show last error', 'error/show', 'news.png', 'Full details of the last thing that went wrong.')
    finish('files')


def tools_menu():
    folder('Set views', 'views', 'settings.png', 'Choose how each kind of list looks in this skin.')
    action_item('Add-on settings', 'settings', 'settings.png', 'Playback, account, SponsorBlock and more.')
    finish('files')


# ---------------------------------------------------------------- Home, row by row (like YouTube's TV app)

HOME_REUSE_MINUTES = 10
HOME_MAX_BATCHES = 6
# Rows that go first on Home, in this order (matched in the row's title); the rest keep YouTube's order.
HOME_FIRST = ('recommended', 'recently uploaded', 'breaking news')


def _home_path():
    folder_ = os.path.join(kodi.profile_dir(), 'home')
    if not os.path.isdir(folder_):
        os.makedirs(folder_)
    return os.path.join(folder_, 'home.json')


def _home_rank(row):
    title = (row.get('title') or '').lower()
    return next((n for n, word in enumerate(HOME_FIRST) if word in title), len(HOME_FIRST))


def _home_page(fresh=False):
    """All of Home's rows on one page. YouTube sends them a few at a time, so the batches are fetched and
    joined, then kept briefly so backing out of a row shows the same rows again."""
    path = _home_path()
    try:
        if not fresh and time.time() - os.path.getmtime(path) < HOME_REUSE_MINUTES * 60:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    data = yt().account_browse('default', require_auth=False)
    rows, more = shelves(data, shorts())
    page = {'rows': rows}
    if not rows:
        page['flat'] = parse(data, shorts())
        kodi.log('Home came back without rows: %s' % renderer_census(data))
    for _ in range(HOME_MAX_BATCHES):
        if not more or not rows:
            break
        try:
            extra, more = shelves(yt().account_browse(continuation=more, require_auth=False), shorts())
        except Exception as e:
            kodi.log('more Home rows failed: %s' % e)
            break
        rows += extra
    rows.sort(key=_home_rank)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(page, f)
    return page


def home():
    try:
        page = _home_page()
    except Exception as e:
        return fail(e)
    if page.get('flat'):
        items, token = page['flat']
        if not items and not auth.signed_in():
            return home_signed_out()
        render(items, 'account/feed', {'id': 'default', 'cont': token})
        return finish()
    refresh = [('Refresh Home', 'RunPlugin(%s)' % kodi.url('home/refresh'))]
    for i, row in enumerate(page['rows']):
        fill_missing_titles(row['items'][:1])
        first = row['items'][0]
        plot = '\n'.join(it.get('title') or '' for it in row['items'][:8])
        folder(row['title'] or 'More for you', 'home/row', first.get('thumb', ''), plot, context=refresh,
               i=i, title=row['title'])
    if not page['rows']:
        kodi.notify('Nothing on Home yet')
    finish('files', view='rows')


def home_signed_out():
    """Signed out, YouTube's Home holds only a "sign in to get started" prompt, so point to what works."""
    action_item('[B]Sign in[/B] for your recommendations', 'account/signin', 'signin.png',
                'YouTube shows nothing on Home until you sign in.')
    folder('Music', 'music', 'music.png', 'YouTube Music: charts, new releases, moods and genres.')
    for fid in ('FEtopics_live', 'FEtopics_gaming', 'FEtopics_news', 'FEtopics_sports'):
        feed_folder(fid)
    folder('Trailers', 'trailers', 'trailers.png', 'The newest TV and movie trailers.')
    finish('files')


def home_row():
    """One Home row: the items YouTube sent with Home, then more of that row, filled to the page size."""
    rows = []

    def fetch(token):
        if token:
            return parse(yt().account_browse(continuation=token, require_auth=False), shorts())
        if not rows:
            rows.extend(_home_page().get('rows') or [])
        i = int(ARGS.get('i', 0))
        if i >= len(rows):
            return [], None
        return rows[i]['items'], rows[i]['cont']
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    if not items and not ARGS.get('cont'):
        kodi.notify('Home has changed. Go back and open the row again.')
    render(items, 'home/row', next_args(nxt))
    finish()


def home_refresh():
    try:
        os.remove(_home_path())
    except OSError:
        pass
    xbmc.executebuiltin('Container.Refresh')


# ---------------------------------------------------------------- music (YouTube Music)

MUSIC_CACHE_HOURS = 0.5
MUSIC_MORE_BATCHES = 4


def music_menu():
    signed = auth.signed_in()
    folder('Music home', 'music/browse', 'music.png', 'Quick picks, mixes, listen again and more from YouTube Music.',
           id='FEmusic_home')
    folder('Charts', 'music/browse', 'music.png', 'Top songs, top music videos, trending and top artists.',
           id='FEmusic_charts')
    folder('New releases', 'music/browse', 'music.png', 'New albums, singles and music videos.',
           id='FEmusic_new_releases')
    folder('Moods & genres', 'music/browse', 'music.png', 'Playlists for every mood and genre.',
           id='FEmusic_moods_and_genres')
    folder('Music on YouTube', 'account/feed', 'music.png', 'YouTube\'s own Music section, with its mixes.',
           id='FEtopics_music')
    if signed:
        feed_folder('VLLM', 'Songs you liked.')
    folder('Search music', 'music/search', 'search.png', 'Songs, videos, albums, artists and playlists.', new='1')
    finish('files')


def _music_request(kind, ident, params, continuation=None):
    if kind == 'search':
        payload = {} if continuation else dict({'query': ident}, **({'params': params} if params else {}))
        endpoint = 'search'
    else:
        payload = {} if continuation else {'browseId': ident}
        if params and not continuation:
            payload['params'] = params
        if ident == 'FEmusic_charts' and not continuation:
            payload['formData'] = {'selectedValues': [yt().gl]}
        endpoint = 'browse'
    data = yt().music_call(endpoint, payload, continuation)
    return endpoint, data


def _music_more(endpoint, token, read):
    """A continuation from YouTube Music, asked the current way and then its older way if that came back empty."""
    for query_style in (False, True):
        got = read(yt().music_call(endpoint, {}, token, query_style=query_style))
        if got[0]:
            return got
    return got


def _music_build(kind, ident, params):
    """A YouTube Music page with all its shelves (YouTube sends a few at a time)."""
    endpoint, data = _music_request(kind, ident, params)
    page = music.page(data)
    token = page['cont']
    for _ in range(MUSIC_MORE_BATCHES):
        if not token:
            break
        try:
            more = _music_more(endpoint, token, lambda d: (lambda p: (p['shelves'], p['cont']))(music.page(d)))
        except Exception as e:
            kodi.log('more music shelves failed: %s' % e)
            break
        page['shelves'] += more[0]
        token = more[1]
    if not page['shelves']:
        kodi.record_error('YouTube Music %s %s' % (kind, ident), YTError(
            'Nothing TubeLite recognises in YouTube Music\'s reply', 'Reply contained: %s' % renderer_census(data)))
    return page


def music_page():
    """A YouTube Music page. Several shelves show as folders (a shelf's "See all" opens its full list);
    a single shelf, or the shelf picked from a page, shows as one list filled to the page size."""
    kind = 'search' if PATH == 'music/search' else 'browse'
    params = ARGS.get('params', '')
    ident = ARGS.get('q') if kind == 'search' else ARGS.get('id')
    if kind == 'search' and ARGS.get('new'):
        ident = typed_query('Search YouTube Music', 'tubelite.music_search')
        if not ident:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if not ident:
        return music_menu()
    base = {'q': ident} if kind == 'search' else {'id': ident}
    if params:
        base['params'] = params
    try:
        page = list_cache('music|%s|%s|%s|%s' % (kodi.ADDON.getAddonInfo('version'), kind, ident, params),
                          lambda: _music_build(kind, ident, params), MUSIC_CACHE_HOURS,
                          keep=lambda p: bool(p.get('shelves')))
    except YTError as e:
        if 'HTTP 401' in str(e):
            if kind == 'browse':
                storage.add_unique('music_signin_only', ident)
            kodi.notify('This part of YouTube Music needs a YouTube Music sign-in, which TubeLite can\'t use')
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return fail(e)
    except Exception as e:
        return fail(e)
    shelves = page['shelves']
    if not shelves:
        kodi.notify('YouTube Music sent nothing here  (details: You → Show last error)')
        return finish()
    if ARGS.get('i') is not None or len(shelves) == 1:
        i = int(ARGS.get('i') or 0)
        if i >= len(shelves):
            return finish()
        return music_list(kind, shelves[i], dict(base, i=i) if len(shelves) > 1 else base)
    main = next((n for n, shelf in enumerate(shelves) if shelf.get('main')), None)
    if main is not None:
        others = [(n, shelf) for n, shelf in enumerate(shelves) if n != main]
        return music_list(kind, shelves[main], dict(base, i=main), others)
    for i, shelf in enumerate(shelves):
        _shelf_folder(i, shelf, base)
    finish('files', view='rows')


def _shelf_folder(i, shelf, base):
    """A folder for one shelf of a YouTube Music page: its "See all" page when it has one."""
    first = shelf['items'][0]
    plot = '\n'.join(it.get('title') or '' for it in shelf['items'][:8])
    more = shelf.get('more')
    if more and more[0] == 'browse' and more[1] in storage.load('music_signin_only'):
        more = None
    label = shelf['title'] or 'More'
    thumb = first.get('thumb') or 'music.png'
    if more and more[0] == 'browse':
        folder(label, 'music/browse', thumb, plot, id=more[1], params=more[2])
    elif more:
        folder(label, 'music/search', thumb, plot, q=more[1], params=more[2])
    else:
        folder(label, PATH, thumb, plot, i=i, **base)


def music_list(kind, shelf, base, others=None):
    """One shelf as a list filled to the page size. others: the page's remaining shelves, shown as folders
    after the list on its first page."""
    endpoint = 'search' if kind == 'search' else 'browse'

    def fetch(token):
        if not token:
            return shelf['items'], shelf.get('cont')
        return _music_more(endpoint, token, music.continuation)
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    render(items)
    if others and not ARGS.get('cont') and not ARGS.get('skip'):
        for i, shelf in others:
            _shelf_folder(i, shelf, dict((k, v) for k, v in base.items() if k != 'i'))
    nxt = next_args(nxt, **base)
    if nxt:
        next_item('Next page', PATH, **nxt)
    finish()


# ---------------------------------------------------------------- subscribed channels

def subscribed_channels():
    """Your subscribed channels, as YouTube's TV app lists them beside the Subscriptions feed."""
    token, chans = None, []
    try:
        if ARGS.get('cont'):
            items, token = parse(yt().account_browse(continuation=ARGS['cont']))
            chans = [i for i in items if i['type'] == 'channel']
        else:
            try:
                items, token = parse(yt().account_browse('FEchannels'))
                chans = [i for i in items if i['type'] == 'channel']
            except YTError as e:
                kodi.log('channel list page refused: %s' % e)
            if not chans:
                data = yt().account_browse('FEsubscriptions')
                chans, token = nav_channels(data), None
                if not chans:
                    kodi.record_error('subscribed channels', YTError(
                        'No channel list in YouTube\'s reply', 'Reply contained: %s' % renderer_census(data)))
    except Exception as e:
        return fail(e)
    if not chans and not ARGS.get('cont'):
        kodi.notify('Couldn\'t find your channel list  (details: You → Show last error)')
    render(chans, 'account/channels', {'cont': token})
    finish(view='channels')


# ---------------------------------------------------------------- free movies (Widevine)

FREE_GENRES = (
    ('All free movies', 'free movies'), ('Action', 'free action movies'), ('Comedy', 'free comedy movies'),
    ('Drama', 'free drama movies'), ('Horror', 'free horror movies'), ('Thriller', 'free thriller movies'),
    ('Family', 'free family movies'), ('Sci-Fi', 'free sci-fi movies'), ('Romance', 'free romance movies'),
    ('Westerns', 'free western movies'), ('Documentaries', 'free documentary films'),
)


def free_movies_menu():
    for label, q in FREE_GENRES:
        folder(label, 'movies/free/list', 'movies.png', q=q)
    folder('Search free movies', 'movies/free/list', 'search.png', new='1')
    finish('files', cache=True)


LIST_CACHE_HOURS = 12


def list_cache(key, build, hours=LIST_CACHE_HOURS, keep=None):
    """A finished listing, kept so Kodi's refresh after playback (to mark what you watched) returns
    straight away instead of searching and checking again."""
    import hashlib
    folder_ = os.path.join(kodi.profile_dir(), 'lists')
    path = os.path.join(folder_, hashlib.md5(key.encode('utf-8')).hexdigest() + '.json')
    try:
        if time.time() - os.path.getmtime(path) < hours * 3600:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    data = build()
    if keep and not keep(data):
        return data
    try:
        if not os.path.isdir(folder_):
            os.makedirs(folder_)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        old = sorted((os.path.join(folder_, n) for n in os.listdir(folder_)), key=os.path.getmtime)
        for stale in old[:-40]:
            os.remove(stale)
    except OSError:
        pass
    return data


def typed_query(prompt, prop):
    """The words for a new search. When Kodi refreshes this same listing (after playback), the words typed
    last time are reused instead of opening the keyboard again."""
    win = xbmcgui.Window(10000)
    here = sys.argv[0] + (sys.argv[2] if len(sys.argv) > 2 else '')
    if xbmc.getInfoLabel('Container.FolderPath') == here and win.getProperty(prop):
        return win.getProperty(prop)
    q = kodi.keyboard(prompt)
    if q:
        win.setProperty(prop, q)
    return q


def free_page_size():
    return min(max(kodi.setting_int('free_page_size', 20), 5), 100)


def free_movies_list():
    """YouTube's free-with-ads movies, keeping only titles that will play here. Fetches more of YouTube's
    pages until a page is full (Settings → Browsing → Free movies per page)."""
    from resources.lib import drm
    q = ARGS.get('q')
    if ARGS.get('new'):
        q = typed_query('Search free movies', 'tubelite.free_search')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    target = free_page_size()

    def build():
        progress = xbmcgui.DialogProgressBG()
        progress.create(kodi.ADDON_NAME, 'Finding movies that play on Kodi…')
        playable, seen, token, pages, free = [], set(), ARGS.get('cont'), 0, 0
        max_pages = max(4, target // 3)
        try:
            while True:
                data = yt().search(None, continuation=token) if token else yt().search(q, drm.MOVIES_FILTER)
                items, token = parse(data, False)
                movies = [i for i in items if i['type'] == 'video' and i.get('free') and i['id'] not in seen]
                seen.update(m['id'] for m in movies)
                free += len(movies)
                fill_missing_titles(movies)
                playable += drm.filter_playable(yt(), movies)
                pages += 1
                progress.update(min(99, 100 * len(playable) // target),
                                message='%d of %d found' % (min(len(playable), target), target))
                if len(playable) >= target or not token or pages >= max_pages:
                    break
        finally:
            progress.close()
        kodi.log('free movies "%s": %d pages, %d free, %d play here' % (q, pages, free, len(playable)))
        return {'items': playable, 'token': token}

    try:
        page = list_cache('free|%s|%s|%d' % (q, ARGS.get('cont', ''), target), build)
    except Exception as e:
        return fail(e)
    for m in page['items']:
        m['description'] = ('%s\n%s' % (' · '.join(m.get('badges') or []), m.get('description', ''))).strip()
        video_item(m)
    if page['token']:
        next_item('More movies', 'movies/free/list', q=q, cont=page['token'])
    if not page['items'] and not page['token']:
        kodi.notify('No free movies here play on Kodi right now')
    finish('movies', cache=True)


# ---------------------------------------------------------------- shows from search results

def show_folder(show, plot=None):
    seasons = [(x['title'], x['playlist']) for x in show.get('season_list') or []]
    folder(show['title'] or 'TV show', 'show', show.get('thumb', ''),
           plot if plot is not None else show.get('seasons', ''),
           id=show.get('playlist') or '', browse=show.get('browse_id') or '', title=show.get('title'),
           seasons=json.dumps(seasons) if len(seasons) > 1 else '')


def show_page():
    """A show's seasons (from its show card) or a season's episodes."""
    title = ARGS.get('title', '')
    if ARGS.get('seasons') and not ARGS.get('cont'):
        for name, pid in json.loads(ARGS['seasons']):
            folder(name or 'Season', 'show', 'tv.png', id=pid, title=title)
        xbmcplugin.setContent(HANDLE, 'seasons')
        return xbmcplugin.endOfDirectory(HANDLE)
    try:
        if ARGS.get('cont'):
            data = yt().browse(continuation=ARGS['cont'])
        elif ARGS.get('id'):
            data = yt().browse('VL' + ARGS['id'])
        else:
            data = yt().browse(ARGS['browse'])
        items, token = parse(data, True)
    except Exception as e:
        return fail(e)
    if not items and not ARGS.get('cont'):
        kodi.record_error('show "%s"' % title, YTError(
            'No episodes in YouTube\'s reply', 'Reply contained: %s' % renderer_census(data)))
    episodes = [i for i in items if i['type'] == 'video']
    for it in items:
        if it['type'] in ('playlist', 'show') and it.get('id') != ARGS.get('id'):
            folder(it['title'] or 'Season', 'show', it.get('thumb', ''), '',
                   id=it.get('playlist', it['id']) if it['type'] == 'show' else it['id'],
                   browse=it.get('browse_id', ''), title=it['title'])
    fill_missing_titles(episodes)
    for ep in episodes:
        label = ('%s · %s' % (ep['index'], ep['title'])) if ep.get('index') else ep['title']
        video_item(dict(ep, channel=ep.get('channel') or title), label=label)
    if token:
        next_item('More episodes', 'show', cont=token, title=title)
    finish('episodes')


def movie_report():
    from resources.lib import drm
    try:
        with open(drm.report_path(), encoding='utf-8') as f:
            text = f.read()
    except Exception:
        text = 'No movie has been played yet.'
    xbmcgui.Dialog().textviewer('Movie playback report', text)


def signed_in_test():
    """Checks signed-in playback step by step and shows what happened. Runs from a video's context menu
    (Check playback) or Settings → Advanced, where a link is optional."""
    from resources.lib import jsc
    lines = ['Signed-in playback check  %s' % time.strftime('%Y-%m-%d %H:%M'), '']
    if not auth.signed_in():
        lines.append('Not signed in. Sign in under You → Sign in first; age-restricted videos need your account.')
    vid = ARGS.get('id')
    if not vid:
        link = kodi.keyboard('Video link or ID to test (optional)') or ''
        m = re.search(r'(?:v=|youtu\.be/|shorts/|embed/|^)([\w-]{11})(?:[?&#]|$)', link.strip())
        vid = m.group(1) if m else None
    progress = xbmcgui.DialogProgressBG()
    progress.create(kodi.ADDON_NAME, 'Checking YouTube\'s player script…')
    try:
        started = time.time()
        try:
            ch = jsc.get(yt().session)
            lines.append('Player script %s: ready in %.1fs (signature timestamp %s, %s)' % (
                ch.pid, time.time() - started, ch.sts, 'downloaded and read now' if ch.built else 'saved copy'))
            t = time.time()
            lines.append('Test unscramble: n=%s, signature OK (%.0f ms)' % (
                ch.n('TubeLiteCheck-0042'), (time.time() - t) * 1000))
            ch.sig('A' * 30 + 'B' * 30 + 'C' * 44)
        except Exception as e:
            lines.append('Player script FAILED: %s' % e)
        try:
            cfg = yt().tv_page_config(max_age=0)
            lines.append('TV page: player %s, sts %s, app version %s, visitor id %s' % (
                cfg.get('player', 'not found'), cfg.get('sts', 'not found'), cfg.get('version', 'not found'),
                'found' if cfg.get('visitor') else 'not found'))
        except Exception as e:
            lines.append('TV page: %s' % e)
        if vid:
            progress.update(50, message='Testing video %s' % vid)
            lines += ['', 'Video %s' % vid]
            modes = (streams.isa_available() and streams.server_alive(), streams.isa_available(), False)
            streams.resolve_embedded(yt(), vid, modes, [])
            for a in streams.LAST_EMBED_ATTEMPT:
                lines.append('  %s' % a)
            if auth.signed_in():
                reasons = []
                info = streams.resolve_signed_in(yt(), vid, modes, reasons)
                for a in streams.LAST_TV_ATTEMPTS:
                    lines.append('  TV app %s' % a)
                if not info and reasons:
                    lines.append('  -> %s' % reasons[0])
                urls, notes = yt().tracking_urls(vid)
                lines.append('  YouTube history links: %s (%s)' % ('found' if urls else 'NOT found', '; '.join(notes)))
            try:
                info = streams.resolve(yt(), vid)
                lines.append('  TubeLite would play it via %s (%s)' % (info['client'], info['kind']))
            except Exception as e:
                lines.append('  TubeLite playback: %s' % e)
    finally:
        progress.close()
    text = '\n'.join(lines)
    kodi.log(text)
    xbmcgui.Dialog().textviewer('Signed-in playback check', text)


def shorts_feed():
    """Shorts, filled to Settings → Browsing → Items per page. YouTube's Shorts player hands out video ids
    a batch at a time; titles and channels come from YouTube's oEmbed lookup."""
    from concurrent.futures import ThreadPoolExecutor

    def info(vid):
        try:
            return vid, yt().oembed(vid)
        except Exception:
            return vid, {}

    def fetch(token):
        ids, nxt = yt().shorts(token)
        with ThreadPoolExecutor(max_workers=8) as pool:
            details = dict(pool.map(info, ids))
        items = []
        for vid in ids:
            d = details.get(vid) or {}
            handle = (d.get('author_url') or '').rstrip('/').split('/')[-1]
            items.append({'type': 'video', 'id': vid, 'title': clean(d.get('title') or '') or 'Short',
                          'channel': d.get('author_name', ''), 'channel_id': handle if handle.startswith('@') else '',
                          'duration': 0, 'live': False, 'views': '', 'published': '', 'description': '',
                          'short': True, 'thumb': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % vid})
        return items, nxt
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    if not items:
        kodi.notify('No Shorts right now')
    render(items, 'shorts', next_args(nxt))
    finish()


def open_settings():
    kodi.ADDON.openSettings()


def trailers_menu():
    folder('Find a Show\'s Trailer', 'trailers/search', 'search.png', 'Type a show or movie name.', kind='tv')
    folder('New TV Trailers This Week', 'trailers/new', 'trailers.png', what='tv', period='week')
    folder('New Movie Trailers This Week', 'trailers/new', 'trailers.png', what='movie', period='week')
    folder('New TV Trailers This Month', 'trailers/new', 'trailers.png', what='tv', period='month')
    folder('New Movie Trailers This Month', 'trailers/new', 'trailers.png', what='movie', period='month')
    folder('Studio & Network Channels', 'trailers/studios', 'channels.png')
    finish('files', cache=True)


def trailers_search():
    q = ARGS.get('q')
    typed = not q
    if typed:
        q = kodi.keyboard('Show or movie name')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    try:
        items = trailers.find(yt(), q, ARGS.get('year', ''), ARGS.get('kind', 'tv'), ARGS.get('season', ''))
    except Exception as e:
        return fail(e)
    render(items)
    finish(cache=typed)


NEW_QUERIES = {
    'tv': 'official series trailer',
    'movie': 'official movie trailer',
}


def trailers_new():
    sp = trailers.NEW_THIS_MONTH if ARGS.get('period') == 'month' else trailers.NEW_THIS_WEEK
    def fetch(token):
        data = yt().search(None, continuation=token) if token else \
            yt().search(NEW_QUERIES.get(ARGS.get('what'), 'official trailer'), sp)
        items, token = parse(data, shorts())
        return [i for i in items if i['type'] == 'video' and 'trailer' in i.get('title', '').lower()
                and trailers.score(i, '') > 0], token
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    render(items, 'trailers/new', next_args(nxt))
    finish()


def trailers_studios():
    with open(os.path.join(kodi.ADDON_PATH, 'resources', 'data', 'trailer_channels.json')) as f:
        studios = json.load(f)
    for s in studios:
        folder(s['title'], 'channel', 'channels.png',
               context=[('Add to My Channels', 'RunPlugin(%s)' % kodi.url('channel/add', id=s['id'], title=s['title']))],
               id=s['id'], title=s['title'])
    finish('files', cache=True, view='channels')


def search_menu():
    folder('[B]New search[/B]', 'search/results', 'search.png', new='1')
    folder('[B]Search channels[/B]', 'search/results', 'channels.png', new='1', kind='channels')
    folder('[B]Search playlists[/B]', 'search/results', 'search.png', new='1', kind='playlists')
    for s in storage.load('searches'):
        kind = s.get('kind', 'all')
        label = s['q'] + ('  [COLOR grey](%s)[/COLOR]' % kind if kind != 'all' else '')
        folder(label, 'search/results', 'search.png',
               context=[('Remove from search history', 'RunPlugin(%s)' % kodi.url('search/remove', q=s['q'])),
                        ('Clear search history', 'RunPlugin(%s)' % kodi.url('clear', what='searches'))],
               q=s['q'], kind=kind)
    finish('files')


SEARCH_PARAMS = {'all': None, 'videos': 'EgIQAQ==', 'channels': 'EgIQAg==', 'playlists': 'EgIQAw=='}


LINK_VIDEO = re.compile(r'(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/|live/|v/)|youtu\.be/)([\w-]{11})')
LINK_PLAYLIST = re.compile(r'[?&]list=([\w-]{10,})')
LINK_CHANNEL = re.compile(r'youtube\.com/(@[\w.-]+|channel/UC[\w-]{22}|c/[\w.-]+|user/[\w.-]+)')
BARE_ID = re.compile(r'^[\w-]{11}$')


def link_target(q):
    """What a pasted YouTube link or video id points at: ('video', id, is_link), ('playlist', id, True),
    ('channel', handle or id, True), or None for ordinary search words."""
    q = (q or '').strip()
    m = LINK_VIDEO.search(q)
    if m:
        return 'video', m.group(1), True
    m = LINK_PLAYLIST.search(q)
    if m and 'youtu' in q:
        return 'playlist', m.group(1), True
    m = LINK_CHANNEL.search(q)
    if m:
        part = m.group(1)
        return 'channel', part.split('/', 1)[1] if part.startswith('channel/') else part, True
    # A bare id: 11 characters with a digit, - or _, or capitals after the first letter ("programming" isn't one).
    if BARE_ID.match(q) and (re.search(r'[\d_-]', q) or re.search(r'[A-Z]', q[1:])):
        return 'video', q, False
    return None


def link_items(target):
    """The item a pasted link opens, ready for render()."""
    kind, ident, _ = target
    if kind == 'playlist':
        title = ''
        try:
            title = yt().playlist_title(ident)
        except Exception:
            pass
        return [{'type': 'playlist', 'id': ident, 'title': clean(title) or 'Playlist', 'channel': '',
                 'channel_id': '', 'count': '', 'thumb': 'playlists.png',
                 'video': ident[2:] if is_mix(ident) and len(ident) == 13 else None}]
    if kind == 'channel':
        title, thumb = ident, ''
        try:
            if ident.startswith(('c/', 'user/')):
                # Old-style channel addresses: ask YouTube which channel they belong to.
                ident = yt().resolve_url('https://www.youtube.com/' + ident).get('browseId') or ident
            title, thumb = channel_title(yt().channel_tab(ident, 'videos'))
        except Exception:
            pass
        return [{'type': 'channel', 'id': ident, 'title': title or ident, 'subs': '', 'description': '',
                 'thumb': thumb}]
    d = {}
    try:
        d = yt().oembed(ident)
    except Exception:
        pass
    if not d:
        # Videos that can't be embedded elsewhere aren't in the quick lookup; read the watch page's details.
        try:
            det = video_details(yt().next(ident))
            d = {'title': det.get('title'), 'author_name': det.get('channel')} if det.get('title') else {}
        except Exception:
            pass
    if not d:
        return []
    item = {'type': 'video', 'id': ident, 'title': clean(d.get('title') or ''), 'channel': d.get('author_name', ''),
            'channel_id': '', 'duration': 0, 'live': False, 'views': '', 'published': '', 'description': ''}
    return [parser.video_art(item)]


def search_results():
    kind = ARGS.get('kind', 'all')
    q = ARGS.get('q')
    new_search = bool(ARGS.get('new'))
    if new_search:
        q = typed_query('Search YouTube', 'tubelite.search')
        if not q:
            return xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        storage.add_search(q, kind)
    target = link_target(q) if not ARGS.get('cont') and not ARGS.get('skip') else None
    if target:
        # A pasted link or video id: open what it points at. A link shows just that; a bare id that could
        # also be ordinary words shows the video first, then the search results for those words.
        found = link_items(target)
        if found and target[2]:
            render(found)
            return finish(cache=new_search)
        render(found)

    def fetch(token):
        data = yt().search(None, continuation=token) if token else yt().search(q, SEARCH_PARAMS.get(kind))
        return parse(data, shorts())
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    render(items, 'search/results', next_args(nxt, q=q, kind=kind))
    # Cached so coming back to these results doesn't open the keyboard again.
    finish(cache=new_search, view={'channels': 'channels', 'playlists': 'playlists'}.get(kind))


def channels_menu():
    chans = storage.channels()
    if not chans:
        folder('[I]No saved channels yet. Use "Add channel to My Channels" on any video.[/I]', 'trailers/studios', 'channels.png')
    for c in chans:
        folder(c['title'], 'channel', c.get('thumb', ''),
               context=[('Remove from My Channels', 'RunPlugin(%s)' % kodi.url('channel/remove', id=c['id']))],
               id=c['id'], title=c['title'])
    finish('files', view='channels')


def channel():
    cid, title = ARGS['id'], ARGS.get('title', '')
    folder('Videos', 'channel/tab', 'trailers.png', id=cid, tab='videos', title=title)
    folder('Live', 'channel/tab', 'trailers.png', id=cid, tab='streams', title=title)
    folder('Playlists', 'channel/tab', 'channels.png', id=cid, tab='playlists', title=title)
    if not kodi.setting_bool('hide_shorts'):
        folder('Shorts', 'channel/tab', 'trailers.png', id=cid, tab='shorts', title=title)
    folder('Add to My Channels', 'channel/add', 'channels.png', id=cid, title=title)
    finish('files', cache=True)


def channel_tab():
    tab = ARGS.get('tab', 'videos')
    try:
        items, nxt = paged(lambda token: parse(yt().channel_tab(ARGS['id'], tab, token), tab == 'shorts' or shorts()))
    except Exception as e:
        return fail(e)
    render(items, 'channel/tab', next_args(nxt))
    finish(view='playlists' if tab == 'playlists' else None)


def channel_add():
    cid, title, thumb = ARGS['id'], ARGS.get('title', ''), ARGS.get('thumb', '')
    if cid.startswith('@') or not title or not thumb:
        try:
            data = yt().channel_tab(cid, 'videos')
            name, avatar = channel_title(data)
            title, thumb = title or name, thumb or avatar
            browse_id = ((data.get('metadata') or {}).get('channelMetadataRenderer') or {}).get('externalId')
            if browse_id:
                cid = browse_id
        except Exception as e:
            kodi.log('channel lookup failed: %s' % e)
    storage.add_channel(cid, title or cid, thumb)
    kodi.notify('Added %s to My Channels' % (title or cid))
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def channel_remove():
    storage.remove('channels', 'id', ARGS['id'])
    xbmc.executebuiltin('Container.Refresh')


def mix_batch(pid, video):
    """One stretch of a Mix, as YouTube's player queues it after video."""
    data = yt().call('next', {'videoId': video, 'playlistId': pid, 'contentCheckOk': True, 'racyCheckOk': True}) \
        if video else yt().call('next', {'playlistId': pid})
    panel = ((((data.get('contents') or {}).get('twoColumnWatchNextResults') or {}).get('playlist') or {})
             .get('playlist')) or find_key(data, 'playlistPanelRenderer') or {}
    return parse(panel.get('contents') or [], True)[0]


def mix():
    """A Mix: built from the video it starts with, then extended page by page from the last video shown."""
    pid = ARGS['id']
    seed = ARGS.get('video') or (pid[2:] if len(pid) == 13 else None)

    def fetch(after):
        items = mix_batch(pid, after or seed)
        if after:
            ids = [it['id'] for it in items]
            items = items[ids.index(after) + 1:] if after in ids else items
        return items, (items[-1]['id'] if items else None)
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    if not items and not ARGS.get('cont'):
        kodi.notify('YouTube didn\'t send this mix')
    render(items, 'playlist', next_args(nxt))
    finish()


def music_instead(browse_id):
    global PATH, ARGS
    PATH, ARGS = 'music/browse', {'id': browse_id}
    return music_page()


def playlist():
    if is_mix(ARGS.get('id', '')):
        return mix()

    def fetch(token):
        if token:
            return parse(yt().browse(continuation=token), True)
        pid = ARGS['id']
        return parse(yt().browse(pid if pid.startswith('VL') else 'VL' + pid), True)
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    pid = ARGS['id'][2:] if ARGS['id'].startswith('VL') else ARGS['id']
    if not items and not ARGS.get('cont') and pid.startswith(('RDCLAK', 'OLAK')):
        # A YouTube Music playlist or album YouTube's website didn't list: ask YouTube Music for it.
        return music_instead('VL' + pid)
    render(items, 'playlist', next_args(nxt))
    finish()


def related():
    def fetch(token):
        data = yt().next(continuation=token) if token else yt().next(ARGS['id'])
        return parse(related_section(data), shorts())
    try:
        items, nxt = paged(fetch)
    except Exception as e:
        return fail(e)
    render(items, 'related', next_args(nxt))
    finish()


def history():
    items = storage.load('history')
    for v in items:
        v = dict(v, type='video')
        video_item(v, [('Remove from history', 'RunPlugin(%s)' % kodi.url('history/remove', id=v['id'])),
                       ('Clear watch history', 'RunPlugin(%s)' % kodi.url('clear', what='history'))])
    finish()


def clear():
    what = ARGS.get('what')
    names = {'history': 'watch history', 'searches': 'search history', 'channels': 'My Channels'}
    if what in names and xbmcgui.Dialog().yesno(kodi.ADDON_NAME, 'Clear %s?' % names[what]):
        storage.clear(what)
        kodi.notify('Cleared %s' % names[what])
        xbmc.executebuiltin('Container.Refresh')


def reset_session():
    yt().reset_state()
    for name in ('clients.json', 'clients_meta.json'):
        try:
            os.remove(os.path.join(kodi.profile_dir(), name))
        except Exception:
            pass
    kodi.notify('Session reset')


# ---------------------------------------------------------------- playback

def _resolved(info):
    li = streams.listitem_for(info)
    li.setArt({'thumb': info['thumb'], 'icon': info['thumb'], 'fanart': video_fanart(info.get('video_id') or
                                                                                    info['thumb'].split('/')[-2])})
    tag = li.getVideoInfoTag()
    tag.setTitle(clean(info.get('title', '')))
    tag.setPlot(info.get('description', ''))
    tag.setMediaType('video')
    if info.get('channel'):
        tag.setStudios([info['channel']])
    if info.get('duration'):
        tag.setDuration(info['duration'])
    return li


def resolve_with_fallback(video_id):
    """Resolves a video; if it's an age-restricted trailer, plays the standard cut instead."""
    try:
        return streams.resolve(yt(), video_id), video_id
    except YTError as e:
        if 'your age' not in ('%s %s' % (e, e.detail)).lower() or not kodi.setting_bool('age_fallback'):
            raise
        original = e
    title = ''
    try:
        title = video_details(yt().next(video_id)).get('title', '')
    except Exception as e:
        kodi.log('title lookup for age fallback failed: %s' % e)
    if not trailers.is_trailer(title):
        raise original
    for alt in trailers.alternatives(yt(), title, video_id):
        try:
            info = streams.resolve(yt(), alt['id'])
        except YTError as e:
            kodi.log('age fallback candidate %s failed: %s' % (alt['id'], e))
            continue
        if not kodi.setting_bool('age_fallback_silent'):
            kodi.notify('Age-restricted. Playing the standard version instead.')
        kodi.log('age fallback: %s -> %s (%s)' % (video_id, alt['id'], alt['title']))
        return info, alt['id']
    raise original


def handoff(video_id):
    """Tells the background service which video is starting, for SponsorBlock and YouTube history."""
    win = xbmcgui.Window(10000)
    win.setProperty('tubelite.playing', video_id)
    win.setProperty('tubelite.playing_ts', str(int(time.time())))


def play_video(video_id):
    try:
        info, played_id = resolve_with_fallback(video_id)
        if info['kind'] == 'widevine':
            from resources.lib import drm
            if not drm.widevine_ready():
                raise YTError('This movie needs Widevine, which isn\'t installed in Kodi on this device. '
                              'Install it when InputStream Helper asks, then play the movie again.')
    except Exception as e:
        kodi.log('playback failed for %s: %s' % (video_id, e), xbmc.LOGERROR)
        kodi.record_error('playing %s' % video_id, e)
        kodi.notify('Can\'t play: %s' % e)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return False
    kodi.log('%s playing via %s (%s)' % (played_id, info['client'], info['kind']))
    storage.add_history(dict(info, id=played_id))
    handoff(played_id)
    li = _resolved(info)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)
    return True


def play():
    vid = ARGS.get('video_id') or ARGS.get('videoid') or ARGS.get('v')
    if not vid and ARGS.get('url'):
        q = dict(parse_qsl(urlparse(ARGS['url']).query))
        vid = q.get('v') or urlparse(ARGS['url']).path.rstrip('/').split('/')[-1]
    if not vid and ARGS.get('playlist_id'):
        xbmc.executebuiltin('Container.Update(%s)' % kodi.url('playlist', id=ARGS['playlist_id']))
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    if not vid:
        kodi.notify('No video id given')
        return
    play_video(vid)


def trailer():
    """External entry: plugin://plugin.video.youtube/trailer/?title=Severance&year=2022&type=tv&season=2"""
    title = ARGS.get('title') or ARGS.get('tvshowtitle')
    if not title:
        kodi.notify('No title given')
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    try:
        ranked = trailers.find(yt(), title, ARGS.get('year', ''), ARGS.get('type', 'tv'), ARGS.get('season', ''))
    except Exception as e:
        kodi.notify(str(e))
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return
    # Try the next-best match when one is restricted or blocked, rather than failing outright.
    for best in ranked[:4]:
        try:
            info = streams.resolve(yt(), best['id'])
        except YTError as e:
            kodi.log('trailer candidate %s skipped: %s' % (best['id'], e))
            continue
        kodi.log('trailer for "%s": %s (%s)' % (title, best['title'], best['id']))
        storage.add_history(dict(info, id=best['id']))
        handoff(best['id'])
        li = _resolved(info)
        if HANDLE >= 0:
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            xbmc.Player().play(li.getPath(), li)
        return
    kodi.notify('No playable trailer found for %s' % title)
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))


ROUTES = {
    '': root,
    'trailers': trailers_menu,
    'trailers/search': trailers_search,
    'trailers/new': trailers_new,
    'trailers/studios': trailers_studios,
    'trailer': trailer,
    'search': search_menu,
    'search/results': search_results,
    'search/remove': lambda: (storage.remove('searches', 'q', ARGS.get('q')), xbmc.executebuiltin('Container.Refresh')),
    'channels': channels_menu,
    'channel': channel,
    'channel/tab': channel_tab,
    'channel/add': channel_add,
    'channel/remove': channel_remove,
    'playlist': playlist,
    'related': related,
    'history': history,
    'history/remove': lambda: (storage.remove('history', 'id', ARGS.get('id')), xbmc.executebuiltin('Container.Refresh')),
    'clear': clear,
    'reset_session': reset_session,
    'play': play,
    'account/signin': lambda: (signin(), HANDLE >= 0 and xbmcplugin.endOfDirectory(HANDLE, succeeded=False)),
    'account/signout': lambda: (signout(), HANDLE >= 0 and xbmcplugin.endOfDirectory(HANDLE, succeeded=False)),
    'account/feed': account_feed,
    'account/identity': lambda: (choose_identity(), HANDLE >= 0 and xbmcplugin.endOfDirectory(HANDLE, succeeded=False)),
    'you': you_menu,
    'home': home,
    'home/row': home_row,
    'home/refresh': home_refresh,
    'account/channels': subscribed_channels,
    'tools': tools_menu,
    'music': music_menu,
    'music/browse': music_page,
    'music/search': music_page,
    'views': views.menu,
    'views/sample': views.sample,
    'views/save': views.save,
    'views/clear': views.clear,
    'shorts': shorts_feed,
    'settings': open_settings,
    'movies/free': free_movies_menu,
    'movies/free/list': free_movies_list,
    'movies/report': movie_report,
    'show': show_page,
    'signedin/test': signed_in_test,
    'error/show': show_error,
    'account/action': account_action,
    'library/fill': library_fill,
    'library/clear': library_clear,
    'clients/refresh': clients_refresh,
}


def run():
    global PATH, ARGS
    kodi.migrate_from_tubelite()
    if PATH == '' and ARGS.get('action') in ('play_video', 'play'):
        return play()
    if PATH not in ROUTES or PATH in ('', 'search') or PATH.startswith('kodion'):
        mapped = official_route(PATH, ARGS)
        if mapped:
            PATH, ARGS = mapped
    route = ROUTES.get(PATH)
    if not route:
        kodi.log('unknown route: %s' % PATH, xbmc.LOGWARNING)
        return root()
    try:
        route()
    except Exception as e:
        # Anything unexpected: keep Kodi from hanging on the folder and save the details for the user.
        fail(e)


if __name__ == '__main__':
    run()
