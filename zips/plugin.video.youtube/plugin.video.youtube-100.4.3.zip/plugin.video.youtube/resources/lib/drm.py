"""YouTube's free-with-ads movies, played through Widevine.

These movies are encrypted. Kodi plays them through InputStream Adaptive, which
asks a license server for the key, the same way the Netflix add-on works. Here
the license request goes to TubeLite's background service (/license/<id>), which
forwards it to YouTube's license endpoint as the same app that fetched the
streams. On-device testing showed YouTube licenses these to its VR headset app
(android_vr) and usually its visionOS app, but some studios keep titles to
YouTube's own apps; is_playable() checks a title before it's listed.
"""

import base64
import json
import os
import random
import threading
import time
from urllib.parse import parse_qs, urlparse
from xml.sax.saxutils import escape

from . import auth, kodi
from .innertube import API, BASE, TV_CLIENT, WEB_UA, YTError

WIDEVINE_UUID = 'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed'
LICENSE_ENDPOINT = API + 'player/get_drm_license'
MOVIES_FILTER = 'EgIQBA=='
SERVICE_CERT_REQUEST = b'\x08\x04'


def folder():
    path = os.path.join(kodi.profile_dir(), 'drm')
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def _session_path(vid):
    return os.path.join(folder(), '%s.json' % vid)


def report_path():
    return os.path.join(folder(), 'last_report.txt')


def cpn():
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
    return ''.join(random.choice(alphabet) for _ in range(16))


def _redact(text):
    return str(text).replace(auth.load().get('access_token') or '\x00', '<token>')[:400]


class Report(object):
    def __init__(self, vid, title=''):
        self.vid = vid
        self.lines = ['Movie playback report: %s %s (%s)' % (title, vid, time.strftime('%Y-%m-%d %H:%M')), '']

    def add(self, text):
        self.lines.append(text)
        kodi.log('movie %s: %s' % (self.vid, text))

    def save(self, append=False):
        mode = 'a' if append else 'w'
        with open(report_path(), mode, encoding='utf-8') as f:
            f.write('\n'.join(self.lines) + '\n')


def append_report(lines):
    with open(report_path(), 'a', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    for line in lines:
        kodi.log('movie license: %s' % line)


# ---------------------------------------------------------------- probing

def classify(fmt):
    url = fmt.get('url') or ''
    return {
        'drm': bool(fmt.get('drmFamilies')),
        'plain': bool(url) and (fmt.get('_solved') or 'n' not in parse_qs(urlparse(url).query)),
        'n': bool(url) and not fmt.get('_solved') and 'n' in parse_qs(urlparse(url).query),
        'cipher': bool(fmt.get('signatureCipher') or fmt.get('cipher')),
        'indexed': bool(fmt.get('initRange') and fmt.get('indexRange')),
        'video': (fmt.get('mimeType') or '').startswith('video/'),
        'otf': fmt.get('type') == 'FORMAT_STREAM_TYPE_OTF',
    }


def summarise(name, pr):
    if '_http' in pr:
        return 'HTTP %s' % pr['_http'], False
    status = pr.get('playabilityStatus') or {}
    sd = pr.get('streamingData') or {}
    fmts = (sd.get('adaptiveFormats') or []) + (sd.get('formats') or [])
    c = [classify(f) for f in fmts]
    drm_video = [x for x in c if x['drm'] and x['video']]
    playable_video = [x for x in drm_video if x['plain'] and x['indexed']]
    audio_ok = [x for x in c if not x['video'] and x['plain'] and x['indexed']]
    lic = [li.get('drmFamily') for li in sd.get('licenseInfos') or []]
    text = ('%s | reason: %s | formats: %d (DRM video %d, usable %d; audio usable %d; need JS %d; OTF %d) | '
            'licenseInfos: %s | drmParams: %s' % (
                status.get('status', '?'), status.get('reason', '-'), len(fmts), len(drm_video),
                len(playable_video), len(audio_ok), sum(1 for x in c if x['n'] or x['cipher']),
                sum(1 for x in c if x['otf']), ','.join(lic) or 'none', 'yes' if sd.get('drmParams') else 'no'))
    usable = status.get('status') == 'OK' and bool(playable_video) and bool(audio_ok)
    return text, usable


# ---------------------------------------------------------------- manifest

def _rng(r):
    return '%s-%s' % (r['start'], r['end'])


VIDEO_PREFERENCE = ('avc1', 'vp09', 'vp9', 'hev1', 'hvc1', 'av01')
AUDIO_PREFERENCE = ('mp4a', 'opus', 'ec-3', 'ac-3')


def _codec(f):
    return (f.get('mimeType') or '').split('codecs="')[-1].rstrip('"').strip()


def codecs_in(sd):
    """Short description of the fetchable streams, for the report."""
    vids, auds = set(), set()
    for f in sd.get('adaptiveFormats') or []:
        c = classify(f)
        if c['plain'] and c['indexed']:
            label = '%s %s%s' % (f['mimeType'].split(';')[0], _codec(f).split('.')[0],
                                 ' DRM' if c['drm'] else '')
            (vids if c['video'] else auds).add(label)
    return 'video: %s | audio: %s' % (', '.join(sorted(vids)) or 'none', ', '.join(sorted(auds)) or 'none')


def build_mpd(sd, duration, max_height=1080, url_for=None):
    """Widevine DASH manifest from the fetchable streams. Returns (mpd, description) or (None, reason)."""
    video, audio = {}, {}
    for f in sd.get('adaptiveFormats') or []:
        c = classify(f)
        if not (c['plain'] and c['indexed']):
            continue
        family = _codec(f).split('.')[0]
        if c['video'] and (f.get('height') or 0) <= max_height and family in VIDEO_PREFERENCE:
            video.setdefault(family, []).append(f)
        elif not c['video'] and family in AUDIO_PREFERENCE:
            audio.setdefault(family, []).append(f)
    vfam = next((fam for fam in VIDEO_PREFERENCE if video.get(fam)), None)
    afam = next((fam for fam in AUDIO_PREFERENCE if audio.get(fam)), None)
    if not vfam or not afam:
        return None, 'no supported codec pair (%s)' % codecs_in(sd)
    # YouTube encrypts SD, HD and audio with different keys (drmTrackType). Mixing key groups in one
    # adaptation set breaks playback when Kodi switches quality (after a seek, for example), so keep
    # only the video group that holds the best picture.
    groups = {}
    for f in video[vfam]:
        groups.setdefault(f.get('drmTrackType') or 'CLEAR', []).append(f)
    track, vreps = max(groups.items(), key=lambda kv: max(f.get('height', 0) for f in kv[1]))
    agroups = {}
    for f in audio[afam]:
        agroups.setdefault(f.get('drmTrackType') or 'CLEAR', []).append(f)
    atrack, areps = max(agroups.items(), key=lambda kv: len(kv[1]))
    protect = ('<ContentProtection schemeIdUri="urn:mpeg:dash:mp4protection:2011" value="cenc"/>'
               '<ContentProtection schemeIdUri="urn:uuid:%s"/>' % WIDEVINE_UUID)
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" '
           'type="static" minBufferTime="PT1.5S" mediaPresentationDuration="PT%sS"><Period>' % (duration or 0)]
    for kind, reps in (('video', vreps), ('audio', areps)):
        reps.sort(key=lambda f: (f.get('height', 0), f.get('bitrate', 0)), reverse=True)
        drm = any(f.get('drmFamilies') for f in reps)
        out.append('<AdaptationSet mimeType="%s" contentType="%s" subsegmentAlignment="true">'
                   % (reps[0]['mimeType'].split(';')[0], kind))
        if drm:
            out.append(protect)
        for f in reps:
            extra = ('width="%s" height="%s"' % (f.get('width', 0), f.get('height', 0))) if kind == 'video' \
                else 'audioSamplingRate="%s"' % f.get('audioSampleRate', 44100)
            out.append('<Representation id="%s" codecs="%s" bandwidth="%s" %s><BaseURL>%s</BaseURL>'
                       '<SegmentBase indexRange="%s"><Initialization range="%s"/></SegmentBase></Representation>'
                       % (f['itag'], _codec(f), f.get('bitrate', 0), extra, escape(url_for(f) if url_for else f['url']),
                          _rng(f['indexRange']), _rng(f['initRange'])))
        out.append('</AdaptationSet>')
    out.append('</Period></MPD>')
    top = max(f.get('height', 0) for f in vreps)
    low = min(f.get('height', 0) for f in vreps)
    return '\n'.join(out), '%s %s-%sp + %s (%d video, %d audio streams; key groups %s + %s)' % (
        vfam, low, top, afam, len(vreps), len(areps), track.replace('DRM_TRACK_TYPE_', ''),
        atrack.replace('DRM_TRACK_TYPE_', ''))


def save_session(video_id, chosen):
    pr = chosen['pr']
    sd = pr.get('streamingData') or {}
    session = {
        'video_id': video_id, 'cpn': cpn(), 'source': chosen['name'], 'ctx': chosen['ctx'],
        'client_id': chosen['client_id'], 'signed': chosen['signed'],
        'drm_params': sd.get('drmParams'), 'license_infos': sd.get('licenseInfos') or [],
        'track_types': sorted(set(f.get('drmTrackType') for f in sd.get('adaptiveFormats') or []
                                  if f.get('drmTrackType'))),
        'worked': None,
        'urls': dict((str(f['itag']), f['url']) for f in sd.get('adaptiveFormats') or [] if f.get('url')),
        'ua': chosen['ctx'].get('userAgent', ''),
    }
    with open(_session_path(video_id), 'w') as f:
        json.dump(session, f)
    return session


def load_session(video_id):
    with open(_session_path(video_id)) as f:
        return json.load(f)


# ---------------------------------------------------------------- playback

UNAVAILABLE = 'This movie only plays in YouTube\'s own apps'


def is_protected(pr):
    return bool((pr.get('streamingData') or {}).get('licenseInfos'))


# YouTube cuts apps that don't send its proof-of-origin token off after the first couple of minutes of a
# stream (on-device: HTTP 403 at a fixed byte, fresh links refused at the same spot). yt-dlp's client data
# marks visionOS as exempt and the Quest VR app as not, so visionOS goes first unless set otherwise.
# Confirmed on-device: visionOS plays whole movies; the VR app stops at the ~2 minute mark.
CLIENT_PREFERENCE = ('visionos', 'android_vr')
FULL_LENGTH = ('visionos',)


def movie_clients():
    """Apps movies may play through: visionOS only by default, or VR first if chosen in settings."""
    if kodi.setting_int('movie_client', 0) == 1:
        return tuple(reversed(CLIENT_PREFERENCE))
    return FULL_LENGTH


def rank_sources(sources):
    order = movie_clients()
    sources = [src for src in sources if src[0] in order]

    def key(src):
        name = src[0]
        pref = order.index(name) if name in order else len(order)
        return pref, -len((src[2].get('streamingData') or {}).get('adaptiveFormats') or [])
    return sorted(sources, key=key)


def prepare(video_id, sources):
    """sources: [(client name, client definition, player response)] that returned protected streams.
    Returns a play info dict for streams.listitem_for, or raises YTError."""
    from .streams import max_height, write_mpd
    title = ((sources[0][2].get('videoDetails') or {}).get('title') or '') if sources else ''
    rep = Report(video_id, title)
    ranked = rank_sources(sources)
    for name, client, pr in sources:
        text, _ = summarise(name, pr)
        rep.add('%-12s %s%s' % (name, text, '' if any(r[0] == name for r in ranked) else
                                 '  (not used: stops after two minutes)' if name == 'android_vr' else '  (not used)'))
    via_service = _via_service(video_id)
    built = []
    for name, client, pr in ranked:
        details = pr.get('videoDetails') or {}
        mpd, desc = build_mpd(pr.get('streamingData') or {}, int(details.get('lengthSeconds') or 0), max_height(),
                              via_service)
        rep.add('%s: %s' % (name, desc))
        built.append((name, client, pr, mpd))
    for name, client, pr, mpd in built:
        sd = pr.get('streamingData') or {}
        if not mpd:
            continue
        save_session(video_id, {'name': name, 'ctx': dict(client['context']), 'client_id': client['id'],
                                'signed': False, 'pr': pr})
        hb = pr.get('heartbeatParams') or {}
        rep.add('Ads in player data: %d | heartbeat: %s | server-ABR only: %s' % (
            len(pr.get('adPlacements') or []),
            ('every %ss' % (int(hb.get('intervalMilliseconds') or 0) // 1000)) if hb else 'no',
            'yes' if sd.get('serverAbrStreamingUrl') and not any(f.get('url') for f in sd.get('adaptiveFormats') or [])
            else 'no'))
        rep.add('Playing through %s. License and stream events follow:' % name)
        rep.save()
        return {'kind': 'widevine', 'url': write_mpd(video_id, mpd), 'mime': 'application/dash+xml',
                'client': name, 'user_agent': client['context'].get('userAgent', ''), 'video_id': video_id}
    rep.add('No source Kodi can play in full (apps allowed: %s).' % ', '.join(movie_clients()))
    rep.save()
    raise YTError(UNAVAILABLE)


def _via_service(video_id):
    port = kodi.setting_int('server_port', 50152) or 50152

    def via_service(f):
        # Streams go through the background service so failures (and YouTube's reasons) are recorded.
        return 'http://127.0.0.1:%d/seg/%s/%s' % (port, video_id, f['itag'])
    return via_service


def prepare_signed(video_id, name, ctx, pr, tv_request):
    """An encrypted video from the signed-in TV app (age-restricted free TV episodes and movies), its stream
    links already unscrambled. License requests go out as the same TV app with your account."""
    from .streams import max_height, write_mpd
    details = pr.get('videoDetails') or {}
    rep = Report(video_id, details.get('title') or '')
    text, _ = summarise('tv (signed in, %s)' % name, pr)
    rep.add(text)
    mpd, desc = build_mpd(pr.get('streamingData') or {}, int(details.get('lengthSeconds') or 0), max_height(),
                          _via_service(video_id))
    rep.add('tv: %s' % desc)
    if not mpd:
        rep.save()
        raise YTError('No encrypted streams Kodi can play (%s)' % desc)
    sess = save_session(video_id, {'name': 'tv', 'ctx': dict(ctx), 'client_id': 7, 'signed': True, 'pr': pr})
    sess['tv'] = tv_request
    with open(_session_path(video_id), 'w') as f:
        json.dump(sess, f)
    rep.add('Playing through the TV app, signed in. License and stream events follow:')
    rep.save()
    return {'kind': 'widevine', 'url': write_mpd(video_id, mpd), 'mime': 'application/dash+xml',
            'client': 'tv', 'user_agent': ctx.get('userAgent', ''), 'video_id': video_id}


def apply_props(li, video_id, ua, kodi_major):
    """Widevine properties for InputStream Adaptive, pointing license requests at the service."""
    from urllib.parse import quote
    port = kodi.setting_int('server_port', 50152) or 50152
    lic = 'http://127.0.0.1:%d/license/%s' % (port, video_id)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=%s' % quote(ua))
    if kodi_major >= 22:
        li.setProperty('inputstream.adaptive.drm_legacy',
                       'com.widevine.alpha|%s|Content-Type=application%%2Foctet-stream' % lic)
    else:
        if kodi_major < 21:
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        li.setProperty('inputstream.adaptive.license_key',
                       '%s|Content-Type=application%%2Foctet-stream|R{SSM}|' % lic)


# ---------------------------------------------------------------- "will this movie play here?" (for listings)


CACHE_DAYS = 7
_cache_lock = threading.Lock()


def _cache_path():
    # v2: earlier checks counted the VR app, whose movies stop after two minutes.
    return os.path.join(folder(), 'playable_v2.json')


def _load_cache():
    try:
        with open(_cache_path()) as f:
            return json.load(f)
    except Exception:
        return {}


def is_playable(yt, video_id, cache=None):
    """True when one of the clients YouTube licenses movies to gives Kodi-playable streams."""
    cache = cache if cache is not None else _load_cache()
    hit = cache.get(video_id)
    if hit and time.time() - hit[1] < CACHE_DAYS * 86400:
        return hit[0]
    clients = dict(yt.player_clients())
    from .innertube import PLAYER_CLIENTS
    ok = False
    for name in movie_clients():
        client = clients.get(name) or PLAYER_CLIENTS.get(name)
        if not client:
            continue
        try:
            pr = yt.player(video_id, name, client)
        except Exception:
            continue
        # Free episodes aren't always encrypted; those play like any other video.
        if _plays_unprotected(pr) or (summarise(name, pr)[1] and build_mpd(pr.get('streamingData') or {}, 0)[0]):
            ok = True
            break
    with _cache_lock:
        cache[video_id] = [ok, time.time()]
    return ok


def _plays_unprotected(pr):
    return (pr.get('playabilityStatus') or {}).get('status') == 'OK' and not is_protected(pr) and \
        bool((pr.get('streamingData') or {}).get('adaptiveFormats') or (pr.get('streamingData') or {}).get('formats'))


def filter_playable(yt, items, workers=6):
    """Keeps only the movies that will play; checks run in parallel and are cached for a week."""
    from concurrent.futures import ThreadPoolExecutor
    cache = _load_cache()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        flags = list(pool.map(lambda it: is_playable(yt, it['id'], cache), items))
    try:
        cutoff = time.time() - CACHE_DAYS * 86400
        keep = dict((k, v) for k, v in cache.items() if v[1] > cutoff)
        with open(_cache_path(), 'w') as f:
            json.dump(keep, f)
    except Exception:
        pass
    return [it for it, ok in zip(items, flags) if ok]


# ---------------------------------------------------------------- stream relay (runs in the background service)

_seen_ok = set()
_refresh_lock = threading.Lock()


def _refresh_urls(video_id, sess):
    """Asks YouTube again as the same app for fresh stream links."""
    from .innertube import InnerTube
    if sess.get('tv'):
        from . import jsc, streams
        yt = InnerTube()
        tv = sess['tv']
        ch = jsc.get(yt.session)
        pr = yt.tv_player(video_id, tv.get('sts') or ch.sts, client=sess['ctx'], visitor=tv.get('visitor'),
                          screen=tv.get('screen', False))
        streams.solve_streaming_data(ch, pr.get('streamingData') or {}, include_drm=True)
    else:
        pr = InnerTube().player(video_id, sess['source'], {'id': sess['client_id'], 'context': sess['ctx']})
    urls = dict((str(f['itag']), f['url']) for f in (pr.get('streamingData') or {}).get('adaptiveFormats') or []
                if f.get('url'))
    if urls:
        sess['urls'].update(urls)
        sess['refreshed'] = sess.get('refreshed', 0) + 1
        with open(_session_path(video_id), 'w') as f:
            json.dump(sess, f)
    return bool(urls), (pr.get('playabilityStatus') or {}).get('status')


def open_stream(session_obj, video_id, itag, range_header):
    """Opens one stream request for Kodi. Records every failure with YouTube's reply and retries once
    with fresh links. Returns a streaming requests response (caller closes it) or None."""
    sess = load_session(video_id)
    url = sess.get('urls', {}).get(str(itag))
    if not url:
        append_report(['%s  stream itag %s: no link stored' % (time.strftime('%H:%M:%S'), itag)])
        return None
    headers = {'User-Agent': sess.get('ua') or WEB_UA}
    if range_header:
        headers['Range'] = range_header
    for attempt in (1, 2):
        r = session_obj.get(url, headers=headers, stream=True, timeout=20)
        if r.status_code in (200, 206):
            key = (video_id, str(itag))
            if key not in _seen_ok:
                _seen_ok.add(key)
                append_report(['%s  stream itag %s OK (HTTP %s, %s)' % (
                    time.strftime('%H:%M:%S'), itag, r.status_code, range_header or 'whole file')])
            return r
        body = ''
        try:
            body = r.raw.read(300, decode_content=True).decode('utf-8', 'replace')
        except Exception:
            pass
        r.close()
        line = '%s  stream itag %s %s -> HTTP %s %s' % (time.strftime('%H:%M:%S'), itag, range_header or '',
                                                      r.status_code, body.strip()[:200])
        recent = [t for t in sess.get('refresh_times', []) if time.time() - t < 120]
        if attempt == 1 and r.status_code in (403, 410, 404) and len(recent) < 2:
            with _refresh_lock:
                sess['refresh_times'] = recent + [time.time()]
                ok, status = _refresh_urls(video_id, sess)
            append_report([line, '    refreshed links from YouTube: %s (player status %s)' % (
                'yes' if ok else 'no', status)])
            url = sess.get('urls', {}).get(str(itag))
            if ok and url:
                continue
        elif attempt == 1 and r.status_code in (403, 410, 404):
            key = (video_id, 'refusing')
            if key not in _seen_ok:
                _seen_ok.add(key)
                append_report([line, '    YouTube keeps refusing this part of the file; not asking for new links '
                                     'again (fresh links were refused at the same spot).'])
        else:
            append_report([line])
        return None
    return None


# ---------------------------------------------------------------- license (runs in the background service)

def _decode_b64(s):
    s = s.strip()
    s += '=' * (-len(s) % 4)
    try:
        return base64.urlsafe_b64decode(s)
    except Exception:
        return base64.b64decode(s)


def _json_license(session_obj, sess, challenge, ctx, client_id, token, label):
    cert = challenge == SERVICE_CERT_REQUEST
    ctx = dict(ctx)
    body = {'context': {'client': ctx}, 'drmSystem': 'DRM_SYSTEM_WIDEVINE', 'videoId': sess['video_id'],
            'cpn': sess['cpn'], 'sessionId': sess['cpn'], 'drmParams': sess.get('drm_params') or '',
            'licenseRequest': base64.b64encode(challenge).decode('ascii'), 'isWidevineServiceCert': cert,
            'drmVideoFeature': 'DRM_VIDEO_FEATURE_SDR'}
    headers = {'Content-Type': 'application/json', 'Origin': BASE, 'User-Agent': ctx.get('userAgent', WEB_UA),
               'X-YouTube-Client-Name': str(client_id), 'X-YouTube-Client-Version': ctx.get('clientVersion', '')}
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    r = session_obj.post(LICENSE_ENDPOINT, params={'prettyPrint': 'false'}, data=json.dumps(body),
                         headers=headers, timeout=20)
    note = '%s: HTTP %s' % (label, r.status_code)
    if r.status_code != 200:
        return None, note + ' ' + _redact(r.text)
    try:
        data = r.json()
    except Exception:
        return None, note + ' (not JSON) ' + _redact(r.text)
    if data.get('status') not in (None, 'LICENSE_STATUS_OK') or not data.get('license'):
        return None, note + ' status=%s %s' % (data.get('status'), _redact(json.dumps(data)))
    return _decode_b64(data['license']), note + ' status=%s license %d bytes' % (data.get('status'),
                                                                                 len(data['license']))


def _raw_license(session_obj, sess, challenge, url, token, label):
    headers = {'Content-Type': 'application/octet-stream',
               'User-Agent': sess['ctx'].get('userAgent', WEB_UA)}
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    sep = '&' if '?' in url else '?'
    r = session_obj.post(url + sep + 'cpn=' + sess['cpn'], data=challenge, headers=headers, timeout=20)
    note = '%s: HTTP %s, %d bytes, %s' % (label, r.status_code, len(r.content or b''),
                                         r.headers.get('Content-Type', '?'))
    ok = r.status_code == 200 and r.content and not r.content.lstrip()[:1] in (b'{', b'<')
    return (r.content if ok else None), (note if ok else note + ' ' + _redact(r.text))


def license(session_obj, video_id, challenge):
    """Tries each way of getting a Widevine license from YouTube. Returns license bytes or None."""
    sess = load_session(video_id)
    token = None
    try:
        token = auth.access_token(session_obj)
    except Exception:
        pass
    kind = 'service certificate' if challenge == SERVICE_CERT_REQUEST else 'license'
    lines = ['%s  %s request (%d bytes):' % (time.strftime('%H:%M:%S'), kind, len(challenge))]
    tv = dict(TV_CLIENT)
    web = {'clientName': 'WEB', 'clientVersion': '2.20260708.00.00', 'userAgent': WEB_UA}
    methods = [
        ('json/%s' % sess['source'], lambda: _json_license(session_obj, sess, challenge, sess['ctx'],
                                                           sess['client_id'], token if sess['signed'] else None,
                                                           'get_drm_license as %s' % sess['source'])),
    ]
    if token:
        methods.append(('json/tv+signin', lambda: _json_license(session_obj, sess, challenge, tv, 7, token,
                                                                'get_drm_license as TV, signed in')))
    methods.append(('json/web', lambda: _json_license(session_obj, sess, challenge, web, 1, None,
                                                      'get_drm_license as web')))
    for i, info in enumerate(sess.get('license_infos') or []):
        if info.get('url') and (info.get('drmFamily') or 'WIDEVINE') == 'WIDEVINE':
            methods.append(('raw/%d' % i, lambda u=info['url']: _raw_license(
                session_obj, sess, challenge, u, token, 'licenseInfos url %s' % urlparse(u).path)))
    if sess.get('worked'):
        methods.sort(key=lambda m: m[0] != sess['worked'])
    result = None
    for key, fn in methods:
        try:
            data, note = fn()
        except Exception as e:
            data, note = None, '%s: error %s' % (key, e)
        lines.append('  ' + note)
        if data:
            result = data
            sess['worked'] = key
            with open(_session_path(video_id), 'w') as f:
                json.dump(sess, f)
            lines.append('  -> using %s' % key)
            break
    if not result:
        lines.append('  -> no license; YouTube refused every method')
    append_report(lines)
    return result
