from . import parser as P
from .runtime import (
    UNDEF, NAN, JSObject, JSArray, JSFunction, Native, Accessor, JSThrow, Symbol, REALM,
    throw_error, typeof, to_str, to_num, to_bool, to_key, to_int32, to_uint32, to_primitive,
    strict_eq, loose_eq, js_add, js_sub, js_mul, js_div, js_mod, js_pow, lt, gt, le, ge,
    get_prop, set_prop, call, construct, instance_of, has_property, norm, to_object, key_str)

_MISSING = object()


class Scope(object):
    __slots__ = ('vars', 'parent', 'this', 'func', 'newtarget')

    def __init__(self, parent, this=UNDEF):
        self.vars = {}
        self.parent = parent
        self.this = this
        self.func = None
        self.newtarget = UNDEF


class Ctx(object):
    __slots__ = ('names', 'parent', 'funcs', 'uses_args', 'is_func')

    def __init__(self, names, parent, is_func=True):
        self.names = names
        self.parent = parent
        self.funcs = []
        self.uses_args = False
        self.is_func = is_func

    def resolve(self, name):
        depth = 0
        c = self
        while c is not None:
            if name in c.names:
                return depth
            depth += 1
            c = c.parent
        return -1


class TopLevel(object):
    def __init__(self, env):
        self.env = env

    def get(self, name):
        return self.env.lookup(name)

    def set(self, name, value):
        self.env.assign(name, value)

    def has(self, name):
        return self.env.defined(name)


class Code(object):
    __slots__ = ('params', 'simple', 'names', 'funcs', 'body', 'uses_args', 'nparams', 'local_tpl', 'name_self')


BRK = ('b', None)
CNT = ('c', None)


def _collect_vars(stmts, names, funcs):
    for s in stmts:
        _collect_stmt(s, names, funcs)


def _pattern_names(p, names):
    k = p[0]
    if k == 'id':
        names.add(p[1])
    elif k == 'default':
        _pattern_names(p[1], names)
    elif k == 'rest':
        _pattern_names(p[1], names)
    elif k == 'pattern_arr':
        for it in p[1]:
            if it is not None:
                _pattern_names(it, names)
    elif k == 'pattern_obj':
        for it in p[1]:
            _pattern_names(it[3], names)


def _collect_stmt(s, names, funcs):
    k = s[0]
    if k == 'var':
        for target, _ in s[2]:
            _pattern_names(target, names)
    elif k == 'fundecl':
        names.add(s[1])
        funcs.append(s[2])
    elif k == 'block':
        _collect_vars(s[1], names, funcs)
    elif k == 'if':
        _collect_stmt(s[2], names, funcs)
        if s[3] is not None:
            _collect_stmt(s[3], names, funcs)
    elif k == 'for':
        if s[1] is not None:
            _collect_stmt(s[1], names, funcs)
        _collect_stmt(s[4], names, funcs)
    elif k in ('forin', 'forof'):
        if s[1][0] == 'decl':
            _pattern_names(s[1][2], names)
        _collect_stmt(s[3], names, funcs)
    elif k in ('while', 'dowhile'):
        _collect_stmt(s[2], names, funcs)
    elif k == 'try':
        _collect_stmt(s[1], names, funcs)
        if s[3] is not None:
            _collect_stmt(s[3], names, funcs)
        if s[4] is not None:
            _collect_stmt(s[4], names, funcs)
    elif k == 'switch':
        for _, body in s[2]:
            _collect_vars(body, names, funcs)
    elif k == 'label':
        _collect_stmt(s[2], names, funcs)


class Closure(JSFunction):
    __slots__ = ('func', 'scope', 'compiler', 'ctx', 'code', 'lex_this', 'home', 'is_ctor_class', 'parent_class', 'fields')

    def __init__(self, func, scope, compiler, ctx, lex_this=UNDEF):
        JSFunction.__init__(self, func.name or '', len([p for p in func.params if p[0] == 'id']))
        self.func = func
        self.scope = scope
        self.compiler = compiler
        self.ctx = ctx
        self.code = None
        self.lex_this = lex_this
        self.home = None
        self.is_ctor_class = False
        self.parent_class = None
        self.fields = None

    def has_prototype(self):
        return not self.func.arrow

    def compile(self):
        self.code = self.compiler.compile_function(self.func, self.ctx)
        return self.code

    def call(self, this, args, newtarget=UNDEF, out=None):
        code = self.code or self.compile()
        sc = Scope(self.scope, self.lex_this if self.func.arrow else this)
        sc.func = self
        sc.newtarget = newtarget
        if out is not None:
            out.append(sc)
        vars = sc.vars
        if code.local_tpl:
            vars.update(code.local_tpl)
        if code.name_self is not None:
            vars[code.name_self] = self
        if code.simple:
            n = len(args)
            i = 0
            for name in code.params:
                vars[name] = args[i] if i < n else UNDEF
                i += 1
        else:
            comp = self.compiler
            n = len(args)
            for i, (rest, pat) in enumerate(code.params):
                if rest:
                    comp._bind_compiled(pat, JSArray(list(args[i:])), sc)
                    break
                comp._bind_compiled(pat, args[i] if i < n else UNDEF, sc)
        if code.uses_args:
            a = JSArray(list(args), REALM.ObjectProto)
            a.cls = 'Arguments'
            vars['arguments'] = a
        if code.funcs:
            comp = self.compiler
            for f, fctx in code.funcs:
                vars[f.name] = Closure(f, sc, comp, fctx)
        r = code.body(sc)
        if r is not None and r[0] == 'r':
            return r[1]
        return UNDEF

    def construct(self, args, new_target=None):
        target = new_target or self
        if self.func.arrow:
            raise throw_error('TypeError', 'not a constructor')
        proto = target.get('prototype')
        if not isinstance(proto, JSObject):
            proto = REALM.ObjectProto
        if self.is_ctor_class and self.parent_class is not None:
            box = []
            r = self.call(_UNINIT, args, target, box)
            if isinstance(r, JSObject):
                return r
            this = box[0].this
            if this is _UNINIT:
                raise throw_error('ReferenceError', 'derived constructor did not call super')
            return this
        obj = JSObject(proto)
        if self.fields:
            self.fields(obj)
        r = self.call(obj, args, target)
        if isinstance(r, JSObject):
            return r
        return obj


_UNINIT = JSObject(None, 'Uninitialized')


class Compiler(object):
    def __init__(self, top, parse_body):
        self.top = top
        self.parse_body = parse_body

    def make_closure(self, f, sc, ctx, this=UNDEF):
        c = Closure(f, sc, self, ctx, this)
        return c

    def compile_function(self, f, outer_ctx):
        body = f.body if f.body is not None else self.parse_body(f)
        names = set()
        funcs = []
        for p in f.params:
            _pattern_names(p, names)
        param_names = set(names)
        _collect_vars(body, names, funcs)
        ctx = Ctx(names, outer_ctx)
        uses_args = 'arguments' not in param_names and not f.arrow
        if uses_args:
            names.add('arguments')
        ctx.uses_args = False
        code = Code()
        code.simple = all(p[0] == 'id' for p in f.params)
        code.params = [p[1] for p in f.params] if code.simple else f.params
        code.names = names
        code.funcs = funcs
        tpl = {}
        for n in names:
            if n not in param_names:
                tpl[n] = UNDEF
        tpl.pop('arguments', None)
        code.local_tpl = tpl
        code.name_self = f.name if (f.name and not f.is_decl and f.name not in names) else None
        if code.name_self:
            names.add(code.name_self)
        self._cur_uses_args = False
        code.body = self.block_fn(body, ctx)
        code.uses_args = uses_args and ctx.uses_args
        if not code.uses_args:
            names.discard('arguments')
        code.nparams = len(f.params)
        code.funcs = [(fn, ctx) for fn in funcs]
        if not code.simple:
            code.params = [(p[0] == 'rest', self._compile_pattern(p[1] if p[0] == 'rest' else p, ctx)) for p in f.params]
        return code

    def assign_name(self, name, v, sc):
        s = sc
        while s is not None:
            if name in s.vars:
                s.vars[name] = v
                return
            s = s.parent
        self.top.set(name, v)

    def block_fn(self, stmts, ctx):
        fns = [self.stmt(s, ctx) for s in stmts]
        fns = [f for f in fns if f is not None]
        if not fns:
            return lambda sc: None
        if len(fns) == 1:
            return fns[0]
        if len(fns) == 2:
            a, b = fns

            def run2(sc):
                r = a(sc)
                if r is not None:
                    return r
                return b(sc)
            return run2
        fns = tuple(fns)

        def run(sc):
            for f in fns:
                r = f(sc)
                if r is not None:
                    return r
            return None
        return run

    def stmt(self, s, ctx, label=None):
        k = s[0]
        m = getattr(self, 's_' + k)
        if k in ('for', 'forin', 'forof', 'while', 'dowhile', 'switch'):
            return m(s, ctx, label)
        return m(s, ctx)

    def s_empty(self, s, ctx):
        return None

    def s_fundecl(self, s, ctx):
        return None

    def s_expr(self, s, ctx):
        e = self.expr(s[1], ctx)

        def run(sc):
            e(sc)
        return run

    def s_var(self, s, ctx):
        fns = []
        for target, init in s[2]:
            if init is None:
                if s[1] != 'var' and target[0] == 'id':
                    name = target[1]
                    fns.append(self._assign_target_fn(target, ctx, const_init=True, value_fn=lambda sc: UNDEF))
                continue
            fns.append(self._assign_target_fn(target, ctx, value_fn=self.expr(init, ctx), name_hint=target))
        if not fns:
            return None
        if len(fns) == 1:
            f0 = fns[0]

            def run1(sc):
                f0(sc)
            return run1
        fns = tuple(fns)

        def run(sc):
            for f in fns:
                f(sc)
        return run

    def s_block(self, s, ctx):
        return self.block_fn(s[1], ctx)

    def s_if(self, s, ctx):
        test = self.cond_fn(s[1], ctx)
        cons = self.stmt(s[2], ctx) or (lambda sc: None)
        if s[3] is None:
            def run(sc):
                if test(sc):
                    return cons(sc)
            return run
        alt = self.stmt(s[3], ctx) or (lambda sc: None)

        def run2(sc):
            if test(sc):
                return cons(sc)
            return alt(sc)
        return run2

    def _loop_signal(self, r, label):
        k = r[0]
        if k == 'b':
            if r[1] is None or r[1] == label:
                return 'break'
            return 'out'
        if k == 'c':
            if r[1] is None or r[1] == label:
                return 'continue'
            return 'out'
        return 'out'

    def s_for(self, s, ctx, label=None):
        init = self.stmt(s[1], ctx) if s[1] is not None else None
        test = self.cond_fn(s[2], ctx) if s[2] is not None else None
        update = self.expr(s[3], ctx) if s[3] is not None else None
        body = self.stmt(s[4], ctx) or (lambda sc: None)
        sig = self._loop_signal

        def run(sc):
            if init is not None:
                init(sc)
            while test is None or test(sc):
                r = body(sc)
                if r is not None:
                    w = sig(r, label)
                    if w == 'break':
                        break
                    if w == 'out':
                        return r
                if update is not None:
                    update(sc)
            return None
        return run

    def s_while(self, s, ctx, label=None):
        test = self.cond_fn(s[1], ctx)
        body = self.stmt(s[2], ctx) or (lambda sc: None)
        sig = self._loop_signal

        def run(sc):
            while test(sc):
                r = body(sc)
                if r is not None:
                    w = sig(r, label)
                    if w == 'break':
                        break
                    if w == 'out':
                        return r
            return None
        return run

    def s_dowhile(self, s, ctx, label=None):
        test = self.cond_fn(s[1], ctx)
        body = self.stmt(s[2], ctx) or (lambda sc: None)
        sig = self._loop_signal

        def run(sc):
            while True:
                r = body(sc)
                if r is not None:
                    w = sig(r, label)
                    if w == 'break':
                        break
                    if w == 'out':
                        return r
                if not test(sc):
                    break
            return None
        return run

    def s_forin(self, s, ctx, label=None):
        target = s[1]
        if target[0] == 'decl':
            target = target[2]
        assign = self._assign_target_fn(target, ctx)
        obj = self.expr(s[2], ctx)
        body = self.stmt(s[3], ctx) or (lambda sc: None)
        sig = self._loop_signal

        def run(sc):
            o = obj(sc)
            if o is UNDEF or o is None:
                return None
            if not isinstance(o, JSObject):
                o = to_object(o)
            keys = []
            seen = set()
            cur = o
            while cur is not None:
                for k in cur.own_keys():
                    if k not in seen:
                        seen.add(k)
                        if k.__class__ is str:
                            keys.append(k)
                cur = cur.proto
            for k in keys:
                if not o.has(k):
                    continue
                assign(sc, k)
                r = body(sc)
                if r is not None:
                    w = sig(r, label)
                    if w == 'break':
                        break
                    if w == 'out':
                        return r
            return None
        return run

    def s_forof(self, s, ctx, label=None):
        target = s[1]
        if target[0] == 'decl':
            target = target[2]
        assign = self._assign_target_fn(target, ctx)
        obj = self.expr(s[2], ctx)
        body = self.stmt(s[3], ctx) or (lambda sc: None)
        sig = self._loop_signal

        def run(sc):
            for v in _iter_values(obj(sc)):
                assign(sc, v)
                r = body(sc)
                if r is not None:
                    w = sig(r, label)
                    if w == 'break':
                        break
                    if w == 'out':
                        return r
            return None
        return run

    def s_return(self, s, ctx):
        if s[1] is None:
            ret = ('r', UNDEF)
            return lambda sc: ret
        e = self.expr(s[1], ctx)

        def run(sc):
            return ('r', e(sc))
        return run

    def s_break(self, s, ctx):
        sig = ('b', s[1])
        return lambda sc: sig

    def s_continue(self, s, ctx):
        sig = ('c', s[1])
        return lambda sc: sig

    def s_throw(self, s, ctx):
        e = self.expr(s[1], ctx)

        def run(sc):
            raise JSThrow(e(sc))
        return run

    def s_try(self, s, ctx):
        block = self.stmt(s[1], ctx) or (lambda sc: None)
        handler = None
        param = s[2]
        cpat = None
        if s[3] is not None:
            if param is not None:
                names = set()
                _pattern_names(param, names)
                cctx = Ctx(names, ctx, is_func=False)
                cpat = self._compile_pattern(param, cctx)
                handler = self.stmt(s[3], cctx) or (lambda sc: None)
            else:
                cctx = None
                handler = self.stmt(s[3], ctx) or (lambda sc: None)
        final = self.stmt(s[4], ctx) if s[4] is not None else None
        compiler = self

        def run(sc):
            try:
                try:
                    return block(sc)
                except JSThrow as e:
                    if handler is None:
                        raise
                    val = e.value
                except RecursionError:
                    if handler is None:
                        raise
                    val = make_js_error('RangeError', 'Maximum call stack size exceeded')
                if param is None:
                    return handler(sc)
                hs = Scope(sc, sc.this)
                hs.func = sc.func
                compiler._bind_compiled(cpat, val, hs)
                return handler(hs)
            finally:
                if final is not None:
                    r = final(sc)
                    if r is not None:
                        return r
        if final is None:
            def run_nf(sc):
                try:
                    return block(sc)
                except JSThrow as e:
                    val = e.value
                except RecursionError:
                    val = make_js_error('RangeError', 'Maximum call stack size exceeded')
                if param is None:
                    return handler(sc)
                hs = Scope(sc, sc.this)
                hs.func = sc.func
                compiler._bind_compiled(cpat, val, hs)
                return handler(hs)
            return run_nf
        return run

    def s_switch(self, s, ctx, label=None):
        disc = self.expr(s[1], ctx)
        cases = []
        default = None
        for i, (test, body) in enumerate(s[2]):
            t = self.expr(test, ctx) if test is not None else None
            b = self.block_fn(body, ctx)
            cases.append((t, b))
            if test is None:
                default = i
        lit = {}
        all_lit = True
        for i, (test, body) in enumerate(s[2]):
            if test is None:
                continue
            if test[0] in ('num', 'str') and (test[1].__class__ in (int, str)):
                lit.setdefault((test[1].__class__, test[1]), i)
            else:
                all_lit = False

        def run(sc):
            v = disc(sc)
            start = None
            if all_lit and v.__class__ in (int, str):
                start = lit.get((v.__class__, v))
            elif all_lit and v.__class__ is float and v.is_integer():
                start = lit.get((int, int(v)))
            else:
                for i, (t, b) in enumerate(cases):
                    if t is not None and strict_eq(v, t(sc)):
                        start = i
                        break
            if start is None:
                start = default
                if start is None:
                    return None
            for i in range(start, len(cases)):
                r = cases[i][1](sc)
                if r is not None:
                    if r[0] == 'b' and (r[1] is None or r[1] == label):
                        return None
                    return r
            return None
        return run

    def s_label(self, s, ctx):
        label = s[1]
        inner = s[2]
        if inner[0] in ('for', 'forin', 'forof', 'while', 'dowhile', 'switch'):
            body = self.stmt(inner, ctx, label)
        else:
            body = self.stmt(inner, ctx) or (lambda sc: None)

        def run(sc):
            r = body(sc)
            if r is not None and r[0] == 'b' and r[1] == label:
                return None
            return r
        return run

    def cond_fn(self, e, ctx):
        k = e[0]
        if k == 'unary' and e[1] == '!':
            inner = self.cond_fn(e[2], ctx)
            return lambda sc: not inner(sc)
        if k == 'bin':
            op = e[1]
            if op in ('<', '>', '<=', '>=', '===', '!==', '==', '!=', 'instanceof', 'in'):
                f = self.expr(e, ctx)
                return f
        if k == 'logic' and e[1] in ('&&', '||'):
            a = self.cond_fn(e[2], ctx)
            b = self.cond_fn(e[3], ctx)
            if e[1] == '&&':
                return lambda sc: a(sc) and b(sc)
            return lambda sc: a(sc) or b(sc)
        f = self.expr(e, ctx)
        return lambda sc: to_bool(f(sc))

    def expr(self, e, ctx):
        return getattr(self, 'e_' + e[0])(e, ctx)

    def e_num(self, e, ctx):
        v = e[1]
        return lambda sc: v

    e_str = e_num

    def e_lit(self, e, ctx):
        v = e[1]
        return lambda sc: v

    def e_regex(self, e, ctx):
        pattern, flags = e[1], e[2]
        make = REALM.make_regexp
        return lambda sc: make(pattern, flags)

    def e_tmpl(self, e, ctx):
        parts = e[1]
        exprs = [self.expr(x, ctx) for x in e[2]]

        def run(sc):
            out = [parts[0]]
            for i, f in enumerate(exprs):
                out.append(to_str(f(sc)))
                out.append(parts[i + 1])
            return ''.join(out)
        return run

    def e_this(self, e, ctx):
        def run(sc):
            t = sc.this
            if t is _UNINIT:
                raise throw_error('ReferenceError', "Must call super constructor before accessing 'this'")
            return t
        return run

    def e_id(self, e, ctx):
        name = e[1]
        if name == 'undefined' and ctx.resolve(name) < 0:
            return lambda sc: UNDEF
        if name == 'arguments':
            c = ctx
            while c is not None and 'arguments' not in c.names:
                c = c.parent
            if c is not None:
                c.uses_args = True
        depth = ctx.resolve(name)
        if depth == 0:
            def local(sc):
                return sc.vars[name]
            return local
        if depth == 1:
            def up1(sc):
                return sc.parent.vars[name]
            return up1
        if depth == 2:
            def up2(sc):
                return sc.parent.parent.vars[name]
            return up2
        if depth > 0:
            def upn(sc):
                s = sc
                for _ in range(depth):
                    s = s.parent
                return s.vars[name]
            return upn
        top = self.top

        def free(sc):
            return top.get(name)
        return free

    def e_arr(self, e, ctx):
        items = []
        spread = False
        for it in e[1]:
            if it is None:
                items.append(None)
            elif it[0] == 'spread':
                spread = True
                items.append(('s', self.expr(it[1], ctx)))
            else:
                items.append(self.expr(it, ctx))
        if not spread:
            fns = tuple(items)
            if None in fns:
                return lambda sc: JSArray([UNDEF if f is None else f(sc) for f in fns])
            return lambda sc: JSArray([f(sc) for f in fns])

        def run(sc):
            out = []
            for f in items:
                if f is None:
                    out.append(UNDEF)
                elif f.__class__ is tuple:
                    out.extend(_iter_values(f[1](sc)))
                else:
                    out.append(f(sc))
            return JSArray(out)
        return run

    def e_obj(self, e, ctx):
        props = []
        for p in e[1]:
            kind = p[0]
            if kind == 'spread':
                props.append(('spread', None, self.expr(p[1], ctx)))
                continue
            key = p[1]
            keyf = self.expr(key, ctx) if p[2] else None
            if kind == 'init':
                val = p[3]
                if val[0] == 'func' and val[1].name is None and not p[2]:
                    props.append(('init', key, self._func_expr(val[1], ctx, name=key)))
                else:
                    props.append(('init', key if keyf is None else keyf, self.expr(val, ctx), keyf is not None))
            else:
                props.append((kind, key if keyf is None else keyf, self._func_expr(p[3], ctx), keyf is not None))
        compiler = self

        def run(sc):
            o = JSObject(REALM.ObjectProto)
            props_d = o.props
            for p in props:
                kind = p[0]
                if kind == 'init':
                    key = p[1]
                    if len(p) > 3 and p[3]:
                        key = key_str(to_key(key(sc)))
                    v = p[2](sc)
                    if key == '__proto__' and not (len(p) > 3 and p[3]):
                        if isinstance(v, JSObject) or v is None:
                            o.proto = v
                        continue
                    props_d[key] = v
                elif kind == 'spread':
                    src = p[2](sc)
                    if isinstance(src, JSObject):
                        for k in src.own_keys():
                            props_d[key_str(k)] = src.get(k)
                    elif src.__class__ is str:
                        for i, ch in enumerate(src):
                            props_d[str(i)] = ch
                else:
                    key = p[1]
                    if p[3]:
                        key = key_str(to_key(key(sc)))
                    f = p[2](sc)
                    cur = props_d.get(key)
                    acc = cur if cur.__class__ is Accessor else Accessor()
                    if kind == 'get':
                        acc.get = f
                    else:
                        acc.set = f
                    props_d[key] = acc
            return o
        return run

    def _func_expr(self, f, ctx, name=None):
        compiler = self
        if f.arrow:
            def arrow(sc):
                c = Closure(f, sc, compiler, ctx, sc.this)
                return c
            return arrow

        def run(sc):
            c = Closure(f, sc, compiler, ctx)
            if name is not None and not c.name and name.__class__ is str:
                c.name = name
            return c
        return run

    def e_func(self, e, ctx):
        return self._func_expr(e[1], ctx)

    def e_member(self, e, ctx):
        key = e[2]
        if e[1][0] == 'optional':
            return self._optional(e, ctx)
        obj = self.expr(e[1], ctx)
        if key == 'length':
            def length(sc):
                o = obj(sc)
                c = o.__class__
                if c is str:
                    return len(o)
                if c is JSArray:
                    return len(o.items)
                return get_prop(o, 'length')
            return length

        def run(sc):
            o = obj(sc)
            if o.__class__ is JSObject:
                props = o.props
                v = props.get(key, _MISSING)
                if v is not _MISSING and v.__class__ is not Accessor:
                    return v
                return o.get(key)
            return get_prop(o, key)
        return run

    def e_index(self, e, ctx):
        if e[1][0] == 'optional':
            return self._optional(e, ctx)
        obj = self.expr(e[1], ctx)
        k = e[2]
        if k[0] in ('str', 'num'):
            key = to_key(k[1])

            def const(sc):
                return get_prop(obj(sc), key)
            return const
        keyf = self.expr(k, ctx)

        def run(sc):
            o = obj(sc)
            kv = keyf(sc)
            if kv.__class__ is int and o.__class__ is JSArray and kv >= 0:
                items = o.items
                if kv < len(items):
                    return items[kv]
                return UNDEF
            if kv.__class__ is int and o.__class__ is str and kv >= 0:
                return o[kv] if kv < len(o) else UNDEF
            return get_prop(o, to_key(kv))
        return run

    def e_chain(self, e, ctx):
        inner = self.expr(e[1], ctx)

        def run(sc):
            try:
                return inner(sc)
            except _ShortCircuit:
                return UNDEF
        return run

    def e_optional(self, e, ctx):
        inner = self.expr(e[1], ctx)

        def run(sc):
            v = inner(sc)
            if v is UNDEF or v is None:
                raise _ShortCircuit()
            return v
        return run

    def _optional(self, e, ctx):
        if e[0] == 'member':
            return self.e_member(('member', ('optional_obj', e[1][1]), e[2]), ctx)
        return self.e_index(('index', ('optional_obj', e[1][1]), e[2]), ctx)

    def e_optional_obj(self, e, ctx):
        return self.e_optional(e, ctx)

    def e_call(self, e, ctx):
        callee = e[1]
        args = self._args(e[2], ctx)
        kind = callee[0]
        if kind == 'super':
            return self._super_call(args, ctx)
        if kind == 'optional':
            target = self.expr(callee, ctx)

            def opt_call(sc):
                f = target(sc)
                return call(f, UNDEF, args(sc))
            return opt_call
        if kind == 'member' or kind == 'index':
            if callee[1][0] == 'optional':
                objf = self.e_optional(callee[1], ctx)
            elif callee[1][0] == 'super':
                objf = None
            else:
                objf = self.expr(callee[1], ctx)
            if kind == 'member':
                keyc = callee[2]
                keyf = None
            else:
                kk = callee[2]
                if kk[0] in ('str', 'num'):
                    keyc = to_key(kk[1])
                    keyf = None
                else:
                    keyc = None
                    keyf = self.expr(kk, ctx)
            if objf is None:
                def super_method(sc):
                    home = _home_proto(sc)
                    key = keyc if keyf is None else to_key(keyf(sc))
                    f = home.get(key, sc.this) if home is not None else UNDEF
                    return call(f, sc.this, args(sc))
                return super_method

            def mcall(sc):
                o = objf(sc)
                key = keyc if keyf is None else to_key(keyf(sc))
                f = get_prop(o, key)
                c = f.__class__
                if c is Closure:
                    return f.call(o, args(sc))
                if c is Native:
                    return f.fn(o, args(sc))
                if isinstance(f, JSFunction):
                    return f.call(o, args(sc))
                raise throw_error('TypeError', '%s is not a function' % _describe(callee))
            return mcall
        fn = self.expr(callee, ctx)

        def fcall(sc):
            f = fn(sc)
            c = f.__class__
            if c is Closure:
                return f.call(UNDEF, args(sc))
            if c is Native:
                return f.fn(UNDEF, args(sc))
            if isinstance(f, JSFunction):
                return f.call(UNDEF, args(sc))
            raise throw_error('TypeError', '%s is not a function' % _describe(callee))
        return fcall

    def _super_call(self, args, ctx):
        def run(sc):
            s = sc
            while s is not None and (s.func is None or s.func.func.arrow):
                s = s.parent
            f = s.func
            parent = f.parent_class
            nt = s.newtarget
            if parent is None:
                raise throw_error('SyntaxError', "'super' keyword unexpected here")
            obj = parent.construct(args(sc), nt if nt is not UNDEF else f)
            if f.fields:
                f.fields(obj)
            s.this = obj
            t = sc
            while t is not s:
                if t.this is _UNINIT:
                    t.this = obj
                t = t.parent
            return UNDEF
        return run

    def _args(self, args, ctx):
        fns = []
        spread = False
        for a in args:
            if a[0] == 'spread':
                spread = True
                fns.append(('s', self.expr(a[1], ctx)))
            else:
                fns.append(self.expr(a, ctx))
        if not spread:
            n = len(fns)
            if n == 0:
                return lambda sc: []
            if n == 1:
                a0 = fns[0]
                return lambda sc: [a0(sc)]
            if n == 2:
                a0, a1 = fns
                return lambda sc: [a0(sc), a1(sc)]
            if n == 3:
                a0, a1, a2 = fns
                return lambda sc: [a0(sc), a1(sc), a2(sc)]
            fns = tuple(fns)
            return lambda sc: [f(sc) for f in fns]

        def run(sc):
            out = []
            for f in fns:
                if f.__class__ is tuple:
                    out.extend(_iter_values(f[1](sc)))
                else:
                    out.append(f(sc))
            return out
        return run

    def e_new(self, e, ctx):
        fn = self.expr(e[1], ctx)
        args = self._args(e[2], ctx)
        callee = e[1]

        def run(sc):
            f = fn(sc)
            if isinstance(f, JSFunction):
                return f.construct(args(sc))
            raise throw_error('TypeError', '%s is not a constructor' % _describe(callee))
        return run

    def e_newtarget(self, e, ctx):
        def run(sc):
            s = sc
            while s is not None and (s.func is None or s.func.func.arrow):
                s = s.parent
            return s.newtarget if s is not None else UNDEF
        return run

    def e_seq(self, e, ctx):
        fns = [self.expr(x, ctx) for x in e[1]]
        last = fns[-1]
        head = tuple(fns[:-1])

        def run(sc):
            for f in head:
                f(sc)
            return last(sc)
        return run

    def e_cond(self, e, ctx):
        test = self.cond_fn(e[1], ctx)
        a = self.expr(e[2], ctx)
        b = self.expr(e[3], ctx)
        return lambda sc: a(sc) if test(sc) else b(sc)

    def e_logic(self, e, ctx):
        a = self.expr(e[2], ctx)
        b = self.expr(e[3], ctx)
        op = e[1]
        if op == '&&':
            def land(sc):
                v = a(sc)
                if not to_bool(v):
                    return v
                return b(sc)
            return land
        if op == '||':
            def lor(sc):
                v = a(sc)
                if to_bool(v):
                    return v
                return b(sc)
            return lor

        def nullish(sc):
            v = a(sc)
            if v is UNDEF or v is None:
                return b(sc)
            return v
        return nullish

    def e_unary(self, e, ctx):
        op = e[1]
        if op == 'typeof':
            arg = e[2]
            if arg[0] == 'id' and ctx.resolve(arg[1]) < 0:
                name = arg[1]
                top = self.top

                def tof(sc):
                    if not top.has(name):
                        return 'undefined'
                    return typeof(top.get(name))
                return tof
            f = self.expr(arg, ctx)
            return lambda sc: typeof(f(sc))
        if op == 'delete':
            arg = e[2]
            if arg[0] in ('member', 'index'):
                obj = self.expr(arg[1], ctx)
                if arg[0] == 'member':
                    key = arg[2]
                    keyf = None
                else:
                    keyf = self.expr(arg[2], ctx)

                def dele(sc):
                    o = obj(sc)
                    k = key if keyf is None else to_key(keyf(sc))
                    if isinstance(o, JSObject):
                        return o.delete(k)
                    return True
                return dele
            return lambda sc: True
        f = self.expr(e[2], ctx)
        if op == '!':
            return lambda sc: not to_bool(f(sc))
        if op == '-':
            def neg(sc):
                v = f(sc)
                if v.__class__ is int:
                    return -v if v != 0 else -0.0
                v = to_num(v)
                return norm(-v) if v != 0 else -v
            return neg
        if op == '+':
            return lambda sc: to_num(f(sc))
        if op == '~':
            return lambda sc: ~to_int32(f(sc))
        if op == 'void':
            def void(sc):
                f(sc)
                return UNDEF
            return void
        raise throw_error('SyntaxError', 'unsupported unary %s' % op)

    def e_bin(self, e, ctx):
        op = e[1]
        a = self.expr(e[2], ctx)
        b = self.expr(e[3], ctx)
        if op == '+':
            def add(sc):
                x = a(sc)
                y = b(sc)
                if x.__class__ is int and y.__class__ is int:
                    r = x + y
                    if -9007199254740992 <= r <= 9007199254740992:
                        return r
                return js_add(x, y)
            return add
        if op == '-':
            def sub(sc):
                x = a(sc)
                y = b(sc)
                if x.__class__ is int and y.__class__ is int:
                    return x - y
                return js_sub(x, y)
            return sub
        if op == '===':
            def seq(sc):
                x = a(sc)
                y = b(sc)
                if x is y:
                    return x == x
                return strict_eq(x, y)
            return seq
        if op == '!==':
            def sne(sc):
                x = a(sc)
                y = b(sc)
                if x is y:
                    return x != x
                return not strict_eq(x, y)
            return sne
        if op == '<':
            return lambda sc: lt(a(sc), b(sc))
        if op == '>':
            return lambda sc: gt(a(sc), b(sc))
        if op == '<=':
            return lambda sc: le(a(sc), b(sc))
        if op == '>=':
            return lambda sc: ge(a(sc), b(sc))
        if op == '==':
            return lambda sc: loose_eq(a(sc), b(sc))
        if op == '!=':
            return lambda sc: not loose_eq(a(sc), b(sc))
        if op == '*':
            return lambda sc: js_mul(a(sc), b(sc))
        if op == '/':
            return lambda sc: js_div(a(sc), b(sc))
        if op == '%':
            def mod(sc):
                x = a(sc)
                y = b(sc)
                if x.__class__ is int and y.__class__ is int and x >= 0 and y > 0:
                    return x % y
                return js_mod(x, y)
            return mod
        if op == '**':
            return lambda sc: js_pow(a(sc), b(sc))
        if op == '&':
            return lambda sc: to_int32(to_int32(a(sc)) & to_int32(b(sc)))
        if op == '|':
            return lambda sc: to_int32(to_int32(a(sc)) | to_int32(b(sc)))
        if op == '^':
            return lambda sc: to_int32(to_int32(a(sc)) ^ to_int32(b(sc)))
        if op == '<<':
            return lambda sc: to_int32(to_int32(a(sc)) << (to_uint32(b(sc)) & 31))
        if op == '>>':
            return lambda sc: to_int32(a(sc)) >> (to_uint32(b(sc)) & 31)
        if op == '>>>':
            return lambda sc: to_uint32(a(sc)) >> (to_uint32(b(sc)) & 31)
        if op == 'instanceof':
            return lambda sc: instance_of(a(sc), b(sc))
        if op == 'in':
            return lambda sc: has_property(b(sc), to_key(a(sc)))
        raise throw_error('SyntaxError', 'unsupported operator %s' % op)

    def _assign_target_fn(self, target, ctx, value_fn=None, const_init=False, name_hint=None):
        k = target[0]
        if k == 'id':
            name = target[1]
            depth = ctx.resolve(name)
            if value_fn is None:
                if depth == 0:
                    def setl(sc, v):
                        sc.vars[name] = v
                    return setl
                if depth > 0:
                    def setu(sc, v):
                        s = sc
                        for _ in range(depth):
                            s = s.parent
                        s.vars[name] = v
                    return setu
                top = self.top

                def setf(sc, v):
                    top.set(name, v)
                return setf
            vf = value_fn
            is_anon_func = name_hint is not None
            if depth == 0:
                def asl(sc):
                    v = vf(sc)
                    if is_anon_func and v.__class__ is Closure and not v.name:
                        v.name = name
                    sc.vars[name] = v
                    return v
                return asl
            if depth > 0:
                def asu(sc):
                    v = vf(sc)
                    s = sc
                    for _ in range(depth):
                        s = s.parent
                    s.vars[name] = v
                    return v
                return asu
            top = self.top

            def asf(sc):
                v = vf(sc)
                if is_anon_func and v.__class__ is Closure and not v.name:
                    v.name = name
                top.set(name, v)
                return v
            return asf
        if k == 'member' or k == 'index':
            obj = self.expr(target[1], ctx)
            if k == 'member':
                keyc = target[2]
                keyf = None
            else:
                kk = target[2]
                if kk[0] in ('str', 'num'):
                    keyc = to_key(kk[1])
                    keyf = None
                else:
                    keyc = None
                    keyf = self.expr(kk, ctx)
            if value_fn is None:
                def setm(sc, v):
                    o = obj(sc)
                    key = keyc if keyf is None else to_key(keyf(sc))
                    set_prop(o, key, v)
                return setm
            vf = value_fn

            def asm(sc):
                o = obj(sc)
                key = keyc if keyf is None else to_key(keyf(sc))
                v = vf(sc)
                if o.__class__ is JSArray and key.__class__ is int and key >= 0:
                    items = o.items
                    if key < len(items):
                        items[key] = v
                        return v
                set_prop(o, key, v)
                return v
            return asm
        if k in ('pattern_arr', 'pattern_obj', 'default'):
            compiler = self
            pat = self._compile_pattern(target, ctx)
            if value_fn is None:
                def setp(sc, v):
                    compiler._bind_compiled(pat, v, sc)
                return setp
            vf = value_fn

            def asp(sc):
                v = vf(sc)
                compiler._bind_compiled(pat, v, sc)
                return v
            return asp
        raise throw_error('SyntaxError', 'bad assignment target')

    def _compile_pattern(self, p, ctx):
        k = p[0]
        if k in ('id', 'member', 'index'):
            return ('t', self._assign_target_fn(p, ctx))
        if k == 'default':
            return ('d', self._compile_pattern(p[1], ctx), self.expr(p[2], ctx))
        if k == 'rest':
            return ('r', self._compile_pattern(p[1], ctx))
        if k == 'pattern_arr':
            return ('a', [None if it is None else self._compile_pattern(it, ctx) for it in p[1]])
        if k == 'pattern_obj':
            out = []
            for it in p[1]:
                if it[0] == 'rest':
                    out.append(('rest', None, self._compile_pattern(it[3], ctx)))
                else:
                    key = self.expr(it[1], ctx) if it[2] else it[1]
                    out.append((it[2], key, self._compile_pattern(it[3], ctx)))
            return ('o', out)
        raise throw_error('SyntaxError', 'bad pattern')

    def _bind_compiled(self, pat, v, sc):
        k = pat[0]
        if k == 't':
            pat[1](sc, v)
        elif k == 'd':
            if v is UNDEF:
                v = pat[2](sc)
            self._bind_compiled(pat[1], v, sc)
        elif k == 'a':
            items = _iter_values(v)
            for i, it in enumerate(pat[1]):
                if it is None:
                    continue
                if it[0] == 'r':
                    self._bind_compiled(it[1], JSArray(items[i:]), sc)
                    break
                self._bind_compiled(it, items[i] if i < len(items) else UNDEF, sc)
        elif k == 'o':
            used = []
            for computed, key, sub in pat[1]:
                if computed == 'rest':
                    o = JSObject(REALM.ObjectProto)
                    if isinstance(v, JSObject):
                        for kk in v.own_keys():
                            if kk not in used:
                                o.put(kk, v.get(kk))
                    self._bind_compiled(sub, o, sc)
                    continue
                if computed:
                    key = to_key(key(sc))
                used.append(key)
                self._bind_compiled(sub, get_prop(v, key), sc)

    def e_assign(self, e, ctx):
        op = e[1]
        target = e[2]
        right = self.expr(e[3], ctx)
        if op == '=':
            hint = target if (e[3][0] == 'func' and target[0] == 'id') else None
            return self._assign_target_fn(target, ctx, value_fn=right, name_hint=hint)
        if op in ('&&=', '||=', '??='):
            getter = self.expr(target, ctx)
            setter = self._assign_target_fn(target, ctx)

            def logical(sc):
                v = getter(sc)
                if op == '&&=':
                    if not to_bool(v):
                        return v
                elif op == '||=':
                    if to_bool(v):
                        return v
                elif v is not UNDEF and v is not None:
                    return v
                nv = right(sc)
                setter(sc, nv)
                return nv
            return logical
        binop = _COMPOUND[op[:-1]]
        k = target[0]
        if k == 'id':
            getter = self.expr(target, ctx)
            setter = self._assign_target_fn(target, ctx)

            def comp_id(sc):
                v = binop(getter(sc), right(sc))
                setter(sc, v)
                return v
            return comp_id
        obj = self.expr(target[1], ctx)
        if k == 'member':
            keyc = target[2]
            keyf = None
        else:
            keyc = None
            keyf = self.expr(target[2], ctx)

        def comp_m(sc):
            o = obj(sc)
            key = keyc if keyf is None else to_key(keyf(sc))
            v = binop(get_prop(o, key), right(sc))
            set_prop(o, key, v)
            return v
        return comp_m

    def e_update(self, e, ctx):
        op = e[1]
        prefix = e[2]
        target = e[3]
        delta = 1 if op == '++' else -1
        k = target[0]
        if k == 'id':
            getter = self.expr(target, ctx)
            setter = self._assign_target_fn(target, ctx)

            def upd_id(sc):
                old = getter(sc)
                if old.__class__ is not int:
                    old = to_num(old)
                new = norm(old + delta)
                setter(sc, new)
                return new if prefix else old
            return upd_id
        obj = self.expr(target[1], ctx)
        if k == 'member':
            keyc = target[2]
            keyf = None
        else:
            keyc = None
            keyf = self.expr(target[2], ctx)

        def upd_m(sc):
            o = obj(sc)
            key = keyc if keyf is None else to_key(keyf(sc))
            old = to_num(get_prop(o, key))
            new = norm(old + delta)
            set_prop(o, key, new)
            return new if prefix else old
        return upd_m

    def e_super(self, e, ctx):
        def run(sc):
            return _home_proto(sc)
        return run

    def e_class(self, e, ctx):
        name, parent_e, members = e[1], e[2], e[3]
        parentf = self.expr(parent_e, ctx) if parent_e is not None else None
        ctor_f = None
        for m in members:
            if m[0] == 'method' and not m[1] and m[2] == 'constructor' and not m[3]:
                ctor_f = m[4]
        cname = name or ''
        if ctor_f is None:
            if parent_e is not None:
                src_body = [('expr', ('call', ('super',), [('spread', ('id', 'arguments'))]))]
            else:
                src_body = []
            ctor_f = P.Func(cname, [], src_body)
        ctor_f.name = cname
        names = set([name]) if name else set()
        cctx = Ctx(names, ctx, is_func=False)
        compiled = []
        fields = []
        for m in members:
            kind, static, key, computed, val = m
            keyf = self.expr(key, cctx) if computed else None
            if kind == 'field':
                vf = self.expr(val, cctx) if val is not None else (lambda sc: UNDEF)
                fields.append((static, key, keyf, vf))
            elif not (kind == 'method' and not static and key == 'constructor' and not computed):
                compiled.append((kind, static, key, keyf, self._func_expr(val, cctx)))
        compiler = self

        def run(sc):
            csc = Scope(sc, sc.this)
            csc.func = sc.func
            parent = parentf(sc) if parentf is not None else None
            ctor = Closure(ctor_f, csc, compiler, cctx)
            ctor.is_ctor_class = True
            if name:
                csc.vars[name] = ctor
            proto = JSObject(REALM.ObjectProto)
            if parent is not None:
                if parent is None or not isinstance(parent, JSFunction):
                    raise throw_error('TypeError', 'Class extends value is not a constructor')
                ctor.parent_class = parent
                pp = parent.get('prototype')
                proto.proto = pp if isinstance(pp, JSObject) else None
                ctor.proto = parent
            proto.define_hidden('constructor', ctor)
            ctor.props['prototype'] = proto
            ctor.hide('prototype')
            for kind, static, key, keyf, ff in compiled:
                target = ctor if static else proto
                k = key if keyf is None else key_str(to_key(keyf(csc)))
                f = ff(csc)
                f.home = target
                if kind == 'method':
                    target.define_hidden(k, f)
                else:
                    cur = target.props.get(k)
                    acc = cur if cur.__class__ is Accessor else Accessor()
                    if kind == 'get':
                        acc.get = f
                    else:
                        acc.set = f
                    target.props[k] = acc
                    target.hide(k)
            inst_fields = [(k, kf, vf) for (st, k, kf, vf) in fields if not st]
            if inst_fields:
                def init_fields(obj):
                    fsc = Scope(csc, obj)
                    for k, kf, vf in inst_fields:
                        kk = k if kf is None else key_str(to_key(kf(csc)))
                        obj.put(kk, vf(fsc))
                ctor.fields = init_fields
            for st, k, kf, vf in fields:
                if st:
                    fsc = Scope(csc, ctor)
                    kk = k if kf is None else key_str(to_key(kf(csc)))
                    ctor.put(kk, vf(fsc))
            return ctor
        return run




class _ShortCircuit(Exception):
    pass


def _home_proto(sc):
    s = sc
    while s is not None:
        f = s.func
        if f is not None and not f.func.arrow and f.home is not None:
            return f.home.proto
        if f is not None and f.is_ctor_class:
            p = f.get('prototype')
            return p.proto if isinstance(p, JSObject) else None
        s = s.parent
    return None


def _describe(e):
    k = e[0]
    if k == 'id':
        return e[1]
    if k == 'member':
        return _describe(e[1]) + '.' + e[2]
    if k == 'index':
        return _describe(e[1]) + '[...]'
    if k == 'this':
        return 'this'
    return 'expression'


def make_js_error(kind, msg):
    try:
        return throw_error(kind, msg).value
    except Exception:
        return msg


def _iter_values(v):
    if v.__class__ is JSArray:
        return list(v.items)
    if v.__class__ is str:
        return list(v)
    if isinstance(v, JSObject):
        it = REALM.iterate(v)
        if it is not None:
            return it
    raise throw_error('TypeError', '%s is not iterable' % typeof(v))


def _bitand(a, b):
    return to_int32(to_int32(a) & to_int32(b))


_COMPOUND = {
    '+': js_add, '-': js_sub, '*': js_mul, '/': js_div, '%': js_mod, '**': js_pow,
    '&': _bitand,
    '|': lambda a, b: to_int32(to_int32(a) | to_int32(b)),
    '^': lambda a, b: to_int32(to_int32(a) ^ to_int32(b)),
    '<<': lambda a, b: to_int32(to_int32(a) << (to_uint32(b) & 31)),
    '>>': lambda a, b: to_int32(a) >> (to_uint32(b) & 31),
    '>>>': lambda a, b: to_uint32(a) >> (to_uint32(b) & 31),
}
