import json
import os
import time

from . import kodi


def _path(name):
    return os.path.join(kodi.profile_dir(), name + '.json')


def load(name, default=None):
    try:
        with open(_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return [] if default is None else default


def save(name, data):
    with open(_path(name), 'w', encoding='utf-8') as f:
        json.dump(data, f)


def push(name, entry, key, limit):
    items = [i for i in load(name) if i.get(key) != entry.get(key)]
    entry['ts'] = int(time.time())
    items.insert(0, entry)
    save(name, items[:limit])


def remove(name, key, value):
    save(name, [i for i in load(name) if i.get(key) != value])


def clear(name):
    save(name, [])


def add_search(query, kind='all'):
    push('searches', {'q': query, 'kind': kind}, 'q', 50)


def add_history(item):
    if kodi.setting_bool('history_enabled'):
        keep = dict((k, item.get(k)) for k in ('id', 'title', 'channel', 'channel_id', 'duration', 'thumb'))
        push('history', keep, 'id', 300)


def channels():
    return load('channels')


def add_channel(cid, title, thumb=''):
    items = [c for c in channels() if c.get('id') != cid]
    items.append({'id': cid, 'title': title, 'thumb': thumb})
    items.sort(key=lambda c: c.get('title', '').lower())
    save('channels', items)


def add_unique(name, value, limit=200):
    items = [v for v in load(name) if v != value]
    items.append(value)
    save(name, items[-limit:])
