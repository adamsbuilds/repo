# Short Fuse [![License](https://img.shields.io/badge/license-CC--NC--SA%204.0-green)](http://creativecommons.org/licenses/by-nc-sa/4.0/)

Short Fuse (`skin.shortfuse`) by adamsbuilds is a fork of [Arctic Fuse 3](https://github.com/jurialmunkey/skin.arctic.fuse.3) by jurialmunkey,
with every TMDb Helper requirement stripped out. Widgets, menus and info screens run on the local library and add-ons,
with add-on content as the main focus. See `changelog.txt` for what was changed and removed.

Everything the skin needs from jurialmunkey's add-ons (script.skinvariables, the colour swatch list from script.texturemaker,
and the script.module.jurialmunkey / script.module.infotagger libraries) is forked into one add-on, script.shortfuse.helper,
served from the adamsbuilds repo.

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Original skin © jurialmunkey; Short Fuse is an independent fork and is not endorsed by the original author.
See `NOTICE.md` for full attribution, the non-commercial terms and third-party font/icon licences.
