# Short Fuse — licence and attribution notice

## The skin
Short Fuse (`skin.shortfuse`) is an adaptation of **Arctic Fuse 3** (`skin.arctic.fuse.3`) by **jurialmunkey**
(https://github.com/jurialmunkey/skin.arctic.fuse.3), forked from upstream commit 907082d (v3.3.12).

The original work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
licence (CC BY-NC-SA 4.0): https://creativecommons.org/licenses/by-nc-sa/4.0/ — see `LICENSE.txt` (upstream notice,
kept unchanged). As required by the ShareAlike term, Short Fuse and all changes made by adamsbuilds are released
under the same CC BY-NC-SA 4.0 licence.

- **Changes:** the skin has been modified. `changelog.txt` describes what was changed, removed and added.
- **No endorsement:** Short Fuse is an independent fork. It is not made, endorsed or supported by jurialmunkey;
  please don't send Short Fuse issues to the original author.
- **Non-commercial:** Short Fuse may not be sold, put behind a paywall, or bundled into paid builds, paid
  subscriptions or devices sold with it pre-installed.
- **New artwork:** `icon.png`, `fanart.jpg` and the profile images in `extras/profiles/` are new artwork made for Short Fuse (CC BY-NC-SA 4.0).

## Required helper
`script.shortfuse.helper` is a separate add-on licensed GPL-3.0-or-later. It contains modified code from
jurialmunkey's script.skinvariables, script.texturemaker, script.module.jurialmunkey and
script.module.infotagger. See its own `NOTICE.md`.

## Third-party material bundled in the skin
| Material | Licence |
|---|---|
| Fonts listed in `fonts/OFL.txt`, and the fonts in `fonts/titles/` with their own `*-OFL.txt` | SIL Open Font License 1.1 |
| `fonts/titles/PermanentMarker.ttf` | Apache License 2.0 (`fonts/titles/PermanentMarker-LICENSE.txt`) |
| `fonts/titles/Turnaround.ttf` (Darrell Flood) | Freeware for personal use; not an open licence — see below |
| Icons in `extras/icons/` derived from Font Awesome Free | CC BY 4.0 — Font Awesome Free by Fonticons, Inc., https://fontawesome.com/license/free |
| Brand, studio, network and rating-service logos (e.g. in `extras/icons/`, `media/flags/`) | Trademarks of their respective owners, used only to identify those services |

**Turnaround:** this inherited title font is free for personal use only and has no open redistribution licence.
It should be replaced with an openly licensed font, or permission obtained from its designer, before wide distribution.
