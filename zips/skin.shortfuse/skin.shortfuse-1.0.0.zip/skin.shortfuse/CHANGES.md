# Short Fuse 1.0.0

Fork of Arctic Fuse 3, based on upstream commit 907082d (v3.3.12). `plugin.video.themoviedb.helper` is no longer a dependency
and nothing in the skin calls it, reads its window properties, or points a widget at it.

## How it was done
- Every `Window(...).Property(TMDbHelper.*)` value written by the TMDbHelper service was treated as
  permanently empty and folded out of all conditions, variables, labels and textures. The skin's own
  "TMDbHelper service disabled" fallbacks (native ListItem art/info) are now the only path.
- The skin's own focus-tracking property `TMDbHelper.WidgetContainer` was renamed `AF3.WidgetContainer`.
- Includes/variables/expressions left unreferenced by the removal were deleted.

## Rewired to native Kodi
- Info dialog Play/Browse: playable items use Kodi's own info-dialog play (`SendClick(8)`, resume aware);
  tvshow/season/set folders close the dialog and open the folder in Videos.
- Info line ratings: IMDb / TMDb / Trakt from `ListItem.Rating(imdb|tmdb|trakt)`, otherwise the
  default `ListItem.Rating` with a star icon (whatever the library scraper or add-on sets).
- Info dialog cast row: Kodi's native cast list (container 50).
- Search window: native search widgets only. Any add-on search can be added as a search widget whose
  path ends in the add-on's query parameter (e.g. `...&query=`); the typed term is appended.
- Widget picker: TMDbHelper sources removed; "Video Add-ons" added at the top level of the picker.
- Stacked widgets: "Stacked Folder" (follows the folder focused in the row above — works with any
  add-on) kept; "Stacked Year" now uses the library (`videodb://.../years/<year>/`).
- OSD info button: opens Wikipedia for the playing title when script.wikipedia is installed.

## Removed (TMDb/Trakt/MDbList data only)
- Next Aired hub (window 1106), TMDb person/cast/crew pages (1113, 1120, 1190, 1193 and person widgets
  in the info dialog), OSD cast panel (1141), episode-ratings heatmap (1127).
- Search discover / decades / keywords / MDbList modes; TMDb search widgets.
- Blurred & cropped artwork (rendered by TMDbHelper): blur options, adaptive dialog background,
  clearlogo cropping. Plain fanart/clearlogo are used instead.
- Trakt watchlist/favourite overlays, Trakt sync button, Trakt history statistics in Settings.
- Online info-dialog rows (recommendations, collections, comments, fanart, trailers lookup, etc.).
- Ratings from RT / Metacritic / MDbList / Letterboxd / MAL, awards, show status, tagline extras.

## Short Fuse 1.0.0 packaging
- Add-on id `skin.shortfuse`, name Short Fuse, provider adamsbuilds (with jurialmunkey credited).
- Requires a single helper, script.shortfuse.helper 1.0.0 (adamsbuilds), which bundles forks of script.skinvariables,
  script.texturemaker's colour swatch list, script.module.jurialmunkey and script.module.infotagger. No jurialmunkey
  add-on IDs are required, so nothing can cross over with his repo. The colour picker swatches are pre-rendered,
  so script.module.pil is not needed either.
- resource.font.robotocjksc is no longer required: the two Inter-Unicode fonts the skin used from it are bundled in fonts/.

## Search providers (Short Fuse addition)
- New "Search provider" option (Settings > Search provider) picks an add-on (FEN, Red Light, Umbrella, POV, Seren, Gears)
  to search alongside the library, using the same per-add-on search paths as Nimbus Plus.
- New search widget rows under the search picker's "Search Provider" group: Movies, TV Shows, Anime, Collections,
  People, Keywords, Trakt Lists (and Umbrella's movie/TV splits). Rows for categories the chosen add-on doesn't
  support stay empty. Movies and TV Shows provider rows are in the default search widgets.
- Providers live in `shortcuts/searchproviders.json`; extra ones can be added in
  `special://profile/addon_data/script.shortfuse.helper/searchproviders.json` without touching the skin.
